# =========================================================================
# 1. Default Unit Setup (Standard units for ETRI 0.5um process)
# =========================================================================
set_units -time ns -capacitance pF -resistance kOhm -voltage V -current uA

# =========================================================================
# 2. Design Rule Constraints (Physical Stability & DRC Margins)
# =========================================================================
# Relaxed transition and capacitance margins for legacy 500nm process nodes
set_max_transition 2.2 [current_design]
set_max_capacitance 1.2 [current_design]
set_max_fanout 10 [current_design]

# =========================================================================
# 3. Clock Constraints
# =========================================================================
# Main system clock definition (Assumed 100MHz, adjust period if necessary)
create_clock -name CLK -period 40.0 [get_ports clk]
set_clock_uncertainty -setup 0.5 [get_clocks CLK]
set_clock_uncertainty -hold 0.1 [get_clocks CLK]

# =========================================================================
# 4. I/O Constraints (Mapped to pong_pt1 top-level ports)
# =========================================================================
# Define input ports excluding the main clock port
set input_ports_no_clk [get_ports {reset enable up down}]

# Assign input delay constraints (approx. 25% of clock period)
set_input_delay -max 1.0 -clock CLK $input_ports_no_clk
set_input_delay -min 0.1 -clock CLK $input_ports_no_clk

# Input driving cell configuration (Verify standard cell name in your target library)
set_driving_cell -lib_cell INVX4 [get_ports {reset enable up down}]
# Define all output ports
set output_ports [get_ports {p_tick hsync vsync rgb}]

# Assign output delay constraints (approx. 30% of clock period)
set_output_delay -max 1.1 -clock CLK $output_ports
set_output_delay -min 0.2 -clock CLK $output_ports

# Output load capacitance (Considering typical output pad load for 0.5um process)
set_load 0.3 $output_ports

# =========================================================================
# 5. Timing Exceptions
# =========================================================================
# 1) Exclude asynchronous reset path from Setup/Hold timing analysis
set_false_path -from [get_ports reset]

# 2) Exclude asynchronous external switch/button inputs from timing analysis
set_false_path -from [get_ports {enable up down}]
