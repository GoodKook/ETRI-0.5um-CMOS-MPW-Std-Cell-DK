// IC Compiler II Version R-2020.09-SP6 Verilog Writer
// Generated on 7/14/2026 at 14:4:19
// Library Name: pong_pt1
// Block Name: pong_pt1_fin
// User Label: 
// Write Command: write_verilog -exclude { physical_only_cells pg_netlist supply_statements } ../VERILOG_pnr/pong_pt1.v
module pong_pt1_DW01_inc_1 ( a , sum ) ;
input  [8:0] a ;
output [8:0] sum ;

wire [8:2] carry ;

HAX1 u1_1_7 ( .A ( a[7] ) , .B ( carry[7] ) , .CO ( carry[8] ) , 
    .S ( sum[7] ) ) ;
HAX1 u1_1_6 ( .A ( a[6] ) , .B ( carry[6] ) , .CO ( carry[7] ) , 
    .S ( sum[6] ) ) ;
HAX1 u1_1_5 ( .A ( a[5] ) , .B ( carry[5] ) , .CO ( carry[6] ) , 
    .S ( sum[5] ) ) ;
HAX1 u1_1_4 ( .A ( a[4] ) , .B ( carry[4] ) , .CO ( carry[5] ) , 
    .S ( sum[4] ) ) ;
HAX1 u1_1_3 ( .A ( a[3] ) , .B ( carry[3] ) , .CO ( carry[4] ) , 
    .S ( sum[3] ) ) ;
HAX1 u1_1_2 ( .A ( a[2] ) , .B ( carry[2] ) , .CO ( carry[3] ) , 
    .S ( sum[2] ) ) ;
HAX1 u1_1_1 ( .A ( a[1] ) , .B ( a[0] ) , .CO ( carry[2] ) , .S ( sum[1] ) ) ;
XOR2X1 u1 ( .A ( carry[8] ) , .B ( a[8] ) , .Y ( sum[8] ) ) ;
INVX1 u2 ( .A ( a[0] ) , .Y ( sum[0] ) ) ;
endmodule


module pong_pt1_DW01_inc_0 ( a , sum ) ;
input  [8:0] a ;
output [8:0] sum ;

wire [8:2] carry ;

HAX1 u1_1_7 ( .A ( a[7] ) , .B ( carry[7] ) , .CO ( carry[8] ) , 
    .S ( sum[7] ) ) ;
HAX1 u1_1_6 ( .A ( a[6] ) , .B ( carry[6] ) , .CO ( carry[7] ) , 
    .S ( sum[6] ) ) ;
HAX1 u1_1_5 ( .A ( a[5] ) , .B ( carry[5] ) , .CO ( carry[6] ) , 
    .S ( sum[5] ) ) ;
HAX1 u1_1_4 ( .A ( a[4] ) , .B ( carry[4] ) , .CO ( carry[5] ) , 
    .S ( sum[4] ) ) ;
HAX1 u1_1_3 ( .A ( a[3] ) , .B ( carry[3] ) , .CO ( carry[4] ) , 
    .S ( sum[3] ) ) ;
HAX1 u1_1_2 ( .A ( a[2] ) , .B ( carry[2] ) , .CO ( carry[3] ) , 
    .S ( sum[2] ) ) ;
HAX1 u1_1_1 ( .A ( a[1] ) , .B ( a[0] ) , .CO ( carry[2] ) , .S ( sum[1] ) ) ;
XOR2X1 u1 ( .A ( carry[8] ) , .B ( a[8] ) , .Y ( sum[8] ) ) ;
INVX1 u2 ( .A ( a[0] ) , .Y ( sum[0] ) ) ;
endmodule


module pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9_DW01_inc_0 ( 
    a , sum ) ;
input  [8:0] a ;
output [8:0] sum ;

wire [8:2] carry ;

HAX1 u1_1_7 ( .A ( a[7] ) , .B ( carry[7] ) , .CO ( carry[8] ) , 
    .S ( sum[7] ) ) ;
HAX1 u1_1_6 ( .A ( a[6] ) , .B ( carry[6] ) , .CO ( carry[7] ) , 
    .S ( sum[6] ) ) ;
HAX1 u1_1_5 ( .A ( a[5] ) , .B ( carry[5] ) , .CO ( carry[6] ) , 
    .S ( sum[5] ) ) ;
HAX1 u1_1_4 ( .A ( a[4] ) , .B ( carry[4] ) , .CO ( carry[5] ) , 
    .S ( sum[4] ) ) ;
HAX1 u1_1_3 ( .A ( a[3] ) , .B ( carry[3] ) , .CO ( carry[4] ) , 
    .S ( sum[3] ) ) ;
HAX1 u1_1_2 ( .A ( a[2] ) , .B ( carry[2] ) , .CO ( carry[3] ) , 
    .S ( sum[2] ) ) ;
HAX1 u1_1_1 ( .A ( a[1] ) , .B ( a[0] ) , .CO ( carry[2] ) , .S ( sum[1] ) ) ;
XOR2X1 u1 ( .A ( carry[8] ) , .B ( a[8] ) , .Y ( sum[8] ) ) ;
INVX1 u2 ( .A ( a[0] ) , .Y ( sum[0] ) ) ;
endmodule


module pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9_DW01_add_2 ( 
    a , b , ci , sum , co ) ;
input  [8:0] a ;
input  [8:0] b ;
input  ci ;
output [8:0] sum ;
output co ;

wire [8:1] carry ;
wire SYNOPSYS_UNCONNECTED_1 ;

FAX1 u1_8 ( .A ( a[8] ) , .B ( b[8] ) , .CI ( carry[8] ) , 
    .CO ( SYNOPSYS_UNCONNECTED_1 ) , .S ( sum[8] ) ) ;
FAX1 u1_7 ( .A ( a[7] ) , .B ( b[7] ) , .CI ( carry[7] ) , .CO ( carry[8] ) , 
    .S ( sum[7] ) ) ;
FAX1 u1_6 ( .A ( a[6] ) , .B ( b[6] ) , .CI ( carry[6] ) , .CO ( carry[7] ) , 
    .S ( sum[6] ) ) ;
FAX1 u1_5 ( .A ( a[5] ) , .B ( b[5] ) , .CI ( carry[5] ) , .CO ( carry[6] ) , 
    .S ( sum[5] ) ) ;
FAX1 u1_4 ( .A ( a[4] ) , .B ( b[4] ) , .CI ( carry[4] ) , .CO ( carry[5] ) , 
    .S ( sum[4] ) ) ;
FAX1 u1_3 ( .A ( a[3] ) , .B ( b[3] ) , .CI ( carry[3] ) , .CO ( carry[4] ) , 
    .S ( sum[3] ) ) ;
FAX1 u1_2 ( .A ( a[2] ) , .B ( b[2] ) , .CI ( carry[2] ) , .CO ( carry[3] ) , 
    .S ( sum[2] ) ) ;
FAX1 u1_1 ( .A ( a[1] ) , .B ( b[1] ) , .CI ( carry[1] ) , .CO ( carry[2] ) , 
    .S ( sum[1] ) ) ;
XOR2X1 u1 ( .A ( b[0] ) , .B ( a[0] ) , .Y ( sum[0] ) ) ;
AND2X1 ctmTdsLR_1_370 ( .A ( a[0] ) , .B ( b[0] ) , .Y ( carry[1] ) ) ;
endmodule


module pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9_DW01_add_1 ( 
    a , b , ci , sum , co ) ;
input  [8:0] a ;
input  [8:0] b ;
input  ci ;
output [8:0] sum ;
output co ;

wire [8:1] carry ;
wire SYNOPSYS_UNCONNECTED_1 ;

FAX1 u1_8 ( .A ( a[8] ) , .B ( b[8] ) , .CI ( carry[8] ) , 
    .CO ( SYNOPSYS_UNCONNECTED_1 ) , .S ( sum[8] ) ) ;
FAX1 u1_7 ( .A ( a[7] ) , .B ( b[7] ) , .CI ( carry[7] ) , .CO ( carry[8] ) , 
    .S ( sum[7] ) ) ;
FAX1 u1_6 ( .A ( a[6] ) , .B ( b[6] ) , .CI ( carry[6] ) , .CO ( carry[7] ) , 
    .S ( sum[6] ) ) ;
FAX1 u1_5 ( .A ( a[5] ) , .B ( b[5] ) , .CI ( carry[5] ) , .CO ( carry[6] ) , 
    .S ( sum[5] ) ) ;
FAX1 u1_4 ( .A ( a[4] ) , .B ( b[4] ) , .CI ( carry[4] ) , .CO ( carry[5] ) , 
    .S ( sum[4] ) ) ;
FAX1 u1_3 ( .A ( a[3] ) , .B ( b[3] ) , .CI ( carry[3] ) , .CO ( carry[4] ) , 
    .S ( sum[3] ) ) ;
FAX1 u1_2 ( .A ( a[2] ) , .B ( b[2] ) , .CI ( carry[2] ) , .CO ( carry[3] ) , 
    .S ( sum[2] ) ) ;
FAX1 u1_1 ( .A ( a[1] ) , .B ( b[1] ) , .CI ( carry[1] ) , .CO ( carry[2] ) , 
    .S ( sum[1] ) ) ;
XOR2X1 u1 ( .A ( b[0] ) , .B ( a[0] ) , .Y ( sum[0] ) ) ;
AND2X1 ctmTdsLR_1_362 ( .A ( a[0] ) , .B ( b[0] ) , .Y ( carry[1] ) ) ;
endmodule


module pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9_DW01_add_0 ( 
    a , b , ci , sum , co ) ;
input  [8:0] a ;
input  [8:0] b ;
input  ci ;
output [8:0] sum ;
output co ;

wire [8:1] carry ;
wire SYNOPSYS_UNCONNECTED_1 ;

FAX1 u1_8 ( .A ( a[8] ) , .B ( b[8] ) , .CI ( carry[8] ) , 
    .CO ( SYNOPSYS_UNCONNECTED_1 ) , .S ( sum[8] ) ) ;
FAX1 u1_7 ( .A ( a[7] ) , .B ( b[7] ) , .CI ( carry[7] ) , .CO ( carry[8] ) , 
    .S ( sum[7] ) ) ;
FAX1 u1_6 ( .A ( a[6] ) , .B ( b[6] ) , .CI ( carry[6] ) , .CO ( carry[7] ) , 
    .S ( sum[6] ) ) ;
FAX1 u1_5 ( .A ( a[5] ) , .B ( b[5] ) , .CI ( carry[5] ) , .CO ( carry[6] ) , 
    .S ( sum[5] ) ) ;
FAX1 u1_4 ( .A ( a[4] ) , .B ( b[4] ) , .CI ( carry[4] ) , .CO ( carry[5] ) , 
    .S ( sum[4] ) ) ;
FAX1 u1_3 ( .A ( a[3] ) , .B ( b[3] ) , .CI ( carry[3] ) , .CO ( carry[4] ) , 
    .S ( sum[3] ) ) ;
FAX1 u1_2 ( .A ( a[2] ) , .B ( b[2] ) , .CI ( carry[2] ) , .CO ( carry[3] ) , 
    .S ( sum[2] ) ) ;
FAX1 u1_1 ( .A ( a[1] ) , .B ( b[1] ) , .CI ( carry[1] ) , .CO ( carry[2] ) , 
    .S ( sum[1] ) ) ;
XOR2X1 u1 ( .A ( b[0] ) , .B ( a[0] ) , .Y ( sum[0] ) ) ;
AND2X1 ctmTdsLR_1_369 ( .A ( a[0] ) , .B ( b[0] ) , .Y ( carry[1] ) ) ;
endmodule


module pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9 ( 
    clk , reset , up , down , video_on , x , y , rgb , cts0 , p0 , p1 , p2 , 
    p3 , p4 , p5 , p6 , p7 , p8 , p14 , p_abuf11 , p9 , p10 , p11 , p12 , 
    p13 , cts1 , p15 , p16 , p17 , p18 , p19 , p20 , p21 , p22 , p23 , p24 , 
    p25 , p26 , p27 , p28 , p29 , p30 ) ;
input  clk ;
input  reset ;
input  up ;
input  down ;
input  video_on ;
input  [8:0] x ;
input  [8:0] y ;
output rgb ;
input  cts0 ;
input  p0 ;
input  p1 ;
input  p2 ;
input  p3 ;
input  p4 ;
input  p5 ;
input  p6 ;
input  p7 ;
input  p8 ;
input  p14 ;
input  p_abuf11 ;
input  p9 ;
input  p10 ;
input  p11 ;
input  p12 ;
input  p13 ;
input  cts1 ;
input  p15 ;
input  p16 ;
input  p17 ;
input  p18 ;
input  p19 ;
input  p20 ;
input  p21 ;
input  p22 ;
input  p23 ;
input  p24 ;
input  p25 ;
input  p26 ;
input  p27 ;
input  p28 ;
input  p29 ;
input  p30 ;

wire n440 ;
wire n510 ;
wire n610 ;
wire n2810 ;
wire n2910 ;
wire n3010 ;
wire gre_a_INV_198_0 ;
wire n3210 ;
wire gre_a_INV_148_0 ;
wire n3410 ;
wire n3510 ;
wire n3610 ;
wire n3810 ;
wire n3910 ;
wire n4010 ;
wire n4110 ;
wire n4210 ;
wire n4310 ;
wire n441 ;
wire n450 ;
wire n460 ;
wire rom_bit ;
wire n620 ;
wire n630 ;
wire n640 ;
wire n650 ;
wire n660 ;
wire n670 ;
wire n680 ;
wire n690 ;
wire n700 ;
wire n720 ;
wire n730 ;
wire n740 ;
wire n750 ;
wire n760 ;
wire n770 ;
wire n780 ;
wire n790 ;
wire n800 ;
wire gre_a_INV_513_0 ;
wire n830 ;
wire n840 ;
wire n850 ;
wire n860 ;
wire n870 ;
wire n880 ;
wire n890 ;
wire n900 ;
wire n910 ;
wire n1490 ;
wire n1500 ;
wire n1510 ;
wire n1520 ;
wire n1530 ;
wire n1540 ;
wire n1550 ;
wire n1560 ;
wire n1570 ;
wire n1580 ;
wire n1590 ;
wire n1600 ;
wire n1610 ;
wire n1620 ;
wire n1630 ;
wire n1640 ;
wire n1650 ;
wire n1660 ;
wire n1670 ;
wire n1680 ;
wire n1690 ;
wire n1700 ;
wire n1710 ;
wire n1720 ;
wire n1730 ;
wire n1740 ;
wire n1750 ;
wire HFSNET_12 ;
wire n205 ;
wire n207 ;
wire n209 ;
wire n211 ;
wire n213 ;
wire n215 ;
wire n217 ;
wire n219 ;
wire n229 ;
wire n232 ;
wire n234 ;
wire n236 ;
wire n238 ;
wire n240 ;
wire n242 ;
wire n244 ;
wire n246 ;
wire n256 ;
wire n258 ;
wire n260 ;
wire n262 ;
wire n264 ;
wire n266 ;
wire n268 ;
wire n270 ;
wire n272 ;
wire n274 ;
wire HFSNET_13 ;
wire n277 ;
wire n278 ;
wire n279 ;
wire n280 ;
wire n281 ;
wire n282 ;
wire n283 ;
wire n284 ;
wire n285 ;
wire n286 ;
wire n287 ;
wire n288 ;
wire n289 ;
wire n290 ;
wire n291 ;
wire n292 ;
wire n293 ;
wire n294 ;
wire sub_158_cf_carry_3_ ;
wire sub_158_cf_carry_4_ ;
wire sub_158_cf_carry_5_ ;
wire sub_158_cf_carry_6_ ;
wire sub_158_cf_carry_7_ ;
wire sub_157_cf_carry_3_ ;
wire sub_157_cf_carry_4_ ;
wire sub_157_cf_carry_5_ ;
wire sub_157_cf_carry_6_ ;
wire sub_157_cf_carry_7_ ;
wire sub_140_cf_carry_4_ ;
wire sub_140_cf_carry_5_ ;
wire sub_140_cf_carry_6_ ;
wire sub_140_cf_carry_7_ ;
wire HFSNET_14 ;
wire HFSNET_16 ;
wire n500 ;
wire n600 ;
wire n7 ;
wire n8 ;
wire n9 ;
wire HFSNET_17 ;
wire n21 ;
wire n23 ;
wire n25 ;
wire n26 ;
wire n27 ;
wire n2811 ;
wire n3000 ;
wire n3100 ;
wire n3200 ;
wire n3400 ;
wire n3500 ;
wire n3600 ;
wire n3800 ;
wire n3900 ;
wire n4000 ;
wire n4100 ;
wire n471 ;
wire n49 ;
wire n501 ;
wire n58 ;
wire n59 ;
wire n601 ;
wire n61 ;
wire n621 ;
wire n641 ;
wire n651 ;
wire n661 ;
wire n671 ;
wire n71 ;
wire n721 ;
wire n741 ;
wire n751 ;
wire n761 ;
wire n771 ;
wire n781 ;
wire n791 ;
wire n801 ;
wire n82_CDR1 ;
wire n831_CDR1 ;
wire n841 ;
wire n851 ;
wire n861 ;
wire n871 ;
wire n881 ;
wire n891 ;
wire n901 ;
wire n911_CDR1 ;
wire n92_CDR1 ;
wire n93 ;
wire n94 ;
wire n95 ;
wire n96 ;
wire n97 ;
wire n98 ;
wire n99_CDR1 ;
wire n100 ;
wire n101 ;
wire n102 ;
wire n103 ;
wire n104 ;
wire n105 ;
wire n106 ;
wire n107 ;
wire n108 ;
wire n109 ;
wire n110 ;
wire n111 ;
wire n112 ;
wire n113 ;
wire n114 ;
wire n115 ;
wire n116 ;
wire n117 ;
wire n118 ;
wire n119 ;
wire n122 ;
wire n123 ;
wire n124 ;
wire n125 ;
wire n126_CDR1 ;
wire n127 ;
wire n128 ;
wire n129 ;
wire n130 ;
wire n131 ;
wire n132 ;
wire n133 ;
wire n136 ;
wire n137 ;
wire n138 ;
wire n139 ;
wire n142 ;
wire n143 ;
wire n144 ;
wire n145 ;
wire n148 ;
wire n1491 ;
wire n1501 ;
wire n1511 ;
wire n1521 ;
wire n1531_CDR1 ;
wire n1541 ;
wire n1551 ;
wire n1561 ;
wire n1571 ;
wire n1581 ;
wire n1591 ;
wire n1601 ;
wire n1611 ;
wire n1621 ;
wire n1631 ;
wire n1641 ;
wire n1651 ;
wire n1661 ;
wire n1671 ;
wire n1701 ;
wire n1711 ;
wire n1721 ;
wire n1731 ;
wire n1741 ;
wire n1751 ;
wire n176 ;
wire n177 ;
wire n178 ;
wire n179 ;
wire n180 ;
wire n181 ;
wire n182 ;
wire n183 ;
wire n184 ;
wire n185 ;
wire n186 ;
wire n187 ;
wire n188 ;
wire n189 ;
wire n190_CDR1 ;
wire n191 ;
wire n192 ;
wire n193 ;
wire n194 ;
wire n195 ;
wire n196 ;
wire n197 ;
wire n198 ;
wire n201 ;
wire n208 ;
wire n210 ;
wire n212_CDR1 ;
wire n214 ;
wire n216 ;
wire n218 ;
wire n220 ;
wire n221_CDR1 ;
wire n222 ;
wire n223 ;
wire n224 ;
wire n225 ;
wire n226_CDR1 ;
wire n227 ;
wire n228 ;
wire n230 ;
wire n231 ;
wire n233 ;
wire n235 ;
wire n237 ;
wire n239 ;
wire n245 ;
wire n247 ;
wire n248 ;
wire n249 ;
wire n250 ;
wire n251 ;
wire n252 ;
wire n253 ;
wire n254 ;
wire n259 ;
wire n261 ;
wire n263 ;
wire n265 ;
wire n267 ;
wire n269 ;
wire n271 ;
wire n273 ;
wire n276 ;
wire n2951 ;
wire n296 ;
wire n297 ;
wire n298 ;
wire n299 ;
wire n3001 ;
wire n301 ;
wire n302 ;
wire n303 ;
wire n304 ;
wire n305 ;
wire n306 ;
wire n307 ;
wire n308 ;
wire n309 ;
wire n3101 ;
wire n311 ;
wire n312 ;
wire n313 ;
wire n314 ;
wire n315 ;
wire n316 ;
wire n317 ;
wire n318 ;
wire n319 ;
wire n321_CDR1 ;
wire n322_CDR1 ;
wire n323_CDR1 ;
wire n324_CDR1 ;
wire n325 ;
wire n326 ;
wire n327 ;
wire n328 ;
wire n329 ;
wire n3301 ;
wire n331 ;
wire n332 ;
wire n333 ;
wire n334 ;
wire n335 ;
wire n336 ;
wire n337 ;
wire n338 ;
wire n339 ;
wire n3401 ;
wire n342_CDR1 ;
wire n343 ;
wire n344_CDR1 ;
wire n345 ;
wire n346 ;
wire n347 ;
wire n348 ;
wire n349 ;
wire n3501 ;
wire n351 ;
wire n352 ;
wire n353 ;
wire n354 ;
wire n355 ;
wire n356 ;
wire n357 ;
wire n3601 ;
wire n361 ;
wire n362 ;
wire n365_CDR1 ;
wire n366 ;
wire n367 ;
wire n368 ;
wire n369 ;
wire n370 ;
wire n371 ;
wire n372 ;
wire n373 ;
wire n374 ;
wire n375 ;
wire n376 ;
wire n377 ;
wire n378 ;
wire n379 ;
wire n3801 ;
wire n381 ;
wire n382 ;
wire n383 ;
wire n384 ;
wire n385 ;
wire n386 ;
wire n387 ;
wire n388 ;
wire n389 ;
wire n3901 ;
wire n391 ;
wire n392 ;
wire n393 ;
wire n394 ;
wire n395 ;
wire n396 ;
wire n397 ;
wire n398 ;
wire n399 ;
wire n4001 ;
wire n401 ;
wire n402 ;
wire n403 ;
wire n404 ;
wire n405 ;
wire n406 ;
wire n407 ;
wire n408 ;
wire n409 ;
wire n4101 ;
wire n411 ;
wire n412 ;
wire n413 ;
wire n414 ;
wire n415 ;
wire n416 ;
wire n417 ;
wire n418 ;
wire n419 ;
wire n4201 ;
wire n421 ;
wire n422 ;
wire n423 ;
wire n424 ;
wire n426_CDR1 ;
wire n427_CDR1 ;
wire n428_CDR1 ;
wire n429_CDR1 ;
wire n4301 ;
wire n431 ;
wire n432_CDR1 ;
wire n433_CDR1 ;
wire n434 ;
wire n435 ;
wire n436 ;
wire n437 ;
wire n438 ;
wire n439 ;
wire [8:0] x_delta_reg ;
wire [8:0] y_delta_reg ;
wire [0:0] rom_data ;
wire [8:0] y_pad_b ;
wire \x_ball_r_CDR1[8] ;
wire \x_ball_r_CDR1[7] ;
wire [5:0] x_ball_r ;
wire [8:1] y_ball_b ;
wire tmp_net33 ;
wire tmp_net34 ;
wire tmp_net35 ;
wire tmp_net36 ;
wire tmp_net37 ;
wire tmp_net39 ;
wire tmp_net40 ;
wire tmp_net41 ;
wire tmp_net42 ;
wire tmp_net43 ;
wire tmp_net44 ;
wire tmp_net45 ;
wire tmp_net46 ;
wire tmp_net47 ;
wire tmp_net48 ;
wire tmp_net49 ;
wire tmp_net50 ;
wire tmp_net51 ;
wire tmp_net52 ;
wire tmp_net53 ;
wire tmp_net54 ;
wire tmp_net55 ;
wire tmp_net56 ;
wire tmp_net57 ;
wire tmp_net58 ;
wire tmp_net60 ;
wire ZBUF_356_0 ;
wire SYNOPSYS_UNCONNECTED_1 ;
wire SYNOPSYS_UNCONNECTED_2 ;
wire SYNOPSYS_UNCONNECTED_3 ;
wire SYNOPSYS_UNCONNECTED_4 ;
wire SYNOPSYS_UNCONNECTED_5 ;
wire SYNOPSYS_UNCONNECTED_6 ;
wire SYNOPSYS_UNCONNECTED_7 ;

DFFSRX1 y_delta_reg_reg_1_ ( .D ( n294 ) , .CLK ( cts1 ) , .R ( p18 ) , 
    .S ( HFSNET_17 ) , .Q ( y_delta_reg[1] ) ) ;
DFFSRX1 x_delta_reg_reg_1_ ( .D ( n286 ) , .CLK ( cts0 ) , .R ( p20 ) , 
    .S ( HFSNET_13 ) , .Q ( x_delta_reg[1] ) ) ;
pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9_DW01_add_0 add_179 (
    .a ( { n1580 , n1590 , n1600 , n1610 , n1620 , n1630 , n1640 , n1650 , 
        n1660 } ) ,
    .b ( x_delta_reg ) , .ci ( SYNOPSYS_UNCONNECTED_1 ) ,
    .sum ( { n910 , n900 , n890 , n880 , n870 , n860 , n850 , n840 , n830 } ) ,
    .co ( SYNOPSYS_UNCONNECTED_2 ) ) ;
pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9_DW01_add_1 add_176 (
    .a ( { n1580 , n1590 , n1600 , n1610 , n1620 , n1630 , n1640 , n1650 , 
        n1660 } ) ,
    .b ( x_delta_reg ) , .ci ( SYNOPSYS_UNCONNECTED_3 ) ,
    .sum ( { n800 , n790 , n780 , n770 , n760 , n750 , n740 , n730 , n720 } ) ,
    .co ( SYNOPSYS_UNCONNECTED_4 ) ) ;
pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9_DW01_add_2 add_169 (
    .a ( { n1670 , n1680 , n1690 , n1700 , n1710 , n1720 , n1730 , n1740 , 
        n1750 } ) ,
    .b ( y_delta_reg ) , .ci ( SYNOPSYS_UNCONNECTED_5 ) ,
    .sum ( { n700 , n690 , n680 , n670 , n660 , n650 , n640 , n630 , n620 } ) ,
    .co ( SYNOPSYS_UNCONNECTED_6 ) ) ;
pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9_DW01_inc_0 add_151 (
    .a ( { n1490 , n1500 , n1510 , n1520 , n1530 , n1540 , n1550 , n1560 , 
        n1570 } ) ,
    .sum ( { n460 , n450 , n441 , n4310 , n4210 , n4110 , n4010 , n3910 , 
        n3810 } ) ) ;
DFFSRX1 y_ball_reg_reg_3_ ( .D ( n242 ) , .CLK ( cts1 ) , .R ( HFSNET_17 ) , 
    .S ( p19 ) , .Q ( n1720 ) ) ;
DFFSRX1 y_ball_reg_reg_2_ ( .D ( n244 ) , .CLK ( clk ) , .R ( HFSNET_17 ) , 
    .S ( p19 ) , .Q ( n1730 ) ) ;
DFFSRX1 y_ball_reg_reg_0_ ( .D ( n258 ) , .CLK ( cts1 ) , .R ( HFSNET_16 ) , 
    .S ( p29 ) , .Q ( n1750 ) ) ;
DFFSRX1 y_ball_reg_reg_1_ ( .D ( n246 ) , .CLK ( cts1 ) , .R ( HFSNET_17 ) , 
    .S ( p18 ) , .Q ( n1740 ) ) ;
DFFSRX1 y_ball_reg_reg_4_ ( .D ( n240 ) , .CLK ( cts1 ) , .R ( HFSNET_16 ) , 
    .S ( p30 ) , .Q ( n1710 ) ) ;
DFFSRX1 y_ball_reg_reg_5_ ( .D ( n238 ) , .CLK ( cts0 ) , .R ( HFSNET_16 ) , 
    .S ( p29 ) , .Q ( n1700 ) ) ;
DFFSRX1 y_delta_reg_reg_0_ ( .D ( n256 ) , .CLK ( cts1 ) , .R ( HFSNET_17 ) , 
    .S ( p16 ) , .Q ( y_delta_reg[0] ) ) ;
DFFSRX1 y_ball_reg_reg_6_ ( .D ( n236 ) , .CLK ( cts0 ) , .R ( HFSNET_16 ) , 
    .S ( p25 ) , .Q ( n1690 ) ) ;
DFFSRX1 y_delta_reg_reg_8_ ( .D ( n287 ) , .CLK ( cts0 ) , .R ( HFSNET_17 ) , 
    .S ( p14 ) , .Q ( y_delta_reg[8] ) ) ;
DFFSRX1 y_delta_reg_reg_7_ ( .D ( n288 ) , .CLK ( cts1 ) , .R ( HFSNET_17 ) , 
    .S ( p14 ) , .Q ( y_delta_reg[7] ) ) ;
DFFSRX1 y_delta_reg_reg_6_ ( .D ( n289 ) , .CLK ( cts0 ) , .R ( HFSNET_17 ) , 
    .S ( p14 ) , .Q ( y_delta_reg[6] ) ) ;
DFFSRX1 y_delta_reg_reg_5_ ( .D ( n290 ) , .CLK ( cts1 ) , .R ( HFSNET_17 ) , 
    .S ( p16 ) , .Q ( y_delta_reg[5] ) ) ;
DFFSRX1 y_delta_reg_reg_4_ ( .D ( n291 ) , .CLK ( cts1 ) , .R ( HFSNET_17 ) , 
    .S ( p16 ) , .Q ( y_delta_reg[4] ) ) ;
DFFSRX1 y_delta_reg_reg_3_ ( .D ( n292 ) , .CLK ( cts1 ) , .R ( HFSNET_17 ) , 
    .S ( p18 ) , .Q ( y_delta_reg[3] ) ) ;
DFFSRX1 y_delta_reg_reg_2_ ( .D ( n293 ) , .CLK ( cts1 ) , .R ( HFSNET_17 ) , 
    .S ( p18 ) , .Q ( y_delta_reg[2] ) ) ;
DFFSRX1 y_ball_reg_reg_7_ ( .D ( n234 ) , .CLK ( cts0 ) , .R ( HFSNET_17 ) , 
    .S ( p14 ) , .Q ( n1680 ) ) ;
DFFSRX1 y_pad_reg_reg_8_ ( .D ( n274 ) , .CLK ( cts1 ) , .R ( HFSNET_16 ) , 
    .S ( p29 ) , .Q ( n1490 ) ) ;
DFFSRX1 y_pad_reg_reg_7_ ( .D ( n272 ) , .CLK ( clk ) , .R ( HFSNET_16 ) , 
    .S ( p26 ) , .Q ( n1500 ) ) ;
DFFSRX1 y_pad_reg_reg_6_ ( .D ( n268 ) , .CLK ( cts1 ) , .R ( HFSNET_16 ) , 
    .S ( p29 ) , .Q ( n1510 ) ) ;
DFFSRX1 y_pad_reg_reg_5_ ( .D ( n266 ) , .CLK ( cts1 ) , .R ( reset ) , 
    .S ( p26 ) , .Q ( n1520 ) ) ;
DFFSRX1 y_pad_reg_reg_4_ ( .D ( n264 ) , .CLK ( cts1 ) , .R ( reset ) , 
    .S ( p26 ) , .Q ( n1530 ) ) ;
DFFSRX1 y_pad_reg_reg_3_ ( .D ( n262 ) , .CLK ( clk ) , .R ( reset ) , 
    .S ( p15 ) , .Q ( n1540 ) ) ;
DFFSRX1 y_pad_reg_reg_2_ ( .D ( n260 ) , .CLK ( clk ) , .R ( reset ) , 
    .S ( p19 ) , .Q ( n1550 ) ) ;
DFFSRX1 y_pad_reg_reg_1_ ( .D ( n270 ) , .CLK ( clk ) , .R ( reset ) , 
    .S ( p15 ) , .Q ( n1560 ) ) ;
DFFSRX1 y_pad_reg_reg_0_ ( .D ( n277 ) , .CLK ( clk ) , .R ( reset ) , 
    .S ( p15 ) , .Q ( n1570 ) ) ;
DFFSRX1 y_ball_reg_reg_8_ ( .D ( n232 ) , .CLK ( cts0 ) , .R ( HFSNET_16 ) , 
    .S ( p24 ) , .Q ( n1670 ) ) ;
DFFSRX1 x_ball_reg_reg_8_ ( .D ( n229 ) , .CLK ( p_abuf11 ) , 
    .R ( HFSNET_14 ) , .S ( p27 ) , .Q ( n1580 ) ) ;
DFFSRX1 x_ball_reg_reg_7_ ( .D ( n219 ) , .CLK ( p_abuf11 ) , .R ( reset ) , 
    .S ( p17 ) , .Q ( n1590 ) ) ;
DFFSRX1 x_ball_reg_reg_6_ ( .D ( n217 ) , .CLK ( p_abuf11 ) , 
    .R ( HFSNET_14 ) , .S ( p28 ) , .Q ( n1600 ) ) ;
DFFSRX1 x_ball_reg_reg_5_ ( .D ( n215 ) , .CLK ( p_abuf11 ) , 
    .R ( HFSNET_14 ) , .S ( p17 ) , .Q ( n1610 ) ) ;
DFFSRX1 x_ball_reg_reg_4_ ( .D ( n213 ) , .CLK ( p_abuf11 ) , 
    .R ( HFSNET_14 ) , .S ( p28 ) , .Q ( n1620 ) ) ;
DFFSRX1 x_ball_reg_reg_3_ ( .D ( n211 ) , .CLK ( cts0 ) , .R ( HFSNET_14 ) , 
    .S ( p28 ) , .Q ( n1630 ) ) ;
DFFSRX1 x_ball_reg_reg_2_ ( .D ( n209 ) , .CLK ( cts0 ) , .R ( HFSNET_14 ) , 
    .S ( p27 ) , .Q ( n1640 ) ) ;
DFFSRX1 x_ball_reg_reg_1_ ( .D ( n207 ) , .CLK ( cts0 ) , .R ( HFSNET_13 ) , 
    .S ( p23 ) , .Q ( n1650 ) ) ;
DFFSRX1 x_ball_reg_reg_0_ ( .D ( n205 ) , .CLK ( cts0 ) , .R ( HFSNET_13 ) , 
    .S ( p23 ) , .Q ( n1660 ) ) ;
DFFSRX1 x_delta_reg_reg_8_ ( .D ( n279 ) , .CLK ( p_abuf11 ) , .R ( reset ) , 
    .S ( p21 ) , .Q ( x_delta_reg[8] ) ) ;
DFFSRX1 x_delta_reg_reg_7_ ( .D ( n280 ) , .CLK ( p_abuf11 ) , .R ( reset ) , 
    .S ( p21 ) , .Q ( x_delta_reg[7] ) ) ;
DFFSRX1 x_delta_reg_reg_6_ ( .D ( n281 ) , .CLK ( p_abuf11 ) , .R ( reset ) , 
    .S ( p22 ) , .Q ( x_delta_reg[6] ) ) ;
DFFSRX1 x_delta_reg_reg_5_ ( .D ( n282 ) , .CLK ( cts0 ) , .R ( HFSNET_13 ) , 
    .S ( p20 ) , .Q ( x_delta_reg[5] ) ) ;
DFFSRX1 x_delta_reg_reg_4_ ( .D ( n283 ) , .CLK ( cts0 ) , .R ( HFSNET_13 ) , 
    .S ( p20 ) , .Q ( x_delta_reg[4] ) ) ;
DFFSRX1 x_delta_reg_reg_3_ ( .D ( n284 ) , .CLK ( p_abuf11 ) , 
    .R ( HFSNET_13 ) , .S ( p21 ) , .Q ( x_delta_reg[3] ) ) ;
DFFSRX1 x_delta_reg_reg_2_ ( .D ( n285 ) , .CLK ( cts0 ) , .R ( HFSNET_13 ) , 
    .S ( p20 ) , .Q ( x_delta_reg[2] ) ) ;
DFFSRX1 x_delta_reg_reg_0_ ( .D ( n278 ) , .CLK ( cts0 ) , .R ( HFSNET_13 ) , 
    .S ( p23 ) , .Q ( x_delta_reg[0] ) ) ;
XNOR2X1 ctmTdsLR_1_333 ( .A ( n21 ) , .B ( n1560 ) , .Y ( n148 ) ) ;
BUFX2 HFSBUF_1973_205 ( .A ( reset ) , .Y ( HFSNET_13 ) ) ;
BUFX2 HFSBUF_1526_206 ( .A ( reset ) , .Y ( HFSNET_14 ) ) ;
NOR2X1 ctmTdsLR_1_334 ( .A ( tmp_net33 ) , .B ( n1560 ) , .Y ( n23 ) ) ;
NAND2X1 ctmTdsLR_1_414 ( .A ( n315 ) , .B ( n276 ) , .Y ( n306 ) ) ;
BUFX2 ZBUF_356_inst_417 ( .A ( n416 ) , .Y ( ZBUF_356_0 ) ) ;
INVX1 u9 ( .A ( n389 ) , .Y ( n600 ) ) ;
INVX2 u10 ( .A ( n600 ) , .Y ( n7 ) ) ;
INVX2 u11 ( .A ( n600 ) , .Y ( n8 ) ) ;
INVX1 u12 ( .A ( n600 ) , .Y ( n9 ) ) ;
BUFX2 HFSBUF_709_211 ( .A ( HFSNET_17 ) , .Y ( HFSNET_16 ) ) ;
BUFX4 HFSBUF_1312_212 ( .A ( reset ) , .Y ( HFSNET_17 ) ) ;
INVX1 ctmTdsLR_2_335 ( .A ( n21 ) , .Y ( tmp_net33 ) ) ;
NOR2X1 ctmTdsLR_1_336 ( .A ( tmp_net34 ) , .B ( n1550 ) , .Y ( n25 ) ) ;
INVX1 ctmTdsLR_2_337 ( .A ( n23 ) , .Y ( tmp_net34 ) ) ;
TIELOX1 u18 ( .Y ( SYNOPSYS_UNCONNECTED_7 ) ) ;
INVX1 u19 ( .A ( n1570 ) , .Y ( y_pad_b[0] ) ) ;
XNOR2X1 ctmTdsLR_1_354 ( .A ( sub_158_cf_carry_3_ ) , .B ( n1720 ) , 
    .Y ( n259 ) ) ;
XNOR2X1 ctmTdsLR_1_355 ( .A ( sub_157_cf_carry_3_ ) , .B ( n1630 ) , 
    .Y ( n226_CDR1 ) ) ;
XOR2X1 u22 ( .A ( sub_140_cf_carry_4_ ) , .B ( n1530 ) , .Y ( y_pad_b[4] ) ) ;
XNOR2X1 ctmTdsLR_1_361 ( .A ( sub_140_cf_carry_5_ ) , .B ( n1520 ) , 
    .Y ( n136 ) ) ;
XNOR2X1 ctmTdsLR_1_363 ( .A ( sub_157_cf_carry_4_ ) , .B ( n1620 ) , 
    .Y ( n221_CDR1 ) ) ;
AND2X1 ctmTdsLR_1_364 ( .A ( sub_140_cf_carry_6_ ) , .B ( n1510 ) , 
    .Y ( sub_140_cf_carry_7_ ) ) ;
XNOR2X1 ctmTdsLR_1_379 ( .A ( sub_157_cf_carry_6_ ) , .B ( n1600 ) , 
    .Y ( n212_CDR1 ) ) ;
AND2X1 ctmTdsLR_1_372 ( .A ( sub_157_cf_carry_5_ ) , .B ( n1610 ) , 
    .Y ( sub_157_cf_carry_6_ ) ) ;
XOR2X1 u28 ( .A ( n1510 ) , .B ( sub_140_cf_carry_6_ ) , .Y ( y_pad_b[6] ) ) ;
XNOR2X1 ctmTdsLR_1_376 ( .A ( sub_158_cf_carry_5_ ) , .B ( n1700 ) , 
    .Y ( n251 ) ) ;
XNOR2X1 ctmTdsLR_1_377 ( .A ( tmp_net45 ) , .B ( n1490 ) , .Y ( y_pad_b[8] ) ) ;
XOR2X1 u31 ( .A ( n1500 ) , .B ( sub_140_cf_carry_7_ ) , .Y ( y_pad_b[7] ) ) ;
OR2X1 ctmTdsLR_1_380 ( .A ( n2811 ) , .B ( n1550 ) , .Y ( n3200 ) ) ;
INVX1 u33 ( .A ( n1570 ) , .Y ( n21 ) ) ;
OAI22X1 ctmTdsLR_1_338 ( .A ( n1740 ) , .B ( n362 ) , .C ( tmp_net35 ) , 
    .D ( n148 ) , .Y ( n3601 ) ) ;
AND2X1 ctmTdsLR_2_339 ( .A ( n362 ) , .B ( n1740 ) , .Y ( tmp_net35 ) ) ;
OAI22X1 ctmTdsLR_1_340 ( .A ( y[1] ) , .B ( n145 ) , .C ( tmp_net36 ) , 
    .D ( n148 ) , .Y ( n143 ) ) ;
AND2X2 ctmTdsLR_2_341 ( .A ( n145 ) , .B ( y[1] ) , .Y ( tmp_net36 ) ) ;
XNOR2X1 ctmTdsLR_1_342 ( .A ( n25 ) , .B ( n1540 ) , .Y ( n142 ) ) ;
XOR2X1 u39 ( .A ( n23 ) , .B ( n1550 ) , .Y ( y_pad_b[2] ) ) ;
NOR2X1 ctmTdsLR_1_343 ( .A ( tmp_net37 ) , .B ( n1650 ) , .Y ( n49 ) ) ;
INVX1 ctmTdsLR_2_344 ( .A ( n471 ) , .Y ( tmp_net37 ) ) ;
INVX1 u42 ( .A ( n1540 ) , .Y ( n26 ) ) ;
NOR2X1 ctmTdsLR_1_345 ( .A ( n1750 ) , .B ( n1740 ) , .Y ( n58 ) ) ;
NAND2X1 u44 ( .A ( n25 ) , .B ( n26 ) , .Y ( sub_140_cf_carry_4_ ) ) ;
INVX1 u45 ( .A ( n1570 ) , .Y ( n2810 ) ) ;
INVX1 u46 ( .A ( n1560 ) , .Y ( n27 ) ) ;
NOR2X1 u47 ( .A ( n1560 ) , .B ( n1570 ) , .Y ( n3100 ) ) ;
INVX1 u48 ( .A ( n3100 ) , .Y ( n2811 ) ) ;
OAI21X1 u49 ( .A ( n27 ) , .B ( n2810 ) , .C ( n2811 ) , .Y ( n2910 ) ) ;
INVX1 u50 ( .A ( n1550 ) , .Y ( n3000 ) ) ;
AOI21X1 ctmTdsLR_1_391 ( .A ( y[7] ) , .B ( n245 ) , .C ( tmp_net50 ) , 
    .Y ( n239 ) ) ;
NOR2X1 ctmTdsLR_2_392 ( .A ( tmp_net49 ) , .B ( y_ball_b[7] ) , 
    .Y ( tmp_net50 ) ) ;
OAI21X1 u53 ( .A ( n3100 ) , .B ( n3000 ) , .C ( n3200 ) , .Y ( n3010 ) ) ;
NOR2X1 u54 ( .A ( n3200 ) , .B ( n1540 ) , .Y ( n3500 ) ) ;
NOR3X1 ctmTdsLR_1_408 ( .A ( n433_CDR1 ) , .B ( y[1] ) , .C ( y[2] ) , 
    .Y ( tmp_net58 ) ) ;
AOI21X1 ctmTdsLR_1_410 ( .A ( n82_CDR1 ) , .B ( n208 ) , 
    .C ( \x_ball_r_CDR1[7] ) , .Y ( tmp_net52 ) ) ;
INVX1 u57 ( .A ( n1530 ) , .Y ( n3400 ) ) ;
NAND2X1 u58 ( .A ( n3500 ) , .B ( n3400 ) , .Y ( n3600 ) ) ;
OAI21X1 u59 ( .A ( n3400 ) , .B ( n3500 ) , .C ( n3600 ) , .Y ( n3210 ) ) ;
NOR2X1 u60 ( .A ( n3600 ) , .B ( n1520 ) , .Y ( n3900 ) ) ;
XOR2X1 ctmTdsLR_1_411 ( .A ( n721 ) , .B ( n71 ) , .Y ( tmp_net51 ) ) ;
AND2X1 ctmTdsLR_1_412 ( .A ( n1640 ) , .B ( n1660 ) , .Y ( tmp_net60 ) ) ;
INVX1 u63 ( .A ( n1510 ) , .Y ( n3800 ) ) ;
NAND2X1 u64 ( .A ( n3900 ) , .B ( n3800 ) , .Y ( n4000 ) ) ;
OAI21X1 u65 ( .A ( n3800 ) , .B ( n3900 ) , .C ( n4000 ) , .Y ( n3410 ) ) ;
XNOR2X1 u66 ( .A ( n4000 ) , .B ( n1500 ) , .Y ( n3510 ) ) ;
NOR2X1 u67 ( .A ( n4000 ) , .B ( n1500 ) , .Y ( n4100 ) ) ;
XOR2X1 u68 ( .A ( n4100 ) , .B ( n1490 ) , .Y ( n3610 ) ) ;
INVX1 u69 ( .A ( n1660 ) , .Y ( x_ball_r[0] ) ) ;
AND2X1 ctmTdsLR_1_365 ( .A ( sub_157_cf_carry_4_ ) , .B ( n1620 ) , 
    .Y ( sub_157_cf_carry_5_ ) ) ;
AND2X1 ctmTdsLR_1_366 ( .A ( sub_158_cf_carry_4_ ) , .B ( n1710 ) , 
    .Y ( sub_158_cf_carry_5_ ) ) ;
AND2X1 ctmTdsLR_1_358 ( .A ( sub_140_cf_carry_5_ ) , .B ( n1520 ) , 
    .Y ( sub_140_cf_carry_6_ ) ) ;
AND2X1 ctmTdsLR_1_373 ( .A ( sub_158_cf_carry_5_ ) , .B ( n1700 ) , 
    .Y ( sub_158_cf_carry_6_ ) ) ;
OAI22X1 ctmTdsLR_1_374 ( .A ( y[5] ) , .B ( n133 ) , .C ( tmp_net44 ) , 
    .D ( n136 ) , .Y ( n131 ) ) ;
AND2X1 ctmTdsLR_2_375 ( .A ( n133 ) , .B ( y[5] ) , .Y ( tmp_net44 ) ) ;
NAND2X1 ctmTdsLR_2_378 ( .A ( sub_140_cf_carry_7_ ) , .B ( n1500 ) , 
    .Y ( tmp_net45 ) ) ;
AND2X1 ctmTdsLR_1_381 ( .A ( sub_157_cf_carry_6_ ) , .B ( n1600 ) , 
    .Y ( sub_157_cf_carry_7_ ) ) ;
XOR2X1 u78 ( .A ( sub_157_cf_carry_5_ ) , .B ( n1610 ) , .Y ( x_ball_r[5] ) ) ;
XNOR2X1 ctmTdsLR_1_387 ( .A ( tmp_net47 ) , .B ( n1580 ) , 
    .Y ( \x_ball_r_CDR1[8] ) ) ;
NAND2X1 ctmTdsLR_2_388 ( .A ( sub_157_cf_carry_7_ ) , .B ( n1590 ) , 
    .Y ( tmp_net47 ) ) ;
XNOR2X1 ctmTdsLR_1_389 ( .A ( tmp_net48 ) , .B ( n1670 ) , 
    .Y ( y_ball_b[8] ) ) ;
NAND2X1 ctmTdsLR_2_390 ( .A ( sub_158_cf_carry_7_ ) , .B ( n1680 ) , 
    .Y ( tmp_net48 ) ) ;
NOR2X1 ctmTdsLR_3_393 ( .A ( n245 ) , .B ( y[7] ) , .Y ( tmp_net49 ) ) ;
XOR2X1 u84 ( .A ( n1590 ) , .B ( sub_157_cf_carry_7_ ) , 
    .Y ( \x_ball_r_CDR1[7] ) ) ;
AOI21X1 ctmTdsLR_1_394 ( .A ( n621 ) , .B ( tmp_net51 ) , .C ( rom_data[0] ) , 
    .Y ( n601 ) ) ;
INVX1 u86 ( .A ( n1660 ) , .Y ( n471 ) ) ;
AND2X2 ctmTdsLR_1_351 ( .A ( sub_140_cf_carry_4_ ) , .B ( n1530 ) , 
    .Y ( sub_140_cf_carry_5_ ) ) ;
XOR2X1 u88 ( .A ( n471 ) , .B ( n1650 ) , .Y ( x_ball_r[1] ) ) ;
OAI22X1 ctmTdsLR_1_352 ( .A ( n1720 ) , .B ( n357 ) , .C ( tmp_net41 ) , 
    .D ( n142 ) , .Y ( n355 ) ) ;
AND2X1 ctmTdsLR_2_353 ( .A ( n357 ) , .B ( n1720 ) , .Y ( tmp_net41 ) ) ;
INVX1 u91 ( .A ( n1640 ) , .Y ( n501 ) ) ;
XOR2X1 u92 ( .A ( n49 ) , .B ( n1640 ) , .Y ( x_ball_r[2] ) ) ;
NAND2X1 u93 ( .A ( n501 ) , .B ( n49 ) , .Y ( sub_157_cf_carry_3_ ) ) ;
OAI22X1 ctmTdsLR_1_367 ( .A ( y[3] ) , .B ( n254 ) , .C ( tmp_net43 ) , 
    .D ( n259 ) , .Y ( n252 ) ) ;
AND2X2 ctmTdsLR_2_368 ( .A ( n254 ) , .B ( y[3] ) , .Y ( tmp_net43 ) ) ;
AND2X1 ctmTdsLR_1_359 ( .A ( sub_157_cf_carry_3_ ) , .B ( n1630 ) , 
    .Y ( sub_157_cf_carry_4_ ) ) ;
AND2X1 ctmTdsLR_1_382 ( .A ( sub_158_cf_carry_6_ ) , .B ( n1690 ) , 
    .Y ( sub_158_cf_carry_7_ ) ) ;
OAI22X1 ctmTdsLR_1_383 ( .A ( n1610 ) , .B ( n1671 ) , .C ( tmp_net46 ) , 
    .D ( n901 ) , .Y ( n1641 ) ) ;
XOR2X1 u100 ( .A ( sub_158_cf_carry_4_ ) , .B ( n1710 ) , .Y ( y_ball_b[4] ) ) ;
AND2X2 ctmTdsLR_2_384 ( .A ( n1671 ) , .B ( n1610 ) , .Y ( tmp_net46 ) ) ;
BUFX2 ctmTdsLR_1_413 ( .A ( n371 ) , .Y ( n500 ) ) ;
XNOR2X1 ctmTdsLR_3_396 ( .A ( n751 ) , .B ( n761 ) , .Y ( rom_data[0] ) ) ;
XNOR2X1 ctmTdsLR_1_397 ( .A ( n610 ) , .B ( n510 ) , .Y ( n61 ) ) ;
AOI21X1 ctmTdsLR_1_398 ( .A ( n831_CDR1 ) , .B ( \x_ball_r_CDR1[8] ) , 
    .C ( tmp_net54 ) , .Y ( n1561 ) ) ;
XOR2X1 u106 ( .A ( n1690 ) , .B ( sub_158_cf_carry_6_ ) , .Y ( y_ball_b[6] ) ) ;
NOR2X1 ctmTdsLR_2_399 ( .A ( tmp_net52 ) , .B ( tmp_net53 ) , 
    .Y ( tmp_net54 ) ) ;
INVX1 gre_a_INV_198_inst_464 ( .A ( n1750 ) , .Y ( gre_a_INV_198_0 ) ) ;
XOR2X1 u109 ( .A ( n1680 ) , .B ( sub_158_cf_carry_7_ ) , .Y ( y_ball_b[7] ) ) ;
OAI22X1 ctmTdsLR_4_401 ( .A ( n82_CDR1 ) , .B ( n208 ) , 
    .C ( \x_ball_r_CDR1[8] ) , .D ( n831_CDR1 ) , .Y ( tmp_net53 ) ) ;
OAI22X1 ctmTdsLR_1_356 ( .A ( y[3] ) , .B ( n139 ) , .C ( tmp_net42 ) , 
    .D ( n142 ) , .Y ( n137 ) ) ;
XOR2X1 u113 ( .A ( gre_a_INV_198_0 ) , .B ( n1740 ) , .Y ( y_ball_b[1] ) ) ;
AND2X2 ctmTdsLR_2_357 ( .A ( n139 ) , .B ( y[3] ) , .Y ( tmp_net42 ) ) ;
AND2X1 ctmTdsLR_1_360 ( .A ( sub_158_cf_carry_3_ ) , .B ( n1720 ) , 
    .Y ( sub_158_cf_carry_4_ ) ) ;
INVX1 u116 ( .A ( n1730 ) , .Y ( n59 ) ) ;
XOR2X1 u117 ( .A ( n58 ) , .B ( n1730 ) , .Y ( y_ball_b[2] ) ) ;
NAND2X1 u118 ( .A ( n58 ) , .B ( n59 ) , .Y ( sub_158_cf_carry_3_ ) ) ;
NAND2X1 u119 ( .A ( n601 ) , .B ( n61 ) , .Y ( rom_bit ) ) ;
XOR2X1 u120 ( .A ( n610 ) , .B ( n440 ) , .Y ( n621 ) ) ;
NOR3X1 ctmTdsLR_1_402 ( .A ( n800 ) , .B ( tmp_net55 ) , .C ( n9 ) , 
    .Y ( n416 ) ) ;
AND2X1 ctmTdsLR_2_403 ( .A ( n790 ) , .B ( n671 ) , .Y ( tmp_net55 ) ) ;
OAI21X1 ctmTdsLR_1_404 ( .A ( n3900 ) , .B ( tmp_net56 ) , .C ( n369 ) , 
    .Y ( n381 ) ) ;
NOR2X1 u124 ( .A ( n760 ) , .B ( n750 ) , .Y ( n661 ) ) ;
NOR2X1 u125 ( .A ( n780 ) , .B ( n770 ) , .Y ( n651 ) ) ;
NOR3X1 u126 ( .A ( n720 ) , .B ( n740 ) , .C ( n730 ) , .Y ( n641 ) ) ;
NAND3X1 u127 ( .A ( n661 ) , .B ( n651 ) , .C ( n641 ) , .Y ( n671 ) ) ;
AND2X2 ctmTdsLR_2_405 ( .A ( n3600 ) , .B ( n1520 ) , .Y ( tmp_net56 ) ) ;
OAI21X1 ctmTdsLR_1_406 ( .A ( n3500 ) , .B ( tmp_net57 ) , .C ( n369 ) , 
    .Y ( n385 ) ) ;
AND2X2 ctmTdsLR_2_407 ( .A ( n3200 ) , .B ( n1540 ) , .Y ( tmp_net57 ) ) ;
INVX1 gre_a_INV_148_inst_465 ( .A ( n1750 ) , .Y ( gre_a_INV_148_0 ) ) ;
AOI21X1 u132 ( .A ( y[0] ) , .B ( gre_a_INV_513_0 ) , .C ( n741 ) , 
    .Y ( n71 ) ) ;
INVX1 gre_a_INV_513_inst_466 ( .A ( n1750 ) , .Y ( gre_a_INV_513_0 ) ) ;
XOR2X1 u135 ( .A ( y[1] ) , .B ( n1740 ) , .Y ( n761 ) ) ;
XOR2X1 u136 ( .A ( n721 ) , .B ( n741 ) , .Y ( n751 ) ) ;
XNOR2X1 u137 ( .A ( n771 ) , .B ( n781 ) , .Y ( n721 ) ) ;
XOR2X1 u138 ( .A ( y[2] ) , .B ( n1730 ) , .Y ( n781 ) ) ;
AOI21X1 u139 ( .A ( n801 ) , .B ( n791 ) , .C ( video_on ) , .Y ( rgb ) ) ;
NAND3X1 u141 ( .A ( n82_CDR1 ) , .B ( n831_CDR1 ) , .C ( n841 ) , 
    .Y ( n801 ) ) ;
MUX2X1 u142 ( .B ( n851 ) , .A ( n861 ) , .S ( x[6] ) , .Y ( n841 ) ) ;
NAND3X1 u143 ( .A ( n871 ) , .B ( n881 ) , .C ( n891 ) , .Y ( n861 ) ) ;
NOR3X1 u144 ( .A ( n901 ) , .B ( n911_CDR1 ) , .C ( n92_CDR1 ) , .Y ( n891 ) ) ;
AOI22X1 u145 ( .A ( x[0] ) , .B ( n93 ) , .C ( n94 ) , .D ( n95 ) , 
    .Y ( n881 ) ) ;
OAI21X1 u146 ( .A ( y[8] ) , .B ( n96 ) , .C ( n97 ) , .Y ( n95 ) ) ;
AOI22X1 u147 ( .A ( n98 ) , .B ( n99_CDR1 ) , .C ( n1500 ) , .D ( n100 ) , 
    .Y ( n97 ) ) ;
INVX1 u148 ( .A ( n101 ) , .Y ( n100 ) ) ;
NAND2X1 u149 ( .A ( n101 ) , .B ( n102 ) , .Y ( n98 ) ) ;
AOI22X1 u150 ( .A ( n103 ) , .B ( n1510 ) , .C ( n104 ) , .D ( n105 ) , 
    .Y ( n101 ) ) ;
OR2X1 u151 ( .A ( n103 ) , .B ( n1510 ) , .Y ( n105 ) ) ;
AOI22X1 u152 ( .A ( n106 ) , .B ( n107 ) , .C ( n108 ) , .D ( y[5] ) , 
    .Y ( n103 ) ) ;
OR2X2 u153 ( .A ( n107 ) , .B ( n106 ) , .Y ( n108 ) ) ;
AOI22X1 u154 ( .A ( n1530 ) , .B ( n109 ) , .C ( n111 ) , .D ( n110 ) , 
    .Y ( n107 ) ) ;
OR2X1 u155 ( .A ( n109 ) , .B ( n1530 ) , .Y ( n111 ) ) ;
AOI22X1 u156 ( .A ( n112 ) , .B ( n113 ) , .C ( n114 ) , .D ( y[3] ) , 
    .Y ( n109 ) ) ;
OR2X1 u157 ( .A ( n113 ) , .B ( n112 ) , .Y ( n114 ) ) ;
AOI22X1 u158 ( .A ( n1550 ) , .B ( n115 ) , .C ( n117 ) , .D ( n116 ) , 
    .Y ( n113 ) ) ;
OR2X1 u159 ( .A ( n115 ) , .B ( n1550 ) , .Y ( n117 ) ) ;
NAND2X1 u163 ( .A ( n1570 ) , .B ( n122 ) , .Y ( n119 ) ) ;
NAND2X1 u164 ( .A ( y[8] ) , .B ( n96 ) , .Y ( n94 ) ) ;
AOI21X1 u165 ( .A ( n123 ) , .B ( n124 ) , .C ( n125 ) , .Y ( n871 ) ) ;
OAI21X1 u166 ( .A ( y_pad_b[8] ) , .B ( n126_CDR1 ) , .C ( n127 ) , 
    .Y ( n124 ) ) ;
AOI22X1 u167 ( .A ( n128 ) , .B ( n129 ) , .C ( y[7] ) , .D ( n130 ) , 
    .Y ( n127 ) ) ;
OR2X1 u168 ( .A ( n130 ) , .B ( y[7] ) , .Y ( n128 ) ) ;
OAI22X1 u169 ( .A ( n104 ) , .B ( n131 ) , .C ( n132 ) , .D ( y_pad_b[6] ) , 
    .Y ( n130 ) ) ;
AND2X1 u170 ( .A ( n131 ) , .B ( n104 ) , .Y ( n132 ) ) ;
OAI22X1 u174 ( .A ( n110 ) , .B ( n137 ) , .C ( n138 ) , .D ( y_pad_b[4] ) , 
    .Y ( n133 ) ) ;
AND2X1 u175 ( .A ( n137 ) , .B ( n110 ) , .Y ( n138 ) ) ;
OAI22X1 u179 ( .A ( n116 ) , .B ( n143 ) , .C ( n144 ) , .D ( y_pad_b[2] ) , 
    .Y ( n139 ) ) ;
AND2X1 u180 ( .A ( n143 ) , .B ( n116 ) , .Y ( n144 ) ) ;
AOI22X1 ctmTdsLR_1_347 ( .A ( y[1] ) , .B ( tmp_net39 ) , .C ( n119 ) , 
    .D ( n118 ) , .Y ( n115 ) ) ;
OR2X2 ctmTdsLR_2_348 ( .A ( n119 ) , .B ( n118 ) , .Y ( tmp_net39 ) ) ;
NOR2X1 u184 ( .A ( n122 ) , .B ( y_pad_b[0] ) , .Y ( n145 ) ) ;
NAND2X1 u185 ( .A ( y_pad_b[8] ) , .B ( n126_CDR1 ) , .Y ( n123 ) ) ;
NAND3X1 u186 ( .A ( n92_CDR1 ) , .B ( n901 ) , .C ( n1491 ) , .Y ( n851 ) ) ;
MUX2X1 u187 ( .B ( n911_CDR1 ) , .A ( n1501 ) , .S ( n93 ) , .Y ( n1491 ) ) ;
NOR2X1 u188 ( .A ( n1521 ) , .B ( n1511 ) , .Y ( n93 ) ) ;
NOR2X1 u189 ( .A ( n1531_CDR1 ) , .B ( n911_CDR1 ) , .Y ( n1501 ) ) ;
NAND3X1 u190 ( .A ( rom_bit ) , .B ( n1541 ) , .C ( n1551 ) , .Y ( n791 ) ) ;
NOR3X1 u191 ( .A ( n1571 ) , .B ( n1561 ) , .C ( n1581 ) , .Y ( n1551 ) ) ;
AOI22X1 u192 ( .A ( x[8] ) , .B ( n1611 ) , .C ( n1591 ) , .D ( n1601 ) , 
    .Y ( n1581 ) ) ;
INVX1 u193 ( .A ( n1580 ) , .Y ( n1611 ) ) ;
NAND2X1 u194 ( .A ( n1580 ) , .B ( n831_CDR1 ) , .Y ( n1601 ) ) ;
AOI22X1 u195 ( .A ( n1621 ) , .B ( n82_CDR1 ) , .C ( n1590 ) , .D ( n1631 ) , 
    .Y ( n1591 ) ) ;
OR2X1 u196 ( .A ( n1631 ) , .B ( n1590 ) , .Y ( n1621 ) ) ;
OAI22X1 u197 ( .A ( n1651 ) , .B ( n1641 ) , .C ( n1661 ) , .D ( x[6] ) , 
    .Y ( n1631 ) ) ;
AND2X1 u198 ( .A ( n1641 ) , .B ( n1651 ) , .Y ( n1661 ) ) ;
INVX1 u199 ( .A ( n1600 ) , .Y ( n1651 ) ) ;
OAI22X1 u203 ( .A ( n1711 ) , .B ( n1701 ) , .C ( n1721 ) , .D ( x[4] ) , 
    .Y ( n1671 ) ) ;
AND2X1 u204 ( .A ( n1701 ) , .B ( n1711 ) , .Y ( n1721 ) ) ;
INVX1 u205 ( .A ( n1620 ) , .Y ( n1711 ) ) ;
OAI22X1 u206 ( .A ( n1630 ) , .B ( n1731 ) , .C ( n1741 ) , .D ( n911_CDR1 ) , 
    .Y ( n1701 ) ) ;
AND2X1 u207 ( .A ( n1731 ) , .B ( n1630 ) , .Y ( n1741 ) ) ;
OAI22X1 u208 ( .A ( n176 ) , .B ( n1751 ) , .C ( n177 ) , .D ( x[2] ) , 
    .Y ( n1731 ) ) ;
AND2X1 u209 ( .A ( n1751 ) , .B ( n176 ) , .Y ( n177 ) ) ;
INVX1 u210 ( .A ( n1640 ) , .Y ( n176 ) ) ;
AOI22X1 u211 ( .A ( n178 ) , .B ( n179 ) , .C ( y[8] ) , .D ( n180 ) , 
    .Y ( n1571 ) ) ;
NAND2X1 u212 ( .A ( n1670 ) , .B ( n126_CDR1 ) , .Y ( n179 ) ) ;
AOI22X1 u213 ( .A ( n181 ) , .B ( n99_CDR1 ) , .C ( n1680 ) , .D ( n182 ) , 
    .Y ( n178 ) ) ;
OR2X1 u214 ( .A ( n182 ) , .B ( n1680 ) , .Y ( n181 ) ) ;
INVX1 u215 ( .A ( n183 ) , .Y ( n182 ) ) ;
AOI22X1 u216 ( .A ( n184 ) , .B ( n1690 ) , .C ( n104 ) , .D ( n185 ) , 
    .Y ( n183 ) ) ;
OR2X1 u217 ( .A ( n184 ) , .B ( n1690 ) , .Y ( n185 ) ) ;
AOI21X1 u218 ( .A ( n186 ) , .B ( n187 ) , .C ( n188 ) , .Y ( n184 ) ) ;
AOI21X1 u219 ( .A ( n189 ) , .B ( n1700 ) , .C ( n190_CDR1 ) , .Y ( n188 ) ) ;
INVX1 u220 ( .A ( n187 ) , .Y ( n189 ) ) ;
AOI22X1 u221 ( .A ( n1710 ) , .B ( n191 ) , .C ( n192 ) , .D ( n110 ) , 
    .Y ( n187 ) ) ;
OR2X1 u222 ( .A ( n191 ) , .B ( n1710 ) , .Y ( n192 ) ) ;
AOI22X1 u223 ( .A ( n193 ) , .B ( n194 ) , .C ( n195 ) , .D ( y[3] ) , 
    .Y ( n191 ) ) ;
OR2X1 u224 ( .A ( n194 ) , .B ( n193 ) , .Y ( n195 ) ) ;
AOI22X1 u225 ( .A ( n1730 ) , .B ( n771 ) , .C ( n196 ) , .D ( n116 ) , 
    .Y ( n194 ) ) ;
NAND2X1 u226 ( .A ( n197 ) , .B ( n198 ) , .Y ( n196 ) ) ;
INVX1 u227 ( .A ( n197 ) , .Y ( n771 ) ) ;
NOR2X1 u231 ( .A ( gre_a_INV_513_0 ) , .B ( y[0] ) , .Y ( n741 ) ) ;
AOI22X1 u237 ( .A ( x[6] ) , .B ( n210 ) , .C ( n214 ) , .D ( n212_CDR1 ) , 
    .Y ( n208 ) ) ;
OR2X1 u238 ( .A ( n210 ) , .B ( x[6] ) , .Y ( n214 ) ) ;
AOI22X1 u239 ( .A ( n901 ) , .B ( n216 ) , .C ( n218 ) , .D ( x_ball_r[5] ) , 
    .Y ( n210 ) ) ;
OR2X2 u240 ( .A ( n216 ) , .B ( n901 ) , .Y ( n218 ) ) ;
AOI22X1 u241 ( .A ( x[4] ) , .B ( n220 ) , .C ( n222 ) , .D ( n221_CDR1 ) , 
    .Y ( n216 ) ) ;
OR2X1 u242 ( .A ( n220 ) , .B ( x[4] ) , .Y ( n222 ) ) ;
AOI21X1 u243 ( .A ( n911_CDR1 ) , .B ( n223 ) , .C ( n224 ) , .Y ( n220 ) ) ;
AOI21X1 u244 ( .A ( n225 ) , .B ( x[3] ) , .C ( n226_CDR1 ) , .Y ( n224 ) ) ;
INVX1 u245 ( .A ( n225 ) , .Y ( n223 ) ) ;
OAI22X1 u246 ( .A ( n1511 ) , .B ( n227 ) , .C ( n228 ) , .D ( x_ball_r[2] ) , 
    .Y ( n225 ) ) ;
AND2X1 u247 ( .A ( n227 ) , .B ( n1511 ) , .Y ( n228 ) ) ;
OAI21X1 u248 ( .A ( x[1] ) , .B ( n230 ) , .C ( n231 ) , .Y ( n227 ) ) ;
OAI21X1 u249 ( .A ( n1521 ) , .B ( n233 ) , .C ( x_ball_r[1] ) , .Y ( n231 ) ) ;
INVX1 u250 ( .A ( n230 ) , .Y ( n233 ) ) ;
INVX1 u251 ( .A ( x[1] ) , .Y ( n1521 ) ) ;
NOR2X1 u252 ( .A ( n1531_CDR1 ) , .B ( x_ball_r[0] ) , .Y ( n230 ) ) ;
INVX1 u253 ( .A ( x[2] ) , .Y ( n1511 ) ) ;
INVX1 u254 ( .A ( x[5] ) , .Y ( n901 ) ) ;
OAI21X1 u255 ( .A ( y[8] ) , .B ( n235 ) , .C ( n237 ) , .Y ( n1541 ) ) ;
OAI21X1 u256 ( .A ( y_ball_b[8] ) , .B ( n126_CDR1 ) , .C ( n239 ) , 
    .Y ( n237 ) ) ;
OAI22X1 u260 ( .A ( n104 ) , .B ( n247 ) , .C ( n248 ) , .D ( y_ball_b[6] ) , 
    .Y ( n245 ) ) ;
AND2X1 u261 ( .A ( n247 ) , .B ( n104 ) , .Y ( n248 ) ) ;
OAI22X1 u262 ( .A ( y[5] ) , .B ( n249 ) , .C ( n250 ) , .D ( n251 ) , 
    .Y ( n247 ) ) ;
AND2X1 u263 ( .A ( n249 ) , .B ( y[5] ) , .Y ( n250 ) ) ;
OAI22X1 u264 ( .A ( n110 ) , .B ( n252 ) , .C ( n253 ) , .D ( y_ball_b[4] ) , 
    .Y ( n249 ) ) ;
AND2X1 u265 ( .A ( n252 ) , .B ( n110 ) , .Y ( n253 ) ) ;
OAI22X1 u269 ( .A ( n116 ) , .B ( n261 ) , .C ( n263 ) , .D ( y_ball_b[2] ) , 
    .Y ( n254 ) ) ;
AND2X1 u270 ( .A ( n261 ) , .B ( n116 ) , .Y ( n263 ) ) ;
OAI21X1 u271 ( .A ( y[1] ) , .B ( n265 ) , .C ( n267 ) , .Y ( n261 ) ) ;
OAI21X1 u272 ( .A ( n201 ) , .B ( n269 ) , .C ( y_ball_b[1] ) , .Y ( n267 ) ) ;
INVX1 u273 ( .A ( n265 ) , .Y ( n269 ) ) ;
INVX1 u274 ( .A ( y[1] ) , .Y ( n201 ) ) ;
NOR2X1 u275 ( .A ( n122 ) , .B ( gre_a_INV_148_0 ) , .Y ( n265 ) ) ;
INVX1 u276 ( .A ( y[0] ) , .Y ( n122 ) ) ;
INVX1 u277 ( .A ( y[2] ) , .Y ( n116 ) ) ;
INVX1 u278 ( .A ( y[4] ) , .Y ( n110 ) ) ;
INVX1 u279 ( .A ( y[6] ) , .Y ( n104 ) ) ;
INVX1 u280 ( .A ( y_ball_b[8] ) , .Y ( n235 ) ) ;
NAND2X1 u281 ( .A ( n273 ) , .B ( n271 ) , .Y ( n294 ) ) ;
NAND2X1 u282 ( .A ( n276 ) , .B ( y_delta_reg[1] ) , .Y ( n273 ) ) ;
NAND2X1 u283 ( .A ( n271 ) , .B ( n2951 ) , .Y ( n293 ) ) ;
NAND2X1 u284 ( .A ( y_delta_reg[2] ) , .B ( n276 ) , .Y ( n2951 ) ) ;
NAND2X1 u285 ( .A ( n271 ) , .B ( n296 ) , .Y ( n292 ) ) ;
NAND2X1 u286 ( .A ( y_delta_reg[3] ) , .B ( n276 ) , .Y ( n296 ) ) ;
NAND2X1 u287 ( .A ( n271 ) , .B ( n297 ) , .Y ( n291 ) ) ;
NAND2X1 u288 ( .A ( y_delta_reg[4] ) , .B ( n276 ) , .Y ( n297 ) ) ;
NAND2X1 u289 ( .A ( n271 ) , .B ( n298 ) , .Y ( n290 ) ) ;
NAND2X1 u290 ( .A ( y_delta_reg[5] ) , .B ( n276 ) , .Y ( n298 ) ) ;
NAND2X1 u291 ( .A ( n271 ) , .B ( n299 ) , .Y ( n289 ) ) ;
NAND2X1 u292 ( .A ( y_delta_reg[6] ) , .B ( n276 ) , .Y ( n299 ) ) ;
NAND2X1 u293 ( .A ( n271 ) , .B ( n3001 ) , .Y ( n288 ) ) ;
NAND2X1 u294 ( .A ( y_delta_reg[7] ) , .B ( n276 ) , .Y ( n3001 ) ) ;
NAND2X1 u295 ( .A ( n271 ) , .B ( n301 ) , .Y ( n287 ) ) ;
NAND2X1 u296 ( .A ( y_delta_reg[8] ) , .B ( n276 ) , .Y ( n301 ) ) ;
NAND2X1 u297 ( .A ( n302 ) , .B ( n303 ) , .Y ( n271 ) ) ;
OAI21X1 u298 ( .A ( HFSNET_12 ) , .B ( n305 ) , .C ( n306 ) , .Y ( n286 ) ) ;
INVX1 u299 ( .A ( x_delta_reg[1] ) , .Y ( n305 ) ) ;
OAI21X1 u300 ( .A ( n307 ) , .B ( HFSNET_12 ) , .C ( n306 ) , .Y ( n285 ) ) ;
INVX1 u301 ( .A ( x_delta_reg[2] ) , .Y ( n307 ) ) ;
OAI21X1 u302 ( .A ( n308 ) , .B ( HFSNET_12 ) , .C ( n306 ) , .Y ( n284 ) ) ;
INVX1 u303 ( .A ( x_delta_reg[3] ) , .Y ( n308 ) ) ;
OAI21X1 u304 ( .A ( n309 ) , .B ( HFSNET_12 ) , .C ( n306 ) , .Y ( n283 ) ) ;
INVX1 u305 ( .A ( x_delta_reg[4] ) , .Y ( n309 ) ) ;
OAI21X1 u306 ( .A ( n3101 ) , .B ( HFSNET_12 ) , .C ( n306 ) , .Y ( n282 ) ) ;
INVX1 u307 ( .A ( x_delta_reg[5] ) , .Y ( n3101 ) ) ;
OAI21X1 u308 ( .A ( n311 ) , .B ( HFSNET_12 ) , .C ( n306 ) , .Y ( n281 ) ) ;
INVX1 u309 ( .A ( x_delta_reg[6] ) , .Y ( n311 ) ) ;
OAI21X1 u310 ( .A ( n312 ) , .B ( HFSNET_12 ) , .C ( n306 ) , .Y ( n280 ) ) ;
INVX1 u311 ( .A ( x_delta_reg[7] ) , .Y ( n312 ) ) ;
OAI21X1 u312 ( .A ( n313 ) , .B ( HFSNET_12 ) , .C ( n306 ) , .Y ( n279 ) ) ;
INVX1 u314 ( .A ( n316 ) , .Y ( n315 ) ) ;
INVX1 u315 ( .A ( n303 ) , .Y ( n276 ) ) ;
INVX1 u316 ( .A ( x_delta_reg[8] ) , .Y ( n313 ) ) ;
OR2X1 u317 ( .A ( HFSNET_12 ) , .B ( x_delta_reg[0] ) , .Y ( n278 ) ) ;
AOI21X1 u318 ( .A ( n316 ) , .B ( n314 ) , .C ( n303 ) , .Y ( n304 ) ) ;
NAND3X1 u319 ( .A ( n317 ) , .B ( n318 ) , .C ( n319 ) , .Y ( n314 ) ) ;
NOR3X1 u320 ( .A ( n1600 ) , .B ( n1620 ) , .C ( n1610 ) , .Y ( n319 ) ) ;
NAND3X1 u321 ( .A ( tmp_net60 ) , .B ( n1650 ) , .C ( n1630 ) , .Y ( n318 ) ) ;
NOR2X1 u323 ( .A ( n1590 ) , .B ( n1580 ) , .Y ( n317 ) ) ;
NAND3X1 u324 ( .A ( n321_CDR1 ) , .B ( n322_CDR1 ) , .C ( n323_CDR1 ) , 
    .Y ( n316 ) ) ;
NOR3X1 u325 ( .A ( n324_CDR1 ) , .B ( n325 ) , .C ( n326 ) , 
    .Y ( n323_CDR1 ) ) ;
NAND2X1 u326 ( .A ( n96 ) , .B ( n102 ) , .Y ( n326 ) ) ;
AOI21X1 u327 ( .A ( n327 ) , .B ( n106 ) , .C ( n328 ) , .Y ( n325 ) ) ;
AOI21X1 u328 ( .A ( n1520 ) , .B ( n329 ) , .C ( n251 ) , .Y ( n328 ) ) ;
INVX1 u330 ( .A ( n1520 ) , .Y ( n106 ) ) ;
INVX1 u331 ( .A ( n329 ) , .Y ( n327 ) ) ;
OAI22X1 u332 ( .A ( n3301 ) , .B ( n331 ) , .C ( n332 ) , .D ( y_ball_b[4] ) , 
    .Y ( n329 ) ) ;
AND2X1 u333 ( .A ( n331 ) , .B ( n3301 ) , .Y ( n332 ) ) ;
OAI22X1 u334 ( .A ( n1540 ) , .B ( n333 ) , .C ( n334 ) , .D ( n259 ) , 
    .Y ( n331 ) ) ;
AND2X1 u336 ( .A ( n333 ) , .B ( n1540 ) , .Y ( n334 ) ) ;
OAI22X1 u337 ( .A ( n335 ) , .B ( n336 ) , .C ( n337 ) , .D ( y_ball_b[2] ) , 
    .Y ( n333 ) ) ;
AND2X1 u338 ( .A ( n336 ) , .B ( n335 ) , .Y ( n337 ) ) ;
OAI21X1 u339 ( .A ( n1560 ) , .B ( n338 ) , .C ( n339 ) , .Y ( n336 ) ) ;
OAI21X1 u340 ( .A ( n118 ) , .B ( n3401 ) , .C ( y_ball_b[1] ) , .Y ( n339 ) ) ;
INVX1 u341 ( .A ( n1560 ) , .Y ( n118 ) ) ;
INVX1 u342 ( .A ( n3401 ) , .Y ( n338 ) ) ;
NAND2X1 u343 ( .A ( n1750 ) , .B ( n1570 ) , .Y ( n3401 ) ) ;
INVX1 u345 ( .A ( n1550 ) , .Y ( n335 ) ) ;
INVX1 u346 ( .A ( n342_CDR1 ) , .Y ( n324_CDR1 ) ) ;
NOR3X1 u347 ( .A ( n365_CDR1 ) , .B ( n344_CDR1 ) , .C ( n1510 ) , 
    .Y ( n342_CDR1 ) ) ;
NOR3X1 u348 ( .A ( n343 ) , .B ( n221_CDR1 ) , .C ( n226_CDR1 ) , 
    .Y ( n322_CDR1 ) ) ;
AOI22X1 u350 ( .A ( n345 ) , .B ( n346 ) , .C ( y_pad_b[8] ) , .D ( n180 ) , 
    .Y ( n344_CDR1 ) ) ;
OR2X1 u351 ( .A ( n180 ) , .B ( y_pad_b[8] ) , .Y ( n346 ) ) ;
AOI22X1 u352 ( .A ( n347 ) , .B ( n129 ) , .C ( n1680 ) , .D ( n348 ) , 
    .Y ( n345 ) ) ;
INVX1 u353 ( .A ( y_pad_b[7] ) , .Y ( n129 ) ) ;
OR2X1 u354 ( .A ( n348 ) , .B ( n1680 ) , .Y ( n347 ) ) ;
OAI22X1 u355 ( .A ( n349 ) , .B ( n3501 ) , .C ( n351 ) , .D ( y_pad_b[6] ) , 
    .Y ( n348 ) ) ;
AND2X1 u356 ( .A ( n3501 ) , .B ( n349 ) , .Y ( n351 ) ) ;
OAI22X1 u357 ( .A ( n1700 ) , .B ( n352 ) , .C ( n353 ) , .D ( n136 ) , 
    .Y ( n3501 ) ) ;
AND2X1 u358 ( .A ( n352 ) , .B ( n1700 ) , .Y ( n353 ) ) ;
OAI22X1 u359 ( .A ( n354 ) , .B ( n355 ) , .C ( n356 ) , .D ( y_pad_b[4] ) , 
    .Y ( n352 ) ) ;
AND2X1 u360 ( .A ( n355 ) , .B ( n354 ) , .Y ( n356 ) ) ;
OAI22X1 u364 ( .A ( n198 ) , .B ( n3601 ) , .C ( n361 ) , .D ( y_pad_b[2] ) , 
    .Y ( n357 ) ) ;
AND2X1 u365 ( .A ( n3601 ) , .B ( n198 ) , .Y ( n361 ) ) ;
OAI22X1 ctmTdsLR_1_349 ( .A ( n1740 ) , .B ( n741 ) , .C ( tmp_net40 ) , 
    .D ( n201 ) , .Y ( n197 ) ) ;
AND2X2 ctmTdsLR_2_350 ( .A ( n741 ) , .B ( n1740 ) , .Y ( tmp_net40 ) ) ;
NOR2X1 u369 ( .A ( gre_a_INV_513_0 ) , .B ( y_pad_b[0] ) , .Y ( n362 ) ) ;
INVX1 u370 ( .A ( x_ball_r[5] ) , .Y ( n343 ) ) ;
NOR3X1 u371 ( .A ( n212_CDR1 ) , .B ( \x_ball_r_CDR1[7] ) , 
    .C ( \x_ball_r_CDR1[8] ) , .Y ( n321_CDR1 ) ) ;
MUX2X1 u374 ( .B ( x_ball_r[1] ) , .A ( n366 ) , .S ( x_ball_r[2] ) , 
    .Y ( n365_CDR1 ) ) ;
NAND2X1 u375 ( .A ( x_ball_r[1] ) , .B ( x_ball_r[0] ) , .Y ( n366 ) ) ;
NAND2X1 u376 ( .A ( n367 ) , .B ( n368 ) , .Y ( n277 ) ) ;
NAND2X1 u377 ( .A ( n369 ) , .B ( n2810 ) , .Y ( n368 ) ) ;
AOI22X1 u378 ( .A ( n1570 ) , .B ( n370 ) , .C ( n3810 ) , .D ( n500 ) , 
    .Y ( n367 ) ) ;
NAND2X1 u380 ( .A ( n372 ) , .B ( n373 ) , .Y ( n274 ) ) ;
NAND2X1 u381 ( .A ( n369 ) , .B ( n3610 ) , .Y ( n373 ) ) ;
AOI22X1 u382 ( .A ( n1490 ) , .B ( n370 ) , .C ( n460 ) , .D ( n500 ) , 
    .Y ( n372 ) ) ;
NAND2X1 u383 ( .A ( n374 ) , .B ( n375 ) , .Y ( n272 ) ) ;
NAND2X1 u384 ( .A ( n369 ) , .B ( n3510 ) , .Y ( n375 ) ) ;
AOI22X1 u385 ( .A ( n1500 ) , .B ( n370 ) , .C ( n450 ) , .D ( n500 ) , 
    .Y ( n374 ) ) ;
NAND2X1 u386 ( .A ( n376 ) , .B ( n377 ) , .Y ( n270 ) ) ;
NAND2X1 u387 ( .A ( n369 ) , .B ( n2910 ) , .Y ( n377 ) ) ;
AOI22X1 u388 ( .A ( n1560 ) , .B ( n370 ) , .C ( n3910 ) , .D ( n500 ) , 
    .Y ( n376 ) ) ;
NAND2X1 u389 ( .A ( n378 ) , .B ( n379 ) , .Y ( n268 ) ) ;
NAND2X1 u390 ( .A ( n369 ) , .B ( n3410 ) , .Y ( n379 ) ) ;
AOI22X1 u391 ( .A ( n1510 ) , .B ( n370 ) , .C ( n441 ) , .D ( n500 ) , 
    .Y ( n378 ) ) ;
NAND2X1 u392 ( .A ( n3801 ) , .B ( n381 ) , .Y ( n266 ) ) ;
AOI22X1 u394 ( .A ( n1520 ) , .B ( n370 ) , .C ( n4310 ) , .D ( n500 ) , 
    .Y ( n3801 ) ) ;
NAND2X1 u395 ( .A ( n382 ) , .B ( n383 ) , .Y ( n264 ) ) ;
NAND2X1 u396 ( .A ( n369 ) , .B ( n3210 ) , .Y ( n383 ) ) ;
AOI22X1 u397 ( .A ( n1530 ) , .B ( n370 ) , .C ( n4210 ) , .D ( n500 ) , 
    .Y ( n382 ) ) ;
NAND2X1 u398 ( .A ( n384 ) , .B ( n385 ) , .Y ( n262 ) ) ;
AOI22X1 u400 ( .A ( n1540 ) , .B ( n370 ) , .C ( n4110 ) , .D ( n500 ) , 
    .Y ( n384 ) ) ;
NAND2X1 u401 ( .A ( n386 ) , .B ( n387 ) , .Y ( n260 ) ) ;
NAND2X1 u402 ( .A ( n369 ) , .B ( n3010 ) , .Y ( n387 ) ) ;
NOR2X1 u403 ( .A ( n7 ) , .B ( n388 ) , .Y ( n369 ) ) ;
AOI22X1 u404 ( .A ( n1550 ) , .B ( n370 ) , .C ( n4010 ) , .D ( n500 ) , 
    .Y ( n386 ) ) ;
NOR3X1 u405 ( .A ( n7 ) , .B ( n3901 ) , .C ( n391 ) , .Y ( n371 ) ) ;
INVX1 u406 ( .A ( n388 ) , .Y ( n3901 ) ) ;
INVX1 u407 ( .A ( n392 ) , .Y ( n370 ) ) ;
AOI21X1 u408 ( .A ( n388 ) , .B ( n391 ) , .C ( n8 ) , .Y ( n392 ) ) ;
NAND3X1 u409 ( .A ( down ) , .B ( n393 ) , .C ( n394 ) , .Y ( n391 ) ) ;
NOR3X1 u410 ( .A ( y_pad_b[6] ) , .B ( y_pad_b[8] ) , .C ( y_pad_b[7] ) , 
    .Y ( n394 ) ) ;
NAND3X1 u411 ( .A ( y_pad_b[4] ) , .B ( y_pad_b[2] ) , .C ( n395 ) , 
    .Y ( n393 ) ) ;
NOR3X1 u412 ( .A ( n136 ) , .B ( n148 ) , .C ( n142 ) , .Y ( n395 ) ) ;
OAI21X1 u416 ( .A ( n396 ) , .B ( n397 ) , .C ( up ) , .Y ( n388 ) ) ;
NAND3X1 u417 ( .A ( n96 ) , .B ( n102 ) , .C ( n398 ) , .Y ( n397 ) ) ;
NOR2X1 u418 ( .A ( n1520 ) , .B ( n1510 ) , .Y ( n398 ) ) ;
INVX1 u419 ( .A ( n1500 ) , .Y ( n102 ) ) ;
INVX1 u420 ( .A ( n1490 ) , .Y ( n96 ) ) ;
NAND3X1 u421 ( .A ( n399 ) , .B ( n3301 ) , .C ( n112 ) , .Y ( n396 ) ) ;
NOR2X1 u422 ( .A ( n1550 ) , .B ( n1560 ) , .Y ( n399 ) ) ;
INVX1 u423 ( .A ( n1540 ) , .Y ( n112 ) ) ;
INVX1 u424 ( .A ( n1530 ) , .Y ( n3301 ) ) ;
MUX2X1 u425 ( .B ( n4001 ) , .A ( gre_a_INV_513_0 ) , .S ( n7 ) , 
    .Y ( n258 ) ) ;
INVX1 u427 ( .A ( n620 ) , .Y ( n4001 ) ) ;
OR2X2 u428 ( .A ( y_delta_reg[0] ) , .B ( n303 ) , .Y ( n256 ) ) ;
NAND3X1 u429 ( .A ( n302 ) , .B ( n401 ) , .C ( n402 ) , .Y ( n303 ) ) ;
NOR2X1 u430 ( .A ( y_ball_b[8] ) , .B ( y_ball_b[7] ) , .Y ( n402 ) ) ;
INVX1 u431 ( .A ( y_ball_b[6] ) , .Y ( n401 ) ) ;
NAND3X1 u432 ( .A ( n403 ) , .B ( n404 ) , .C ( n405 ) , .Y ( n302 ) ) ;
NOR3X1 u433 ( .A ( n406 ) , .B ( n1680 ) , .C ( n1670 ) , .Y ( n405 ) ) ;
NAND2X1 u434 ( .A ( n349 ) , .B ( n186 ) , .Y ( n406 ) ) ;
NOR3X1 u435 ( .A ( n1730 ) , .B ( n1750 ) , .C ( n1740 ) , .Y ( n404 ) ) ;
NOR2X1 u436 ( .A ( n1720 ) , .B ( n1710 ) , .Y ( n403 ) ) ;
INVX1 u437 ( .A ( n407 ) , .Y ( n246 ) ) ;
MUX2X1 u438 ( .B ( n630 ) , .A ( n1740 ) , .S ( n9 ) , .Y ( n407 ) ) ;
MUX2X1 u439 ( .B ( n408 ) , .A ( n198 ) , .S ( n9 ) , .Y ( n244 ) ) ;
INVX1 u440 ( .A ( n1730 ) , .Y ( n198 ) ) ;
INVX1 u441 ( .A ( n640 ) , .Y ( n408 ) ) ;
MUX2X1 u442 ( .B ( n409 ) , .A ( n193 ) , .S ( n8 ) , .Y ( n242 ) ) ;
INVX1 u443 ( .A ( n1720 ) , .Y ( n193 ) ) ;
INVX1 u444 ( .A ( n650 ) , .Y ( n409 ) ) ;
MUX2X1 u445 ( .B ( n4101 ) , .A ( n354 ) , .S ( n7 ) , .Y ( n240 ) ) ;
INVX1 u446 ( .A ( n1710 ) , .Y ( n354 ) ) ;
INVX1 u447 ( .A ( n660 ) , .Y ( n4101 ) ) ;
MUX2X1 u448 ( .B ( n411 ) , .A ( n186 ) , .S ( n9 ) , .Y ( n238 ) ) ;
INVX1 u449 ( .A ( n1700 ) , .Y ( n186 ) ) ;
INVX1 u450 ( .A ( n670 ) , .Y ( n411 ) ) ;
MUX2X1 u451 ( .B ( n412 ) , .A ( n349 ) , .S ( n8 ) , .Y ( n236 ) ) ;
INVX1 u452 ( .A ( n1690 ) , .Y ( n349 ) ) ;
INVX1 u453 ( .A ( n680 ) , .Y ( n412 ) ) ;
INVX1 u454 ( .A ( n413 ) , .Y ( n234 ) ) ;
MUX2X1 u455 ( .B ( n690 ) , .A ( n1680 ) , .S ( n8 ) , .Y ( n413 ) ) ;
MUX2X1 u456 ( .B ( n414 ) , .A ( n180 ) , .S ( n7 ) , .Y ( n232 ) ) ;
INVX1 u457 ( .A ( n1670 ) , .Y ( n180 ) ) ;
INVX1 u458 ( .A ( n700 ) , .Y ( n414 ) ) ;
INVX1 u459 ( .A ( n415 ) , .Y ( n229 ) ) ;
AOI22X1 u460 ( .A ( n7 ) , .B ( n1580 ) , .C ( ZBUF_356_0 ) , .D ( n910 ) , 
    .Y ( n415 ) ) ;
INVX1 u461 ( .A ( n417 ) , .Y ( n219 ) ) ;
AOI22X1 u462 ( .A ( n9 ) , .B ( n1590 ) , .C ( ZBUF_356_0 ) , .D ( n900 ) , 
    .Y ( n417 ) ) ;
INVX1 u463 ( .A ( n418 ) , .Y ( n217 ) ) ;
AOI22X1 u464 ( .A ( n8 ) , .B ( n1600 ) , .C ( ZBUF_356_0 ) , .D ( n890 ) , 
    .Y ( n418 ) ) ;
INVX1 u465 ( .A ( n419 ) , .Y ( n215 ) ) ;
AOI22X1 u466 ( .A ( n7 ) , .B ( n1610 ) , .C ( ZBUF_356_0 ) , .D ( n880 ) , 
    .Y ( n419 ) ) ;
INVX1 u467 ( .A ( n4201 ) , .Y ( n213 ) ) ;
AOI22X1 u468 ( .A ( n9 ) , .B ( n1620 ) , .C ( ZBUF_356_0 ) , .D ( n870 ) , 
    .Y ( n4201 ) ) ;
INVX1 u469 ( .A ( n421 ) , .Y ( n211 ) ) ;
AOI22X1 u470 ( .A ( n8 ) , .B ( n1630 ) , .C ( ZBUF_356_0 ) , .D ( n860 ) , 
    .Y ( n421 ) ) ;
INVX1 u471 ( .A ( n422 ) , .Y ( n209 ) ) ;
AOI22X1 u472 ( .A ( n7 ) , .B ( n1640 ) , .C ( ZBUF_356_0 ) , .D ( n850 ) , 
    .Y ( n422 ) ) ;
INVX1 u473 ( .A ( n423 ) , .Y ( n207 ) ) ;
AOI22X1 u474 ( .A ( n9 ) , .B ( n1650 ) , .C ( ZBUF_356_0 ) , .D ( n840 ) , 
    .Y ( n423 ) ) ;
INVX1 u475 ( .A ( n424 ) , .Y ( n205 ) ) ;
AOI22X1 u476 ( .A ( n8 ) , .B ( n1660 ) , .C ( ZBUF_356_0 ) , .D ( n830 ) , 
    .Y ( n424 ) ) ;
NAND3X1 u478 ( .A ( n426_CDR1 ) , .B ( n427_CDR1 ) , .C ( tmp_net58 ) , 
    .Y ( n389 ) ) ;
NOR3X1 u479 ( .A ( n428_CDR1 ) , .B ( n429_CDR1 ) , .C ( n4301 ) , 
    .Y ( n427_CDR1 ) ) ;
NAND2X1 u480 ( .A ( n125 ) , .B ( y[6] ) , .Y ( n4301 ) ) ;
NOR2X1 u481 ( .A ( x[1] ) , .B ( x[2] ) , .Y ( n125 ) ) ;
NAND2X1 u482 ( .A ( n1531_CDR1 ) , .B ( y[0] ) , .Y ( n429_CDR1 ) ) ;
NAND3X1 u483 ( .A ( n92_CDR1 ) , .B ( n911_CDR1 ) , .C ( n431 ) , 
    .Y ( n428_CDR1 ) ) ;
NOR2X1 u484 ( .A ( x[6] ) , .B ( x[5] ) , .Y ( n431 ) ) ;
INVX1 u485 ( .A ( x[4] ) , .Y ( n92_CDR1 ) ) ;
INVX1 u486 ( .A ( x[3] ) , .Y ( n911_CDR1 ) ) ;
NOR3X1 u487 ( .A ( n432_CDR1 ) , .B ( y[4] ) , .C ( y[3] ) , 
    .Y ( n426_CDR1 ) ) ;
NAND3X1 u488 ( .A ( n126_CDR1 ) , .B ( n190_CDR1 ) , .C ( n99_CDR1 ) , 
    .Y ( n432_CDR1 ) ) ;
INVX1 u489 ( .A ( y[5] ) , .Y ( n190_CDR1 ) ) ;
INVX1 u490 ( .A ( y[8] ) , .Y ( n126_CDR1 ) ) ;
INVX1 u491 ( .A ( y[7] ) , .Y ( n99_CDR1 ) ) ;
NAND2X1 u493 ( .A ( n831_CDR1 ) , .B ( n82_CDR1 ) , .Y ( n433_CDR1 ) ) ;
INVX1 u494 ( .A ( x[8] ) , .Y ( n831_CDR1 ) ) ;
INVX1 u495 ( .A ( x[7] ) , .Y ( n82_CDR1 ) ) ;
XNOR2X1 u496 ( .A ( n1751 ) , .B ( n434 ) , .Y ( n610 ) ) ;
XOR2X1 u497 ( .A ( x[2] ) , .B ( n1640 ) , .Y ( n434 ) ) ;
OAI21X1 u498 ( .A ( n1650 ) , .B ( n435 ) , .C ( n436 ) , .Y ( n1751 ) ) ;
OAI21X1 u499 ( .A ( n437 ) , .B ( n438 ) , .C ( x[1] ) , .Y ( n436 ) ) ;
INVX1 u500 ( .A ( n1650 ) , .Y ( n438 ) ) ;
INVX1 u501 ( .A ( n437 ) , .Y ( n435 ) ) ;
XNOR2X1 u502 ( .A ( n439 ) , .B ( n437 ) , .Y ( n510 ) ) ;
XOR2X1 u503 ( .A ( x[1] ) , .B ( n1650 ) , .Y ( n439 ) ) ;
OAI21X1 u504 ( .A ( n1660 ) , .B ( n1531_CDR1 ) , .C ( n437 ) , .Y ( n440 ) ) ;
NAND2X1 u505 ( .A ( n1660 ) , .B ( n1531_CDR1 ) , .Y ( n437 ) ) ;
INVX1 u506 ( .A ( x[0] ) , .Y ( n1531_CDR1 ) ) ;
BUFX2 HFSBUF_256_204 ( .A ( n304 ) , .Y ( HFSNET_12 ) ) ;
endmodule


module pong_pt1 ( clk , reset , enable , up , down , p_tick , hsync , vsync , 
    rgb ) ;
input  clk ;
input  reset ;
input  enable ;
input  up ;
input  down ;
output p_tick ;
output hsync ;
output vsync ;
output rgb ;

wire n134 ;
wire n135 ;
wire pixel_tick ;
wire n8 ;
wire n17 ;
wire n18 ;
wire n19 ;
wire n20 ;
wire n21 ;
wire n22 ;
wire n23 ;
wire n24 ;
wire n25 ;
wire n35 ;
wire n36 ;
wire n37 ;
wire n38 ;
wire n39 ;
wire n40 ;
wire n410 ;
wire n42 ;
wire n430 ;
wire ropt_net_88 ;
wire n411 ;
wire n431 ;
wire n45 ;
wire n47 ;
wire n49 ;
wire n51 ;
wire n53 ;
wire n55 ;
wire n57 ;
wire optlc_net_61 ;
wire n70 ;
wire n71 ;
wire n72 ;
wire n73 ;
wire n74 ;
wire n75 ;
wire n76 ;
wire n77 ;
wire n78 ;
wire optlc_net_62 ;
wire gre_a_INV_1025_0 ;
wire HFSNET_1 ;
wire HFSNET_2 ;
wire HFSNET_3 ;
wire optlc_net_63 ;
wire n90 ;
wire optlc_net_64 ;
wire n92 ;
wire n93 ;
wire n94 ;
wire n95 ;
wire n96 ;
wire n97 ;
wire n98 ;
wire n99 ;
wire n100 ;
wire n101 ;
wire n102 ;
wire n103 ;
wire n104 ;
wire n105 ;
wire n106 ;
wire n107 ;
wire n108 ;
wire n109 ;
wire n110 ;
wire n111 ;
wire n112 ;
wire n113 ;
wire n114 ;
wire n115 ;
wire n116 ;
wire n118 ;
wire n119 ;
wire n120 ;
wire n121 ;
wire n122 ;
wire n123 ;
wire n124 ;
wire n125 ;
wire n126 ;
wire n127 ;
wire n128 ;
wire n129 ;
wire n130 ;
wire n131 ;
wire n132 ;
wire n133 ;
wire [8:0] y ;
wire [8:0] x ;
wire ctsbuf_net_129 ;
wire ctsbuf_net_230 ;
wire ctsbuf_net_331 ;
wire ctsbuf_net_432 ;
wire cts0 ;
wire cts1 ;
wire optlc_net_65 ;
wire optlc_net_66 ;
wire optlc_net_67 ;
wire optlc_net_68 ;
wire optlc_net_69 ;
wire optlc_net_70 ;
wire optlc_net_71 ;
wire optlc_net_72 ;
wire optlc_net_73 ;
wire optlc_net_74 ;
wire optlc_net_75 ;
wire optlc_net_76 ;
wire optlc_net_77 ;
wire optlc_net_78 ;
wire optlc_net_79 ;
wire optlc_net_80 ;
wire optlc_net_81 ;
wire tmp_net59 ;
wire optlc_net_82 ;
wire optlc_net_83 ;
wire optlc_net_84 ;
wire optlc_net_85 ;
wire SYNOPSYS_UNCONNECTED_1 ;
wire SYNOPSYS_UNCONNECTED_2 ;
wire SYNOPSYS_UNCONNECTED_3 ;
wire SYNOPSYS_UNCONNECTED_4 ;
wire SYNOPSYS_UNCONNECTED_5 ;
wire SYNOPSYS_UNCONNECTED_6 ;
wire SYNOPSYS_UNCONNECTED_7 ;
wire SYNOPSYS_UNCONNECTED_8 ;
wire SYNOPSYS_UNCONNECTED_9 ;
wire SYNOPSYS_UNCONNECTED_10 ;
wire SYNOPSYS_UNCONNECTED_11 ;
wire SYNOPSYS_UNCONNECTED_12 ;
wire SYNOPSYS_UNCONNECTED_13 ;
wire SYNOPSYS_UNCONNECTED_14 ;

DFFSRX1 x_reg_7_ ( .D ( n53 ) , .CLK ( cts0 ) , .R ( optlc_net_64 ) , 
    .S ( HFSNET_1 ) , .Q ( x[7] ) ) ;
pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9 pg ( 
    .clk ( ctsbuf_net_331 ) , .reset ( HFSNET_3 ) , .up ( up ) , 
    .down ( down ) , .video_on ( n90 ) , .x ( x ) , .y ( y ) , .rgb ( rgb ) , 
    .cts0 ( ctsbuf_net_230 ) , .p0 ( SYNOPSYS_UNCONNECTED_1 ) , 
    .p1 ( SYNOPSYS_UNCONNECTED_2 ) , .p2 ( SYNOPSYS_UNCONNECTED_3 ) , 
    .p3 ( SYNOPSYS_UNCONNECTED_4 ) , .p4 ( SYNOPSYS_UNCONNECTED_5 ) , 
    .p5 ( SYNOPSYS_UNCONNECTED_6 ) , .p6 ( SYNOPSYS_UNCONNECTED_7 ) , 
    .p7 ( SYNOPSYS_UNCONNECTED_8 ) , .p8 ( SYNOPSYS_UNCONNECTED_9 ) , 
    .p14 ( optlc_net_62 ) , .p_abuf11 ( ctsbuf_net_129 ) , 
    .p9 ( SYNOPSYS_UNCONNECTED_10 ) , .p10 ( SYNOPSYS_UNCONNECTED_11 ) , 
    .p11 ( SYNOPSYS_UNCONNECTED_12 ) , .p12 ( SYNOPSYS_UNCONNECTED_13 ) , 
    .p13 ( SYNOPSYS_UNCONNECTED_14 ) , .cts1 ( cts1 ) , 
    .p15 ( optlc_net_65 ) , .p16 ( optlc_net_66 ) , .p17 ( optlc_net_67 ) , 
    .p18 ( optlc_net_69 ) , .p19 ( optlc_net_71 ) , .p20 ( optlc_net_73 ) , 
    .p21 ( optlc_net_74 ) , .p22 ( optlc_net_75 ) , .p23 ( optlc_net_76 ) , 
    .p24 ( optlc_net_77 ) , .p25 ( optlc_net_78 ) , .p26 ( optlc_net_79 ) , 
    .p27 ( optlc_net_80 ) , .p28 ( optlc_net_81 ) , .p29 ( optlc_net_82 ) , 
    .p30 ( optlc_net_83 ) ) ;
pong_pt1_DW01_inc_0 add_101 ( .a ( x ) ,
    .sum ( { n430 , n42 , n410 , n40 , n39 , n38 , n37 , n36 , n35 } ) ) ;
pong_pt1_DW01_inc_1 add_98 ( .a ( y ) ,
    .sum ( { n25 , n24 , n23 , n22 , n21 , n20 , n19 , n18 , n17 } ) ) ;
DFFSRX1 y_reg_6_ ( .D ( n71 ) , .CLK ( cts0 ) , .R ( optlc_net_84 ) , 
    .S ( HFSNET_2 ) , .Q ( y[6] ) ) ;
DFFSRX1 pixel_tick_reg ( .D ( n8 ) , .CLK ( cts0 ) , .R ( HFSNET_1 ) , 
    .S ( optlc_net_63 ) , .Q ( pixel_tick ) ) ;
DFFSRX1 y_reg_3_ ( .D ( n74 ) , .CLK ( cts0 ) , .R ( HFSNET_2 ) , 
    .S ( optlc_net_85 ) , .Q ( y[3] ) ) ;
DFFSRX1 y_reg_2_ ( .D ( n75 ) , .CLK ( cts0 ) , .R ( HFSNET_2 ) , 
    .S ( optlc_net_85 ) , .Q ( y[2] ) ) ;
DFFSRX1 y_reg_1_ ( .D ( n76 ) , .CLK ( cts0 ) , .R ( HFSNET_2 ) , 
    .S ( optlc_net_68 ) , .Q ( y[1] ) ) ;
DFFSRX1 y_reg_0_ ( .D ( n77 ) , .CLK ( cts0 ) , .R ( HFSNET_2 ) , 
    .S ( optlc_net_68 ) , .Q ( y[0] ) ) ;
DFFSRX1 y_reg_4_ ( .D ( n73 ) , .CLK ( cts0 ) , .R ( HFSNET_2 ) , 
    .S ( optlc_net_84 ) , .Q ( y[4] ) ) ;
DFFSRX1 x_reg_4_ ( .D ( n47 ) , .CLK ( ctsbuf_net_129 ) , .R ( HFSNET_1 ) , 
    .S ( optlc_net_63 ) , .Q ( x[4] ) ) ;
DFFSRX1 x_reg_3_ ( .D ( n45 ) , .CLK ( ctsbuf_net_129 ) , .R ( HFSNET_1 ) , 
    .S ( optlc_net_72 ) , .Q ( x[3] ) ) ;
DFFSRX1 x_reg_2_ ( .D ( n431 ) , .CLK ( ctsbuf_net_129 ) , .R ( HFSNET_1 ) , 
    .S ( optlc_net_63 ) , .Q ( x[2] ) ) ;
DFFSRX1 x_reg_1_ ( .D ( n411 ) , .CLK ( cts0 ) , .R ( HFSNET_1 ) , 
    .S ( optlc_net_68 ) , .Q ( x[1] ) ) ;
DFFSRX1 x_reg_0_ ( .D ( n57 ) , .CLK ( cts0 ) , .R ( HFSNET_1 ) , 
    .S ( optlc_net_68 ) , .Q ( x[0] ) ) ;
DFFSRX1 x_reg_5_ ( .D ( n49 ) , .CLK ( cts0 ) , .R ( HFSNET_1 ) , 
    .S ( optlc_net_61 ) , .Q ( x[5] ) ) ;
DFFSRX1 y_reg_5_ ( .D ( n72 ) , .CLK ( ctsbuf_net_129 ) , .R ( HFSNET_2 ) , 
    .S ( optlc_net_85 ) , .Q ( y[5] ) ) ;
DFFSRX1 x_reg_6_ ( .D ( n51 ) , .CLK ( cts0 ) , .R ( HFSNET_1 ) , 
    .S ( optlc_net_64 ) , .Q ( x[6] ) ) ;
DFFSRX1 y_reg_7_ ( .D ( n70 ) , .CLK ( cts0 ) , .R ( HFSNET_2 ) , 
    .S ( optlc_net_84 ) , .Q ( y[7] ) ) ;
DFFSRX1 x_reg_8_ ( .D ( n55 ) , .CLK ( ctsbuf_net_129 ) , .R ( HFSNET_1 ) , 
    .S ( optlc_net_70 ) , .Q ( x[8] ) ) ;
DFFSRX1 y_reg_8_ ( .D ( n78 ) , .CLK ( cts0 ) , .R ( HFSNET_2 ) , 
    .S ( optlc_net_63 ) , .Q ( y[8] ) ) ;
TIEHIX1 optlc_437 ( .Y ( optlc_net_61 ) ) ;
TIEHIX1 optlc_438 ( .Y ( optlc_net_62 ) ) ;
BUFX2 ropt_mt_inst_467 ( .A ( n94 ) , .Y ( ropt_net_88 ) ) ;
TIEHIX1 optlc_439 ( .Y ( optlc_net_63 ) ) ;
TIEHIX1 optlc_440 ( .Y ( optlc_net_64 ) ) ;
TIEHIX1 optlc_441 ( .Y ( optlc_net_65 ) ) ;
TIEHIX1 optlc_442 ( .Y ( optlc_net_66 ) ) ;
TIEHIX1 optlc_443 ( .Y ( optlc_net_67 ) ) ;
BUFX2 HFSBUF_2743_208 ( .A ( HFSNET_3 ) , .Y ( HFSNET_1 ) ) ;
BUFX4 HFSBUF_3322_209 ( .A ( HFSNET_3 ) , .Y ( HFSNET_2 ) ) ;
NOR3X1 u93 ( .A ( gre_a_INV_1025_0 ) , .B ( vsync ) , .C ( n90 ) , 
    .Y ( n134 ) ) ;
NAND2X1 u94 ( .A ( n92 ) , .B ( n93 ) , .Y ( n90 ) ) ;
OAI22X1 u95 ( .A ( n95 ) , .B ( n94 ) , .C ( n97 ) , .D ( n96 ) , .Y ( n78 ) ) ;
INVX1 u96 ( .A ( n25 ) , .Y ( n97 ) ) ;
OAI22X1 u97 ( .A ( n99 ) , .B ( n96 ) , .C ( ropt_net_88 ) , .D ( n98 ) , 
    .Y ( n77 ) ) ;
INVX1 u98 ( .A ( n17 ) , .Y ( n99 ) ) ;
OAI22X1 u99 ( .A ( n101 ) , .B ( n96 ) , .C ( ropt_net_88 ) , .D ( n100 ) , 
    .Y ( n76 ) ) ;
INVX1 u100 ( .A ( n18 ) , .Y ( n101 ) ) ;
OAI22X1 u101 ( .A ( ropt_net_88 ) , .B ( n102 ) , .C ( n96 ) , .D ( n103 ) , 
    .Y ( n75 ) ) ;
INVX1 u102 ( .A ( n19 ) , .Y ( n103 ) ) ;
OAI22X1 u103 ( .A ( ropt_net_88 ) , .B ( n104 ) , .C ( n96 ) , .D ( n105 ) , 
    .Y ( n74 ) ) ;
INVX1 u104 ( .A ( n20 ) , .Y ( n105 ) ) ;
OAI22X1 u105 ( .A ( ropt_net_88 ) , .B ( n106 ) , .C ( n96 ) , .D ( n107 ) , 
    .Y ( n73 ) ) ;
INVX1 u106 ( .A ( n21 ) , .Y ( n107 ) ) ;
OAI22X1 u107 ( .A ( n108 ) , .B ( ropt_net_88 ) , .C ( n109 ) , .D ( n96 ) , 
    .Y ( n72 ) ) ;
INVX1 u108 ( .A ( n22 ) , .Y ( n109 ) ) ;
OAI22X1 u109 ( .A ( n110 ) , .B ( ropt_net_88 ) , .C ( n111 ) , .D ( n96 ) , 
    .Y ( n71 ) ) ;
INVX1 u110 ( .A ( n23 ) , .Y ( n111 ) ) ;
OAI22X1 u111 ( .A ( n112 ) , .B ( ropt_net_88 ) , .C ( n113 ) , .D ( n96 ) , 
    .Y ( n70 ) ) ;
INVX1 u112 ( .A ( n24 ) , .Y ( n113 ) ) ;
NAND2X1 u113 ( .A ( n94 ) , .B ( n92 ) , .Y ( n96 ) ) ;
INVX1 u114 ( .A ( n114 ) , .Y ( n92 ) ) ;
NAND3X1 u115 ( .A ( n112 ) , .B ( n95 ) , .C ( n115 ) , .Y ( n114 ) ) ;
OAI21X1 u116 ( .A ( n116 ) , .B ( tmp_net59 ) , .C ( y[6] ) , .Y ( n115 ) ) ;
BUFX2 ctmTdsLR_1_415 ( .A ( n135 ) , .Y ( hsync ) ) ;
INVX1 u118 ( .A ( y[0] ) , .Y ( n98 ) ) ;
INVX1 u119 ( .A ( y[2] ) , .Y ( n102 ) ) ;
INVX1 u120 ( .A ( y[1] ) , .Y ( n100 ) ) ;
NAND3X1 u121 ( .A ( n106 ) , .B ( n108 ) , .C ( n104 ) , .Y ( n116 ) ) ;
INVX1 u122 ( .A ( y[3] ) , .Y ( n104 ) ) ;
INVX1 u123 ( .A ( y[5] ) , .Y ( n108 ) ) ;
INVX1 u124 ( .A ( y[4] ) , .Y ( n106 ) ) ;
NOR2X1 u125 ( .A ( n118 ) , .B ( gre_a_INV_1025_0 ) , .Y ( n94 ) ) ;
INVX4 HFSINV_8364_213 ( .A ( reset ) , .Y ( HFSNET_3 ) ) ;
INVX1 u127 ( .A ( n119 ) , .Y ( n57 ) ) ;
AOI22X1 u128 ( .A ( gre_a_INV_1025_0 ) , .B ( x[0] ) , .C ( n120 ) , 
    .D ( n35 ) , .Y ( n119 ) ) ;
INVX1 u129 ( .A ( n121 ) , .Y ( n55 ) ) ;
AOI22X1 u130 ( .A ( gre_a_INV_1025_0 ) , .B ( x[8] ) , .C ( n120 ) , 
    .D ( n430 ) , .Y ( n121 ) ) ;
INVX1 u131 ( .A ( n122 ) , .Y ( n53 ) ) ;
AOI22X1 u132 ( .A ( gre_a_INV_1025_0 ) , .B ( x[7] ) , .C ( n120 ) , 
    .D ( n42 ) , .Y ( n122 ) ) ;
INVX1 u133 ( .A ( n123 ) , .Y ( n51 ) ) ;
AOI22X1 u134 ( .A ( gre_a_INV_1025_0 ) , .B ( x[6] ) , .C ( n120 ) , 
    .D ( n410 ) , .Y ( n123 ) ) ;
INVX1 u135 ( .A ( n124 ) , .Y ( n49 ) ) ;
AOI22X1 u136 ( .A ( gre_a_INV_1025_0 ) , .B ( x[5] ) , .C ( n120 ) , 
    .D ( n40 ) , .Y ( n124 ) ) ;
INVX1 u137 ( .A ( n125 ) , .Y ( n47 ) ) ;
AOI22X1 u138 ( .A ( gre_a_INV_1025_0 ) , .B ( x[4] ) , .C ( n120 ) , 
    .D ( n39 ) , .Y ( n125 ) ) ;
INVX1 u139 ( .A ( n126 ) , .Y ( n45 ) ) ;
AOI22X1 u140 ( .A ( gre_a_INV_1025_0 ) , .B ( x[3] ) , .C ( n120 ) , 
    .D ( n38 ) , .Y ( n126 ) ) ;
INVX1 u141 ( .A ( n127 ) , .Y ( n431 ) ) ;
AOI22X1 u142 ( .A ( gre_a_INV_1025_0 ) , .B ( x[2] ) , .C ( n120 ) , 
    .D ( n37 ) , .Y ( n127 ) ) ;
INVX1 u143 ( .A ( n128 ) , .Y ( n411 ) ) ;
AOI22X1 u144 ( .A ( gre_a_INV_1025_0 ) , .B ( x[1] ) , .C ( n120 ) , 
    .D ( n36 ) , .Y ( n128 ) ) ;
NOR2X1 u145 ( .A ( gre_a_INV_1025_0 ) , .B ( n129 ) , .Y ( n120 ) ) ;
NOR3X1 u146 ( .A ( n93 ) , .B ( vsync ) , .C ( n129 ) , .Y ( n135 ) ) ;
INVX1 u147 ( .A ( n118 ) , .Y ( n129 ) ) ;
OAI21X1 u148 ( .A ( x[8] ) , .B ( x[7] ) , .C ( n130 ) , .Y ( n118 ) ) ;
NAND3X1 u149 ( .A ( n112 ) , .B ( n95 ) , .C ( n110 ) , .Y ( vsync ) ) ;
INVX1 u150 ( .A ( y[6] ) , .Y ( n110 ) ) ;
INVX1 u151 ( .A ( y[8] ) , .Y ( n95 ) ) ;
INVX1 u152 ( .A ( y[7] ) , .Y ( n112 ) ) ;
OAI22X1 u153 ( .A ( x[8] ) , .B ( x[7] ) , .C ( x[0] ) , .D ( n130 ) , 
    .Y ( n93 ) ) ;
NAND3X1 u154 ( .A ( n131 ) , .B ( n132 ) , .C ( n133 ) , .Y ( n130 ) ) ;
NOR3X1 u155 ( .A ( x[1] ) , .B ( x[3] ) , .C ( x[2] ) , .Y ( n133 ) ) ;
NOR2X1 u156 ( .A ( x[8] ) , .B ( x[6] ) , .Y ( n132 ) ) ;
NOR2X1 u157 ( .A ( x[5] ) , .B ( x[4] ) , .Y ( n131 ) ) ;
AND2X1 u158 ( .A ( enable ) , .B ( gre_a_INV_1025_0 ) , .Y ( n8 ) ) ;
TIEHIX1 optlc_444 ( .Y ( optlc_net_68 ) ) ;
INVX8 inv_drc_cln330 ( .A ( ctsbuf_net_432 ) , .Y ( cts0 ) ) ;
INVX8 cts_inv_65319 ( .A ( ctsbuf_net_432 ) , .Y ( ctsbuf_net_129 ) ) ;
INVX8 cts_inv_66320 ( .A ( ctsbuf_net_432 ) , .Y ( ctsbuf_net_230 ) ) ;
INVX8 cts_inv_67321 ( .A ( ctsbuf_net_432 ) , .Y ( ctsbuf_net_331 ) ) ;
INVX8 cts_inv_71325 ( .A ( clk ) , .Y ( ctsbuf_net_432 ) ) ;
INVX8 inv_drc_cln331 ( .A ( ctsbuf_net_432 ) , .Y ( cts1 ) ) ;
TIEHIX1 optlc_445 ( .Y ( optlc_net_69 ) ) ;
TIEHIX1 optlc_446 ( .Y ( optlc_net_70 ) ) ;
TIEHIX1 optlc_447 ( .Y ( optlc_net_71 ) ) ;
TIEHIX1 optlc_448 ( .Y ( optlc_net_72 ) ) ;
TIEHIX1 optlc_449 ( .Y ( optlc_net_73 ) ) ;
TIEHIX1 optlc_450 ( .Y ( optlc_net_74 ) ) ;
TIEHIX1 optlc_451 ( .Y ( optlc_net_75 ) ) ;
TIEHIX1 optlc_452 ( .Y ( optlc_net_76 ) ) ;
TIEHIX1 optlc_453 ( .Y ( optlc_net_77 ) ) ;
TIEHIX1 optlc_454 ( .Y ( optlc_net_78 ) ) ;
TIEHIX1 optlc_455 ( .Y ( optlc_net_79 ) ) ;
TIEHIX1 optlc_456 ( .Y ( optlc_net_80 ) ) ;
TIEHIX1 optlc_457 ( .Y ( optlc_net_81 ) ) ;
TIEHIX1 optlc_458 ( .Y ( optlc_net_82 ) ) ;
TIEHIX1 optlc_459 ( .Y ( optlc_net_83 ) ) ;
TIEHIX1 optlc_460 ( .Y ( optlc_net_84 ) ) ;
TIEHIX1 optlc_461 ( .Y ( optlc_net_85 ) ) ;
NAND3X1 ctmTdsLR_1_409 ( .A ( n100 ) , .B ( n98 ) , .C ( n102 ) , 
    .Y ( tmp_net59 ) ) ;
BUFX2 ctmTdsLR_1_416 ( .A ( n134 ) , .Y ( p_tick ) ) ;
INVX2 gre_a_INV_1025_inst_462 ( .A ( pixel_tick ) , .Y ( gre_a_INV_1025_0 ) ) ;
endmodule


