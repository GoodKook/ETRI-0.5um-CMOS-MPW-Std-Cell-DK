

    module pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9_DW01_add_0 ( 
        a, b, ci, sum, co );
  input [8:0] a;
  input [8:0] b;
  output [8:0] sum;
  input ci;
  output co;
  wire   n1;
  wire   [8:1] carry;

  FAX1 u1_8 ( .A(a[8]), .B(b[8]), .CI(carry[8]), .CO(), .S(sum[8]) );
  FAX1 u1_7 ( .A(a[7]), .B(b[7]), .CI(carry[7]), .CO(carry[8]), .S(sum[7]) );
  FAX1 u1_6 ( .A(a[6]), .B(b[6]), .CI(carry[6]), .CO(carry[7]), .S(sum[6]) );
  FAX1 u1_5 ( .A(a[5]), .B(b[5]), .CI(carry[5]), .CO(carry[6]), .S(sum[5]) );
  FAX1 u1_4 ( .A(a[4]), .B(b[4]), .CI(carry[4]), .CO(carry[5]), .S(sum[4]) );
  FAX1 u1_3 ( .A(a[3]), .B(b[3]), .CI(carry[3]), .CO(carry[4]), .S(sum[3]) );
  FAX1 u1_2 ( .A(a[2]), .B(b[2]), .CI(carry[2]), .CO(carry[3]), .S(sum[2]) );
  FAX1 u1_1 ( .A(a[1]), .B(b[1]), .CI(carry[1]), .CO(carry[2]), .S(sum[1]) );
  XOR2X1 u1 ( .A(b[0]), .B(a[0]), .Y(sum[0]) );
  NAND2X1 u2 ( .A(b[0]), .B(a[0]), .Y(n1) );
  INVX2 u3 ( .A(n1), .Y(carry[1]) );
endmodule



    module pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9_DW01_add_1 ( 
        a, b, ci, sum, co );
  input [8:0] a;
  input [8:0] b;
  output [8:0] sum;
  input ci;
  output co;
  wire   n1;
  wire   [8:1] carry;

  FAX1 u1_8 ( .A(a[8]), .B(b[8]), .CI(carry[8]), .CO(), .S(sum[8]) );
  FAX1 u1_7 ( .A(a[7]), .B(b[7]), .CI(carry[7]), .CO(carry[8]), .S(sum[7]) );
  FAX1 u1_6 ( .A(a[6]), .B(b[6]), .CI(carry[6]), .CO(carry[7]), .S(sum[6]) );
  FAX1 u1_5 ( .A(a[5]), .B(b[5]), .CI(carry[5]), .CO(carry[6]), .S(sum[5]) );
  FAX1 u1_4 ( .A(a[4]), .B(b[4]), .CI(carry[4]), .CO(carry[5]), .S(sum[4]) );
  FAX1 u1_3 ( .A(a[3]), .B(b[3]), .CI(carry[3]), .CO(carry[4]), .S(sum[3]) );
  FAX1 u1_2 ( .A(a[2]), .B(b[2]), .CI(carry[2]), .CO(carry[3]), .S(sum[2]) );
  FAX1 u1_1 ( .A(a[1]), .B(b[1]), .CI(carry[1]), .CO(carry[2]), .S(sum[1]) );
  XOR2X1 u1 ( .A(b[0]), .B(a[0]), .Y(sum[0]) );
  NAND2X1 u2 ( .A(b[0]), .B(a[0]), .Y(n1) );
  INVX2 u3 ( .A(n1), .Y(carry[1]) );
endmodule



    module pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9_DW01_add_2 ( 
        a, b, ci, sum, co );
  input [8:0] a;
  input [8:0] b;
  output [8:0] sum;
  input ci;
  output co;
  wire   n1;
  wire   [8:1] carry;

  FAX1 u1_8 ( .A(a[8]), .B(b[8]), .CI(carry[8]), .CO(), .S(sum[8]) );
  FAX1 u1_7 ( .A(a[7]), .B(b[7]), .CI(carry[7]), .CO(carry[8]), .S(sum[7]) );
  FAX1 u1_6 ( .A(a[6]), .B(b[6]), .CI(carry[6]), .CO(carry[7]), .S(sum[6]) );
  FAX1 u1_5 ( .A(a[5]), .B(b[5]), .CI(carry[5]), .CO(carry[6]), .S(sum[5]) );
  FAX1 u1_4 ( .A(a[4]), .B(b[4]), .CI(carry[4]), .CO(carry[5]), .S(sum[4]) );
  FAX1 u1_3 ( .A(a[3]), .B(b[3]), .CI(carry[3]), .CO(carry[4]), .S(sum[3]) );
  FAX1 u1_2 ( .A(a[2]), .B(b[2]), .CI(carry[2]), .CO(carry[3]), .S(sum[2]) );
  FAX1 u1_1 ( .A(a[1]), .B(b[1]), .CI(carry[1]), .CO(carry[2]), .S(sum[1]) );
  XOR2X1 u1 ( .A(b[0]), .B(a[0]), .Y(sum[0]) );
  NAND2X1 u2 ( .A(b[0]), .B(a[0]), .Y(n1) );
  INVX2 u3 ( .A(n1), .Y(carry[1]) );
endmodule



    module pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9_DW01_inc_0 ( 
        a, sum );
  input [8:0] a;
  output [8:0] sum;

  wire   [8:2] carry;

  HAX1 u1_1_7 ( .A(a[7]), .B(carry[7]), .CO(carry[8]), .S(sum[7]) );
  HAX1 u1_1_6 ( .A(a[6]), .B(carry[6]), .CO(carry[7]), .S(sum[6]) );
  HAX1 u1_1_5 ( .A(a[5]), .B(carry[5]), .CO(carry[6]), .S(sum[5]) );
  HAX1 u1_1_4 ( .A(a[4]), .B(carry[4]), .CO(carry[5]), .S(sum[4]) );
  HAX1 u1_1_3 ( .A(a[3]), .B(carry[3]), .CO(carry[4]), .S(sum[3]) );
  HAX1 u1_1_2 ( .A(a[2]), .B(carry[2]), .CO(carry[3]), .S(sum[2]) );
  HAX1 u1_1_1 ( .A(a[1]), .B(a[0]), .CO(carry[2]), .S(sum[1]) );
  XOR2X1 u1 ( .A(carry[8]), .B(a[8]), .Y(sum[8]) );
  INVX1 u2 ( .A(a[0]), .Y(sum[0]) );
endmodule



    module pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9 ( 
        clk, reset, up, down, video_on, x, y, rgb );
  input [8:0] x;
  input [8:0] y;
  input clk, reset, up, down, video_on;
  output rgb;
  wire   n440, n510, n610, n2810, n2910, n3010, n3110, n3210, n3310, n3410,
         n3510, n3610, n3810, n3910, n4010, n4110, n4210, n4310, n441, n450,
         n460, rom_bit, n620, n630, n640, n650, n660, n670, n680, n690, n700,
         n720, n730, n740, n750, n760, n770, n780, n790, n800, n810, n830,
         n840, n850, n860, n870, n880, n890, n900, n910, n1490, n1500, n1510,
         n1520, n1530, n1540, n1550, n1560, n1570, n1580, n1590, n1600, n1610,
         n1620, n1630, n1640, n1650, n1660, n1670, n1680, n1690, n1700, n1710,
         n1720, n1730, n1740, n1750, n12, n205, n207, n209, n211, n213, n215,
         n217, n219, n229, n232, n234, n236, n238, n240, n242, n244, n246,
         n256, n258, n260, n262, n264, n266, n268, n270, n272, n274, n275,
         n277, n278, n279, n280, n281, n282, n283, n284, n285, n286, n287,
         n288, n289, n290, n291, n292, n293, n294, sub_158_cf_carry_2_,
         sub_158_cf_carry_3_, sub_158_cf_carry_4_, sub_158_cf_carry_5_,
         sub_158_cf_carry_6_, sub_158_cf_carry_7_, sub_158_cf_carry_8_,
         sub_157_cf_carry_2_, sub_157_cf_carry_3_, sub_157_cf_carry_4_,
         sub_157_cf_carry_5_, sub_157_cf_carry_6_, sub_157_cf_carry_7_,
         sub_157_cf_carry_8_, sub_140_cf_carry_2_, sub_140_cf_carry_3_,
         sub_140_cf_carry_4_, sub_140_cf_carry_5_, sub_140_cf_carry_6_,
         sub_140_cf_carry_7_, sub_140_cf_carry_8_, n1, n2, n3, n470, n500,
         n600, n7, n8, n9, n10, n11, n13, n14, n15, n16, n17, n18, n19, n20,
         n21, n22, n23, n24, n25, n26, n27, n2811, n2950, n3000, n3100, n3200,
         n3300, n3400, n3500, n3600, n37, n3800, n3900, n4000, n4100, n4200,
         n4300, n442, n451, n461, n471, n48, n49, n501, n51, n52, n53, n54,
         n55, n56, n57, n58, n59, n601, n61, n621, n631, n641, n651, n661,
         n671, n681, n691, n701, n71, n721, n731, n741, n751, n761, n771, n781,
         n791, n801, n811, n82, n831, n841, n851, n861, n871, n881, n891, n901,
         n911, n92, n93, n94, n95, n96, n97, n98, n99, n100, n101, n102, n103,
         n104, n105, n106, n107, n108, n109, n110, n111, n112, n113, n114,
         n115, n116, n117, n118, n119, n120, n121, n122, n123, n124, n125,
         n126, n127, n128, n129, n130, n131, n132, n133, n134, n135, n136,
         n137, n138, n139, n140, n141, n142, n143, n144, n145, n146, n147,
         n148, n1491, n1501, n1511, n1521, n1531, n1541, n1551, n1561, n1571,
         n1581, n1591, n1601, n1611, n1621, n1631, n1641, n1651, n1661, n1671,
         n1681, n1691, n1701, n1711, n1721, n1731, n1741, n1751, n176, n177,
         n178, n179, n180, n181, n182, n183, n184, n185, n186, n187, n188,
         n189, n190, n191, n192, n193, n194, n195, n196, n197, n198, n199,
         n200, n201, n202, n203, n204, n206, n208, n210, n212, n214, n216,
         n218, n220, n221, n222, n223, n224, n225, n226, n227, n228, n230,
         n231, n233, n235, n237, n239, n241, n243, n245, n247, n248, n249,
         n250, n251, n252, n253, n254, n255, n257, n259, n261, n263, n265,
         n267, n269, n271, n273, n276, n2951, n296, n297, n298, n299, n3001,
         n301, n302, n303, n304, n305, n306, n307, n308, n309, n3101, n311,
         n312, n313, n314, n315, n316, n317, n318, n319, n3201, n321, n322,
         n323, n324, n325, n326, n327, n328, n329, n3301, n331, n332, n333,
         n334, n335, n336, n337, n338, n339, n3401, n341, n342, n343, n344,
         n345, n346, n347, n348, n349, n3501, n351, n352, n353, n354, n355,
         n356, n357, n358, n359, n3601, n361, n362, n363, n364, n365, n366,
         n367, n368, n369, n370, n371, n372, n373, n374, n375, n376, n377,
         n378, n379, n3801, n381, n382, n383, n384, n385, n386, n387, n388,
         n389, n3901, n391, n392, n393, n394, n395, n396, n397, n398, n399,
         n4001, n401, n402, n403, n404, n405, n406, n407, n408, n409, n4101,
         n411, n412, n413, n414, n415, n416, n417, n418, n419, n4201, n421,
         n422, n423, n424, n425, n426, n427, n428, n429, n4301, n431, n432,
         n433, n434, n435, n436, n437, n438, n439;
  wire   [8:0] x_delta_reg;
  wire   [8:0] y_delta_reg;
  wire   [1:0] rom_data;
  wire   [8:0] y_pad_b;
  wire   [8:0] x_ball_r;
  wire   [8:0] y_ball_b;

  DFFSRX1 y_delta_reg_reg_1_ ( .D(n294), .CLK(clk), .R(n16), .S(n15), .Q(
        y_delta_reg[1]) );
  DFFSRX1 x_delta_reg_reg_1_ ( .D(n286), .CLK(clk), .R(n16), .S(n3), .Q(
        x_delta_reg[1]) );
  pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9_DW01_add_0 add_179 ( 
        .a({n1580, n1590, n1600, n1610, n1620, n1630, n1640, n1650, n1660}), 
        .b(x_delta_reg), .ci(n12), .sum({n910, n900, n890, n880, n870, n860, 
        n850, n840, n830}), .co() );
  pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9_DW01_add_1 add_176 ( 
        .a({n1580, n1590, n1600, n1610, n1620, n1630, n1640, n1650, n1660}), 
        .b(x_delta_reg), .ci(n12), .sum({n800, n790, n780, n770, n760, n750, 
        n740, n730, n720}), .co() );
  pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9_DW01_add_2 add_169 ( 
        .a({n1670, n1680, n1690, n1700, n1710, n1720, n1730, n1740, n1750}), 
        .b(y_delta_reg), .ci(n12), .sum({n700, n690, n680, n670, n660, n650, 
        n640, n630, n620}), .co() );
  pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9_DW01_inc_0 add_151 ( 
        .a({n1490, n1500, n1510, n1520, n1530, n1540, n1550, n1560, n1570}), 
        .sum({n460, n450, n441, n4310, n4210, n4110, n4010, n3910, n3810}) );
  DFFSRX1 y_ball_reg_reg_3_ ( .D(n242), .CLK(clk), .R(n11), .S(n16), .Q(n1720)
         );
  DFFSRX1 y_ball_reg_reg_2_ ( .D(n244), .CLK(clk), .R(n15), .S(n16), .Q(n1730)
         );
  DFFSRX1 y_ball_reg_reg_0_ ( .D(n258), .CLK(clk), .R(n2), .S(n16), .Q(n1750)
         );
  DFFSRX1 y_ball_reg_reg_1_ ( .D(n246), .CLK(clk), .R(n14), .S(n16), .Q(n1740)
         );
  DFFSRX1 y_ball_reg_reg_4_ ( .D(n240), .CLK(clk), .R(n13), .S(n16), .Q(n1710)
         );
  DFFSRX1 y_ball_reg_reg_5_ ( .D(n238), .CLK(clk), .R(n11), .S(n16), .Q(n1700)
         );
  DFFSRX1 y_delta_reg_reg_0_ ( .D(n256), .CLK(clk), .R(n3), .S(n16), .Q(
        y_delta_reg[0]) );
  DFFSRX1 y_ball_reg_reg_6_ ( .D(n236), .CLK(clk), .R(n15), .S(n16), .Q(n1690)
         );
  DFFSRX1 y_delta_reg_reg_8_ ( .D(n287), .CLK(clk), .R(n14), .S(n16), .Q(
        y_delta_reg[8]) );
  DFFSRX1 y_delta_reg_reg_7_ ( .D(n288), .CLK(clk), .R(n13), .S(n16), .Q(
        y_delta_reg[7]) );
  DFFSRX1 y_delta_reg_reg_6_ ( .D(n289), .CLK(clk), .R(n2), .S(n16), .Q(
        y_delta_reg[6]) );
  DFFSRX1 y_delta_reg_reg_5_ ( .D(n290), .CLK(clk), .R(n11), .S(n16), .Q(
        y_delta_reg[5]) );
  DFFSRX1 y_delta_reg_reg_4_ ( .D(n291), .CLK(clk), .R(n15), .S(n16), .Q(
        y_delta_reg[4]) );
  DFFSRX1 y_delta_reg_reg_3_ ( .D(n292), .CLK(clk), .R(n14), .S(n16), .Q(
        y_delta_reg[3]) );
  DFFSRX1 y_delta_reg_reg_2_ ( .D(n293), .CLK(clk), .R(n3), .S(n16), .Q(
        y_delta_reg[2]) );
  DFFSRX1 y_ball_reg_reg_7_ ( .D(n234), .CLK(clk), .R(n13), .S(n16), .Q(n1680)
         );
  DFFSRX1 y_pad_reg_reg_8_ ( .D(n274), .CLK(clk), .R(n11), .S(n16), .Q(n1490)
         );
  DFFSRX1 y_pad_reg_reg_7_ ( .D(n272), .CLK(clk), .R(n15), .S(n16), .Q(n1500)
         );
  DFFSRX1 y_pad_reg_reg_6_ ( .D(n268), .CLK(clk), .R(n2), .S(n16), .Q(n1510)
         );
  DFFSRX1 y_pad_reg_reg_5_ ( .D(n266), .CLK(clk), .R(n14), .S(n16), .Q(n1520)
         );
  DFFSRX1 y_pad_reg_reg_4_ ( .D(n264), .CLK(clk), .R(n13), .S(n16), .Q(n1530)
         );
  DFFSRX1 y_pad_reg_reg_3_ ( .D(n262), .CLK(clk), .R(n11), .S(n16), .Q(n1540)
         );
  DFFSRX1 y_pad_reg_reg_2_ ( .D(n260), .CLK(clk), .R(n3), .S(n16), .Q(n1550)
         );
  DFFSRX1 y_pad_reg_reg_1_ ( .D(n270), .CLK(clk), .R(n15), .S(n16), .Q(n1560)
         );
  DFFSRX1 y_pad_reg_reg_0_ ( .D(n277), .CLK(clk), .R(n14), .S(n16), .Q(n1570)
         );
  DFFSRX1 y_ball_reg_reg_8_ ( .D(n232), .CLK(clk), .R(n13), .S(n16), .Q(n1670)
         );
  DFFSRX1 x_ball_reg_reg_8_ ( .D(n229), .CLK(clk), .R(n2), .S(n16), .Q(n1580)
         );
  DFFSRX1 x_ball_reg_reg_7_ ( .D(n219), .CLK(clk), .R(n11), .S(n16), .Q(n1590)
         );
  DFFSRX1 x_ball_reg_reg_6_ ( .D(n217), .CLK(clk), .R(n15), .S(n16), .Q(n1600)
         );
  DFFSRX1 x_ball_reg_reg_5_ ( .D(n215), .CLK(clk), .R(n14), .S(n16), .Q(n1610)
         );
  DFFSRX1 x_ball_reg_reg_4_ ( .D(n213), .CLK(clk), .R(n3), .S(n16), .Q(n1620)
         );
  DFFSRX1 x_ball_reg_reg_3_ ( .D(n211), .CLK(clk), .R(n13), .S(n16), .Q(n1630)
         );
  DFFSRX1 x_ball_reg_reg_2_ ( .D(n209), .CLK(clk), .R(n11), .S(n16), .Q(n1640)
         );
  DFFSRX1 x_ball_reg_reg_1_ ( .D(n207), .CLK(clk), .R(n15), .S(n16), .Q(n1650)
         );
  DFFSRX1 x_ball_reg_reg_0_ ( .D(n205), .CLK(clk), .R(n2), .S(n16), .Q(n1660)
         );
  DFFSRX1 x_delta_reg_reg_8_ ( .D(n279), .CLK(clk), .R(n14), .S(n16), .Q(
        x_delta_reg[8]) );
  DFFSRX1 x_delta_reg_reg_7_ ( .D(n280), .CLK(clk), .R(n13), .S(n16), .Q(
        x_delta_reg[7]) );
  DFFSRX1 x_delta_reg_reg_6_ ( .D(n281), .CLK(clk), .R(n11), .S(n16), .Q(
        x_delta_reg[6]) );
  DFFSRX1 x_delta_reg_reg_5_ ( .D(n282), .CLK(clk), .R(n3), .S(n16), .Q(
        x_delta_reg[5]) );
  DFFSRX1 x_delta_reg_reg_4_ ( .D(n283), .CLK(clk), .R(n15), .S(n16), .Q(
        x_delta_reg[4]) );
  DFFSRX1 x_delta_reg_reg_3_ ( .D(n284), .CLK(clk), .R(n14), .S(n16), .Q(
        x_delta_reg[3]) );
  DFFSRX1 x_delta_reg_reg_2_ ( .D(n285), .CLK(clk), .R(n13), .S(n16), .Q(
        x_delta_reg[2]) );
  DFFSRX1 x_delta_reg_reg_0_ ( .D(n278), .CLK(clk), .R(n2), .S(n16), .Q(
        x_delta_reg[0]) );
  TIEHIX1 u3 ( .Y(n16) );
  INVX1 u4 ( .A(n14), .Y(n1) );
  INVX1 u5 ( .A(n1), .Y(n2) );
  INVX1 u6 ( .A(n1), .Y(n3) );
  INVX1 u7 ( .A(n371), .Y(n470) );
  INVX1 u8 ( .A(n470), .Y(n500) );
  INVX1 u9 ( .A(n389), .Y(n600) );
  INVX1 u10 ( .A(n600), .Y(n7) );
  INVX1 u11 ( .A(n600), .Y(n8) );
  INVX1 u12 ( .A(n600), .Y(n9) );
  INVX1 u13 ( .A(n275), .Y(n10) );
  INVX1 u14 ( .A(n10), .Y(n11) );
  INVX1 u15 ( .A(n10), .Y(n13) );
  INVX1 u16 ( .A(n10), .Y(n14) );
  INVX1 u17 ( .A(n10), .Y(n15) );
  TIELOX1 u18 ( .Y(n12) );
  INVX1 u19 ( .A(n1570), .Y(y_pad_b[0]) );
  INVX2 u20 ( .A(n17), .Y(sub_140_cf_carry_5_) );
  NAND2X1 u21 ( .A(n1530), .B(sub_140_cf_carry_4_), .Y(n17) );
  XOR2X1 u22 ( .A(n1530), .B(sub_140_cf_carry_4_), .Y(y_pad_b[4]) );
  INVX2 u23 ( .A(n18), .Y(sub_140_cf_carry_6_) );
  NAND2X1 u24 ( .A(n1520), .B(sub_140_cf_carry_5_), .Y(n18) );
  XOR2X1 u25 ( .A(n1520), .B(sub_140_cf_carry_5_), .Y(y_pad_b[5]) );
  INVX2 u26 ( .A(n19), .Y(sub_140_cf_carry_7_) );
  NAND2X1 u27 ( .A(n1510), .B(sub_140_cf_carry_6_), .Y(n19) );
  XOR2X1 u28 ( .A(n1510), .B(sub_140_cf_carry_6_), .Y(y_pad_b[6]) );
  INVX2 u29 ( .A(n20), .Y(sub_140_cf_carry_8_) );
  NAND2X1 u30 ( .A(n1500), .B(sub_140_cf_carry_7_), .Y(n20) );
  XOR2X1 u31 ( .A(n1500), .B(sub_140_cf_carry_7_), .Y(y_pad_b[7]) );
  XOR2X1 u32 ( .A(n1490), .B(sub_140_cf_carry_8_), .Y(y_pad_b[8]) );
  INVX2 u33 ( .A(n1570), .Y(n21) );
  INVX2 u34 ( .A(n1560), .Y(n22) );
  XOR2X1 u35 ( .A(n21), .B(n1560), .Y(y_pad_b[1]) );
  NAND2X1 u36 ( .A(n22), .B(n21), .Y(sub_140_cf_carry_2_) );
  INVX2 u37 ( .A(sub_140_cf_carry_2_), .Y(n23) );
  INVX2 u38 ( .A(n1550), .Y(n24) );
  XOR2X1 u39 ( .A(n23), .B(n1550), .Y(y_pad_b[2]) );
  NAND2X1 u40 ( .A(n24), .B(n23), .Y(sub_140_cf_carry_3_) );
  INVX2 u41 ( .A(sub_140_cf_carry_3_), .Y(n25) );
  INVX2 u42 ( .A(n1540), .Y(n26) );
  XOR2X1 u43 ( .A(n25), .B(n1540), .Y(y_pad_b[3]) );
  NAND2X1 u44 ( .A(n26), .B(n25), .Y(sub_140_cf_carry_4_) );
  INVX1 u45 ( .A(n1570), .Y(n2810) );
  INVX1 u46 ( .A(n1560), .Y(n27) );
  NOR2X1 u47 ( .A(n1560), .B(n1570), .Y(n3100) );
  INVX1 u48 ( .A(n3100), .Y(n2811) );
  OAI21X1 u49 ( .A(n2810), .B(n27), .C(n2811), .Y(n2910) );
  INVX1 u50 ( .A(n1550), .Y(n3000) );
  NOR2X1 u51 ( .A(n2811), .B(n1550), .Y(n2950) );
  INVX1 u52 ( .A(n2950), .Y(n3200) );
  OAI21X1 u53 ( .A(n3100), .B(n3000), .C(n3200), .Y(n3010) );
  NOR2X1 u54 ( .A(n3200), .B(n1540), .Y(n3500) );
  AOI21X1 u55 ( .A(n3200), .B(n1540), .C(n3500), .Y(n3300) );
  INVX1 u56 ( .A(n3300), .Y(n3110) );
  INVX1 u57 ( .A(n1530), .Y(n3400) );
  NAND2X1 u58 ( .A(n3500), .B(n3400), .Y(n3600) );
  OAI21X1 u59 ( .A(n3500), .B(n3400), .C(n3600), .Y(n3210) );
  NOR2X1 u60 ( .A(n3600), .B(n1520), .Y(n3900) );
  AOI21X1 u61 ( .A(n3600), .B(n1520), .C(n3900), .Y(n37) );
  INVX1 u62 ( .A(n37), .Y(n3310) );
  INVX1 u63 ( .A(n1510), .Y(n3800) );
  NAND2X1 u64 ( .A(n3900), .B(n3800), .Y(n4000) );
  OAI21X1 u65 ( .A(n3900), .B(n3800), .C(n4000), .Y(n3410) );
  XNOR2X1 u66 ( .A(n1500), .B(n4000), .Y(n3510) );
  NOR2X1 u67 ( .A(n1500), .B(n4000), .Y(n4100) );
  XOR2X1 u68 ( .A(n1490), .B(n4100), .Y(n3610) );
  INVX1 u69 ( .A(n1660), .Y(x_ball_r[0]) );
  INVX2 u70 ( .A(n4200), .Y(sub_157_cf_carry_4_) );
  NAND2X1 u71 ( .A(n1630), .B(sub_157_cf_carry_3_), .Y(n4200) );
  XOR2X1 u72 ( .A(n1630), .B(sub_157_cf_carry_3_), .Y(x_ball_r[3]) );
  INVX2 u73 ( .A(n4300), .Y(sub_157_cf_carry_5_) );
  NAND2X1 u74 ( .A(n1620), .B(sub_157_cf_carry_4_), .Y(n4300) );
  XOR2X1 u75 ( .A(n1620), .B(sub_157_cf_carry_4_), .Y(x_ball_r[4]) );
  INVX2 u76 ( .A(n442), .Y(sub_157_cf_carry_6_) );
  NAND2X1 u77 ( .A(n1610), .B(sub_157_cf_carry_5_), .Y(n442) );
  XOR2X1 u78 ( .A(n1610), .B(sub_157_cf_carry_5_), .Y(x_ball_r[5]) );
  INVX2 u79 ( .A(n451), .Y(sub_157_cf_carry_7_) );
  NAND2X1 u80 ( .A(n1600), .B(sub_157_cf_carry_6_), .Y(n451) );
  XOR2X1 u81 ( .A(n1600), .B(sub_157_cf_carry_6_), .Y(x_ball_r[6]) );
  INVX2 u82 ( .A(n461), .Y(sub_157_cf_carry_8_) );
  NAND2X1 u83 ( .A(n1590), .B(sub_157_cf_carry_7_), .Y(n461) );
  XOR2X1 u84 ( .A(n1590), .B(sub_157_cf_carry_7_), .Y(x_ball_r[7]) );
  XOR2X1 u85 ( .A(n1580), .B(sub_157_cf_carry_8_), .Y(x_ball_r[8]) );
  INVX2 u86 ( .A(n1660), .Y(n471) );
  INVX2 u87 ( .A(n1650), .Y(n48) );
  XOR2X1 u88 ( .A(n471), .B(n1650), .Y(x_ball_r[1]) );
  NAND2X1 u89 ( .A(n48), .B(n471), .Y(sub_157_cf_carry_2_) );
  INVX2 u90 ( .A(sub_157_cf_carry_2_), .Y(n49) );
  INVX2 u91 ( .A(n1640), .Y(n501) );
  XOR2X1 u92 ( .A(n49), .B(n1640), .Y(x_ball_r[2]) );
  NAND2X1 u93 ( .A(n501), .B(n49), .Y(sub_157_cf_carry_3_) );
  INVX1 u94 ( .A(n1750), .Y(y_ball_b[0]) );
  INVX2 u95 ( .A(n51), .Y(sub_158_cf_carry_4_) );
  NAND2X1 u96 ( .A(n1720), .B(sub_158_cf_carry_3_), .Y(n51) );
  XOR2X1 u97 ( .A(n1720), .B(sub_158_cf_carry_3_), .Y(y_ball_b[3]) );
  INVX2 u98 ( .A(n52), .Y(sub_158_cf_carry_5_) );
  NAND2X1 u99 ( .A(n1710), .B(sub_158_cf_carry_4_), .Y(n52) );
  XOR2X1 u100 ( .A(n1710), .B(sub_158_cf_carry_4_), .Y(y_ball_b[4]) );
  INVX2 u101 ( .A(n53), .Y(sub_158_cf_carry_6_) );
  NAND2X1 u102 ( .A(n1700), .B(sub_158_cf_carry_5_), .Y(n53) );
  XOR2X1 u103 ( .A(n1700), .B(sub_158_cf_carry_5_), .Y(y_ball_b[5]) );
  INVX2 u104 ( .A(n54), .Y(sub_158_cf_carry_7_) );
  NAND2X1 u105 ( .A(n1690), .B(sub_158_cf_carry_6_), .Y(n54) );
  XOR2X1 u106 ( .A(n1690), .B(sub_158_cf_carry_6_), .Y(y_ball_b[6]) );
  INVX2 u107 ( .A(n55), .Y(sub_158_cf_carry_8_) );
  NAND2X1 u108 ( .A(n1680), .B(sub_158_cf_carry_7_), .Y(n55) );
  XOR2X1 u109 ( .A(n1680), .B(sub_158_cf_carry_7_), .Y(y_ball_b[7]) );
  XOR2X1 u110 ( .A(n1670), .B(sub_158_cf_carry_8_), .Y(y_ball_b[8]) );
  INVX2 u111 ( .A(n1750), .Y(n56) );
  INVX2 u112 ( .A(n1740), .Y(n57) );
  XOR2X1 u113 ( .A(n56), .B(n1740), .Y(y_ball_b[1]) );
  NAND2X1 u114 ( .A(n57), .B(n56), .Y(sub_158_cf_carry_2_) );
  INVX2 u115 ( .A(sub_158_cf_carry_2_), .Y(n58) );
  INVX2 u116 ( .A(n1730), .Y(n59) );
  XOR2X1 u117 ( .A(n58), .B(n1730), .Y(y_ball_b[2]) );
  NAND2X1 u118 ( .A(n59), .B(n58), .Y(sub_158_cf_carry_3_) );
  NAND2X1 u119 ( .A(n601), .B(n61), .Y(rom_bit) );
  XOR2X1 u120 ( .A(n440), .B(n610), .Y(n621) );
  INVX2 u121 ( .A(n610), .Y(n631) );
  XOR2X1 u122 ( .A(n631), .B(n510), .Y(n61) );
  MUX2X1 u123 ( .B(rom_data[0]), .A(rom_data[1]), .S(n621), .Y(n601) );
  NOR2X1 u124 ( .A(n760), .B(n750), .Y(n661) );
  NOR2X1 u125 ( .A(n780), .B(n770), .Y(n651) );
  NOR3X1 u126 ( .A(n720), .B(n740), .C(n730), .Y(n641) );
  NAND3X1 u127 ( .A(n661), .B(n651), .C(n641), .Y(n671) );
  AOI21X1 u128 ( .A(n790), .B(n671), .C(n800), .Y(n681) );
  INVX1 u129 ( .A(n681), .Y(n810) );
  NAND2X1 u130 ( .A(n691), .B(n701), .Y(rom_data[1]) );
  XNOR2X1 u131 ( .A(n71), .B(n721), .Y(n691) );
  AOI21X1 u132 ( .A(y[0]), .B(n731), .C(n741), .Y(n71) );
  INVX1 u133 ( .A(n701), .Y(rom_data[0]) );
  XOR2X1 u134 ( .A(n751), .B(n761), .Y(n701) );
  XOR2X1 u135 ( .A(y[1]), .B(n1740), .Y(n761) );
  XOR2X1 u136 ( .A(n721), .B(n741), .Y(n751) );
  XNOR2X1 u137 ( .A(n771), .B(n781), .Y(n721) );
  XOR2X1 u138 ( .A(y[2]), .B(n1730), .Y(n781) );
  AOI21X1 u139 ( .A(n791), .B(n801), .C(n811), .Y(rgb) );
  INVX1 u140 ( .A(video_on), .Y(n811) );
  NAND3X1 u141 ( .A(n82), .B(n831), .C(n841), .Y(n801) );
  MUX2X1 u142 ( .B(n851), .A(n861), .S(x[6]), .Y(n841) );
  NAND3X1 u143 ( .A(n871), .B(n881), .C(n891), .Y(n861) );
  NOR3X1 u144 ( .A(n901), .B(n911), .C(n92), .Y(n891) );
  AOI22X1 u145 ( .A(x[0]), .B(n93), .C(n94), .D(n95), .Y(n881) );
  OAI21X1 u146 ( .A(y[8]), .B(n96), .C(n97), .Y(n95) );
  AOI22X1 u147 ( .A(n98), .B(n99), .C(n1500), .D(n100), .Y(n97) );
  INVX1 u148 ( .A(n101), .Y(n100) );
  NAND2X1 u149 ( .A(n101), .B(n102), .Y(n98) );
  AOI22X1 u150 ( .A(n103), .B(n1510), .C(n104), .D(n105), .Y(n101) );
  OR2X1 u151 ( .A(n103), .B(n1510), .Y(n105) );
  AOI22X1 u152 ( .A(n106), .B(n107), .C(n108), .D(y[5]), .Y(n103) );
  OR2X1 u153 ( .A(n107), .B(n106), .Y(n108) );
  AOI22X1 u154 ( .A(n109), .B(n1530), .C(n110), .D(n111), .Y(n107) );
  OR2X1 u155 ( .A(n109), .B(n1530), .Y(n111) );
  AOI22X1 u156 ( .A(n112), .B(n113), .C(n114), .D(y[3]), .Y(n109) );
  OR2X1 u157 ( .A(n113), .B(n112), .Y(n114) );
  AOI22X1 u158 ( .A(n115), .B(n1550), .C(n116), .D(n117), .Y(n113) );
  OR2X1 u159 ( .A(n115), .B(n1550), .Y(n117) );
  AOI21X1 u160 ( .A(n118), .B(n119), .C(n120), .Y(n115) );
  INVX1 u161 ( .A(n121), .Y(n120) );
  OAI21X1 u162 ( .A(n119), .B(n118), .C(y[1]), .Y(n121) );
  NAND2X1 u163 ( .A(n1570), .B(n122), .Y(n119) );
  NAND2X1 u164 ( .A(y[8]), .B(n96), .Y(n94) );
  AOI21X1 u165 ( .A(n123), .B(n124), .C(n125), .Y(n871) );
  OAI21X1 u166 ( .A(y_pad_b[8]), .B(n126), .C(n127), .Y(n124) );
  AOI22X1 u167 ( .A(n128), .B(n129), .C(y[7]), .D(n130), .Y(n127) );
  OR2X1 u168 ( .A(n130), .B(y[7]), .Y(n128) );
  OAI22X1 u169 ( .A(n131), .B(n104), .C(y_pad_b[6]), .D(n132), .Y(n130) );
  AND2X1 u170 ( .A(n131), .B(n104), .Y(n132) );
  OAI21X1 u171 ( .A(y[5]), .B(n133), .C(n134), .Y(n131) );
  INVX1 u172 ( .A(n135), .Y(n134) );
  AOI21X1 u173 ( .A(n133), .B(y[5]), .C(n136), .Y(n135) );
  OAI22X1 u174 ( .A(n137), .B(n110), .C(y_pad_b[4]), .D(n138), .Y(n133) );
  AND2X1 u175 ( .A(n137), .B(n110), .Y(n138) );
  OAI21X1 u176 ( .A(y[3]), .B(n139), .C(n140), .Y(n137) );
  INVX1 u177 ( .A(n141), .Y(n140) );
  AOI21X1 u178 ( .A(n139), .B(y[3]), .C(n142), .Y(n141) );
  OAI22X1 u179 ( .A(n116), .B(n143), .C(y_pad_b[2]), .D(n144), .Y(n139) );
  AND2X1 u180 ( .A(n143), .B(n116), .Y(n144) );
  OAI21X1 u181 ( .A(y[1]), .B(n145), .C(n146), .Y(n143) );
  INVX1 u182 ( .A(n147), .Y(n146) );
  AOI21X1 u183 ( .A(y[1]), .B(n145), .C(n148), .Y(n147) );
  NOR2X1 u184 ( .A(n122), .B(y_pad_b[0]), .Y(n145) );
  NAND2X1 u185 ( .A(y_pad_b[8]), .B(n126), .Y(n123) );
  NAND3X1 u186 ( .A(n92), .B(n901), .C(n1491), .Y(n851) );
  MUX2X1 u187 ( .B(n911), .A(n1501), .S(n93), .Y(n1491) );
  NOR2X1 u188 ( .A(n1511), .B(n1521), .Y(n93) );
  NOR2X1 u189 ( .A(n1531), .B(n911), .Y(n1501) );
  NAND3X1 u190 ( .A(rom_bit), .B(n1541), .C(n1551), .Y(n791) );
  NOR3X1 u191 ( .A(n1561), .B(n1571), .C(n1581), .Y(n1551) );
  AOI22X1 u192 ( .A(n1591), .B(n1601), .C(x[8]), .D(n1611), .Y(n1581) );
  INVX1 u193 ( .A(n1580), .Y(n1611) );
  NAND2X1 u194 ( .A(n1580), .B(n831), .Y(n1601) );
  AOI22X1 u195 ( .A(n1621), .B(n82), .C(n1590), .D(n1631), .Y(n1591) );
  OR2X1 u196 ( .A(n1631), .B(n1590), .Y(n1621) );
  OAI22X1 u197 ( .A(n1641), .B(n1651), .C(x[6]), .D(n1661), .Y(n1631) );
  AND2X1 u198 ( .A(n1641), .B(n1651), .Y(n1661) );
  INVX1 u199 ( .A(n1600), .Y(n1651) );
  OAI21X1 u200 ( .A(n1610), .B(n1671), .C(n1681), .Y(n1641) );
  INVX1 u201 ( .A(n1691), .Y(n1681) );
  AOI21X1 u202 ( .A(n1671), .B(n1610), .C(n901), .Y(n1691) );
  OAI22X1 u203 ( .A(n1701), .B(n1711), .C(x[4]), .D(n1721), .Y(n1671) );
  AND2X1 u204 ( .A(n1701), .B(n1711), .Y(n1721) );
  INVX1 u205 ( .A(n1620), .Y(n1711) );
  OAI22X1 u206 ( .A(n1630), .B(n1731), .C(n1741), .D(n911), .Y(n1701) );
  AND2X1 u207 ( .A(n1731), .B(n1630), .Y(n1741) );
  OAI22X1 u208 ( .A(n1751), .B(n176), .C(x[2]), .D(n177), .Y(n1731) );
  AND2X1 u209 ( .A(n1751), .B(n176), .Y(n177) );
  INVX1 u210 ( .A(n1640), .Y(n176) );
  AOI22X1 u211 ( .A(n178), .B(n179), .C(y[8]), .D(n180), .Y(n1571) );
  NAND2X1 u212 ( .A(n1670), .B(n126), .Y(n179) );
  AOI22X1 u213 ( .A(n181), .B(n99), .C(n1680), .D(n182), .Y(n178) );
  OR2X1 u214 ( .A(n182), .B(n1680), .Y(n181) );
  INVX1 u215 ( .A(n183), .Y(n182) );
  AOI22X1 u216 ( .A(n184), .B(n1690), .C(n104), .D(n185), .Y(n183) );
  OR2X1 u217 ( .A(n184), .B(n1690), .Y(n185) );
  AOI21X1 u218 ( .A(n186), .B(n187), .C(n188), .Y(n184) );
  AOI21X1 u219 ( .A(n189), .B(n1700), .C(n190), .Y(n188) );
  INVX1 u220 ( .A(n187), .Y(n189) );
  AOI22X1 u221 ( .A(n191), .B(n1710), .C(n110), .D(n192), .Y(n187) );
  OR2X1 u222 ( .A(n191), .B(n1710), .Y(n192) );
  AOI22X1 u223 ( .A(n193), .B(n194), .C(n195), .D(y[3]), .Y(n191) );
  OR2X1 u224 ( .A(n194), .B(n193), .Y(n195) );
  AOI22X1 u225 ( .A(n1730), .B(n771), .C(n116), .D(n196), .Y(n194) );
  NAND2X1 u226 ( .A(n197), .B(n198), .Y(n196) );
  INVX1 u227 ( .A(n197), .Y(n771) );
  OAI21X1 u228 ( .A(n1740), .B(n741), .C(n199), .Y(n197) );
  INVX1 u229 ( .A(n200), .Y(n199) );
  AOI21X1 u230 ( .A(n1740), .B(n741), .C(n201), .Y(n200) );
  NOR2X1 u231 ( .A(n731), .B(y[0]), .Y(n741) );
  AOI22X1 u232 ( .A(n202), .B(n203), .C(x_ball_r[8]), .D(n831), .Y(n1561) );
  OR2X1 u233 ( .A(n831), .B(x_ball_r[8]), .Y(n203) );
  INVX1 u234 ( .A(n204), .Y(n202) );
  OAI22X1 u235 ( .A(n206), .B(x_ball_r[7]), .C(n82), .D(n208), .Y(n204) );
  AND2X1 u236 ( .A(n208), .B(n82), .Y(n206) );
  AOI22X1 u237 ( .A(x[6]), .B(n210), .C(n212), .D(n214), .Y(n208) );
  OR2X1 u238 ( .A(n210), .B(x[6]), .Y(n214) );
  AOI22X1 u239 ( .A(n901), .B(n216), .C(n218), .D(x_ball_r[5]), .Y(n210) );
  OR2X1 u240 ( .A(n216), .B(n901), .Y(n218) );
  AOI22X1 u241 ( .A(x[4]), .B(n220), .C(n221), .D(n222), .Y(n216) );
  OR2X1 u242 ( .A(n220), .B(x[4]), .Y(n222) );
  AOI21X1 u243 ( .A(n911), .B(n223), .C(n224), .Y(n220) );
  AOI21X1 u244 ( .A(n225), .B(x[3]), .C(n226), .Y(n224) );
  INVX1 u245 ( .A(n225), .Y(n223) );
  OAI22X1 u246 ( .A(n1511), .B(n227), .C(x_ball_r[2]), .D(n228), .Y(n225) );
  AND2X1 u247 ( .A(n227), .B(n1511), .Y(n228) );
  OAI21X1 u248 ( .A(x[1]), .B(n230), .C(n231), .Y(n227) );
  OAI21X1 u249 ( .A(n1521), .B(n233), .C(x_ball_r[1]), .Y(n231) );
  INVX1 u250 ( .A(n230), .Y(n233) );
  INVX1 u251 ( .A(x[1]), .Y(n1521) );
  NOR2X1 u252 ( .A(n1531), .B(x_ball_r[0]), .Y(n230) );
  INVX1 u253 ( .A(x[2]), .Y(n1511) );
  INVX1 u254 ( .A(x[5]), .Y(n901) );
  OAI21X1 u255 ( .A(y[8]), .B(n235), .C(n237), .Y(n1541) );
  OAI21X1 u256 ( .A(y_ball_b[8]), .B(n126), .C(n239), .Y(n237) );
  AOI22X1 u257 ( .A(n241), .B(n243), .C(y[7]), .D(n245), .Y(n239) );
  INVX1 u258 ( .A(y_ball_b[7]), .Y(n243) );
  OR2X1 u259 ( .A(n245), .B(y[7]), .Y(n241) );
  OAI22X1 u260 ( .A(n104), .B(n247), .C(y_ball_b[6]), .D(n248), .Y(n245) );
  AND2X1 u261 ( .A(n247), .B(n104), .Y(n248) );
  OAI22X1 u262 ( .A(y[5]), .B(n249), .C(n250), .D(n251), .Y(n247) );
  AND2X1 u263 ( .A(n249), .B(y[5]), .Y(n250) );
  OAI22X1 u264 ( .A(n110), .B(n252), .C(y_ball_b[4]), .D(n253), .Y(n249) );
  AND2X1 u265 ( .A(n252), .B(n110), .Y(n253) );
  OAI21X1 u266 ( .A(y[3]), .B(n254), .C(n255), .Y(n252) );
  INVX1 u267 ( .A(n257), .Y(n255) );
  AOI21X1 u268 ( .A(n254), .B(y[3]), .C(n259), .Y(n257) );
  OAI22X1 u269 ( .A(n116), .B(n261), .C(y_ball_b[2]), .D(n263), .Y(n254) );
  AND2X1 u270 ( .A(n261), .B(n116), .Y(n263) );
  OAI21X1 u271 ( .A(y[1]), .B(n265), .C(n267), .Y(n261) );
  OAI21X1 u272 ( .A(n201), .B(n269), .C(y_ball_b[1]), .Y(n267) );
  INVX1 u273 ( .A(n265), .Y(n269) );
  INVX1 u274 ( .A(y[1]), .Y(n201) );
  NOR2X1 u275 ( .A(n122), .B(y_ball_b[0]), .Y(n265) );
  INVX1 u276 ( .A(y[0]), .Y(n122) );
  INVX1 u277 ( .A(y[2]), .Y(n116) );
  INVX1 u278 ( .A(y[4]), .Y(n110) );
  INVX1 u279 ( .A(y[6]), .Y(n104) );
  INVX1 u280 ( .A(y_ball_b[8]), .Y(n235) );
  NAND2X1 u281 ( .A(n271), .B(n273), .Y(n294) );
  NAND2X1 u282 ( .A(y_delta_reg[1]), .B(n276), .Y(n273) );
  NAND2X1 u283 ( .A(n271), .B(n2951), .Y(n293) );
  NAND2X1 u284 ( .A(y_delta_reg[2]), .B(n276), .Y(n2951) );
  NAND2X1 u285 ( .A(n271), .B(n296), .Y(n292) );
  NAND2X1 u286 ( .A(y_delta_reg[3]), .B(n276), .Y(n296) );
  NAND2X1 u287 ( .A(n271), .B(n297), .Y(n291) );
  NAND2X1 u288 ( .A(y_delta_reg[4]), .B(n276), .Y(n297) );
  NAND2X1 u289 ( .A(n271), .B(n298), .Y(n290) );
  NAND2X1 u290 ( .A(y_delta_reg[5]), .B(n276), .Y(n298) );
  NAND2X1 u291 ( .A(n271), .B(n299), .Y(n289) );
  NAND2X1 u292 ( .A(y_delta_reg[6]), .B(n276), .Y(n299) );
  NAND2X1 u293 ( .A(n271), .B(n3001), .Y(n288) );
  NAND2X1 u294 ( .A(y_delta_reg[7]), .B(n276), .Y(n3001) );
  NAND2X1 u295 ( .A(n271), .B(n301), .Y(n287) );
  NAND2X1 u296 ( .A(y_delta_reg[8]), .B(n276), .Y(n301) );
  NAND2X1 u297 ( .A(n302), .B(n303), .Y(n271) );
  OAI21X1 u298 ( .A(n304), .B(n305), .C(n306), .Y(n286) );
  INVX1 u299 ( .A(x_delta_reg[1]), .Y(n305) );
  OAI21X1 u300 ( .A(n304), .B(n307), .C(n306), .Y(n285) );
  INVX1 u301 ( .A(x_delta_reg[2]), .Y(n307) );
  OAI21X1 u302 ( .A(n304), .B(n308), .C(n306), .Y(n284) );
  INVX1 u303 ( .A(x_delta_reg[3]), .Y(n308) );
  OAI21X1 u304 ( .A(n304), .B(n309), .C(n306), .Y(n283) );
  INVX1 u305 ( .A(x_delta_reg[4]), .Y(n309) );
  OAI21X1 u306 ( .A(n304), .B(n3101), .C(n306), .Y(n282) );
  INVX1 u307 ( .A(x_delta_reg[5]), .Y(n3101) );
  OAI21X1 u308 ( .A(n304), .B(n311), .C(n306), .Y(n281) );
  INVX1 u309 ( .A(x_delta_reg[6]), .Y(n311) );
  OAI21X1 u310 ( .A(n304), .B(n312), .C(n306), .Y(n280) );
  INVX1 u311 ( .A(x_delta_reg[7]), .Y(n312) );
  OAI21X1 u312 ( .A(n304), .B(n313), .C(n306), .Y(n279) );
  NAND3X1 u313 ( .A(n276), .B(n314), .C(n315), .Y(n306) );
  INVX1 u314 ( .A(n316), .Y(n315) );
  INVX1 u315 ( .A(n303), .Y(n276) );
  INVX1 u316 ( .A(x_delta_reg[8]), .Y(n313) );
  OR2X1 u317 ( .A(n304), .B(x_delta_reg[0]), .Y(n278) );
  AOI21X1 u318 ( .A(n316), .B(n314), .C(n303), .Y(n304) );
  NAND3X1 u319 ( .A(n317), .B(n318), .C(n319), .Y(n314) );
  NOR3X1 u320 ( .A(n1600), .B(n1620), .C(n1610), .Y(n319) );
  NAND3X1 u321 ( .A(n1630), .B(n1640), .C(n3201), .Y(n318) );
  AND2X1 u322 ( .A(n1660), .B(n1650), .Y(n3201) );
  NOR2X1 u323 ( .A(n1590), .B(n1580), .Y(n317) );
  NAND3X1 u324 ( .A(n321), .B(n322), .C(n323), .Y(n316) );
  NOR3X1 u325 ( .A(n324), .B(n325), .C(n326), .Y(n323) );
  NAND2X1 u326 ( .A(n96), .B(n102), .Y(n326) );
  AOI21X1 u327 ( .A(n327), .B(n106), .C(n328), .Y(n325) );
  AOI21X1 u328 ( .A(n1520), .B(n329), .C(n251), .Y(n328) );
  INVX1 u329 ( .A(y_ball_b[5]), .Y(n251) );
  INVX1 u330 ( .A(n1520), .Y(n106) );
  INVX1 u331 ( .A(n329), .Y(n327) );
  OAI22X1 u332 ( .A(n3301), .B(n331), .C(y_ball_b[4]), .D(n332), .Y(n329) );
  AND2X1 u333 ( .A(n331), .B(n3301), .Y(n332) );
  OAI22X1 u334 ( .A(n1540), .B(n333), .C(n334), .D(n259), .Y(n331) );
  INVX1 u335 ( .A(y_ball_b[3]), .Y(n259) );
  AND2X1 u336 ( .A(n333), .B(n1540), .Y(n334) );
  OAI22X1 u337 ( .A(n335), .B(n336), .C(y_ball_b[2]), .D(n337), .Y(n333) );
  AND2X1 u338 ( .A(n336), .B(n335), .Y(n337) );
  OAI21X1 u339 ( .A(n1560), .B(n338), .C(n339), .Y(n336) );
  OAI21X1 u340 ( .A(n118), .B(n3401), .C(y_ball_b[1]), .Y(n339) );
  INVX1 u341 ( .A(n1560), .Y(n118) );
  INVX1 u342 ( .A(n3401), .Y(n338) );
  NAND2X1 u343 ( .A(n1570), .B(n341), .Y(n3401) );
  INVX1 u344 ( .A(y_ball_b[0]), .Y(n341) );
  INVX1 u345 ( .A(n1550), .Y(n335) );
  INVX1 u346 ( .A(n342), .Y(n324) );
  NOR3X1 u347 ( .A(x_ball_r[7]), .B(x_ball_r[8]), .C(n1510), .Y(n342) );
  NOR3X1 u348 ( .A(n343), .B(n344), .C(n226), .Y(n322) );
  INVX1 u349 ( .A(x_ball_r[3]), .Y(n226) );
  AOI22X1 u350 ( .A(n345), .B(n346), .C(y_pad_b[8]), .D(n180), .Y(n344) );
  OR2X1 u351 ( .A(n180), .B(y_pad_b[8]), .Y(n346) );
  AOI22X1 u352 ( .A(n347), .B(n129), .C(n1680), .D(n348), .Y(n345) );
  INVX1 u353 ( .A(y_pad_b[7]), .Y(n129) );
  OR2X1 u354 ( .A(n348), .B(n1680), .Y(n347) );
  OAI22X1 u355 ( .A(n349), .B(n3501), .C(y_pad_b[6]), .D(n351), .Y(n348) );
  AND2X1 u356 ( .A(n3501), .B(n349), .Y(n351) );
  OAI22X1 u357 ( .A(n1700), .B(n352), .C(n353), .D(n136), .Y(n3501) );
  AND2X1 u358 ( .A(n352), .B(n1700), .Y(n353) );
  OAI22X1 u359 ( .A(n354), .B(n355), .C(y_pad_b[4]), .D(n356), .Y(n352) );
  AND2X1 u360 ( .A(n355), .B(n354), .Y(n356) );
  OAI21X1 u361 ( .A(n1720), .B(n357), .C(n358), .Y(n355) );
  INVX1 u362 ( .A(n359), .Y(n358) );
  AOI21X1 u363 ( .A(n357), .B(n1720), .C(n142), .Y(n359) );
  OAI22X1 u364 ( .A(n198), .B(n3601), .C(y_pad_b[2]), .D(n361), .Y(n357) );
  AND2X1 u365 ( .A(n3601), .B(n198), .Y(n361) );
  OAI21X1 u366 ( .A(n1740), .B(n362), .C(n363), .Y(n3601) );
  INVX1 u367 ( .A(n364), .Y(n363) );
  AOI21X1 u368 ( .A(n1740), .B(n362), .C(n148), .Y(n364) );
  NOR2X1 u369 ( .A(n731), .B(y_pad_b[0]), .Y(n362) );
  INVX1 u370 ( .A(x_ball_r[5]), .Y(n343) );
  NOR3X1 u371 ( .A(n365), .B(n221), .C(n212), .Y(n321) );
  INVX1 u372 ( .A(x_ball_r[6]), .Y(n212) );
  INVX1 u373 ( .A(x_ball_r[4]), .Y(n221) );
  MUX2X1 u374 ( .B(x_ball_r[1]), .A(n366), .S(x_ball_r[2]), .Y(n365) );
  NAND2X1 u375 ( .A(x_ball_r[0]), .B(x_ball_r[1]), .Y(n366) );
  NAND2X1 u376 ( .A(n367), .B(n368), .Y(n277) );
  NAND2X1 u377 ( .A(n2810), .B(n369), .Y(n368) );
  AOI22X1 u378 ( .A(n1570), .B(n370), .C(n3810), .D(n500), .Y(n367) );
  INVX1 u379 ( .A(reset), .Y(n275) );
  NAND2X1 u380 ( .A(n372), .B(n373), .Y(n274) );
  NAND2X1 u381 ( .A(n3610), .B(n369), .Y(n373) );
  AOI22X1 u382 ( .A(n1490), .B(n370), .C(n460), .D(n500), .Y(n372) );
  NAND2X1 u383 ( .A(n374), .B(n375), .Y(n272) );
  NAND2X1 u384 ( .A(n3510), .B(n369), .Y(n375) );
  AOI22X1 u385 ( .A(n1500), .B(n370), .C(n450), .D(n500), .Y(n374) );
  NAND2X1 u386 ( .A(n376), .B(n377), .Y(n270) );
  NAND2X1 u387 ( .A(n2910), .B(n369), .Y(n377) );
  AOI22X1 u388 ( .A(n1560), .B(n370), .C(n3910), .D(n500), .Y(n376) );
  NAND2X1 u389 ( .A(n378), .B(n379), .Y(n268) );
  NAND2X1 u390 ( .A(n3410), .B(n369), .Y(n379) );
  AOI22X1 u391 ( .A(n1510), .B(n370), .C(n441), .D(n500), .Y(n378) );
  NAND2X1 u392 ( .A(n3801), .B(n381), .Y(n266) );
  NAND2X1 u393 ( .A(n3310), .B(n369), .Y(n381) );
  AOI22X1 u394 ( .A(n1520), .B(n370), .C(n4310), .D(n500), .Y(n3801) );
  NAND2X1 u395 ( .A(n382), .B(n383), .Y(n264) );
  NAND2X1 u396 ( .A(n3210), .B(n369), .Y(n383) );
  AOI22X1 u397 ( .A(n1530), .B(n370), .C(n4210), .D(n500), .Y(n382) );
  NAND2X1 u398 ( .A(n384), .B(n385), .Y(n262) );
  NAND2X1 u399 ( .A(n3110), .B(n369), .Y(n385) );
  AOI22X1 u400 ( .A(n1540), .B(n370), .C(n4110), .D(n500), .Y(n384) );
  NAND2X1 u401 ( .A(n386), .B(n387), .Y(n260) );
  NAND2X1 u402 ( .A(n3010), .B(n369), .Y(n387) );
  NOR2X1 u403 ( .A(n388), .B(n7), .Y(n369) );
  AOI22X1 u404 ( .A(n1550), .B(n370), .C(n4010), .D(n500), .Y(n386) );
  NOR3X1 u405 ( .A(n7), .B(n3901), .C(n391), .Y(n371) );
  INVX1 u406 ( .A(n388), .Y(n3901) );
  INVX1 u407 ( .A(n392), .Y(n370) );
  AOI21X1 u408 ( .A(n388), .B(n391), .C(n8), .Y(n392) );
  NAND3X1 u409 ( .A(down), .B(n393), .C(n394), .Y(n391) );
  NOR3X1 u410 ( .A(y_pad_b[6]), .B(y_pad_b[8]), .C(y_pad_b[7]), .Y(n394) );
  NAND3X1 u411 ( .A(y_pad_b[4]), .B(y_pad_b[2]), .C(n395), .Y(n393) );
  NOR3X1 u412 ( .A(n136), .B(n148), .C(n142), .Y(n395) );
  INVX1 u413 ( .A(y_pad_b[3]), .Y(n142) );
  INVX1 u414 ( .A(y_pad_b[1]), .Y(n148) );
  INVX1 u415 ( .A(y_pad_b[5]), .Y(n136) );
  OAI21X1 u416 ( .A(n396), .B(n397), .C(up), .Y(n388) );
  NAND3X1 u417 ( .A(n96), .B(n102), .C(n398), .Y(n397) );
  NOR2X1 u418 ( .A(n1520), .B(n1510), .Y(n398) );
  INVX1 u419 ( .A(n1500), .Y(n102) );
  INVX1 u420 ( .A(n1490), .Y(n96) );
  NAND3X1 u421 ( .A(n3301), .B(n112), .C(n399), .Y(n396) );
  NOR2X1 u422 ( .A(n1560), .B(n1550), .Y(n399) );
  INVX1 u423 ( .A(n1540), .Y(n112) );
  INVX1 u424 ( .A(n1530), .Y(n3301) );
  MUX2X1 u425 ( .B(n4001), .A(n731), .S(n7), .Y(n258) );
  INVX1 u426 ( .A(n1750), .Y(n731) );
  INVX1 u427 ( .A(n620), .Y(n4001) );
  OR2X1 u428 ( .A(y_delta_reg[0]), .B(n303), .Y(n256) );
  NAND3X1 u429 ( .A(n302), .B(n401), .C(n402), .Y(n303) );
  NOR2X1 u430 ( .A(y_ball_b[8]), .B(y_ball_b[7]), .Y(n402) );
  INVX1 u431 ( .A(y_ball_b[6]), .Y(n401) );
  NAND3X1 u432 ( .A(n403), .B(n404), .C(n405), .Y(n302) );
  NOR3X1 u433 ( .A(n406), .B(n1680), .C(n1670), .Y(n405) );
  NAND2X1 u434 ( .A(n349), .B(n186), .Y(n406) );
  NOR3X1 u435 ( .A(n1730), .B(n1750), .C(n1740), .Y(n404) );
  NOR2X1 u436 ( .A(n1720), .B(n1710), .Y(n403) );
  INVX1 u437 ( .A(n407), .Y(n246) );
  MUX2X1 u438 ( .B(n630), .A(n1740), .S(n9), .Y(n407) );
  MUX2X1 u439 ( .B(n408), .A(n198), .S(n9), .Y(n244) );
  INVX1 u440 ( .A(n1730), .Y(n198) );
  INVX1 u441 ( .A(n640), .Y(n408) );
  MUX2X1 u442 ( .B(n409), .A(n193), .S(n8), .Y(n242) );
  INVX1 u443 ( .A(n1720), .Y(n193) );
  INVX1 u444 ( .A(n650), .Y(n409) );
  MUX2X1 u445 ( .B(n4101), .A(n354), .S(n7), .Y(n240) );
  INVX1 u446 ( .A(n1710), .Y(n354) );
  INVX1 u447 ( .A(n660), .Y(n4101) );
  MUX2X1 u448 ( .B(n411), .A(n186), .S(n9), .Y(n238) );
  INVX1 u449 ( .A(n1700), .Y(n186) );
  INVX1 u450 ( .A(n670), .Y(n411) );
  MUX2X1 u451 ( .B(n412), .A(n349), .S(n8), .Y(n236) );
  INVX1 u452 ( .A(n1690), .Y(n349) );
  INVX1 u453 ( .A(n680), .Y(n412) );
  INVX1 u454 ( .A(n413), .Y(n234) );
  MUX2X1 u455 ( .B(n690), .A(n1680), .S(n8), .Y(n413) );
  MUX2X1 u456 ( .B(n414), .A(n180), .S(n7), .Y(n232) );
  INVX1 u457 ( .A(n1670), .Y(n180) );
  INVX1 u458 ( .A(n700), .Y(n414) );
  INVX1 u459 ( .A(n415), .Y(n229) );
  AOI22X1 u460 ( .A(n7), .B(n1580), .C(n416), .D(n910), .Y(n415) );
  INVX1 u461 ( .A(n417), .Y(n219) );
  AOI22X1 u462 ( .A(n9), .B(n1590), .C(n416), .D(n900), .Y(n417) );
  INVX1 u463 ( .A(n418), .Y(n217) );
  AOI22X1 u464 ( .A(n8), .B(n1600), .C(n416), .D(n890), .Y(n418) );
  INVX1 u465 ( .A(n419), .Y(n215) );
  AOI22X1 u466 ( .A(n7), .B(n1610), .C(n416), .D(n880), .Y(n419) );
  INVX1 u467 ( .A(n4201), .Y(n213) );
  AOI22X1 u468 ( .A(n9), .B(n1620), .C(n416), .D(n870), .Y(n4201) );
  INVX1 u469 ( .A(n421), .Y(n211) );
  AOI22X1 u470 ( .A(n8), .B(n1630), .C(n416), .D(n860), .Y(n421) );
  INVX1 u471 ( .A(n422), .Y(n209) );
  AOI22X1 u472 ( .A(n7), .B(n1640), .C(n416), .D(n850), .Y(n422) );
  INVX1 u473 ( .A(n423), .Y(n207) );
  AOI22X1 u474 ( .A(n9), .B(n1650), .C(n416), .D(n840), .Y(n423) );
  INVX1 u475 ( .A(n424), .Y(n205) );
  AOI22X1 u476 ( .A(n8), .B(n1660), .C(n416), .D(n830), .Y(n424) );
  NOR2X1 u477 ( .A(n810), .B(n9), .Y(n416) );
  NAND3X1 u478 ( .A(n425), .B(n426), .C(n427), .Y(n389) );
  NOR3X1 u479 ( .A(n428), .B(n429), .C(n4301), .Y(n427) );
  NAND2X1 u480 ( .A(n125), .B(y[6]), .Y(n4301) );
  NOR2X1 u481 ( .A(x[2]), .B(x[1]), .Y(n125) );
  NAND2X1 u482 ( .A(y[0]), .B(n1531), .Y(n429) );
  NAND3X1 u483 ( .A(n911), .B(n92), .C(n431), .Y(n428) );
  NOR2X1 u484 ( .A(x[6]), .B(x[5]), .Y(n431) );
  INVX1 u485 ( .A(x[4]), .Y(n92) );
  INVX1 u486 ( .A(x[3]), .Y(n911) );
  NOR3X1 u487 ( .A(n432), .B(y[4]), .C(y[3]), .Y(n426) );
  NAND3X1 u488 ( .A(n99), .B(n126), .C(n190), .Y(n432) );
  INVX1 u489 ( .A(y[5]), .Y(n190) );
  INVX1 u490 ( .A(y[8]), .Y(n126) );
  INVX1 u491 ( .A(y[7]), .Y(n99) );
  NOR3X1 u492 ( .A(n433), .B(y[2]), .C(y[1]), .Y(n425) );
  NAND2X1 u493 ( .A(n82), .B(n831), .Y(n433) );
  INVX1 u494 ( .A(x[8]), .Y(n831) );
  INVX1 u495 ( .A(x[7]), .Y(n82) );
  XNOR2X1 u496 ( .A(n1751), .B(n434), .Y(n610) );
  XOR2X1 u497 ( .A(x[2]), .B(n1640), .Y(n434) );
  OAI21X1 u498 ( .A(n1650), .B(n435), .C(n436), .Y(n1751) );
  OAI21X1 u499 ( .A(n437), .B(n438), .C(x[1]), .Y(n436) );
  INVX1 u500 ( .A(n1650), .Y(n438) );
  INVX1 u501 ( .A(n437), .Y(n435) );
  XNOR2X1 u502 ( .A(n437), .B(n439), .Y(n510) );
  XOR2X1 u503 ( .A(x[1]), .B(n1650), .Y(n439) );
  OAI21X1 u504 ( .A(n1660), .B(n1531), .C(n437), .Y(n440) );
  NAND2X1 u505 ( .A(n1660), .B(n1531), .Y(n437) );
  INVX1 u506 ( .A(x[0]), .Y(n1531) );
endmodule


module pong_pt1_DW01_inc_0 ( a, sum );
  input [8:0] a;
  output [8:0] sum;

  wire   [8:2] carry;

  HAX1 u1_1_7 ( .A(a[7]), .B(carry[7]), .CO(carry[8]), .S(sum[7]) );
  HAX1 u1_1_6 ( .A(a[6]), .B(carry[6]), .CO(carry[7]), .S(sum[6]) );
  HAX1 u1_1_5 ( .A(a[5]), .B(carry[5]), .CO(carry[6]), .S(sum[5]) );
  HAX1 u1_1_4 ( .A(a[4]), .B(carry[4]), .CO(carry[5]), .S(sum[4]) );
  HAX1 u1_1_3 ( .A(a[3]), .B(carry[3]), .CO(carry[4]), .S(sum[3]) );
  HAX1 u1_1_2 ( .A(a[2]), .B(carry[2]), .CO(carry[3]), .S(sum[2]) );
  HAX1 u1_1_1 ( .A(a[1]), .B(a[0]), .CO(carry[2]), .S(sum[1]) );
  XOR2X1 u1 ( .A(carry[8]), .B(a[8]), .Y(sum[8]) );
  INVX1 u2 ( .A(a[0]), .Y(sum[0]) );
endmodule


module pong_pt1_DW01_inc_1 ( a, sum );
  input [8:0] a;
  output [8:0] sum;

  wire   [8:2] carry;

  HAX1 u1_1_7 ( .A(a[7]), .B(carry[7]), .CO(carry[8]), .S(sum[7]) );
  HAX1 u1_1_6 ( .A(a[6]), .B(carry[6]), .CO(carry[7]), .S(sum[6]) );
  HAX1 u1_1_5 ( .A(a[5]), .B(carry[5]), .CO(carry[6]), .S(sum[5]) );
  HAX1 u1_1_4 ( .A(a[4]), .B(carry[4]), .CO(carry[5]), .S(sum[4]) );
  HAX1 u1_1_3 ( .A(a[3]), .B(carry[3]), .CO(carry[4]), .S(sum[3]) );
  HAX1 u1_1_2 ( .A(a[2]), .B(carry[2]), .CO(carry[3]), .S(sum[2]) );
  HAX1 u1_1_1 ( .A(a[1]), .B(a[0]), .CO(carry[2]), .S(sum[1]) );
  XOR2X1 u1 ( .A(carry[8]), .B(a[8]), .Y(sum[8]) );
  INVX1 u2 ( .A(a[0]), .Y(sum[0]) );
endmodule


module pong_pt1 ( clk, reset, enable, up, down, p_tick, hsync, vsync, rgb );
  input clk, reset, enable, up, down;
  output p_tick, hsync, vsync, rgb;
  wire   n134, n135, pixel_tick, n8, n17, n18, n19, n20, n21, n22, n23, n24,
         n25, n35, n36, n37, n38, n39, n40, n410, n42, n430, vid_on, n411,
         n431, n45, n47, n49, n51, n53, n55, n57, n58, n70, n71, n72, n73, n74,
         n75, n76, n77, n78, n79, n80, n81, n82, n84, n86, n87, n88, n89, n90,
         n91, n92, n93, n94, n95, n96, n97, n98, n99, n100, n101, n102, n103,
         n104, n105, n106, n107, n108, n109, n110, n111, n112, n113, n114,
         n115, n116, n117, n118, n119, n120, n121, n122, n123, n124, n125,
         n126, n127, n128, n129, n130, n131, n132, n133;
  wire   [8:0] y;
  wire   [8:0] x;

  DFFSRX1 x_reg_7_ ( .D(n53), .CLK(clk), .R(n89), .S(n88), .Q(x[7]) );
  pixel_gen_TABLE_WIDTH128_TABLE_HEIGHT64_WALL_THICKNESS8_PADDLE_HEIGHT16_PADDLE_VELOCITY1_BALL_VELOCITY_POS1_BALL_VELOCITY_NEGn1_X_BIT_WIDTH9_Y_BIT_WIDTH9 pg ( 
        .clk(clk), .reset(reset), .up(up), .down(down), .video_on(vid_on), .x(
        x), .y(y), .rgb(rgb) );
  pong_pt1_DW01_inc_0 add_101 ( .a(x), .sum({n430, n42, n410, n40, n39, n38, 
        n37, n36, n35}) );
  pong_pt1_DW01_inc_1 add_98 ( .a(y), .sum({n25, n24, n23, n22, n21, n20, n19, 
        n18, n17}) );
  DFFSRX1 y_reg_6_ ( .D(n71), .CLK(clk), .R(n89), .S(n87), .Q(y[6]) );
  DFFSRX1 pixel_tick_reg ( .D(n8), .CLK(clk), .R(n87), .S(n89), .Q(pixel_tick)
         );
  DFFSRX1 y_reg_3_ ( .D(n74), .CLK(clk), .R(n88), .S(n89), .Q(y[3]) );
  DFFSRX1 y_reg_2_ ( .D(n75), .CLK(clk), .R(n87), .S(n89), .Q(y[2]) );
  DFFSRX1 y_reg_1_ ( .D(n76), .CLK(clk), .R(n88), .S(n89), .Q(y[1]) );
  DFFSRX1 y_reg_0_ ( .D(n77), .CLK(clk), .R(n87), .S(n89), .Q(y[0]) );
  DFFSRX1 y_reg_4_ ( .D(n73), .CLK(clk), .R(n88), .S(n89), .Q(y[4]) );
  DFFSRX1 x_reg_4_ ( .D(n47), .CLK(clk), .R(n87), .S(n89), .Q(x[4]) );
  DFFSRX1 x_reg_3_ ( .D(n45), .CLK(clk), .R(n88), .S(n89), .Q(x[3]) );
  DFFSRX1 x_reg_2_ ( .D(n431), .CLK(clk), .R(n87), .S(n89), .Q(x[2]) );
  DFFSRX1 x_reg_1_ ( .D(n411), .CLK(clk), .R(n88), .S(n89), .Q(x[1]) );
  DFFSRX1 x_reg_0_ ( .D(n57), .CLK(clk), .R(n87), .S(n89), .Q(x[0]) );
  DFFSRX1 x_reg_5_ ( .D(n49), .CLK(clk), .R(n88), .S(n89), .Q(x[5]) );
  DFFSRX1 y_reg_5_ ( .D(n72), .CLK(clk), .R(n87), .S(n89), .Q(y[5]) );
  DFFSRX1 x_reg_6_ ( .D(n51), .CLK(clk), .R(n88), .S(n89), .Q(x[6]) );
  DFFSRX1 y_reg_7_ ( .D(n70), .CLK(clk), .R(n87), .S(n89), .Q(y[7]) );
  DFFSRX1 x_reg_8_ ( .D(n55), .CLK(clk), .R(n88), .S(n89), .Q(x[8]) );
  DFFSRX1 y_reg_8_ ( .D(n78), .CLK(clk), .R(n87), .S(n89), .Q(y[8]) );
  TIEHIX1 u81 ( .Y(n89) );
  INVX1 u82 ( .A(n91), .Y(n79) );
  INVX1 u83 ( .A(n79), .Y(n80) );
  INVX1 u84 ( .A(n79), .Y(n81) );
  INVX1 u85 ( .A(n134), .Y(n82) );
  INVX1 u86 ( .A(n82), .Y(p_tick) );
  INVX1 u87 ( .A(n135), .Y(n84) );
  INVX1 u88 ( .A(n84), .Y(hsync) );
  INVX1 u89 ( .A(n58), .Y(n86) );
  INVX1 u90 ( .A(n86), .Y(n87) );
  INVX1 u91 ( .A(n86), .Y(n88) );
  INVX1 u92 ( .A(n90), .Y(vid_on) );
  NOR3X1 u93 ( .A(n80), .B(vsync), .C(n90), .Y(n134) );
  NAND2X1 u94 ( .A(n92), .B(n93), .Y(n90) );
  OAI22X1 u95 ( .A(n94), .B(n95), .C(n96), .D(n97), .Y(n78) );
  INVX1 u96 ( .A(n25), .Y(n97) );
  OAI22X1 u97 ( .A(n94), .B(n98), .C(n96), .D(n99), .Y(n77) );
  INVX1 u98 ( .A(n17), .Y(n99) );
  OAI22X1 u99 ( .A(n94), .B(n100), .C(n96), .D(n101), .Y(n76) );
  INVX1 u100 ( .A(n18), .Y(n101) );
  OAI22X1 u101 ( .A(n94), .B(n102), .C(n96), .D(n103), .Y(n75) );
  INVX1 u102 ( .A(n19), .Y(n103) );
  OAI22X1 u103 ( .A(n94), .B(n104), .C(n96), .D(n105), .Y(n74) );
  INVX1 u104 ( .A(n20), .Y(n105) );
  OAI22X1 u105 ( .A(n94), .B(n106), .C(n96), .D(n107), .Y(n73) );
  INVX1 u106 ( .A(n21), .Y(n107) );
  OAI22X1 u107 ( .A(n94), .B(n108), .C(n96), .D(n109), .Y(n72) );
  INVX1 u108 ( .A(n22), .Y(n109) );
  OAI22X1 u109 ( .A(n94), .B(n110), .C(n96), .D(n111), .Y(n71) );
  INVX1 u110 ( .A(n23), .Y(n111) );
  OAI22X1 u111 ( .A(n94), .B(n112), .C(n96), .D(n113), .Y(n70) );
  INVX1 u112 ( .A(n24), .Y(n113) );
  NAND2X1 u113 ( .A(n94), .B(n92), .Y(n96) );
  INVX1 u114 ( .A(n114), .Y(n92) );
  NAND3X1 u115 ( .A(n112), .B(n95), .C(n115), .Y(n114) );
  OAI21X1 u116 ( .A(n116), .B(n117), .C(y[6]), .Y(n115) );
  NAND3X1 u117 ( .A(n100), .B(n102), .C(n98), .Y(n117) );
  INVX1 u118 ( .A(y[0]), .Y(n98) );
  INVX1 u119 ( .A(y[2]), .Y(n102) );
  INVX1 u120 ( .A(y[1]), .Y(n100) );
  NAND3X1 u121 ( .A(n106), .B(n108), .C(n104), .Y(n116) );
  INVX1 u122 ( .A(y[3]), .Y(n104) );
  INVX1 u123 ( .A(y[5]), .Y(n108) );
  INVX1 u124 ( .A(y[4]), .Y(n106) );
  NOR2X1 u125 ( .A(n118), .B(n80), .Y(n94) );
  INVX1 u126 ( .A(reset), .Y(n58) );
  INVX1 u127 ( .A(n119), .Y(n57) );
  AOI22X1 u128 ( .A(n81), .B(x[0]), .C(n120), .D(n35), .Y(n119) );
  INVX1 u129 ( .A(n121), .Y(n55) );
  AOI22X1 u130 ( .A(n80), .B(x[8]), .C(n120), .D(n430), .Y(n121) );
  INVX1 u131 ( .A(n122), .Y(n53) );
  AOI22X1 u132 ( .A(n81), .B(x[7]), .C(n120), .D(n42), .Y(n122) );
  INVX1 u133 ( .A(n123), .Y(n51) );
  AOI22X1 u134 ( .A(n80), .B(x[6]), .C(n120), .D(n410), .Y(n123) );
  INVX1 u135 ( .A(n124), .Y(n49) );
  AOI22X1 u136 ( .A(n81), .B(x[5]), .C(n120), .D(n40), .Y(n124) );
  INVX1 u137 ( .A(n125), .Y(n47) );
  AOI22X1 u138 ( .A(n80), .B(x[4]), .C(n120), .D(n39), .Y(n125) );
  INVX1 u139 ( .A(n126), .Y(n45) );
  AOI22X1 u140 ( .A(n81), .B(x[3]), .C(n120), .D(n38), .Y(n126) );
  INVX1 u141 ( .A(n127), .Y(n431) );
  AOI22X1 u142 ( .A(n80), .B(x[2]), .C(n120), .D(n37), .Y(n127) );
  INVX1 u143 ( .A(n128), .Y(n411) );
  AOI22X1 u144 ( .A(n81), .B(x[1]), .C(n120), .D(n36), .Y(n128) );
  NOR2X1 u145 ( .A(n81), .B(n129), .Y(n120) );
  NOR3X1 u146 ( .A(n93), .B(vsync), .C(n129), .Y(n135) );
  INVX1 u147 ( .A(n118), .Y(n129) );
  OAI21X1 u148 ( .A(x[8]), .B(x[7]), .C(n130), .Y(n118) );
  NAND3X1 u149 ( .A(n112), .B(n95), .C(n110), .Y(vsync) );
  INVX1 u150 ( .A(y[6]), .Y(n110) );
  INVX1 u151 ( .A(y[8]), .Y(n95) );
  INVX1 u152 ( .A(y[7]), .Y(n112) );
  OAI22X1 u153 ( .A(x[8]), .B(x[7]), .C(x[0]), .D(n130), .Y(n93) );
  NAND3X1 u154 ( .A(n131), .B(n132), .C(n133), .Y(n130) );
  NOR3X1 u155 ( .A(x[1]), .B(x[3]), .C(x[2]), .Y(n133) );
  NOR2X1 u156 ( .A(x[8]), .B(x[6]), .Y(n132) );
  NOR2X1 u157 ( .A(x[5]), .B(x[4]), .Y(n131) );
  AND2X1 u158 ( .A(enable), .B(n80), .Y(n8) );
  INVX1 u159 ( .A(pixel_tick), .Y(n91) );
endmodule

