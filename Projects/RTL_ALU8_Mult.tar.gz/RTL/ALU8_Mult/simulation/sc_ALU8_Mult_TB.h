/**********************************************************************
Filename: sc_ALU8_Mult_TB.h
Purpose : Core of 8-Tab Systolic FIR filter
Author  : goodkook@gmail.com
History : Mar. 2024, First release
***********************************************************************/

#ifndef _SC_ALU8_Mult_TB_H_
#define  _SC_ALU8_Mult_TB_H_

#include <systemc.h>
#ifdef VCD_TRACE_DUT_VERILOG
#include <verilated_vcd_sc.h>
#endif

#ifdef EMULATED_CO_SIM
#include "EALU8_Mult.h"
#else
#include "VALU8_Mult.h"    // Verilated RTL
#endif

#include "def_commands.h"

SC_MODULE(sc_ALU8_Mult_TB)
{
    sc_clock                clk;
    sc_signal<bool>         reset;
    sc_signal<sc_uint<8> >  ABCmd_i;
    sc_signal<bool>         LoadA_i;
    sc_signal<bool>         LoadB_i;
    sc_signal<bool>         LoadCmd_i;
    sc_signal<bool>         MulL_i;
    sc_signal<bool>         MulH_i;
    sc_signal<bool>         Flag_i;
    sc_signal<sc_uint<8> >  ACC_o;

#ifdef EMULATED_CO_SIM
    EALU8_Mult*    u_ALU8_Mult;
#else   // Verilated RTL
    VALU8_Mult*    u_ALU8_Mult;
#endif

#ifdef  VCD_TRACE_TEST_TB
    sc_trace_file* fp;  // VCD file
#endif

#ifdef VCD_TRACE_DUT_VERILOG
    VerilatedVcdSc*     tfp;    // Verilator VCD
#endif

    sc_signal<sc_uint<8> >      rA, rB, rCmd;
    sc_signal<sc_uint<8> >      rFLAG, rACC;

    sc_signal<sc_uint<8*4> >    regOP;      // char[4]
    sc_signal<sc_uint<8*5> >    regFLAG;    // char[5]
    sc_signal<sc_uint<16> >     regMUL;

    // Test utilities
    void Test_Gen();
    void Test_Mon();
    char* decode_op(uint8_t op)
    {
        switch (op & 0x0F)
        {
            case FUNC_ADD:  return (char*)"ADD";
            case FUNC_SUB:  return (char*)"SUB";
            case FUNC_OR:   return (char*)"OR ";
            case FUNC_AND:  return (char*)"AND";
            case FUNC_XOR:  return (char*)"XOR";
            default:        return (char*)"nop";
        }
        return (char*)"NIL";
    }

    SC_CTOR(sc_ALU8_Mult_TB):   // Constructor
    clk("clk", 100, SC_NS, 0.5, 0.0, SC_NS, false)
    {
        SC_THREAD(Test_Gen);
        sensitive << clk;

        SC_THREAD(Test_Mon);
        sensitive << clk;

        // Instaltiate PE & Build array
#ifdef EMULATED_CO_SIM
        u_ALU8_Mult = new EALU8_Mult("u_EALU8_Mult");
#else
        u_ALU8_Mult = new VALU8_Mult("u_VALU8_Mult");
#endif
        u_ALU8_Mult->clk(clk);
        u_ALU8_Mult->reset(reset);
        u_ALU8_Mult->ABCmd_i(ABCmd_i);
        u_ALU8_Mult->LoadA_i(LoadA_i);
        u_ALU8_Mult->LoadB_i(LoadB_i);
        u_ALU8_Mult->LoadCmd_i(LoadCmd_i);
        u_ALU8_Mult->MulL_i(MulL_i);
        u_ALU8_Mult->MulH_i(MulH_i);
        u_ALU8_Mult->Flag_i(Flag_i);
        u_ALU8_Mult->ACC_o(ACC_o);

#ifdef VCD_TRACE_TEST_TB
        // WAVE
        fp = sc_create_vcd_trace_file("sc_ALU8_Mult_TB");
        fp->set_time_unit(100, SC_PS);  // resolution (trace) ps
        sc_trace(fp, clk,       "clk");
        sc_trace(fp, reset,     "reset");
        sc_trace(fp, ABCmd_i,   "ABCmd_i");
        sc_trace(fp, LoadA_i,   "LoadA_i");
        sc_trace(fp, LoadB_i,   "LoadB_i");
        sc_trace(fp, LoadCmd_i, "LoadCmd_i");
        sc_trace(fp, MulL_i,    "MulL_i");
        sc_trace(fp, MulH_i,    "MulH_i");
        sc_trace(fp, Flag_i,    "Flag_i");
        sc_trace(fp, ACC_o,     "ACC_o");
        sc_trace(fp, rA,        "rA");
        sc_trace(fp, rB,        "rB");
        sc_trace(fp, rCmd,      "rCmd");
        sc_trace(fp, rFLAG,     "rFLAG");
        sc_trace(fp, rACC,      "rACC");
        sc_trace(fp, regOP,     "regOP");   // char[4]
        sc_trace(fp, regFLAG,   "regFLAG"); // char[5]
        sc_trace(fp, regMUL,    "regMUL");
#endif

#ifdef VCD_TRACE_DUT_VERILOG
        // Trace Verilated Verilog internals
        Verilated::traceEverOn(true);

        tfp = new VerilatedVcdSc;
        sc_start(SC_ZERO_TIME);
        u_ALU8_Mult->trace(tfp, 99);  // Trace levels of hierarchy
        tfp->open("VALU8_Mult.vcd");
#endif
    }
    
    ~sc_ALU8_Mult_TB(void)
    {
    }
};

#endif
