/*******************************************************************************
Poorman's Standard-Emulator
---------------------------
Vendor: GoodKook, goodkook@gmail.com
Associated Filename: sc_ALU8_Mult_TB.cpp
Purpose: Testbench
Revision History: Sep. 2025
*******************************************************************************/
#include "sc_ALU8_Mult_TB.h"

#include <iostream> // std::cout, std::hex, std::endl
#include <iomanip>  // std::setiosflags

#include <stdlib.h>
#include <time.h>
#include <math.h>

//
// Cycle-Accurate Test Generator
//
#define N_TEST_OPS  8
void sc_ALU8_Mult_TB::Test_Gen()
{
    int nSim = 0;
    sc_uint<8>  regA_Val, regB_Val;
    sc_uint<8>  Test_Ops[N_TEST_OPS] =
    {
        FUNC_NON,
        FUNC_OR |FUNC_CI,
        FUNC_AND,
        FUNC_XOR|FUNC_CI,
        FUNC_ADD,
        FUNC_SUB|FUNC_CI,
        FUNC_MUL,
        FUNC_NON
    };
    regA_Val = 0xAA;
    regB_Val = 0x55;
    srand(time(NULL));
REPEAT:
    // Initialize
    ABCmd_i.write(0);
    LoadA_i.write(false);
    LoadB_i.write(false);
    LoadCmd_i.write(false);
    MulL_i.write(false);
    MulH_i.write(false);
    Flag_i.write(false);
    reset.write(true);
    wait(clk.posedge_event());
    wait(clk.posedge_event());
    reset.write(false);
    wait(clk.posedge_event());
    // Load A Reg.
    LoadA_i.write(true);
    LoadB_i.write(false);
    ABCmd_i.write(regA_Val);
    wait(clk.posedge_event());
    // Load B Reg.
    LoadA_i.write(false);
    LoadB_i.write(true);
    ABCmd_i.write(regB_Val);
    wait(clk.posedge_event());
    // Load Cmd Reg.
    for (int i=0; i<N_TEST_OPS; i++)
    {
        LoadA_i.write(false);
        LoadB_i.write(false);
        Flag_i.write(false);
        MulL_i.write(false);
        MulH_i.write(false);
        // Load Command
        LoadCmd_i.write(true);
        ABCmd_i.write(Test_Ops[i]);
        wait(clk.posedge_event());
        LoadCmd_i.write(false);
        // Execute
        if (Test_Ops[i] & FUNC_MUL)
        {
            MulL_i.write(true);
            wait(clk.posedge_event());
            MulL_i.write(false);
            MulH_i.write(true);
            wait(clk.posedge_event());
            MulH_i.write(false);
            wait(clk.posedge_event());
        }
        else
        {
            Flag_i.write(true);
            wait(clk.posedge_event());
            Flag_i.write(false);
            wait(clk.posedge_event());
            wait(clk.posedge_event());
        }
    }
    
    nSim++;
    regA_Val = rand() & 0x00FF;
    regB_Val = rand() & 0x00FF;
    if (nSim<100)
        goto REPEAT;
    else
    {
#if defined(DVPI_SIM)
        sc_Stopped.write(true);
#endif
        sc_stop();
    }
}
//
// Cycle-Accurate Output Monitor
//
void sc_ALU8_Mult_TB::Test_Mon()
{
    char        szOP[16], szFLAG[16];
    sc_uint<8>  _rACC;
    sc_uint<16> MulVal;

    while(true)
    {
        wait(clk.posedge_event());
        if (LoadA_i.read())   rA.write(ABCmd_i.read());
        if (LoadB_i.read())   rB.write(ABCmd_i.read());
        if (LoadCmd_i.read())
        {
            rCmd.write(ABCmd_i.read());
            strcpy(szOP, decode_op(ABCmd_i.read()));
            regOP.write((sc_uint<8*4>)szOP[0]<<24|szOP[1]<<16|szOP[2]<<8|szOP[3]);
        }
        if (Flag_i.read())
        {
            wait(clk.posedge_event());
            rFLAG.write(ACC_o.read());
            szFLAG[0] = (rFLAG.get_new_value() & 0x10)? 'C':'-';
            szFLAG[1] = (rFLAG.get_new_value() & 0x08)? 'V':'-';
            szFLAG[2] = (rFLAG.get_new_value() & 0x04)? 'Z':'-';
            szFLAG[3] = (rFLAG.get_new_value() & 0x02)? 'N':'-';
            szFLAG[4] = (rFLAG.get_new_value() & 0x01)? 'H':'-';
            szFLAG[5] = '\0';
            regFLAG.write((sc_uint<5*8>)szFLAG[0]<<32|szFLAG[1]<<24|szFLAG[2]<<16|szFLAG[3]<<8|szFLAG[4]);
            wait(clk.posedge_event());
            rACC.write(ACC_o.read());
            switch (rCmd.read() & 0x0F)
            {
                case FUNC_ADD:  _rACC = rA.read() + rB.read();  break;
                case FUNC_SUB:  _rACC = rA.read() - rB.read();  break;
                case FUNC_OR:   _rACC = rA.read() | rB.read();  break;
                case FUNC_AND:  _rACC = rA.read() & rB.read();  break;
                case FUNC_XOR:  _rACC = rA.read() ^ rB.read();  break;
                case FUNC_NON:  _rACC = rA.read();              break;
                default:        _rACC = rACC.read();            break;
            }
            
            if (_rACC!=rACC.get_new_value())
                printf("Error:");
            else
                printf("Pass :");
            printf("A=0x%02X B=0x%02X CMD=%s FLAG=0x%02X{%s} ACC=0x%02X\n", \
                            (uint8_t)rA.read(), (uint8_t)rB.read(), decode_op((uint8_t)rCmd.read()),
                            (uint8_t)rFLAG.read(), szFLAG, (uint8_t)rACC.get_new_value());
        }
        if (MulL_i.read())
        {
            wait(clk.posedge_event());
            MulVal = (uint16_t)ACC_o.read();
            wait(clk.posedge_event());
            MulVal |= (uint16_t)ACC_o.read() << 8;
            regMUL.write(MulVal);
            
            if (MulVal!=(sc_uint<16>)(rA.read() * rB.read()))
                printf("Error:");
            else
                printf("Pass :");
            printf("A=0x%02X B=0x%02X CMD=%s Mult=0x%04X\n", (uint8_t)rA.read(), (uint8_t)rB.read(), "MUL", (uint16_t)MulVal);
        }
    }
}

