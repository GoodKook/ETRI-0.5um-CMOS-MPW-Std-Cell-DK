/**********************************************************************
Filename: sc_ALU8_Mult_TB.h
Purpose : Testbench
Author  : goodkook@gmail.com
History : Apr. 2025, First release
***********************************************************************/

#ifndef _SC_ALU8_Mult_TB_H_
#define _SC_ALU8_Mult_TB_H_

#include <systemc.h>
#include <stdio.h>

#include "def_commands.h"

SC_MODULE(sc_ALU8_Mult_TB)
{
    // Signal for DUT's inputs
    sc_clock                clk;
    sc_signal<bool>         reset;
    sc_signal<sc_uint<8> >  ABCmd_i;
    sc_signal<bool>         LoadA_i;
    sc_signal<bool>         LoadB_i;
    sc_signal<bool>         LoadCmd_i;
    sc_signal<bool>         MulL_i;
    sc_signal<bool>         MulH_i;
    sc_signal<bool>         Flag_i;
    // Signal for DUT's outputs
    sc_signal<sc_uint<8> >  ACC_o;

    sc_signal<bool>         sc_Stopped;

    sc_signal<sc_uint<8> >      rA, rB, rCmd;
    sc_signal<sc_uint<8> >      rFLAG, rACC;

    sc_signal<sc_uint<8*4> >    regOP;      // char[4]
    sc_signal<sc_uint<8*5> >    regFLAG;    // char[5]
    sc_signal<sc_uint<16> >     regMUL;

    // Test utilities
    void Test_Gen();
    void Test_Mon();
    char* decode_op(uint8_t op)
    {
        switch (op & 0x0F)
        {
            case FUNC_ADD:  return (char*)"ADD";
            case FUNC_SUB:  return (char*)"SUB";
            case FUNC_OR:   return (char*)"OR ";
            case FUNC_AND:  return (char*)"AND";
            case FUNC_XOR:  return (char*)"XOR";
            default:        return (char*)"nop";
        }
        return (char*)"NIL";
    }

    sc_trace_file* fp;  // VCD file

    SC_CTOR(sc_ALU8_Mult_TB):
        clk("clk", 100, SC_NS, 0.5, 0.0, SC_NS, false)
    {
        SC_THREAD(Test_Gen);
        sensitive << clk;

        SC_THREAD(Test_Mon);
        sensitive << clk;

        sc_Stopped.write(false);
        
        // WAVE
        fp = sc_create_vcd_trace_file("sc_ALU8_Mult_TB");
        fp->set_time_unit(100, SC_PS);  // resolution (trace) ps
        sc_trace(fp, clk,       "clk");
        sc_trace(fp, reset,     "reset");
        sc_trace(fp, ABCmd_i,   "ABCmd_i");
        sc_trace(fp, LoadA_i,   "LoadA_i");
        sc_trace(fp, LoadB_i,   "LoadB_i");
        sc_trace(fp, LoadCmd_i, "LoadCmd_i");
        sc_trace(fp, MulL_i,    "MulL_i");
        sc_trace(fp, MulH_i,    "MulH_i");
        sc_trace(fp, Flag_i,    "Flag_i");
        sc_trace(fp, ACC_o,     "ACC_o");
    }
    
    ~sc_ALU8_Mult_TB(void)
    {
    }
};

#endif
