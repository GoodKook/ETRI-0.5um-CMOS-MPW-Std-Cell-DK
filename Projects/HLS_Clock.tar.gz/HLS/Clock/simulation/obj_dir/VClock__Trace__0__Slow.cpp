// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_sc.h"
#include "VClock__Syms.h"


VL_ATTR_COLD void VClock___024root__trace_init_sub__TOP__0(VClock___024root* vlSelf, VerilatedVcd* tracep) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root__trace_init_sub__TOP__0\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->pushPrefix("Clock", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+23,0,"ap_ST_fsm_state1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBit(c+11,0,"ap_clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+12,0,"ap_rst",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+13,0,"clear",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBus(c+14,0,"start_r",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBus(c+15,0,"hh",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+16,0,"mm",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+17,0,"ss",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+1,0,"p_ss",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 5,0);
    tracep->declBus(c+2,0,"p_mm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 5,0);
    tracep->declBus(c+3,0,"p_hh",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+18,0,"ap_phi_mux_p_ss_loc_2_phi_fu_90_p10",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 5,0);
    tracep->declBus(c+4,0,"ap_CS_fsm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBit(c+4,0,"ap_CS_fsm_state1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+13,0,"clear_read_read_fu_60_p2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBus(c+14,0,"start_r_read_read_fu_54_p2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBus(c+5,0,"add_ln59_fu_162_p2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 5,0);
    tracep->declBus(c+6,0,"icmp_ln44_fu_156_p2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBus(c+7,0,"icmp_ln47_fu_181_p2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBus(c+19,0,"ap_phi_mux_p_mm_loc_3_phi_fu_108_p10",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 5,0);
    tracep->declBus(c+8,0,"add_ln56_fu_187_p2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 5,0);
    tracep->declBus(c+20,0,"ap_phi_mux_p_hh_loc_3_phi_fu_125_p10",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+21,0,"select_ln50_fu_218_p3",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+9,0,"icmp_ln50_fu_206_p2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBus(c+10,0,"add_ln53_fu_212_p2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+4,0,"ap_NS_fsm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBit(c+24,0,"ap_ST_fsm_state1_blk",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+22,0,"ap_condition_53",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+25,0,"ap_ce_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->popPrefix();
}

VL_ATTR_COLD void VClock___024root__trace_init_top(VClock___024root* vlSelf, VerilatedVcd* tracep) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root__trace_init_top\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    VClock___024root__trace_init_sub__TOP__0(vlSelf, tracep);
}

VL_ATTR_COLD void VClock___024root__trace_const_0(void* voidSelf, VerilatedVcd::Buffer* bufp);
VL_ATTR_COLD void VClock___024root__trace_full_0(void* voidSelf, VerilatedVcd::Buffer* bufp);
void VClock___024root__trace_chg_0(void* voidSelf, VerilatedVcd::Buffer* bufp);
void VClock___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/);

VL_ATTR_COLD void VClock___024root__trace_register(VClock___024root* vlSelf, VerilatedVcd* tracep) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root__trace_register\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    tracep->addConstCb(&VClock___024root__trace_const_0, 0U, vlSelf);
    tracep->addFullCb(&VClock___024root__trace_full_0, 0U, vlSelf);
    tracep->addChgCb(&VClock___024root__trace_chg_0, 0U, vlSelf);
    tracep->addCleanupCb(&VClock___024root__trace_cleanup, vlSelf);
}

VL_ATTR_COLD void VClock___024root__trace_const_0_sub_0(VClock___024root* vlSelf, VerilatedVcd::Buffer* bufp);

VL_ATTR_COLD void VClock___024root__trace_const_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root__trace_const_0\n"); );
    // Init
    VClock___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<VClock___024root*>(voidSelf);
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    VClock___024root__trace_const_0_sub_0((&vlSymsp->TOP), bufp);
}

VL_ATTR_COLD void VClock___024root__trace_const_0_sub_0(VClock___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root__trace_const_0_sub_0\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode);
    // Body
    bufp->fullBit(oldp+23,(1U));
    bufp->fullBit(oldp+24,(0U));
    bufp->fullBit(oldp+25,(vlSelfRef.Clock__DOT__ap_ce_reg));
}

VL_ATTR_COLD void VClock___024root__trace_full_0_sub_0(VClock___024root* vlSelf, VerilatedVcd::Buffer* bufp);

VL_ATTR_COLD void VClock___024root__trace_full_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root__trace_full_0\n"); );
    // Init
    VClock___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<VClock___024root*>(voidSelf);
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    VClock___024root__trace_full_0_sub_0((&vlSymsp->TOP), bufp);
}

VL_ATTR_COLD void VClock___024root__trace_full_0_sub_0(VClock___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root__trace_full_0_sub_0\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode);
    // Body
    bufp->fullCData(oldp+1,(vlSelfRef.Clock__DOT__p_ss),6);
    bufp->fullCData(oldp+2,(vlSelfRef.Clock__DOT__p_mm),6);
    bufp->fullCData(oldp+3,(vlSelfRef.Clock__DOT__p_hh),5);
    bufp->fullBit(oldp+4,(vlSelfRef.Clock__DOT__ap_CS_fsm));
    bufp->fullCData(oldp+5,((0x3fU & ((IData)(1U) + (IData)(vlSelfRef.Clock__DOT__p_ss)))),6);
    bufp->fullBit(oldp+6,((0x3bU == (IData)(vlSelfRef.Clock__DOT__p_ss))));
    bufp->fullBit(oldp+7,((0x3bU == (IData)(vlSelfRef.Clock__DOT__p_mm))));
    bufp->fullCData(oldp+8,((0x3fU & ((IData)(1U) + (IData)(vlSelfRef.Clock__DOT__p_mm)))),6);
    bufp->fullBit(oldp+9,((0x17U == (IData)(vlSelfRef.Clock__DOT__p_hh))));
    bufp->fullCData(oldp+10,((0x1fU & ((IData)(1U) 
                                       + (IData)(vlSelfRef.Clock__DOT__p_hh)))),5);
    bufp->fullBit(oldp+11,(vlSelfRef.__Vcellinp__Clock__ap_clk));
    bufp->fullBit(oldp+12,(vlSelfRef.__Vcellinp__Clock__ap_rst));
    bufp->fullBit(oldp+13,(vlSelfRef.__Vcellinp__Clock__clear));
    bufp->fullBit(oldp+14,(vlSelfRef.__Vcellinp__Clock__start_r));
    bufp->fullCData(oldp+15,((((IData)(vlSelfRef.Clock__DOT__ap_condition_53) 
                               & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                               ? (IData)(vlSelfRef.Clock__DOT__select_ln50_fu_218_p3)
                               : ((((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5) 
                                    | (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2)) 
                                   & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                   ? (IData)(vlSelfRef.Clock__DOT__p_hh)
                                   : 0U))),8);
    bufp->fullCData(oldp+16,((0x3fU & (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5) 
                                        & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                        ? ((IData)(1U) 
                                           + (IData)(vlSelfRef.Clock__DOT__p_mm))
                                        : (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2) 
                                            & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                            ? (IData)(vlSelfRef.Clock__DOT__p_mm)
                                            : 0U)))),8);
    bufp->fullCData(oldp+17,((0x3fU & (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_3) 
                                        & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                        ? ((IData)(1U) 
                                           + (IData)(vlSelfRef.Clock__DOT__p_ss))
                                        : (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_1) 
                                            & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                            ? (IData)(vlSelfRef.Clock__DOT__p_ss)
                                            : 0U)))),8);
    bufp->fullCData(oldp+18,((0x3fU & (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_3) 
                                        & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                        ? ((IData)(1U) 
                                           + (IData)(vlSelfRef.Clock__DOT__p_ss))
                                        : (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_1) 
                                            & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                            ? (IData)(vlSelfRef.Clock__DOT__p_ss)
                                            : 0U)))),6);
    bufp->fullCData(oldp+19,((0x3fU & (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5) 
                                        & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                        ? ((IData)(1U) 
                                           + (IData)(vlSelfRef.Clock__DOT__p_mm))
                                        : (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2) 
                                            & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                            ? (IData)(vlSelfRef.Clock__DOT__p_mm)
                                            : 0U)))),6);
    bufp->fullCData(oldp+20,((((IData)(vlSelfRef.Clock__DOT__ap_condition_53) 
                               & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                               ? (IData)(vlSelfRef.Clock__DOT__select_ln50_fu_218_p3)
                               : ((((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5) 
                                    | (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2)) 
                                   & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                   ? (IData)(vlSelfRef.Clock__DOT__p_hh)
                                   : 0U))),5);
    bufp->fullCData(oldp+21,(vlSelfRef.Clock__DOT__select_ln50_fu_218_p3),5);
    bufp->fullBit(oldp+22,(vlSelfRef.Clock__DOT__ap_condition_53));
}
