// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VClock.h for the primary calling header

#include "VClock__pch.h"
#include "VClock___024root.h"

VlCoroutine VClock___024root___eval_initial__TOP__Vtiming__0(VClock___024root* vlSelf);

void VClock___024root___eval_initial(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___eval_initial\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vm_traceActivity[1U] = 1U;
    VClock___024root___eval_initial__TOP__Vtiming__0(vlSelf);
}

VL_INLINE_OPT VlCoroutine VClock___024root___eval_initial__TOP__Vtiming__0(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___eval_initial__TOP__Vtiming__0\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../Clock/hls_component/syn/verilog/Clock.v", 
                                         55);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.Clock__DOT__p_ss = 0U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../Clock/hls_component/syn/verilog/Clock.v", 
                                         56);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.Clock__DOT__p_mm = 0U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../Clock/hls_component/syn/verilog/Clock.v", 
                                         57);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.Clock__DOT__p_hh = 0U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../Clock/hls_component/syn/verilog/Clock.v", 
                                         58);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.Clock__DOT__ap_CS_fsm = 1U;
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
}

void VClock___024root___ico_sequent__TOP__0(VClock___024root* vlSelf);

void VClock___024root___eval_ico(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___eval_ico\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VicoTriggered.word(0U))) {
        VClock___024root___ico_sequent__TOP__0(vlSelf);
        vlSelfRef.__Vm_traceActivity[3U] = 1U;
    }
}

VL_INLINE_OPT void VClock___024root___ico_sequent__TOP__0(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___ico_sequent__TOP__0\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    VL_ASSIGN_ISI(1,vlSelfRef.__Vcellinp__Clock__ap_clk, vlSelfRef.ap_clk);
    VL_ASSIGN_ISI(1,vlSelfRef.__Vcellinp__Clock__ap_rst, vlSelfRef.ap_rst);
    VL_ASSIGN_ISI(1,vlSelfRef.__Vcellinp__Clock__start_r, vlSelfRef.start_r);
    VL_ASSIGN_ISI(1,vlSelfRef.__Vcellinp__Clock__clear, vlSelfRef.clear);
    vlSelfRef.Clock__DOT__ap_condition_53 = ((~ (IData)(vlSelfRef.__Vcellinp__Clock__clear)) 
                                             & ((0x3bU 
                                                 == (IData)(vlSelfRef.Clock__DOT__p_mm)) 
                                                & ((0x3bU 
                                                    == (IData)(vlSelfRef.Clock__DOT__p_ss)) 
                                                   & (IData)(vlSelfRef.__Vcellinp__Clock__start_r))));
    vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_1 
        = (1U & ((~ (IData)(vlSelfRef.__Vcellinp__Clock__start_r)) 
                 & (~ (IData)(vlSelfRef.__Vcellinp__Clock__clear))));
    vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_4 
        = ((~ (IData)(vlSelfRef.__Vcellinp__Clock__clear)) 
           & (IData)(vlSelfRef.__Vcellinp__Clock__start_r));
    vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5 
        = ((0x3bU != (IData)(vlSelfRef.Clock__DOT__p_mm)) 
           & ((0x3bU == (IData)(vlSelfRef.Clock__DOT__p_ss)) 
              & (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_4)));
    vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_3 
        = ((0x3bU != (IData)(vlSelfRef.Clock__DOT__p_ss)) 
           & (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_4));
    VL_ASSIGN_SUI(8,vlSelfRef.ss, (0x3fU & (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_3) 
                                             & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                             ? ((IData)(1U) 
                                                + (IData)(vlSelfRef.Clock__DOT__p_ss))
                                             : (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_1) 
                                                 & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                                 ? (IData)(vlSelfRef.Clock__DOT__p_ss)
                                                 : 0U))));
    vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2 
        = ((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_3) 
           | (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_1));
    VL_ASSIGN_SUI(8,vlSelfRef.mm, (0x3fU & (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5) 
                                             & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                             ? ((IData)(1U) 
                                                + (IData)(vlSelfRef.Clock__DOT__p_mm))
                                             : (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2) 
                                                 & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                                 ? (IData)(vlSelfRef.Clock__DOT__p_mm)
                                                 : 0U))));
    VL_ASSIGN_SUI(8,vlSelfRef.hh, (((IData)(vlSelfRef.Clock__DOT__ap_condition_53) 
                                    & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                    ? (IData)(vlSelfRef.Clock__DOT__select_ln50_fu_218_p3)
                                    : ((((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5) 
                                         | (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2)) 
                                        & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                        ? (IData)(vlSelfRef.Clock__DOT__p_hh)
                                        : 0U)));
}

void VClock___024root___eval_triggers__ico(VClock___024root* vlSelf);

bool VClock___024root___eval_phase__ico(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___eval_phase__ico\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VicoExecute;
    // Body
    VClock___024root___eval_triggers__ico(vlSelf);
    __VicoExecute = vlSelfRef.__VicoTriggered.any();
    if (__VicoExecute) {
        VClock___024root___eval_ico(vlSelf);
    }
    return (__VicoExecute);
}

void VClock___024root___act_sequent__TOP__0(VClock___024root* vlSelf);

void VClock___024root___eval_act(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___eval_act\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((2ULL & vlSelfRef.__VactTriggered.word(0U))) {
        VClock___024root___act_sequent__TOP__0(vlSelf);
    }
}

VL_INLINE_OPT void VClock___024root___act_sequent__TOP__0(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___act_sequent__TOP__0\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.Clock__DOT__add_ln56_fu_187_p2 = (0x3fU 
                                                & ((IData)(1U) 
                                                   + (IData)(vlSelfRef.Clock__DOT__p_mm)));
    vlSelfRef.Clock__DOT__add_ln59_fu_162_p2 = (0x3fU 
                                                & ((IData)(1U) 
                                                   + (IData)(vlSelfRef.Clock__DOT__p_ss)));
    vlSelfRef.Clock__DOT__ap_NS_fsm = vlSelfRef.Clock__DOT__ap_CS_fsm;
    vlSelfRef.Clock__DOT__icmp_ln47_fu_181_p2 = (0x3bU 
                                                 == (IData)(vlSelfRef.Clock__DOT__p_mm));
    vlSelfRef.Clock__DOT__icmp_ln44_fu_156_p2 = (0x3bU 
                                                 == (IData)(vlSelfRef.Clock__DOT__p_ss));
    vlSelfRef.Clock__DOT__select_ln50_fu_218_p3 = (
                                                   (0x17U 
                                                    == (IData)(vlSelfRef.Clock__DOT__p_hh))
                                                    ? 0U
                                                    : 
                                                   (0x1fU 
                                                    & ((IData)(1U) 
                                                       + (IData)(vlSelfRef.Clock__DOT__p_hh))));
    vlSelfRef.Clock__DOT__ap_condition_53 = ((~ (IData)(vlSelfRef.__Vcellinp__Clock__clear)) 
                                             & ((0x3bU 
                                                 == (IData)(vlSelfRef.Clock__DOT__p_mm)) 
                                                & ((0x3bU 
                                                    == (IData)(vlSelfRef.Clock__DOT__p_ss)) 
                                                   & (IData)(vlSelfRef.__Vcellinp__Clock__start_r))));
    vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5 
        = ((0x3bU != (IData)(vlSelfRef.Clock__DOT__p_mm)) 
           & ((0x3bU == (IData)(vlSelfRef.Clock__DOT__p_ss)) 
              & (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_4)));
    vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_3 
        = ((0x3bU != (IData)(vlSelfRef.Clock__DOT__p_ss)) 
           & (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_4));
    VL_ASSIGN_SUI(8,vlSelfRef.ss, (0x3fU & (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_3) 
                                             & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                             ? ((IData)(1U) 
                                                + (IData)(vlSelfRef.Clock__DOT__p_ss))
                                             : (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_1) 
                                                 & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                                 ? (IData)(vlSelfRef.Clock__DOT__p_ss)
                                                 : 0U))));
    vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2 
        = ((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_3) 
           | (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_1));
    VL_ASSIGN_SUI(8,vlSelfRef.mm, (0x3fU & (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5) 
                                             & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                             ? ((IData)(1U) 
                                                + (IData)(vlSelfRef.Clock__DOT__p_mm))
                                             : (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2) 
                                                 & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                                 ? (IData)(vlSelfRef.Clock__DOT__p_mm)
                                                 : 0U))));
    VL_ASSIGN_SUI(8,vlSelfRef.hh, (((IData)(vlSelfRef.Clock__DOT__ap_condition_53) 
                                    & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                    ? (IData)(vlSelfRef.Clock__DOT__select_ln50_fu_218_p3)
                                    : ((((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5) 
                                         | (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2)) 
                                        & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                        ? (IData)(vlSelfRef.Clock__DOT__p_hh)
                                        : 0U)));
}

void VClock___024root___nba_sequent__TOP__0(VClock___024root* vlSelf);
void VClock___024root___nba_comb__TOP__0(VClock___024root* vlSelf);

void VClock___024root___eval_nba(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___eval_nba\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        VClock___024root___nba_sequent__TOP__0(vlSelf);
        vlSelfRef.__Vm_traceActivity[4U] = 1U;
    }
    if ((3ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        VClock___024root___nba_comb__TOP__0(vlSelf);
    }
}

VL_INLINE_OPT void VClock___024root___nba_sequent__TOP__0(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___nba_sequent__TOP__0\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __Vdly__Clock__DOT__ap_CS_fsm;
    __Vdly__Clock__DOT__ap_CS_fsm = 0;
    CData/*4:0*/ __Vdly__Clock__DOT__p_hh;
    __Vdly__Clock__DOT__p_hh = 0;
    CData/*4:0*/ __VdlyMask__Clock__DOT__p_hh;
    __VdlyMask__Clock__DOT__p_hh = 0;
    CData/*5:0*/ __Vdly__Clock__DOT__p_mm;
    __Vdly__Clock__DOT__p_mm = 0;
    CData/*5:0*/ __VdlyMask__Clock__DOT__p_mm;
    __VdlyMask__Clock__DOT__p_mm = 0;
    CData/*5:0*/ __Vdly__Clock__DOT__p_ss;
    __Vdly__Clock__DOT__p_ss = 0;
    CData/*5:0*/ __VdlyMask__Clock__DOT__p_ss;
    __VdlyMask__Clock__DOT__p_ss = 0;
    // Body
    __Vdly__Clock__DOT__ap_CS_fsm = ((IData)(vlSelfRef.__Vcellinp__Clock__ap_rst) 
                                     || (IData)(vlSelfRef.Clock__DOT__ap_NS_fsm));
    if (vlSelfRef.__Vcellinp__Clock__ap_rst) {
        __Vdly__Clock__DOT__p_hh = 0U;
        __VdlyMask__Clock__DOT__p_hh = 0x1fU;
        __Vdly__Clock__DOT__p_ss = 0U;
        __VdlyMask__Clock__DOT__p_ss = 0x3fU;
        __Vdly__Clock__DOT__p_mm = 0U;
        __VdlyMask__Clock__DOT__p_mm = 0x3fU;
    } else {
        if (vlSelfRef.Clock__DOT__ap_CS_fsm) {
            if (vlSelfRef.__Vcellinp__Clock__clear) {
                __Vdly__Clock__DOT__p_hh = 0U;
                __VdlyMask__Clock__DOT__p_hh = 0x1fU;
            } else if (vlSelfRef.Clock__DOT__ap_condition_53) {
                __Vdly__Clock__DOT__p_hh = vlSelfRef.Clock__DOT__select_ln50_fu_218_p3;
                __VdlyMask__Clock__DOT__p_hh = 0x1fU;
            }
        }
        if (((((IData)(vlSelfRef.Clock__DOT__icmp_ln44_fu_156_p2) 
               & (IData)(vlSelfRef.__Vcellinp__Clock__start_r)) 
              | (IData)(vlSelfRef.__Vcellinp__Clock__clear)) 
             & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))) {
            __Vdly__Clock__DOT__p_ss = 0U;
            __VdlyMask__Clock__DOT__p_ss = 0x3fU;
        } else if (((((~ (IData)(vlSelfRef.Clock__DOT__icmp_ln44_fu_156_p2)) 
                      & (IData)(vlSelfRef.__Vcellinp__Clock__start_r)) 
                     & (~ (IData)(vlSelfRef.__Vcellinp__Clock__clear))) 
                    & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))) {
            __Vdly__Clock__DOT__p_ss = vlSelfRef.Clock__DOT__add_ln59_fu_162_p2;
            __VdlyMask__Clock__DOT__p_ss = 0x3fU;
        }
        if ((((((IData)(vlSelfRef.Clock__DOT__icmp_ln47_fu_181_p2) 
                & (0x3bU == (IData)(vlSelfRef.Clock__DOT__p_ss))) 
               & (IData)(vlSelfRef.__Vcellinp__Clock__start_r)) 
              | (IData)(vlSelfRef.__Vcellinp__Clock__clear)) 
             & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))) {
            __Vdly__Clock__DOT__p_mm = 0U;
            __VdlyMask__Clock__DOT__p_mm = 0x3fU;
        } else if ((((((~ (IData)(vlSelfRef.Clock__DOT__icmp_ln47_fu_181_p2)) 
                       & (0x3bU == (IData)(vlSelfRef.Clock__DOT__p_ss))) 
                      & (IData)(vlSelfRef.__Vcellinp__Clock__start_r)) 
                     & (~ (IData)(vlSelfRef.__Vcellinp__Clock__clear))) 
                    & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))) {
            __Vdly__Clock__DOT__p_mm = vlSelfRef.Clock__DOT__add_ln56_fu_187_p2;
            __VdlyMask__Clock__DOT__p_mm = 0x3fU;
        }
    }
    vlSelfRef.Clock__DOT__p_hh = (((IData)(__Vdly__Clock__DOT__p_hh) 
                                   & (IData)(__VdlyMask__Clock__DOT__p_hh)) 
                                  | ((IData)(vlSelfRef.Clock__DOT__p_hh) 
                                     & (~ (IData)(__VdlyMask__Clock__DOT__p_hh))));
    __VdlyMask__Clock__DOT__p_hh = 0U;
    vlSelfRef.Clock__DOT__ap_CS_fsm = __Vdly__Clock__DOT__ap_CS_fsm;
    vlSelfRef.Clock__DOT__p_mm = (((IData)(__Vdly__Clock__DOT__p_mm) 
                                   & (IData)(__VdlyMask__Clock__DOT__p_mm)) 
                                  | ((IData)(vlSelfRef.Clock__DOT__p_mm) 
                                     & (~ (IData)(__VdlyMask__Clock__DOT__p_mm))));
    __VdlyMask__Clock__DOT__p_mm = 0U;
    vlSelfRef.Clock__DOT__p_ss = (((IData)(__Vdly__Clock__DOT__p_ss) 
                                   & (IData)(__VdlyMask__Clock__DOT__p_ss)) 
                                  | ((IData)(vlSelfRef.Clock__DOT__p_ss) 
                                     & (~ (IData)(__VdlyMask__Clock__DOT__p_ss))));
    __VdlyMask__Clock__DOT__p_ss = 0U;
}

VL_INLINE_OPT void VClock___024root___nba_comb__TOP__0(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___nba_comb__TOP__0\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.Clock__DOT__select_ln50_fu_218_p3 = (
                                                   (0x17U 
                                                    == (IData)(vlSelfRef.Clock__DOT__p_hh))
                                                    ? 0U
                                                    : 
                                                   (0x1fU 
                                                    & ((IData)(1U) 
                                                       + (IData)(vlSelfRef.Clock__DOT__p_hh))));
    vlSelfRef.Clock__DOT__ap_NS_fsm = vlSelfRef.Clock__DOT__ap_CS_fsm;
    vlSelfRef.Clock__DOT__add_ln56_fu_187_p2 = (0x3fU 
                                                & ((IData)(1U) 
                                                   + (IData)(vlSelfRef.Clock__DOT__p_mm)));
    vlSelfRef.Clock__DOT__icmp_ln47_fu_181_p2 = (0x3bU 
                                                 == (IData)(vlSelfRef.Clock__DOT__p_mm));
    vlSelfRef.Clock__DOT__add_ln59_fu_162_p2 = (0x3fU 
                                                & ((IData)(1U) 
                                                   + (IData)(vlSelfRef.Clock__DOT__p_ss)));
    vlSelfRef.Clock__DOT__icmp_ln44_fu_156_p2 = (0x3bU 
                                                 == (IData)(vlSelfRef.Clock__DOT__p_ss));
    vlSelfRef.Clock__DOT__ap_condition_53 = ((~ (IData)(vlSelfRef.__Vcellinp__Clock__clear)) 
                                             & ((0x3bU 
                                                 == (IData)(vlSelfRef.Clock__DOT__p_mm)) 
                                                & ((0x3bU 
                                                    == (IData)(vlSelfRef.Clock__DOT__p_ss)) 
                                                   & (IData)(vlSelfRef.__Vcellinp__Clock__start_r))));
    vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5 
        = ((0x3bU != (IData)(vlSelfRef.Clock__DOT__p_mm)) 
           & ((0x3bU == (IData)(vlSelfRef.Clock__DOT__p_ss)) 
              & (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_4)));
    vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_3 
        = ((0x3bU != (IData)(vlSelfRef.Clock__DOT__p_ss)) 
           & (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_4));
    VL_ASSIGN_SUI(8,vlSelfRef.ss, (0x3fU & (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_3) 
                                             & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                             ? ((IData)(1U) 
                                                + (IData)(vlSelfRef.Clock__DOT__p_ss))
                                             : (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_1) 
                                                 & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                                 ? (IData)(vlSelfRef.Clock__DOT__p_ss)
                                                 : 0U))));
    vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2 
        = ((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_3) 
           | (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_1));
    VL_ASSIGN_SUI(8,vlSelfRef.mm, (0x3fU & (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5) 
                                             & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                             ? ((IData)(1U) 
                                                + (IData)(vlSelfRef.Clock__DOT__p_mm))
                                             : (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2) 
                                                 & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                                 ? (IData)(vlSelfRef.Clock__DOT__p_mm)
                                                 : 0U))));
    VL_ASSIGN_SUI(8,vlSelfRef.hh, (((IData)(vlSelfRef.Clock__DOT__ap_condition_53) 
                                    & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                    ? (IData)(vlSelfRef.Clock__DOT__select_ln50_fu_218_p3)
                                    : ((((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5) 
                                         | (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2)) 
                                        & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                        ? (IData)(vlSelfRef.Clock__DOT__p_hh)
                                        : 0U)));
}

void VClock___024root___timing_resume(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___timing_resume\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((2ULL & vlSelfRef.__VactTriggered.word(0U))) {
        vlSelfRef.__VdlySched.resume();
    }
}

void VClock___024root___eval_triggers__act(VClock___024root* vlSelf);

bool VClock___024root___eval_phase__act(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___eval_phase__act\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlTriggerVec<2> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    VClock___024root___eval_triggers__act(vlSelf);
    __VactExecute = vlSelfRef.__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelfRef.__VactTriggered, vlSelfRef.__VnbaTriggered);
        vlSelfRef.__VnbaTriggered.thisOr(vlSelfRef.__VactTriggered);
        VClock___024root___timing_resume(vlSelf);
        VClock___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool VClock___024root___eval_phase__nba(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___eval_phase__nba\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelfRef.__VnbaTriggered.any();
    if (__VnbaExecute) {
        VClock___024root___eval_nba(vlSelf);
        vlSelfRef.__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void VClock___024root___dump_triggers__ico(VClock___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void VClock___024root___dump_triggers__nba(VClock___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void VClock___024root___dump_triggers__act(VClock___024root* vlSelf);
#endif  // VL_DEBUG

void VClock___024root___eval(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___eval\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __VicoIterCount;
    CData/*0:0*/ __VicoContinue;
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VicoIterCount = 0U;
    vlSelfRef.__VicoFirstIteration = 1U;
    __VicoContinue = 1U;
    while (__VicoContinue) {
        if (VL_UNLIKELY(((0x64U < __VicoIterCount)))) {
#ifdef VL_DEBUG
            VClock___024root___dump_triggers__ico(vlSelf);
#endif
            VL_FATAL_MT("../Clock/hls_component/syn/verilog/Clock.v", 11, "", "Input combinational region did not converge.");
        }
        __VicoIterCount = ((IData)(1U) + __VicoIterCount);
        __VicoContinue = 0U;
        if (VClock___024root___eval_phase__ico(vlSelf)) {
            __VicoContinue = 1U;
        }
        vlSelfRef.__VicoFirstIteration = 0U;
    }
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY(((0x64U < __VnbaIterCount)))) {
#ifdef VL_DEBUG
            VClock___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("../Clock/hls_component/syn/verilog/Clock.v", 11, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelfRef.__VactIterCount = 0U;
        vlSelfRef.__VactContinue = 1U;
        while (vlSelfRef.__VactContinue) {
            if (VL_UNLIKELY(((0x64U < vlSelfRef.__VactIterCount)))) {
#ifdef VL_DEBUG
                VClock___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("../Clock/hls_component/syn/verilog/Clock.v", 11, "", "Active region did not converge.");
            }
            vlSelfRef.__VactIterCount = ((IData)(1U) 
                                         + vlSelfRef.__VactIterCount);
            vlSelfRef.__VactContinue = 0U;
            if (VClock___024root___eval_phase__act(vlSelf)) {
                vlSelfRef.__VactContinue = 1U;
            }
        }
        if (VClock___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void VClock___024root___eval_debug_assertions(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___eval_debug_assertions\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
