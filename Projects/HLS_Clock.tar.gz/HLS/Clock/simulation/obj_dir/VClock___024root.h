// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design internal header
// See VClock.h for the primary calling header

#ifndef VERILATED_VCLOCK___024ROOT_H_
#define VERILATED_VCLOCK___024ROOT_H_  // guard

#include "systemc"
#include "verilated_sc.h"
#include "verilated.h"
#include "verilated_timing.h"


class VClock__Syms;

class alignas(VL_CACHE_LINE_BYTES) VClock___024root final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    CData/*0:0*/ __Vcellinp__Clock__ap_clk;
    CData/*0:0*/ __Vcellinp__Clock__start_r;
    CData/*0:0*/ __Vcellinp__Clock__clear;
    CData/*0:0*/ __Vcellinp__Clock__ap_rst;
    CData/*5:0*/ Clock__DOT__p_ss;
    CData/*5:0*/ Clock__DOT__p_mm;
    CData/*4:0*/ Clock__DOT__p_hh;
    CData/*0:0*/ Clock__DOT__ap_CS_fsm;
    CData/*5:0*/ Clock__DOT__add_ln59_fu_162_p2;
    CData/*0:0*/ Clock__DOT__icmp_ln44_fu_156_p2;
    CData/*0:0*/ Clock__DOT__icmp_ln47_fu_181_p2;
    CData/*5:0*/ Clock__DOT__add_ln56_fu_187_p2;
    CData/*4:0*/ Clock__DOT__select_ln50_fu_218_p3;
    CData/*0:0*/ Clock__DOT__ap_NS_fsm;
    CData/*0:0*/ Clock__DOT__ap_condition_53;
    CData/*0:0*/ Clock__DOT__ap_ce_reg;
    CData/*0:0*/ Clock__DOT____VdfgRegularize_hc8442788_0_1;
    CData/*0:0*/ Clock__DOT____VdfgRegularize_hc8442788_0_2;
    CData/*0:0*/ Clock__DOT____VdfgRegularize_hc8442788_0_3;
    CData/*0:0*/ Clock__DOT____VdfgRegularize_hc8442788_0_4;
    CData/*0:0*/ Clock__DOT____VdfgRegularize_hc8442788_0_5;
    CData/*0:0*/ __VstlFirstIteration;
    CData/*0:0*/ __VicoFirstIteration;
    CData/*0:0*/ __Vtrigprevexpr___TOP____Vcellinp__Clock__ap_clk__0;
    CData/*0:0*/ __VactContinue;
    IData/*31:0*/ __VactIterCount;
    VlUnpacked<CData/*0:0*/, 5> __Vm_traceActivity;
    sc_core::sc_in<bool> ap_clk;
    sc_core::sc_in<bool> ap_rst;
    sc_core::sc_in<bool> clear;
    sc_core::sc_in<bool> start_r;
    sc_core::sc_out<sc_dt::sc_uint<8> > hh;
    sc_core::sc_out<sc_dt::sc_uint<8> > mm;
    sc_core::sc_out<sc_dt::sc_uint<8> > ss;
    VlDelayScheduler __VdlySched;
    VlTriggerVec<1> __VstlTriggered;
    VlTriggerVec<1> __VicoTriggered;
    VlTriggerVec<2> __VactTriggered;
    VlTriggerVec<2> __VnbaTriggered;

    // INTERNAL VARIABLES
    VClock__Syms* const vlSymsp;

    // CONSTRUCTORS
    VClock___024root(VClock__Syms* symsp, const char* v__name);
    ~VClock___024root();
    VL_UNCOPYABLE(VClock___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
