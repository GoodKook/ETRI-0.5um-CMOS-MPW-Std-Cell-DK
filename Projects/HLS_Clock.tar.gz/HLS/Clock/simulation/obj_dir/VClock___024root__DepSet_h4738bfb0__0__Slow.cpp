// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VClock.h for the primary calling header

#include "VClock__pch.h"
#include "VClock___024root.h"

VL_ATTR_COLD void VClock___024root___eval_static(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___eval_static\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vtrigprevexpr___TOP____Vcellinp__Clock__ap_clk__0 
        = vlSelfRef.__Vcellinp__Clock__ap_clk;
}

VL_ATTR_COLD void VClock___024root___eval_final(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___eval_final\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void VClock___024root___dump_triggers__stl(VClock___024root* vlSelf);
#endif  // VL_DEBUG
VL_ATTR_COLD bool VClock___024root___eval_phase__stl(VClock___024root* vlSelf);

VL_ATTR_COLD void VClock___024root___eval_settle(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___eval_settle\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __VstlIterCount;
    CData/*0:0*/ __VstlContinue;
    // Body
    __VstlIterCount = 0U;
    vlSelfRef.__VstlFirstIteration = 1U;
    __VstlContinue = 1U;
    while (__VstlContinue) {
        if (VL_UNLIKELY(((0x64U < __VstlIterCount)))) {
#ifdef VL_DEBUG
            VClock___024root___dump_triggers__stl(vlSelf);
#endif
            VL_FATAL_MT("../Clock/hls_component/syn/verilog/Clock.v", 11, "", "Settle region did not converge.");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        __VstlContinue = 0U;
        if (VClock___024root___eval_phase__stl(vlSelf)) {
            __VstlContinue = 1U;
        }
        vlSelfRef.__VstlFirstIteration = 0U;
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void VClock___024root___dump_triggers__stl(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___dump_triggers__stl\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VstlTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VstlTriggered.word(0U))) {
        VL_DBG_MSGF("         'stl' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void VClock___024root___stl_sequent__TOP__0(VClock___024root* vlSelf);
VL_ATTR_COLD void VClock___024root____Vm_traceActivitySetAll(VClock___024root* vlSelf);

VL_ATTR_COLD void VClock___024root___eval_stl(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___eval_stl\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VstlTriggered.word(0U))) {
        VClock___024root___stl_sequent__TOP__0(vlSelf);
        VClock___024root____Vm_traceActivitySetAll(vlSelf);
    }
}

VL_ATTR_COLD void VClock___024root___stl_sequent__TOP__0(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___stl_sequent__TOP__0\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    VL_ASSIGN_ISI(1,vlSelfRef.__Vcellinp__Clock__ap_rst, vlSelfRef.ap_rst);
    VL_ASSIGN_ISI(1,vlSelfRef.__Vcellinp__Clock__ap_clk, vlSelfRef.ap_clk);
    vlSelfRef.Clock__DOT__add_ln56_fu_187_p2 = (0x3fU 
                                                & ((IData)(1U) 
                                                   + (IData)(vlSelfRef.Clock__DOT__p_mm)));
    vlSelfRef.Clock__DOT__add_ln59_fu_162_p2 = (0x3fU 
                                                & ((IData)(1U) 
                                                   + (IData)(vlSelfRef.Clock__DOT__p_ss)));
    vlSelfRef.Clock__DOT__ap_NS_fsm = vlSelfRef.Clock__DOT__ap_CS_fsm;
    vlSelfRef.Clock__DOT__icmp_ln47_fu_181_p2 = (0x3bU 
                                                 == (IData)(vlSelfRef.Clock__DOT__p_mm));
    vlSelfRef.Clock__DOT__icmp_ln44_fu_156_p2 = (0x3bU 
                                                 == (IData)(vlSelfRef.Clock__DOT__p_ss));
    vlSelfRef.Clock__DOT__select_ln50_fu_218_p3 = (
                                                   (0x17U 
                                                    == (IData)(vlSelfRef.Clock__DOT__p_hh))
                                                    ? 0U
                                                    : 
                                                   (0x1fU 
                                                    & ((IData)(1U) 
                                                       + (IData)(vlSelfRef.Clock__DOT__p_hh))));
    VL_ASSIGN_ISI(1,vlSelfRef.__Vcellinp__Clock__start_r, vlSelfRef.start_r);
    VL_ASSIGN_ISI(1,vlSelfRef.__Vcellinp__Clock__clear, vlSelfRef.clear);
    vlSelfRef.Clock__DOT__ap_condition_53 = ((~ (IData)(vlSelfRef.__Vcellinp__Clock__clear)) 
                                             & ((0x3bU 
                                                 == (IData)(vlSelfRef.Clock__DOT__p_mm)) 
                                                & ((0x3bU 
                                                    == (IData)(vlSelfRef.Clock__DOT__p_ss)) 
                                                   & (IData)(vlSelfRef.__Vcellinp__Clock__start_r))));
    vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_1 
        = (1U & ((~ (IData)(vlSelfRef.__Vcellinp__Clock__start_r)) 
                 & (~ (IData)(vlSelfRef.__Vcellinp__Clock__clear))));
    vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_4 
        = ((~ (IData)(vlSelfRef.__Vcellinp__Clock__clear)) 
           & (IData)(vlSelfRef.__Vcellinp__Clock__start_r));
    vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5 
        = ((0x3bU != (IData)(vlSelfRef.Clock__DOT__p_mm)) 
           & ((0x3bU == (IData)(vlSelfRef.Clock__DOT__p_ss)) 
              & (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_4)));
    vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_3 
        = ((0x3bU != (IData)(vlSelfRef.Clock__DOT__p_ss)) 
           & (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_4));
    VL_ASSIGN_SUI(8,vlSelfRef.ss, (0x3fU & (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_3) 
                                             & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                             ? ((IData)(1U) 
                                                + (IData)(vlSelfRef.Clock__DOT__p_ss))
                                             : (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_1) 
                                                 & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                                 ? (IData)(vlSelfRef.Clock__DOT__p_ss)
                                                 : 0U))));
    vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2 
        = ((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_3) 
           | (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_1));
    VL_ASSIGN_SUI(8,vlSelfRef.mm, (0x3fU & (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5) 
                                             & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                             ? ((IData)(1U) 
                                                + (IData)(vlSelfRef.Clock__DOT__p_mm))
                                             : (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2) 
                                                 & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                                 ? (IData)(vlSelfRef.Clock__DOT__p_mm)
                                                 : 0U))));
    VL_ASSIGN_SUI(8,vlSelfRef.hh, (((IData)(vlSelfRef.Clock__DOT__ap_condition_53) 
                                    & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                    ? (IData)(vlSelfRef.Clock__DOT__select_ln50_fu_218_p3)
                                    : ((((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5) 
                                         | (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2)) 
                                        & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                        ? (IData)(vlSelfRef.Clock__DOT__p_hh)
                                        : 0U)));
}

VL_ATTR_COLD void VClock___024root___eval_triggers__stl(VClock___024root* vlSelf);

VL_ATTR_COLD bool VClock___024root___eval_phase__stl(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___eval_phase__stl\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VstlExecute;
    // Body
    VClock___024root___eval_triggers__stl(vlSelf);
    __VstlExecute = vlSelfRef.__VstlTriggered.any();
    if (__VstlExecute) {
        VClock___024root___eval_stl(vlSelf);
    }
    return (__VstlExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void VClock___024root___dump_triggers__ico(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___dump_triggers__ico\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VicoTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VicoTriggered.word(0U))) {
        VL_DBG_MSGF("         'ico' region trigger index 0 is active: Internal 'ico' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void VClock___024root___dump_triggers__act(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___dump_triggers__act\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VactTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 0 is active: @(posedge __Vcellinp__Clock__ap_clk)\n");
    }
    if ((2ULL & vlSelfRef.__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 1 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void VClock___024root___dump_triggers__nba(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___dump_triggers__nba\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VnbaTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 0 is active: @(posedge __Vcellinp__Clock__ap_clk)\n");
    }
    if ((2ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 1 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void VClock___024root____Vm_traceActivitySetAll(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root____Vm_traceActivitySetAll\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vm_traceActivity[0U] = 1U;
    vlSelfRef.__Vm_traceActivity[1U] = 1U;
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.__Vm_traceActivity[3U] = 1U;
    vlSelfRef.__Vm_traceActivity[4U] = 1U;
}

VL_ATTR_COLD void VClock___024root___ctor_var_reset(VClock___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root___ctor_var_reset\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const uint64_t __VscopeHash = VL_MURMUR64_HASH(vlSelf->name());
    vlSelf->__Vcellinp__Clock__start_r = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17537334507410454633ull);
    vlSelf->__Vcellinp__Clock__clear = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14499921191558601294ull);
    vlSelf->__Vcellinp__Clock__ap_rst = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 11750130501319352904ull);
    vlSelf->__Vcellinp__Clock__ap_clk = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 17583396906895105853ull);
    vlSelf->Clock__DOT__p_ss = VL_SCOPED_RAND_RESET_I(6, __VscopeHash, 3421645062090405796ull);
    vlSelf->Clock__DOT__p_mm = VL_SCOPED_RAND_RESET_I(6, __VscopeHash, 4052723332802369621ull);
    vlSelf->Clock__DOT__p_hh = VL_SCOPED_RAND_RESET_I(5, __VscopeHash, 10608041163874352192ull);
    vlSelf->Clock__DOT__ap_CS_fsm = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1568725334073897720ull);
    vlSelf->Clock__DOT__add_ln59_fu_162_p2 = VL_SCOPED_RAND_RESET_I(6, __VscopeHash, 16185820055253621572ull);
    vlSelf->Clock__DOT__icmp_ln44_fu_156_p2 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1771963177141715174ull);
    vlSelf->Clock__DOT__icmp_ln47_fu_181_p2 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9632965420543286341ull);
    vlSelf->Clock__DOT__add_ln56_fu_187_p2 = VL_SCOPED_RAND_RESET_I(6, __VscopeHash, 11420732996767288434ull);
    vlSelf->Clock__DOT__select_ln50_fu_218_p3 = VL_SCOPED_RAND_RESET_I(5, __VscopeHash, 3224008687185251353ull);
    vlSelf->Clock__DOT__ap_NS_fsm = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3315612093623155096ull);
    vlSelf->Clock__DOT__ap_condition_53 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1365093876141998341ull);
    vlSelf->Clock__DOT__ap_ce_reg = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3554724924123177644ull);
    vlSelf->Clock__DOT____VdfgRegularize_hc8442788_0_1 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6727932895333823652ull);
    vlSelf->Clock__DOT____VdfgRegularize_hc8442788_0_2 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5503966990965204699ull);
    vlSelf->Clock__DOT____VdfgRegularize_hc8442788_0_3 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4340076503241566270ull);
    vlSelf->Clock__DOT____VdfgRegularize_hc8442788_0_4 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 2035282836596094808ull);
    vlSelf->Clock__DOT____VdfgRegularize_hc8442788_0_5 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10151201619513539126ull);
    vlSelf->__Vtrigprevexpr___TOP____Vcellinp__Clock__ap_clk__0 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12341240328128374867ull);
    for (int __Vi0 = 0; __Vi0 < 5; ++__Vi0) {
        vlSelf->__Vm_traceActivity[__Vi0] = 0;
    }
}
