// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_sc.h"
#include "VClock__Syms.h"


void VClock___024root__trace_chg_0_sub_0(VClock___024root* vlSelf, VerilatedVcd::Buffer* bufp);

void VClock___024root__trace_chg_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root__trace_chg_0\n"); );
    // Init
    VClock___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<VClock___024root*>(voidSelf);
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    if (VL_UNLIKELY(!vlSymsp->__Vm_activity)) return;
    // Body
    VClock___024root__trace_chg_0_sub_0((&vlSymsp->TOP), bufp);
}

void VClock___024root__trace_chg_0_sub_0(VClock___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root__trace_chg_0_sub_0\n"); );
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode + 1);
    // Body
    if (VL_UNLIKELY((((vlSelfRef.__Vm_traceActivity
                       [1U] | vlSelfRef.__Vm_traceActivity
                       [2U]) | vlSelfRef.__Vm_traceActivity
                      [4U])))) {
        bufp->chgCData(oldp+0,(vlSelfRef.Clock__DOT__p_ss),6);
        bufp->chgCData(oldp+1,(vlSelfRef.Clock__DOT__p_mm),6);
        bufp->chgCData(oldp+2,(vlSelfRef.Clock__DOT__p_hh),5);
        bufp->chgBit(oldp+3,(vlSelfRef.Clock__DOT__ap_CS_fsm));
        bufp->chgCData(oldp+4,((0x3fU & ((IData)(1U) 
                                         + (IData)(vlSelfRef.Clock__DOT__p_ss)))),6);
        bufp->chgBit(oldp+5,((0x3bU == (IData)(vlSelfRef.Clock__DOT__p_ss))));
        bufp->chgBit(oldp+6,((0x3bU == (IData)(vlSelfRef.Clock__DOT__p_mm))));
        bufp->chgCData(oldp+7,((0x3fU & ((IData)(1U) 
                                         + (IData)(vlSelfRef.Clock__DOT__p_mm)))),6);
        bufp->chgBit(oldp+8,((0x17U == (IData)(vlSelfRef.Clock__DOT__p_hh))));
        bufp->chgCData(oldp+9,((0x1fU & ((IData)(1U) 
                                         + (IData)(vlSelfRef.Clock__DOT__p_hh)))),5);
    }
    if (VL_UNLIKELY((vlSelfRef.__Vm_traceActivity[3U]))) {
        bufp->chgBit(oldp+10,(vlSelfRef.__Vcellinp__Clock__ap_clk));
        bufp->chgBit(oldp+11,(vlSelfRef.__Vcellinp__Clock__ap_rst));
        bufp->chgBit(oldp+12,(vlSelfRef.__Vcellinp__Clock__clear));
        bufp->chgBit(oldp+13,(vlSelfRef.__Vcellinp__Clock__start_r));
    }
    bufp->chgCData(oldp+14,((((IData)(vlSelfRef.Clock__DOT__ap_condition_53) 
                              & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                              ? (IData)(vlSelfRef.Clock__DOT__select_ln50_fu_218_p3)
                              : ((((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5) 
                                   | (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2)) 
                                  & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                  ? (IData)(vlSelfRef.Clock__DOT__p_hh)
                                  : 0U))),8);
    bufp->chgCData(oldp+15,((0x3fU & (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5) 
                                       & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                       ? ((IData)(1U) 
                                          + (IData)(vlSelfRef.Clock__DOT__p_mm))
                                       : (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2) 
                                           & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                           ? (IData)(vlSelfRef.Clock__DOT__p_mm)
                                           : 0U)))),8);
    bufp->chgCData(oldp+16,((0x3fU & (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_3) 
                                       & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                       ? ((IData)(1U) 
                                          + (IData)(vlSelfRef.Clock__DOT__p_ss))
                                       : (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_1) 
                                           & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                           ? (IData)(vlSelfRef.Clock__DOT__p_ss)
                                           : 0U)))),8);
    bufp->chgCData(oldp+17,((0x3fU & (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_3) 
                                       & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                       ? ((IData)(1U) 
                                          + (IData)(vlSelfRef.Clock__DOT__p_ss))
                                       : (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_1) 
                                           & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                           ? (IData)(vlSelfRef.Clock__DOT__p_ss)
                                           : 0U)))),6);
    bufp->chgCData(oldp+18,((0x3fU & (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5) 
                                       & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                       ? ((IData)(1U) 
                                          + (IData)(vlSelfRef.Clock__DOT__p_mm))
                                       : (((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2) 
                                           & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                           ? (IData)(vlSelfRef.Clock__DOT__p_mm)
                                           : 0U)))),6);
    bufp->chgCData(oldp+19,((((IData)(vlSelfRef.Clock__DOT__ap_condition_53) 
                              & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                              ? (IData)(vlSelfRef.Clock__DOT__select_ln50_fu_218_p3)
                              : ((((IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_5) 
                                   | (IData)(vlSelfRef.Clock__DOT____VdfgRegularize_hc8442788_0_2)) 
                                  & (IData)(vlSelfRef.Clock__DOT__ap_CS_fsm))
                                  ? (IData)(vlSelfRef.Clock__DOT__p_hh)
                                  : 0U))),5);
    bufp->chgCData(oldp+20,(vlSelfRef.Clock__DOT__select_ln50_fu_218_p3),5);
    bufp->chgBit(oldp+21,(vlSelfRef.Clock__DOT__ap_condition_53));
}

void VClock___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    VClock___024root__trace_cleanup\n"); );
    // Init
    VClock___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<VClock___024root*>(voidSelf);
    VClock__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    vlSymsp->__Vm_activity = false;
    vlSymsp->TOP.__Vm_traceActivity[0U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[1U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[2U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[3U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[4U] = 0U;
}
