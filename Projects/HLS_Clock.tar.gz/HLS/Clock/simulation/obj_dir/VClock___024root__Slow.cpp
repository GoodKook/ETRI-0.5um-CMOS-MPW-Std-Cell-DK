// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See VClock.h for the primary calling header

#include "VClock__pch.h"
#include "VClock__Syms.h"
#include "VClock___024root.h"

void VClock___024root___ctor_var_reset(VClock___024root* vlSelf);

VClock___024root::VClock___024root(VClock__Syms* symsp, const char* v__name)
    : VerilatedModule{v__name}
    , ap_clk("ap_clk")
    , ap_rst("ap_rst")
    , clear("clear")
    , start_r("start_r")
    , hh("hh")
    , mm("mm")
    , ss("ss")
    , __VdlySched{*symsp->_vm_contextp__}
    , vlSymsp{symsp}
 {
    // Reset structure values
    VClock___024root___ctor_var_reset(this);
}

void VClock___024root::__Vconfigure(bool first) {
    (void)first;  // Prevent unused variable warning
}

VClock___024root::~VClock___024root() {
}
