//=======================================================================
// Co-Simulation of SystemC VPI+iVerilog
// Filename: vpi_Clock_tb.cpp
// Purpose: Instantiate SC Testbench,
//          Read HDL signal via VPI call-back & Write to SC signals
// Author: GoodKook, goodkook@gmail.com
// History: 2025, Aug. 31
//

#include <systemc.h>
#include "sc_Clock_TB.h"

#include "vpi_Clock_tb_ports.h"
#include "vpi_Clock_tb_exports.h"

#define CLOCK_PERIOD    50
#define SC_TIME_UNIT    SC_NS

// Instantiate SystemC TB module
sc_Clock_TB*  u_sc_Clock_TB;

// Init. SystemC
void init_sc()
{
    // Instantiate SystemC TB
    u_sc_Clock_TB = new sc_Clock_TB("u_sc_Clock_TB");

    // Initialize SC
    sc_start(0,SC_NS);
    cout<<"#"<<sc_time_stamp()<<" SystemC started"<<endl;
}

// Call-Back: Read from HDL & Drive SystemC TB
void sample_hdl(void *In_vector)
{
    IN_VECTOR *p = (IN_VECTOR *)In_vector;
    u_sc_Clock_TB->hh.write(p->hh);
    u_sc_Clock_TB->mm.write(p->mm);
    u_sc_Clock_TB->ss.write(p->ss);
}
// Call-Back: Read from SystemC TB & Drive HDL
void drive_hdl(void *Out_vector)
{
    OUT_VECTOR *p   = (OUT_VECTOR *)Out_vector;
    p->end_of_sim   = u_sc_Clock_TB->sc_Stopped.read();
    p->ap_clk       = u_sc_Clock_TB->ap_clk.read();
    p->ap_rst       = u_sc_Clock_TB->ap_rst.read();
    p->clear        = u_sc_Clock_TB->clear.read();
    p->start_r      = u_sc_Clock_TB->start_r.read();
}
// Advance SystemC kernel
void exec_sc(void *invector, void *outvector)
{
    sample_hdl(invector);
    drive_hdl(outvector);
    if (!u_sc_Clock_TB->sc_Stopped)
        sc_start(1,SC_TIME_UNIT);
}

void exit_sc()
{
    cout<<"#"<<sc_time_stamp()<<" SystemC stopped"<<endl;
    sc_stop();
}

