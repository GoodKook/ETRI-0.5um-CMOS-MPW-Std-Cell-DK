/* Verilog module written by vlog2Verilog (qflow) */
/* With bit-blasted vectors */
/* With power connections converted to binary 1, 0 */

module invaders(
    input clk,
    input reset,
    output v_sync,
    output pixel,
    output p_tick,
    input btn_left,
    input btn_right,
    output game_over,
    output game_complete,
    input game_new
);

wire _588_ ;
wire _168_ ;
wire _800_ ;
wire _60_ ;
wire _397_ ;
wire \u_ball.sign_x  ;
wire _703_ ;
wire _19_ ;
wire _512_ ;
wire _741_ ;
wire _321_ ;
wire _57_ ;
wire _550_ ;
wire _130_ ;
wire _606_ ;
wire _835_ ;
wire _415_ ;
wire _95_ ;
wire _644_ ;
wire _224_ ;
wire _453_ ;
wire _509_ ;
wire _682_ ;
wire _262_ ;
wire _738_ ;
wire _318_ ;
wire _491_ ;
wire _547_ ;
wire _127_ ;
wire _776_ ;
wire _356_ ;
wire btn_right ;
wire _585_ ;
wire _165_ ;
wire _394_ ;
wire _679_ ;
wire _259_ ;
wire _488_ ;
wire _700_ ;
wire _297_ ;
wire _16_ ;
wire _54_ ;
wire _603_ ;
wire _832_ ;
wire _412_ ;
wire _92_ ;
wire _641_ ;
wire _221_ ;
wire _450_ ;
wire _506_ ;
wire _735_ ;
wire _315_ ;
wire _544_ ;
wire _124_ ;
wire _773_ ;
wire _353_ ;
wire _829_ ;
wire _409_ ;
wire _89_ ;
wire _582_ ;
wire _162_ ;
wire _638_ ;
wire _218_ ;
wire _391_ ;
wire _447_ ;
wire _676_ ;
wire _256_ ;
wire _485_ ;
wire _294_ ;
wire _13_ ;
wire _579_ ;
wire _159_ ;
wire _51_ ;
wire _388_ ;
wire _600_ ;
wire _197_ ;
wire _7_ ;
wire _503_ ;
wire _732_ ;
wire _312_ ;
wire _48_ ;
wire _541_ ;
wire _121_ ;
wire _770_ ;
wire _350_ ;
wire _826_ ;
wire _406_ ;
wire _86_ ;
wire _635_ ;
wire _215_ ;
wire _444_ ;
wire _673_ ;
wire _253_ ;
wire _729_ ;
wire _309_ ;
wire _482_ ;
wire _538_ ;
wire _118_ ;
wire _291_ ;
wire _10_ ;
wire _767_ ;
wire _347_ ;
wire _576_ ;
wire _156_ ;
wire _385_ ;
wire pixel ;
wire _194_ ;
wire _479_ ;
wire _288_ ;
wire _4_ ;
wire _500_ ;
wire _45_ ;
wire _823_ ;
wire _403_ ;
wire _83_ ;
wire _632_ ;
wire _212_ ;
wire _441_ ;
wire _670_ ;
wire _250_ ;
wire _726_ ;
wire _306_ ;
wire _535_ ;
wire _115_ ;
wire _764_ ;
wire _344_ ;
wire _573_ ;
wire _153_ ;
wire _629_ ;
wire _209_ ;
wire _382_ ;
wire _858_ ;
wire _438_ ;
wire _191_ ;
wire _667_ ;
wire _247_ ;
wire _476_ ;
wire clk_bF$buf0 ;
wire clk_bF$buf1 ;
wire clk_bF$buf2 ;
wire clk_bF$buf3 ;
wire clk_bF$buf4 ;
wire clk_bF$buf5 ;
wire clk_bF$buf6 ;
wire clk_bF$buf7 ;
wire _285_ ;
wire _1_ ;
wire [6:0] \u_alien.x_pos  ;
wire _42_ ;
wire _799_ ;
wire _379_ ;
wire _188_ ;
wire _820_ ;
wire _400_ ;
wire _80_ ;
wire pixel_bullet ;
wire _723_ ;
wire _303_ ;
wire _39_ ;
wire _532_ ;
wire _112_ ;
wire _761_ ;
wire _341_ ;
wire clk ;
wire _817_ ;
wire _77_ ;
wire _570_ ;
wire _150_ ;
wire _626_ ;
wire _206_ ;
wire _855_ ;
wire _435_ ;
wire _664_ ;
wire _244_ ;
wire _473_ ;
wire _529_ ;
wire _109_ ;
wire _282_ ;
wire _758_ ;
wire _338_ ;
wire _567_ ;
wire _147_ ;
wire _796_ ;
wire _376_ ;
wire _185_ ;
wire _699_ ;
wire _279_ ;
wire _720_ ;
wire _300_ ;
wire _36_ ;
wire _814_ ;
wire _74_ ;
wire _623_ ;
wire _203_ ;
wire _852_ ;
wire _432_ ;
wire pixel_paddle ;
wire _661_ ;
wire _241_ ;
wire _717_ ;
wire _470_ ;
wire _526_ ;
wire _106_ ;
wire _755_ ;
wire _335_ ;
wire _564_ ;
wire _144_ ;
wire [2:0] \u_ctrl.cnt_v_sync  ;
wire _793_ ;
wire _373_ ;
wire _849_ ;
wire _429_ ;
wire _182_ ;
wire _658_ ;
wire _238_ ;
wire _467_ ;
wire _696_ ;
wire _276_ ;
wire _33_ ;
wire \u_ball.hit_paddle  ;
wire _599_ ;
wire _179_ ;
wire _811_ ;
wire _71_ ;
wire _620_ ;
wire _200_ ;
wire _714_ ;
wire _523_ ;
wire _103_ ;
wire \u_ctrl.State_3_bF$buf3  ;
wire _752_ ;
wire _332_ ;
wire _808_ ;
wire _68_ ;
wire _561_ ;
wire _141_ ;
wire _617_ ;
wire _790_ ;
wire _370_ ;
wire _846_ ;
wire _426_ ;
wire _655_ ;
wire _235_ ;
wire _464_ ;
wire [6:0] \u_alien.x_bullet  ;
wire _693_ ;
wire _273_ ;
wire _749_ ;
wire _329_ ;
wire _558_ ;
wire _138_ ;
wire _30_ ;
wire _787_ ;
wire _367_ ;
wire _596_ ;
wire _176_ ;
wire _499_ ;
wire _711_ ;
wire _27_ ;
wire _520_ ;
wire _100_ ;
wire \u_ctrl.State_3_bF$buf0  ;
wire _805_ ;
wire _65_ ;
wire _614_ ;
wire _843_ ;
wire _423_ ;
wire _652_ ;
wire _232_ ;
wire _708_ ;
wire _461_ ;
wire _517_ ;
wire _690_ ;
wire _270_ ;
wire _746_ ;
wire _326_ ;
wire _555_ ;
wire _135_ ;
wire _784_ ;
wire _364_ ;
wire _593_ ;
wire _173_ ;
wire _649_ ;
wire _229_ ;
wire _458_ ;
wire _687_ ;
wire _267_ ;
wire _496_ ;
wire _24_ ;
wire _802_ ;
wire _62_ ;
wire [6:0] \u_alien.x_ball  ;
wire _399_ ;
wire _611_ ;
wire _840_ ;
wire _420_ ;
wire _705_ ;
wire _514_ ;
wire _743_ ;
wire _323_ ;
wire _59_ ;
wire _552_ ;
wire _132_ ;
wire _608_ ;
wire _781_ ;
wire _361_ ;
wire _837_ ;
wire _417_ ;
wire _97_ ;
wire _590_ ;
wire _170_ ;
wire _646_ ;
wire _226_ ;
wire _455_ ;
wire _684_ ;
wire _264_ ;
wire _493_ ;
wire _549_ ;
wire _129_ ;
wire _21_ ;
wire _778_ ;
wire _358_ ;
wire _587_ ;
wire _167_ ;
wire _396_ ;
wire \u_ball.x2  ;
wire en_lfsr4 ;
wire _702_ ;
wire _299_ ;
wire _18_ ;
wire _511_ ;
wire _740_ ;
wire _320_ ;
wire _56_ ;
wire _605_ ;
wire _834_ ;
wire _414_ ;
wire _94_ ;
wire _643_ ;
wire _223_ ;
wire _452_ ;
wire _508_ ;
wire _681_ ;
wire _261_ ;
wire _737_ ;
wire _317_ ;
wire _490_ ;
wire _546_ ;
wire _126_ ;
wire _775_ ;
wire _355_ ;
wire game_over ;
wire _584_ ;
wire _164_ ;
wire _393_ ;
wire _449_ ;
wire _678_ ;
wire _258_ ;
wire _487_ ;
wire _296_ ;
wire _15_ ;
wire [7:0] \u_alien.regAliens  ;
wire _53_ ;
wire _602_ ;
wire _199_ ;
wire _831_ ;
wire _411_ ;
wire _91_ ;
wire _640_ ;
wire _220_ ;
wire _9_ ;
wire _505_ ;
wire _734_ ;
wire _314_ ;
wire _543_ ;
wire _123_ ;
wire _772_ ;
wire _352_ ;
wire _828_ ;
wire _408_ ;
wire _88_ ;
wire _581_ ;
wire _161_ ;
wire _637_ ;
wire _217_ ;
wire _390_ ;
wire _446_ ;
wire _675_ ;
wire _255_ ;
wire _484_ ;
wire _293_ ;
wire _12_ ;
wire _769_ ;
wire _349_ ;
wire _578_ ;
wire _158_ ;
wire _50_ ;
wire _387_ ;
wire _196_ ;
wire [2:0] \u_ctrl.cnt_alien_flip  ;
wire _6_ ;
wire _502_ ;
wire _731_ ;
wire _311_ ;
wire _47_ ;
wire _540_ ;
wire _120_ ;
wire [6:0] \u_ball.x_paddle  ;
wire _825_ ;
wire _405_ ;
wire _85_ ;
wire _634_ ;
wire _214_ ;
wire _443_ ;
wire _672_ ;
wire _252_ ;
wire _728_ ;
wire _308_ ;
wire _481_ ;
wire _537_ ;
wire _117_ ;
wire _290_ ;
wire _766_ ;
wire _346_ ;
wire _575_ ;
wire _155_ ;
wire _384_ ;
wire _193_ ;
wire _669_ ;
wire _249_ ;
wire _478_ ;
wire _287_ ;
wire _3_ ;
wire game_complete ;
wire _44_ ;
wire _822_ ;
wire _402_ ;
wire _82_ ;
wire _631_ ;
wire _211_ ;
wire _860_ ;
wire _440_ ;
wire _725_ ;
wire _305_ ;
wire _534_ ;
wire _114_ ;
wire _763_ ;
wire _343_ ;
wire _819_ ;
wire _79_ ;
wire _572_ ;
wire _152_ ;
wire _628_ ;
wire _208_ ;
wire _381_ ;
wire _857_ ;
wire _437_ ;
wire _190_ ;
wire _354__bF$buf0 ;
wire _354__bF$buf1 ;
wire _354__bF$buf2 ;
wire _354__bF$buf3 ;
wire _666_ ;
wire _246_ ;
wire pixel_ball ;
wire _475_ ;
wire _284_ ;
wire _0_ ;
wire v_sync ;
wire _569_ ;
wire _149_ ;
wire _41_ ;
wire _798_ ;
wire _378_ ;
wire _187_ ;
wire [5:0] \u_alien.y_pos  ;
wire _722_ ;
wire _302_ ;
wire _38_ ;
wire _531_ ;
wire _111_ ;
wire _760_ ;
wire _340_ ;
wire _816_ ;
wire _76_ ;
wire _625_ ;
wire _205_ ;
wire _854_ ;
wire _434_ ;
wire _663_ ;
wire _243_ ;
wire _719_ ;
wire _472_ ;
wire _528_ ;
wire _108_ ;
wire _281_ ;
wire _757_ ;
wire _337_ ;
wire _566_ ;
wire _146_ ;
wire _795_ ;
wire _375_ ;
wire _184_ ;
wire _469_ ;
wire _698_ ;
wire _278_ ;
wire _35_ ;
wire _813_ ;
wire _73_ ;
wire _622_ ;
wire _202_ ;
wire _851_ ;
wire _431_ ;
wire _660_ ;
wire _240_ ;
wire _716_ ;
wire _525_ ;
wire _105_ ;
wire _754_ ;
wire _334_ ;
wire _563_ ;
wire _143_ ;
wire _619_ ;
wire _792_ ;
wire _372_ ;
wire _848_ ;
wire _428_ ;
wire _181_ ;
wire _657_ ;
wire _237_ ;
wire _466_ ;
wire _695_ ;
wire _275_ ;
wire _32_ ;
wire _789_ ;
wire _369_ ;
wire _598_ ;
wire _178_ ;
wire _810_ ;
wire _70_ ;
wire _713_ ;
wire _29_ ;
wire _522_ ;
wire _102_ ;
wire \u_ctrl.State_3_bF$buf2  ;
wire _751_ ;
wire _331_ ;
wire _807_ ;
wire _67_ ;
wire _560_ ;
wire _140_ ;
wire _616_ ;
wire _845_ ;
wire _425_ ;
wire _654_ ;
wire _234_ ;
wire _463_ ;
wire _519_ ;
wire _692_ ;
wire _272_ ;
wire game_init ;
wire _748_ ;
wire _328_ ;
wire _557_ ;
wire _137_ ;
wire [4:0] \u_ctrl.State  ;
wire _786_ ;
wire _366_ ;
wire _595_ ;
wire _175_ ;
wire _689_ ;
wire _269_ ;
wire _498_ ;
wire _710_ ;
wire _26_ ;
wire _804_ ;
wire _64_ ;
wire _613_ ;
wire _842_ ;
wire _422_ ;
wire _651_ ;
wire _231_ ;
wire _707_ ;
wire _460_ ;
wire _516_ ;
wire [5:0] \u_ball.y_ball  ;
wire _745_ ;
wire _325_ ;
wire _554_ ;
wire _134_ ;
wire _783_ ;
wire _363_ ;
wire [2:0] \u_alien.rom_addr  ;
wire _839_ ;
wire _419_ ;
wire _99_ ;
wire _592_ ;
wire _172_ ;
wire _648_ ;
wire _228_ ;
wire _457_ ;
wire _686_ ;
wire _266_ ;
wire _495_ ;
wire _23_ ;
wire _589_ ;
wire _169_ ;
wire _801_ ;
wire _61_ ;
wire _398_ ;
wire _610_ ;
wire \u_ball.sign_y  ;
wire _704_ ;
wire [3:0] lfsr4 ;
wire _513_ ;
wire _742_ ;
wire _322_ ;
wire _58_ ;
wire _551_ ;
wire _131_ ;
wire _607_ ;
wire _780_ ;
wire _360_ ;
wire _836_ ;
wire _416_ ;
wire _96_ ;
wire _645_ ;
wire _225_ ;
wire game_new ;
wire _454_ ;
wire _683_ ;
wire _263_ ;
wire _739_ ;
wire _319_ ;
wire _492_ ;
wire _548_ ;
wire _128_ ;
wire _20_ ;
wire _777_ ;
wire _357_ ;
wire _586_ ;
wire _166_ ;
wire _395_ ;
wire _489_ ;
wire _701_ ;
wire _298_ ;
wire _17_ ;
wire _510_ ;
wire _55_ ;
wire _604_ ;
wire _833_ ;
wire _413_ ;
wire _93_ ;
wire _642_ ;
wire _222_ ;
wire _451_ ;
wire _507_ ;
wire _680_ ;
wire _260_ ;
wire _736_ ;
wire _316_ ;
wire _545_ ;
wire _125_ ;
wire _774_ ;
wire _354_ ;
wire _583_ ;
wire _163_ ;
wire _639_ ;
wire _219_ ;
wire _392_ ;
wire _448_ ;
wire _677_ ;
wire _257_ ;
wire _486_ ;
wire _295_ ;
wire _14_ ;
wire _52_ ;
wire _389_ ;
wire _601_ ;
wire _198_ ;
wire _830_ ;
wire _410_ ;
wire _90_ ;
wire _8_ ;
wire _504_ ;
wire _733_ ;
wire _313_ ;
wire _49_ ;
wire _542_ ;
wire _122_ ;
wire _771_ ;
wire _351_ ;
wire _827_ ;
wire _407_ ;
wire _87_ ;
wire _580_ ;
wire _160_ ;
wire _636_ ;
wire _216_ ;
wire _445_ ;
wire btn_left ;
wire _674_ ;
wire _254_ ;
wire _483_ ;
wire _539_ ;
wire _119_ ;
wire _292_ ;
wire _11_ ;
wire _768_ ;
wire _348_ ;
wire _577_ ;
wire _157_ ;
wire _386_ ;
wire _195_ ;
wire pixel_alien ;
wire _289_ ;
wire _5_ ;
wire _501_ ;
wire _730_ ;
wire _310_ ;
wire _46_ ;
wire _824_ ;
wire _404_ ;
wire _84_ ;
wire _633_ ;
wire _213_ ;
wire _442_ ;
wire _671_ ;
wire _251_ ;
wire _727_ ;
wire _307_ ;
wire _480_ ;
wire _536_ ;
wire _116_ ;
wire _765_ ;
wire _345_ ;
wire _574_ ;
wire _154_ ;
wire _383_ ;
wire _859_ ;
wire _439_ ;
wire _192_ ;
wire _668_ ;
wire _248_ ;
wire _477_ ;
wire _286_ ;
wire _2_ ;
wire _43_ ;
wire _189_ ;
wire _821_ ;
wire _401_ ;
wire _81_ ;
wire _630_ ;
wire _210_ ;
wire _724_ ;
wire _304_ ;
wire _533_ ;
wire _113_ ;
wire _762_ ;
wire _342_ ;
wire _818_ ;
wire _78_ ;
wire _571_ ;
wire _151_ ;
wire _627_ ;
wire _207_ ;
wire _380_ ;
wire _856_ ;
wire _436_ ;
wire _665_ ;
wire _245_ ;
wire _474_ ;
wire _283_ ;
wire _759_ ;
wire _339_ ;
wire _568_ ;
wire _148_ ;
wire _40_ ;
wire _797_ ;
wire _377_ ;
wire _186_ ;
wire [5:0] \u_alien.y_bullet  ;
wire _721_ ;
wire _301_ ;
wire _37_ ;
wire _530_ ;
wire _110_ ;
wire _815_ ;
wire _75_ ;
wire _624_ ;
wire _204_ ;
wire _853_ ;
wire _433_ ;
wire _662_ ;
wire _242_ ;
wire _718_ ;
wire _471_ ;
wire _527_ ;
wire _107_ ;
wire _280_ ;
wire _756_ ;
wire _336_ ;
wire hit_alien ;
wire _565_ ;
wire _145_ ;
wire _270__bF$buf0 ;
wire _270__bF$buf1 ;
wire _270__bF$buf2 ;
wire _270__bF$buf3 ;
wire _794_ ;
wire _374_ ;
wire _183_ ;
wire _659_ ;
wire _239_ ;
wire _468_ ;
wire _697_ ;
wire _277_ ;
wire _34_ ;
wire _812_ ;
wire _72_ ;
wire _621_ ;
wire _201_ ;
wire _850_ ;
wire _430_ ;
wire _715_ ;
wire _524_ ;
wire _104_ ;
wire alien_flip ;
wire _753_ ;
wire _333_ ;
wire _809_ ;
wire _69_ ;
wire _562_ ;
wire _142_ ;
wire _618_ ;
wire _791_ ;
wire _371_ ;
wire _847_ ;
wire _427_ ;
wire _180_ ;
wire _656_ ;
wire _236_ ;
wire _465_ ;
wire _694_ ;
wire _274_ ;
wire _559_ ;
wire _139_ ;
wire _31_ ;
wire _788_ ;
wire _368_ ;
wire _597_ ;
wire _177_ ;
wire _712_ ;
wire _28_ ;
wire _521_ ;
wire _101_ ;
wire \u_ctrl.State_3_bF$buf1  ;
wire _750_ ;
wire _330_ ;
wire _806_ ;
wire _66_ ;
wire _615_ ;
wire _844_ ;
wire _424_ ;
wire _653_ ;
wire _233_ ;
wire _709_ ;
wire _462_ ;
wire _518_ ;
wire _691_ ;
wire _271_ ;
wire p_tick ;
wire _747_ ;
wire _327_ ;
wire _556_ ;
wire _136_ ;
wire _785_ ;
wire _365_ ;
wire _594_ ;
wire _174_ ;
wire _459_ ;
wire _800__bF$buf0 ;
wire _800__bF$buf1 ;
wire _800__bF$buf2 ;
wire _800__bF$buf3 ;
wire _800__bF$buf4 ;
wire _688_ ;
wire _268_ ;
wire _497_ ;
wire _25_ ;
wire _803_ ;
wire _63_ ;
wire _612_ ;
wire reset ;
wire _841_ ;
wire _421_ ;
wire _650_ ;
wire _230_ ;
wire _706_ ;
wire _515_ ;
wire _744_ ;
wire _324_ ;
wire _553_ ;
wire _133_ ;
wire _609_ ;
wire _782_ ;
wire _362_ ;
wire _838_ ;
wire _418_ ;
wire _98_ ;
wire _591_ ;
wire _171_ ;
wire _647_ ;
wire _227_ ;
wire _456_ ;
wire _685_ ;
wire _265_ ;
wire _494_ ;
wire _22_ ;
wire _779_ ;
wire _359_ ;

BUFX2 BUFX2_insert24 (
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf0 )
);

BUFX2 BUFX2_insert23 (
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf1 )
);

BUFX2 BUFX2_insert22 (
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf2 )
);

BUFX2 BUFX2_insert21 (
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf3 )
);

BUFX2 BUFX2_insert20 (
    .A(_354_),
    .Y(_354__bF$buf0)
);

BUFX2 BUFX2_insert19 (
    .A(_354_),
    .Y(_354__bF$buf1)
);

BUFX2 BUFX2_insert18 (
    .A(_354_),
    .Y(_354__bF$buf2)
);

BUFX2 BUFX2_insert17 (
    .A(_354_),
    .Y(_354__bF$buf3)
);

BUFX2 BUFX2_insert16 (
    .A(_270_),
    .Y(_270__bF$buf0)
);

BUFX2 BUFX2_insert15 (
    .A(_270_),
    .Y(_270__bF$buf1)
);

BUFX2 BUFX2_insert14 (
    .A(_270_),
    .Y(_270__bF$buf2)
);

BUFX2 BUFX2_insert13 (
    .A(_270_),
    .Y(_270__bF$buf3)
);

CLKBUF1 CLKBUF1_insert12 (
    .A(clk),
    .Y(clk_bF$buf0)
);

CLKBUF1 CLKBUF1_insert11 (
    .A(clk),
    .Y(clk_bF$buf1)
);

CLKBUF1 CLKBUF1_insert10 (
    .A(clk),
    .Y(clk_bF$buf2)
);

CLKBUF1 CLKBUF1_insert9 (
    .A(clk),
    .Y(clk_bF$buf3)
);

CLKBUF1 CLKBUF1_insert8 (
    .A(clk),
    .Y(clk_bF$buf4)
);

CLKBUF1 CLKBUF1_insert7 (
    .A(clk),
    .Y(clk_bF$buf5)
);

CLKBUF1 CLKBUF1_insert6 (
    .A(clk),
    .Y(clk_bF$buf6)
);

CLKBUF1 CLKBUF1_insert5 (
    .A(clk),
    .Y(clk_bF$buf7)
);

BUFX2 BUFX2_insert4 (
    .A(_800_),
    .Y(_800__bF$buf0)
);

BUFX2 BUFX2_insert3 (
    .A(_800_),
    .Y(_800__bF$buf1)
);

BUFX2 BUFX2_insert2 (
    .A(_800_),
    .Y(_800__bF$buf2)
);

BUFX2 BUFX2_insert1 (
    .A(_800_),
    .Y(_800__bF$buf3)
);

BUFX2 BUFX2_insert0 (
    .A(_800_),
    .Y(_800__bF$buf4)
);

NAND2X1 _1000_ (
    .A(_622_),
    .B(_617_),
    .Y(_623_)
);

AOI21X1 _1001_ (
    .A(_337_),
    .B(_604_),
    .C(_619_),
    .Y(_622_)
);

NOR2X1 _1002_ (
    .A(\u_alien.rom_addr [2]),
    .B(_337_),
    .Y(_619_)
);

NAND3X1 _1003_ (
    .A(_615_),
    .B(_611_),
    .C(_614_),
    .Y(_617_)
);

NAND2X1 _1004_ (
    .A(\u_alien.rom_addr [2]),
    .B(_337_),
    .Y(_615_)
);

INVX1 _1005_ (
    .A(_613_),
    .Y(_614_)
);

AOI22X1 _1006_ (
    .A(_609_),
    .B(\u_ball.y_ball [1]),
    .C(\u_ball.y_ball [0]),
    .D(_612_),
    .Y(_613_)
);

INVX1 _1007_ (
    .A(\u_alien.rom_addr [0]),
    .Y(_612_)
);

INVX1 _1008_ (
    .A(_610_),
    .Y(_611_)
);

NOR2X1 _1009_ (
    .A(\u_ball.y_ball [1]),
    .B(_609_),
    .Y(_610_)
);

INVX1 _1010_ (
    .A(\u_alien.rom_addr [1]),
    .Y(_609_)
);

NOR2X1 _1011_ (
    .A(_605_),
    .B(_607_),
    .Y(_608_)
);

INVX1 _1012_ (
    .A(_606_),
    .Y(_607_)
);

NAND3X1 _1013_ (
    .A(_337_),
    .B(_335_),
    .C(_604_),
    .Y(_606_)
);

AOI21X1 _1014_ (
    .A(_604_),
    .B(_337_),
    .C(_335_),
    .Y(_605_)
);

NOR2X1 _1015_ (
    .A(\u_ball.y_ball [0]),
    .B(\u_ball.y_ball [1]),
    .Y(_604_)
);

INVX1 _1016_ (
    .A(\u_alien.y_pos [3]),
    .Y(_603_)
);

AND2X2 _1017_ (
    .A(_599_),
    .B(_601_),
    .Y(_602_)
);

AOI22X1 _1018_ (
    .A(_600_),
    .B(\u_alien.x_ball [5]),
    .C(\u_alien.x_ball [6]),
    .D(_589_),
    .Y(_601_)
);

INVX1 _1019_ (
    .A(\u_alien.x_pos [5]),
    .Y(_600_)
);

OAI21X1 _1020_ (
    .A(_597_),
    .B(_596_),
    .C(_598_),
    .Y(_599_)
);

AOI22X1 _1021_ (
    .A(_330_),
    .B(\u_alien.x_pos [4]),
    .C(_45_),
    .D(\u_alien.x_pos [5]),
    .Y(_598_)
);

OAI22X1 _1022_ (
    .A(\u_alien.x_pos [3]),
    .B(_312_),
    .C(_330_),
    .D(\u_alien.x_pos [4]),
    .Y(_597_)
);

AOI22X1 _1023_ (
    .A(_312_),
    .B(\u_alien.x_pos [3]),
    .C(_567_),
    .D(_595_),
    .Y(_596_)
);

NAND2X1 _1024_ (
    .A(\u_alien.x_ball [2]),
    .B(_568_),
    .Y(_595_)
);

NOR2X1 _1025_ (
    .A(\u_alien.x_ball [6]),
    .B(_589_),
    .Y(_594_)
);

OAI21X1 _1026_ (
    .A(_591_),
    .B(_587_),
    .C(_592_),
    .Y(_593_)
);

NAND2X1 _1027_ (
    .A(\u_alien.x_pos [6]),
    .B(_588_),
    .Y(_592_)
);

OAI22X1 _1028_ (
    .A(\u_alien.x_pos [5]),
    .B(_585_),
    .C(_590_),
    .D(_588_),
    .Y(_591_)
);

OAI21X1 _1029_ (
    .A(_30_),
    .B(_388_),
    .C(_589_),
    .Y(_590_)
);

INVX1 _1030_ (
    .A(\u_alien.x_pos [6]),
    .Y(_589_)
);

AND2X2 _1031_ (
    .A(_388_),
    .B(_30_),
    .Y(_588_)
);

AND2X2 _1032_ (
    .A(_586_),
    .B(_582_),
    .Y(_587_)
);

AOI22X1 _1033_ (
    .A(\u_alien.x_pos [4]),
    .B(_583_),
    .C(_585_),
    .D(\u_alien.x_pos [5]),
    .Y(_586_)
);

NAND2X1 _1034_ (
    .A(_388_),
    .B(_584_),
    .Y(_585_)
);

NAND2X1 _1035_ (
    .A(_45_),
    .B(_575_),
    .Y(_584_)
);

NAND2X1 _1036_ (
    .A(_575_),
    .B(_577_),
    .Y(_583_)
);

NAND3X1 _1037_ (
    .A(_578_),
    .B(_581_),
    .C(_572_),
    .Y(_582_)
);

NAND2X1 _1038_ (
    .A(_579_),
    .B(_580_),
    .Y(_581_)
);

NOR2X1 _1039_ (
    .A(_387_),
    .B(_562_),
    .Y(_580_)
);

INVX1 _1040_ (
    .A(\u_alien.x_pos [3]),
    .Y(_579_)
);

NAND3X1 _1041_ (
    .A(_573_),
    .B(_575_),
    .C(_577_),
    .Y(_578_)
);

OAI21X1 _1042_ (
    .A(_312_),
    .B(_576_),
    .C(_330_),
    .Y(_577_)
);

NOR3X1 _1043_ (
    .A(\u_alien.x_ball [1]),
    .B(\u_alien.x_ball [0]),
    .C(\u_alien.x_ball [2]),
    .Y(_576_)
);

NAND3X1 _1044_ (
    .A(\u_alien.x_ball [4]),
    .B(\u_alien.x_ball [3]),
    .C(_574_),
    .Y(_575_)
);

NAND3X1 _1045_ (
    .A(_323_),
    .B(_285_),
    .C(_317_),
    .Y(_574_)
);

INVX1 _1046_ (
    .A(\u_alien.x_pos [4]),
    .Y(_573_)
);

NAND2X1 _1047_ (
    .A(_563_),
    .B(_571_),
    .Y(_572_)
);

NAND2X1 _1048_ (
    .A(_570_),
    .B(_567_),
    .Y(_571_)
);

OAI21X1 _1049_ (
    .A(_317_),
    .B(_568_),
    .C(_569_),
    .Y(_570_)
);

OAI21X1 _1050_ (
    .A(\u_alien.x_ball [1]),
    .B(\u_alien.x_ball [0]),
    .C(_317_),
    .Y(_569_)
);

INVX1 _1051_ (
    .A(\u_alien.x_pos [2]),
    .Y(_568_)
);

NAND3X1 _1052_ (
    .A(_564_),
    .B(_565_),
    .C(_566_),
    .Y(_567_)
);

OAI22X1 _1053_ (
    .A(\u_alien.x_pos [1]),
    .B(_323_),
    .C(_285_),
    .D(\u_alien.x_pos [0]),
    .Y(_566_)
);

NAND2X1 _1054_ (
    .A(\u_alien.x_pos [1]),
    .B(_323_),
    .Y(_565_)
);

NAND2X1 _1055_ (
    .A(\u_alien.x_pos [2]),
    .B(_317_),
    .Y(_564_)
);

OAI21X1 _1056_ (
    .A(_387_),
    .B(_562_),
    .C(\u_alien.x_pos [3]),
    .Y(_563_)
);

AND2X2 _1057_ (
    .A(_307_),
    .B(_386_),
    .Y(_562_)
);

OAI22X1 _1058_ (
    .A(_335_),
    .B(_343_),
    .C(_561_),
    .D(_560_),
    .Y(_358_)
);

OAI21X1 _1059_ (
    .A(_559_),
    .B(_556_),
    .C(_328_),
    .Y(_561_)
);

AND2X2 _1060_ (
    .A(_556_),
    .B(_559_),
    .Y(_560_)
);

NOR2X1 _1061_ (
    .A(_557_),
    .B(_558_),
    .Y(_559_)
);

NOR2X1 _1062_ (
    .A(_410_),
    .B(_335_),
    .Y(_558_)
);

NOR2X1 _1063_ (
    .A(\u_ball.sign_y ),
    .B(\u_ball.y_ball [3]),
    .Y(_557_)
);

OAI21X1 _1064_ (
    .A(_410_),
    .B(_337_),
    .C(_421_),
    .Y(_556_)
);

OAI21X1 _1065_ (
    .A(_420_),
    .B(_554_),
    .C(_555_),
    .Y(_359_)
);

AOI21X1 _1066_ (
    .A(_329_),
    .B(\u_ball.y_ball [2]),
    .C(game_init),
    .Y(_555_)
);

NAND2X1 _1067_ (
    .A(_859_),
    .B(_421_),
    .Y(_554_)
);

NAND3X1 _1068_ (
    .A(_418_),
    .B(_419_),
    .C(_417_),
    .Y(_421_)
);

AOI21X1 _1069_ (
    .A(_418_),
    .B(_419_),
    .C(_417_),
    .Y(_420_)
);

NAND2X1 _1070_ (
    .A(_410_),
    .B(_337_),
    .Y(_419_)
);

NAND2X1 _1071_ (
    .A(\u_ball.sign_y ),
    .B(\u_ball.y_ball [2]),
    .Y(_418_)
);

OAI21X1 _1072_ (
    .A(_410_),
    .B(_338_),
    .C(_416_),
    .Y(_417_)
);

NAND2X1 _1073_ (
    .A(\u_ball.y_ball [0]),
    .B(_413_),
    .Y(_416_)
);

OAI21X1 _1074_ (
    .A(_338_),
    .B(_343_),
    .C(_415_),
    .Y(_360_)
);

OAI21X1 _1075_ (
    .A(\u_ball.y_ball [0]),
    .B(_413_),
    .C(_414_),
    .Y(_415_)
);

AOI21X1 _1076_ (
    .A(\u_ball.y_ball [0]),
    .B(_413_),
    .C(_327_),
    .Y(_414_)
);

NAND2X1 _1077_ (
    .A(_411_),
    .B(_412_),
    .Y(_413_)
);

NAND2X1 _1078_ (
    .A(\u_ball.sign_y ),
    .B(_338_),
    .Y(_412_)
);

NAND2X1 _1079_ (
    .A(\u_ball.y_ball [1]),
    .B(_410_),
    .Y(_411_)
);

INVX2 _1080_ (
    .A(\u_ball.sign_y ),
    .Y(_410_)
);

MUX2X1 _1081_ (
    .A(_343_),
    .B(_327_),
    .S(\u_ball.y_ball [0]),
    .Y(_361_)
);

OAI21X1 _1082_ (
    .A(_45_),
    .B(_343_),
    .C(_409_),
    .Y(_362_)
);

OAI21X1 _1083_ (
    .A(_407_),
    .B(_408_),
    .C(_328_),
    .Y(_409_)
);

AND2X2 _1084_ (
    .A(_402_),
    .B(_406_),
    .Y(_408_)
);

NOR2X1 _1085_ (
    .A(_406_),
    .B(_402_),
    .Y(_407_)
);

NAND2X1 _1086_ (
    .A(_403_),
    .B(_405_),
    .Y(_406_)
);

INVX1 _1087_ (
    .A(_404_),
    .Y(_405_)
);

NOR2X1 _1088_ (
    .A(_326_),
    .B(_45_),
    .Y(_404_)
);

NAND2X1 _1089_ (
    .A(_326_),
    .B(_45_),
    .Y(_403_)
);

OAI21X1 _1090_ (
    .A(_330_),
    .B(_326_),
    .C(_301_),
    .Y(_402_)
);

OAI21X1 _1091_ (
    .A(_325_),
    .B(_341_),
    .C(_401_),
    .Y(_363_)
);

NAND3X1 _1092_ (
    .A(\u_ball.hit_paddle ),
    .B(_328_),
    .C(_385_),
    .Y(_401_)
);

OAI21X1 _1093_ (
    .A(_397_),
    .B(_399_),
    .C(_400_),
    .Y(_364_)
);

NAND2X1 _1094_ (
    .A(\u_ball.sign_x ),
    .B(_397_),
    .Y(_400_)
);

AOI21X1 _1095_ (
    .A(_392_),
    .B(_391_),
    .C(_398_),
    .Y(_399_)
);

NOR2X1 _1096_ (
    .A(_297_),
    .B(_27_),
    .Y(_398_)
);

OAI21X1 _1097_ (
    .A(_297_),
    .B(_385_),
    .C(_396_),
    .Y(_397_)
);

NOR2X1 _1098_ (
    .A(_344_),
    .B(_395_),
    .Y(_396_)
);

NOR2X1 _1099_ (
    .A(_394_),
    .B(_391_),
    .Y(_395_)
);

OAI21X1 _1100_ (
    .A(\u_alien.x_ball [6]),
    .B(_393_),
    .C(_392_),
    .Y(_394_)
);

NAND3X1 _1101_ (
    .A(_330_),
    .B(_45_),
    .C(_307_),
    .Y(_393_)
);

NOR2X1 _1102_ (
    .A(game_init),
    .B(\u_ball.hit_paddle ),
    .Y(_392_)
);

INVX1 _1103_ (
    .A(_390_),
    .Y(_391_)
);

NAND2X1 _1104_ (
    .A(\u_alien.x_ball [6]),
    .B(_389_),
    .Y(_390_)
);

INVX1 _1105_ (
    .A(_388_),
    .Y(_389_)
);

NAND3X1 _1106_ (
    .A(\u_alien.x_ball [4]),
    .B(\u_alien.x_ball [5]),
    .C(_387_),
    .Y(_388_)
);

AOI21X1 _1107_ (
    .A(_386_),
    .B(_317_),
    .C(_312_),
    .Y(_387_)
);

NOR2X1 _1108_ (
    .A(\u_alien.x_ball [1]),
    .B(\u_alien.x_ball [0]),
    .Y(_386_)
);

NAND3X1 _1109_ (
    .A(_383_),
    .B(_384_),
    .C(_27_),
    .Y(_385_)
);

NAND2X1 _1110_ (
    .A(\u_alien.x_ball [6]),
    .B(_379_),
    .Y(_384_)
);

OAI21X1 _1111_ (
    .A(\u_alien.x_ball [5]),
    .B(_355_),
    .C(_382_),
    .Y(_383_)
);

AOI21X1 _1112_ (
    .A(_377_),
    .B(_378_),
    .C(_381_),
    .Y(_382_)
);

OAI21X1 _1113_ (
    .A(\u_alien.x_ball [6]),
    .B(_379_),
    .C(_380_),
    .Y(_381_)
);

NAND2X1 _1114_ (
    .A(\u_ball.x_paddle [6]),
    .B(_24_),
    .Y(_380_)
);

NOR2X1 _1115_ (
    .A(\u_ball.x_paddle [6]),
    .B(_24_),
    .Y(_379_)
);

AOI22X1 _1116_ (
    .A(\u_alien.x_ball [4]),
    .B(_357_),
    .C(_355_),
    .D(\u_alien.x_ball [5]),
    .Y(_378_)
);

OAI21X1 _1117_ (
    .A(\u_alien.x_ball [4]),
    .B(_357_),
    .C(_376_),
    .Y(_377_)
);

OAI21X1 _1118_ (
    .A(_370_),
    .B(_375_),
    .C(_369_),
    .Y(_376_)
);

OAI22X1 _1119_ (
    .A(\u_alien.x_ball [3]),
    .B(_368_),
    .C(_374_),
    .D(_371_),
    .Y(_375_)
);

OAI21X1 _1120_ (
    .A(_323_),
    .B(_296_),
    .C(_373_),
    .Y(_374_)
);

OAI21X1 _1121_ (
    .A(\u_alien.x_ball [1]),
    .B(\u_ball.x_paddle [1]),
    .C(_372_),
    .Y(_373_)
);

NOR2X1 _1122_ (
    .A(gnd),
    .B(_285_),
    .Y(_372_)
);

NOR2X1 _1123_ (
    .A(_317_),
    .B(_287_),
    .Y(_371_)
);

AND2X2 _1124_ (
    .A(_287_),
    .B(_317_),
    .Y(_370_)
);

NAND2X1 _1125_ (
    .A(\u_alien.x_ball [3]),
    .B(_368_),
    .Y(_369_)
);

NAND2X1 _1126_ (
    .A(_26_),
    .B(_367_),
    .Y(_368_)
);

NAND2X1 _1127_ (
    .A(_292_),
    .B(_289_),
    .Y(_367_)
);

NAND2X1 _1128_ (
    .A(_356_),
    .B(_25_),
    .Y(_357_)
);

OAI21X1 _1129_ (
    .A(_292_),
    .B(_289_),
    .C(_51_),
    .Y(_356_)
);

OR2X2 _1130_ (
    .A(_24_),
    .B(_22_),
    .Y(_355_)
);

INVX1 _1131_ (
    .A(_23_),
    .Y(_22_)
);

OAI21X1 _1132_ (
    .A(_51_),
    .B(_26_),
    .C(_44_),
    .Y(_23_)
);

NOR2X1 _1133_ (
    .A(_44_),
    .B(_25_),
    .Y(_24_)
);

OR2X2 _1134_ (
    .A(_26_),
    .B(_51_),
    .Y(_25_)
);

OAI21X1 _1135_ (
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .C(\u_ball.x_paddle [3]),
    .Y(_26_)
);

AOI21X1 _1136_ (
    .A(_39_),
    .B(_31_),
    .C(_28_),
    .Y(_27_)
);

OAI21X1 _1137_ (
    .A(_35_),
    .B(_43_),
    .C(_29_),
    .Y(_28_)
);

OAI21X1 _1138_ (
    .A(\u_ball.x_paddle [6]),
    .B(_38_),
    .C(_30_),
    .Y(_29_)
);

INVX1 _1139_ (
    .A(\u_alien.x_ball [6]),
    .Y(_30_)
);

AND2X2 _1140_ (
    .A(_32_),
    .B(_36_),
    .Y(_31_)
);

OAI21X1 _1141_ (
    .A(_33_),
    .B(_34_),
    .C(\u_alien.x_ball [6]),
    .Y(_32_)
);

NOR2X1 _1142_ (
    .A(\u_ball.x_paddle [6]),
    .B(_38_),
    .Y(_33_)
);

NOR2X1 _1143_ (
    .A(_35_),
    .B(_43_),
    .Y(_34_)
);

INVX1 _1144_ (
    .A(\u_ball.x_paddle [6]),
    .Y(_35_)
);

OAI21X1 _1145_ (
    .A(_37_),
    .B(_38_),
    .C(\u_alien.x_ball [5]),
    .Y(_36_)
);

INVX1 _1146_ (
    .A(_42_),
    .Y(_37_)
);

NOR2X1 _1147_ (
    .A(_44_),
    .B(_50_),
    .Y(_38_)
);

OR2X2 _1148_ (
    .A(_46_),
    .B(_40_),
    .Y(_39_)
);

OAI21X1 _1149_ (
    .A(\u_alien.x_ball [4]),
    .B(_48_),
    .C(_41_),
    .Y(_40_)
);

NAND3X1 _1150_ (
    .A(_45_),
    .B(_42_),
    .C(_43_),
    .Y(_41_)
);

OAI21X1 _1151_ (
    .A(_51_),
    .B(_293_),
    .C(_44_),
    .Y(_42_)
);

OR2X2 _1152_ (
    .A(_50_),
    .B(_44_),
    .Y(_43_)
);

INVX1 _1153_ (
    .A(\u_ball.x_paddle [5]),
    .Y(_44_)
);

INVX2 _1154_ (
    .A(\u_alien.x_ball [5]),
    .Y(_45_)
);

AND2X2 _1155_ (
    .A(_271_),
    .B(_47_),
    .Y(_46_)
);

AOI22X1 _1156_ (
    .A(\u_alien.x_ball [3]),
    .B(_290_),
    .C(_48_),
    .D(\u_alien.x_ball [4]),
    .Y(_47_)
);

NAND2X1 _1157_ (
    .A(_49_),
    .B(_50_),
    .Y(_48_)
);

NAND2X1 _1158_ (
    .A(_51_),
    .B(_293_),
    .Y(_49_)
);

OR2X2 _1159_ (
    .A(_293_),
    .B(_51_),
    .Y(_50_)
);

INVX2 _1160_ (
    .A(\u_ball.x_paddle [4]),
    .Y(_51_)
);

OAI21X1 _1161_ (
    .A(\u_alien.x_ball [3]),
    .B(_290_),
    .C(_272_),
    .Y(_271_)
);

OAI21X1 _1162_ (
    .A(_273_),
    .B(_286_),
    .C(_288_),
    .Y(_272_)
);

AOI21X1 _1163_ (
    .A(\u_alien.x_ball [1]),
    .B(\u_ball.x_paddle [1]),
    .C(_274_),
    .Y(_273_)
);

AOI21X1 _1164_ (
    .A(_285_),
    .B(gnd),
    .C(_284_),
    .Y(_274_)
);

NOR2X1 _1165_ (
    .A(\u_alien.x_ball [1]),
    .B(\u_ball.x_paddle [1]),
    .Y(_284_)
);

INVX2 _1166_ (
    .A(\u_alien.x_ball [0]),
    .Y(_285_)
);

NOR2X1 _1167_ (
    .A(\u_alien.x_ball [2]),
    .B(_287_),
    .Y(_286_)
);

OR2X2 _1168_ (
    .A(_294_),
    .B(_289_),
    .Y(_287_)
);

OAI21X1 _1169_ (
    .A(_289_),
    .B(_294_),
    .C(\u_alien.x_ball [2]),
    .Y(_288_)
);

NOR2X1 _1170_ (
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .Y(_289_)
);

NAND2X1 _1171_ (
    .A(_291_),
    .B(_293_),
    .Y(_290_)
);

OAI21X1 _1172_ (
    .A(_296_),
    .B(_295_),
    .C(_292_),
    .Y(_291_)
);

INVX1 _1173_ (
    .A(\u_ball.x_paddle [3]),
    .Y(_292_)
);

NAND2X1 _1174_ (
    .A(\u_ball.x_paddle [3]),
    .B(_294_),
    .Y(_293_)
);

NOR2X1 _1175_ (
    .A(_296_),
    .B(_295_),
    .Y(_294_)
);

INVX1 _1176_ (
    .A(\u_ball.x_paddle [2]),
    .Y(_295_)
);

INVX1 _1177_ (
    .A(\u_ball.x_paddle [1]),
    .Y(_296_)
);

INVX1 _1178_ (
    .A(_298_),
    .Y(_297_)
);

NOR2X1 _1179_ (
    .A(game_init),
    .B(_299_),
    .Y(_298_)
);

INVX1 _1180_ (
    .A(\u_ball.hit_paddle ),
    .Y(_299_)
);

OAI22X1 _1181_ (
    .A(_330_),
    .B(_343_),
    .C(_327_),
    .D(_300_),
    .Y(_365_)
);

NAND2X1 _1182_ (
    .A(_301_),
    .B(_302_),
    .Y(_300_)
);

NAND2X1 _1183_ (
    .A(_303_),
    .B(_306_),
    .Y(_301_)
);

OR2X2 _1184_ (
    .A(_306_),
    .B(_303_),
    .Y(_302_)
);

NAND2X1 _1185_ (
    .A(_305_),
    .B(_304_),
    .Y(_303_)
);

NAND2X1 _1186_ (
    .A(\u_ball.sign_x ),
    .B(_330_),
    .Y(_304_)
);

NAND2X1 _1187_ (
    .A(\u_alien.x_ball [4]),
    .B(_326_),
    .Y(_305_)
);

OAI21X1 _1188_ (
    .A(_326_),
    .B(_307_),
    .C(_308_),
    .Y(_306_)
);

NOR2X1 _1189_ (
    .A(\u_alien.x_ball [2]),
    .B(\u_alien.x_ball [3]),
    .Y(_307_)
);

NAND2X1 _1190_ (
    .A(_309_),
    .B(_313_),
    .Y(_308_)
);

NAND2X1 _1191_ (
    .A(_311_),
    .B(_310_),
    .Y(_309_)
);

NAND2X1 _1192_ (
    .A(\u_alien.x_ball [3]),
    .B(_326_),
    .Y(_310_)
);

NAND2X1 _1193_ (
    .A(\u_ball.sign_x ),
    .B(_312_),
    .Y(_311_)
);

INVX2 _1194_ (
    .A(\u_alien.x_ball [3]),
    .Y(_312_)
);

NOR2X1 _1195_ (
    .A(_314_),
    .B(_319_),
    .Y(_313_)
);

INVX1 _1196_ (
    .A(_315_),
    .Y(_314_)
);

NAND2X1 _1197_ (
    .A(_318_),
    .B(_316_),
    .Y(_315_)
);

NAND2X1 _1198_ (
    .A(\u_ball.sign_x ),
    .B(_317_),
    .Y(_316_)
);

INVX2 _1199_ (
    .A(\u_alien.x_ball [2]),
    .Y(_317_)
);

NAND2X1 _1200_ (
    .A(\u_alien.x_ball [2]),
    .B(_326_),
    .Y(_318_)
);

AND2X2 _1201_ (
    .A(_320_),
    .B(_324_),
    .Y(_319_)
);

OAI21X1 _1202_ (
    .A(\u_ball.x2 ),
    .B(\u_alien.x_ball [0]),
    .C(_321_),
    .Y(_320_)
);

AND2X2 _1203_ (
    .A(_322_),
    .B(_324_),
    .Y(_321_)
);

OAI21X1 _1204_ (
    .A(\u_ball.x2 ),
    .B(_326_),
    .C(_323_),
    .Y(_322_)
);

INVX2 _1205_ (
    .A(\u_alien.x_ball [1]),
    .Y(_323_)
);

NAND3X1 _1206_ (
    .A(\u_ball.sign_x ),
    .B(\u_alien.x_ball [1]),
    .C(_325_),
    .Y(_324_)
);

INVX1 _1207_ (
    .A(\u_ball.x2 ),
    .Y(_325_)
);

INVX2 _1208_ (
    .A(\u_ball.sign_x ),
    .Y(_326_)
);

INVX2 _1209_ (
    .A(_328_),
    .Y(_327_)
);

NOR2X1 _1210_ (
    .A(game_init),
    .B(_329_),
    .Y(_328_)
);

INVX1 _1211_ (
    .A(_859_),
    .Y(_329_)
);

INVX2 _1212_ (
    .A(\u_alien.x_ball [4]),
    .Y(_330_)
);

AOI21X1 _1213_ (
    .A(_859_),
    .B(_331_),
    .C(_340_),
    .Y(_366_)
);

OAI21X1 _1214_ (
    .A(_336_),
    .B(_332_),
    .C(_339_),
    .Y(_331_)
);

NAND3X1 _1215_ (
    .A(_335_),
    .B(_334_),
    .C(_333_),
    .Y(_332_)
);

INVX1 _1216_ (
    .A(\u_ball.y_ball [5]),
    .Y(_333_)
);

INVX1 _1217_ (
    .A(\u_ball.y_ball [4]),
    .Y(_334_)
);

INVX2 _1218_ (
    .A(\u_ball.y_ball [3]),
    .Y(_335_)
);

NAND2X1 _1219_ (
    .A(_338_),
    .B(_337_),
    .Y(_336_)
);

INVX2 _1220_ (
    .A(\u_ball.y_ball [2]),
    .Y(_337_)
);

INVX1 _1221_ (
    .A(\u_ball.y_ball [1]),
    .Y(_338_)
);

INVX1 _1222_ (
    .A(hit_alien),
    .Y(_339_)
);

OAI21X1 _1223_ (
    .A(\u_ball.sign_y ),
    .B(_341_),
    .C(_345_),
    .Y(_340_)
);

INVX1 _1224_ (
    .A(_342_),
    .Y(_341_)
);

OAI21X1 _1225_ (
    .A(game_init),
    .B(\u_ball.hit_paddle ),
    .C(_343_),
    .Y(_342_)
);

INVX4 _1226_ (
    .A(_344_),
    .Y(_343_)
);

NOR2X1 _1227_ (
    .A(game_init),
    .B(_859_),
    .Y(_344_)
);

INVX1 _1228_ (
    .A(game_init),
    .Y(_345_)
);

DFFSR _1229_ (
    .CLK(clk_bF$buf7),
    .D(_803_),
    .Q(\u_ball.hit_paddle ),
    .R(_354__bF$buf3),
    .S(vdd)
);

DFFSR _1230_ (
    .CLK(clk_bF$buf6),
    .D(_552_),
    .Q(lfsr4[0]),
    .R(vdd),
    .S(_550_)
);

DFFSR _1231_ (
    .CLK(clk_bF$buf5),
    .D(_551_),
    .Q(lfsr4[1]),
    .R(vdd),
    .S(_550_)
);

DFFSR _1232_ (
    .CLK(clk_bF$buf4),
    .D(_553_),
    .Q(lfsr4[3]),
    .R(vdd),
    .S(_550_)
);

OAI21X1 _1233_ (
    .A(en_lfsr4),
    .B(_548_),
    .C(_422_),
    .Y(_549_)
);

NAND2X1 _1234_ (
    .A(en_lfsr4),
    .B(lfsr4[1]),
    .Y(_422_)
);

INVX2 _1235_ (
    .A(reset),
    .Y(_550_)
);

OAI21X1 _1236_ (
    .A(en_lfsr4),
    .B(_424_),
    .C(_423_),
    .Y(_551_)
);

NAND2X1 _1237_ (
    .A(en_lfsr4),
    .B(lfsr4[0]),
    .Y(_423_)
);

INVX1 _1238_ (
    .A(lfsr4[1]),
    .Y(_424_)
);

NAND2X1 _1239_ (
    .A(_425_),
    .B(_539_),
    .Y(_552_)
);

NAND2X1 _1240_ (
    .A(lfsr4[0]),
    .B(_547_),
    .Y(_425_)
);

NAND3X1 _1241_ (
    .A(en_lfsr4),
    .B(_545_),
    .C(_544_),
    .Y(_539_)
);

OR2X2 _1242_ (
    .A(lfsr4[3]),
    .B(lfsr4[2]),
    .Y(_544_)
);

NAND2X1 _1243_ (
    .A(lfsr4[3]),
    .B(lfsr4[2]),
    .Y(_545_)
);

OAI21X1 _1244_ (
    .A(_548_),
    .B(_547_),
    .C(_546_),
    .Y(_553_)
);

NAND2X1 _1245_ (
    .A(lfsr4[3]),
    .B(_547_),
    .Y(_546_)
);

INVX1 _1246_ (
    .A(en_lfsr4),
    .Y(_547_)
);

INVX1 _1247_ (
    .A(lfsr4[2]),
    .Y(_548_)
);

DFFSR _1248_ (
    .CLK(clk_bF$buf3),
    .D(_347_),
    .Q(_856_),
    .R(_354__bF$buf2),
    .S(vdd)
);

DFFSR _1249_ (
    .CLK(clk_bF$buf2),
    .D(_263_),
    .Q(\u_alien.x_bullet [4]),
    .R(_270__bF$buf3),
    .S(vdd)
);

DFFSR _1250_ (
    .CLK(clk_bF$buf1),
    .D(_279_),
    .Q(\u_alien.regAliens [7]),
    .R(vdd),
    .S(_270__bF$buf2)
);

DFFSR _1251_ (
    .CLK(clk_bF$buf0),
    .D(_264_),
    .Q(\u_alien.regAliens [4]),
    .R(vdd),
    .S(_270__bF$buf1)
);

DFFSR _1252_ (
    .CLK(clk_bF$buf7),
    .D(_282_),
    .Q(\u_alien.regAliens [6]),
    .R(vdd),
    .S(_270__bF$buf0)
);

DFFSR _1253_ (
    .CLK(clk_bF$buf6),
    .D(_265_),
    .Q(\u_alien.regAliens [3]),
    .R(vdd),
    .S(_270__bF$buf3)
);

DFFSR _1254_ (
    .CLK(clk_bF$buf5),
    .D(_280_),
    .Q(\u_alien.y_bullet [1]),
    .R(_270__bF$buf2),
    .S(vdd)
);

DFFSR _1255_ (
    .CLK(clk_bF$buf4),
    .D(_266_),
    .Q(\u_alien.regAliens [2]),
    .R(vdd),
    .S(_270__bF$buf1)
);

DFFSR _1256_ (
    .CLK(clk_bF$buf3),
    .D(_276_),
    .Q(\u_alien.y_bullet [3]),
    .R(_270__bF$buf0),
    .S(vdd)
);

DFFSR _1257_ (
    .CLK(clk_bF$buf2),
    .D(_267_),
    .Q(\u_alien.y_bullet [5]),
    .R(_270__bF$buf3),
    .S(vdd)
);

DFFSR _1258_ (
    .CLK(clk_bF$buf1),
    .D(_262_),
    .Q(\u_alien.x_bullet [5]),
    .R(_270__bF$buf2),
    .S(vdd)
);

DFFSR _1259_ (
    .CLK(clk_bF$buf0),
    .D(_268_),
    .Q(\u_alien.regAliens [1]),
    .R(vdd),
    .S(_270__bF$buf1)
);

DFFSR _1260_ (
    .CLK(clk_bF$buf7),
    .D(_277_),
    .Q(\u_alien.x_bullet [6]),
    .R(vdd),
    .S(_270__bF$buf0)
);

DFFSR _1261_ (
    .CLK(clk_bF$buf6),
    .D(_269_),
    .Q(\u_alien.regAliens [0]),
    .R(vdd),
    .S(_270__bF$buf3)
);

DFFSR _1262_ (
    .CLK(clk_bF$buf5),
    .D(_281_),
    .Q(\u_alien.y_bullet [0]),
    .R(_270__bF$buf2),
    .S(vdd)
);

DFFSR _1263_ (
    .CLK(clk_bF$buf4),
    .D(_275_),
    .Q(\u_alien.y_bullet [4]),
    .R(_270__bF$buf1),
    .S(vdd)
);

DFFSR _1264_ (
    .CLK(clk_bF$buf3),
    .D(_278_),
    .Q(\u_alien.y_bullet [2]),
    .R(_270__bF$buf0),
    .S(vdd)
);

OAI21X1 _1265_ (
    .A(_133_),
    .B(_200_),
    .C(_52_),
    .Y(_262_)
);

NAND3X1 _1266_ (
    .A(lfsr4[1]),
    .B(_223_),
    .C(_199_),
    .Y(_52_)
);

OAI21X1 _1267_ (
    .A(_143_),
    .B(_200_),
    .C(_53_),
    .Y(_263_)
);

NAND3X1 _1268_ (
    .A(lfsr4[0]),
    .B(_223_),
    .C(_199_),
    .Y(_53_)
);

AOI21X1 _1269_ (
    .A(_59_),
    .B(\u_alien.x_ball [6]),
    .C(_250_),
    .Y(_264_)
);

AOI21X1 _1270_ (
    .A(_58_),
    .B(_215_),
    .C(_235_),
    .Y(_265_)
);

AOI21X1 _1271_ (
    .A(_58_),
    .B(_252_),
    .C(_238_),
    .Y(_266_)
);

OAI21X1 _1272_ (
    .A(_177_),
    .B(_220_),
    .C(_54_),
    .Y(_267_)
);

NAND2X1 _1273_ (
    .A(_55_),
    .B(_220_),
    .Y(_54_)
);

AOI21X1 _1274_ (
    .A(_56_),
    .B(_57_),
    .C(game_init),
    .Y(_55_)
);

NAND2X1 _1275_ (
    .A(_177_),
    .B(_189_),
    .Y(_56_)
);

NAND2X1 _1276_ (
    .A(\u_alien.y_bullet [5]),
    .B(_190_),
    .Y(_57_)
);

AOI21X1 _1277_ (
    .A(_58_),
    .B(_259_),
    .C(_247_),
    .Y(_268_)
);

NOR2X1 _1278_ (
    .A(\u_alien.x_ball [6]),
    .B(_258_),
    .Y(_58_)
);

AOI21X1 _1279_ (
    .A(_59_),
    .B(_61_),
    .C(_84_),
    .Y(_269_)
);

NOR2X1 _1280_ (
    .A(_258_),
    .B(_60_),
    .Y(_59_)
);

NAND2X1 _1281_ (
    .A(_260_),
    .B(_253_),
    .Y(_60_)
);

INVX1 _1282_ (
    .A(\u_alien.x_ball [6]),
    .Y(_61_)
);

INVX8 _1283_ (
    .A(reset),
    .Y(_270_)
);

NOR2X1 _1284_ (
    .A(_64_),
    .B(_62_),
    .Y(_0_)
);

NAND3X1 _1285_ (
    .A(_75_),
    .B(_235_),
    .C(_63_),
    .Y(_62_)
);

NOR2X1 _1286_ (
    .A(\u_alien.regAliens [5]),
    .B(\u_alien.regAliens [6]),
    .Y(_63_)
);

NAND3X1 _1287_ (
    .A(_238_),
    .B(_250_),
    .C(_65_),
    .Y(_64_)
);

NOR2X1 _1288_ (
    .A(\u_alien.regAliens [1]),
    .B(\u_alien.regAliens [0]),
    .Y(_65_)
);

INVX1 _1289_ (
    .A(_66_),
    .Y(pixel_alien)
);

OAI21X1 _1290_ (
    .A(_129_),
    .B(_101_),
    .C(_67_),
    .Y(_66_)
);

AOI21X1 _1291_ (
    .A(_91_),
    .B(_86_),
    .C(_68_),
    .Y(_67_)
);

NAND3X1 _1292_ (
    .A(_78_),
    .B(_72_),
    .C(_69_),
    .Y(_68_)
);

AOI21X1 _1293_ (
    .A(_137_),
    .B(_129_),
    .C(_70_),
    .Y(_69_)
);

NAND3X1 _1294_ (
    .A(_164_),
    .B(_71_),
    .C(_125_),
    .Y(_70_)
);

NOR2X1 _1295_ (
    .A(\u_alien.y_pos [5]),
    .B(\u_alien.y_pos [4]),
    .Y(_71_)
);

NAND3X1 _1296_ (
    .A(\u_alien.x_pos [6]),
    .B(_73_),
    .C(_76_),
    .Y(_72_)
);

OAI21X1 _1297_ (
    .A(\u_alien.regAliens [6]),
    .B(\u_alien.x_pos [4]),
    .C(_74_),
    .Y(_73_)
);

AOI21X1 _1298_ (
    .A(_75_),
    .B(\u_alien.x_pos [4]),
    .C(_136_),
    .Y(_74_)
);

INVX1 _1299_ (
    .A(\u_alien.regAliens [7]),
    .Y(_75_)
);

OAI21X1 _1300_ (
    .A(\u_alien.regAliens [5]),
    .B(_134_),
    .C(_77_),
    .Y(_76_)
);

AOI21X1 _1301_ (
    .A(_250_),
    .B(_134_),
    .C(\u_alien.x_pos [5]),
    .Y(_77_)
);

NAND3X1 _1302_ (
    .A(_85_),
    .B(_81_),
    .C(_79_),
    .Y(_78_)
);

OAI21X1 _1303_ (
    .A(\u_alien.regAliens [1]),
    .B(\u_alien.x_pos [5]),
    .C(_80_),
    .Y(_79_)
);

AOI21X1 _1304_ (
    .A(_235_),
    .B(\u_alien.x_pos [5]),
    .C(_134_),
    .Y(_80_)
);

NAND3X1 _1305_ (
    .A(_134_),
    .B(_82_),
    .C(_83_),
    .Y(_81_)
);

NAND2X1 _1306_ (
    .A(\u_alien.x_pos [5]),
    .B(_238_),
    .Y(_82_)
);

NAND2X1 _1307_ (
    .A(_84_),
    .B(_136_),
    .Y(_83_)
);

INVX1 _1308_ (
    .A(\u_alien.regAliens [0]),
    .Y(_84_)
);

INVX1 _1309_ (
    .A(\u_alien.x_pos [6]),
    .Y(_85_)
);

AOI21X1 _1310_ (
    .A(_90_),
    .B(_87_),
    .C(\u_alien.x_pos [3]),
    .Y(_86_)
);

AOI21X1 _1311_ (
    .A(_89_),
    .B(_88_),
    .C(_140_),
    .Y(_87_)
);

AOI21X1 _1312_ (
    .A(_127_),
    .B(\u_alien.x_pos [2]),
    .C(_139_),
    .Y(_88_)
);

OAI21X1 _1313_ (
    .A(_127_),
    .B(_126_),
    .C(alien_flip),
    .Y(_89_)
);

OAI21X1 _1314_ (
    .A(\u_alien.x_pos [2]),
    .B(_112_),
    .C(_139_),
    .Y(_90_)
);

OAI21X1 _1315_ (
    .A(_96_),
    .B(_99_),
    .C(_92_),
    .Y(_91_)
);

AOI21X1 _1316_ (
    .A(_94_),
    .B(_93_),
    .C(_95_),
    .Y(_92_)
);

AOI21X1 _1317_ (
    .A(_121_),
    .B(alien_flip),
    .C(_140_),
    .Y(_93_)
);

NAND3X1 _1318_ (
    .A(_139_),
    .B(_128_),
    .C(_114_),
    .Y(_94_)
);

INVX1 _1319_ (
    .A(\u_alien.x_pos [2]),
    .Y(_95_)
);

NAND3X1 _1320_ (
    .A(_140_),
    .B(_107_),
    .C(_97_),
    .Y(_96_)
);

NAND3X1 _1321_ (
    .A(\u_alien.x_pos [0]),
    .B(_128_),
    .C(_98_),
    .Y(_97_)
);

NAND3X1 _1322_ (
    .A(\u_alien.rom_addr [1]),
    .B(\u_alien.rom_addr [2]),
    .C(_185_),
    .Y(_98_)
);

AOI21X1 _1323_ (
    .A(_123_),
    .B(_100_),
    .C(\u_alien.x_pos [0]),
    .Y(_99_)
);

NAND2X1 _1324_ (
    .A(alien_flip),
    .B(_114_),
    .Y(_100_)
);

AOI22X1 _1325_ (
    .A(\u_alien.x_pos [2]),
    .B(_118_),
    .C(_104_),
    .D(_102_),
    .Y(_101_)
);

AOI21X1 _1326_ (
    .A(_103_),
    .B(_139_),
    .C(\u_alien.x_pos [2]),
    .Y(_102_)
);

OAI21X1 _1327_ (
    .A(_140_),
    .B(_116_),
    .C(\u_alien.rom_addr [1]),
    .Y(_103_)
);

AOI22X1 _1328_ (
    .A(_140_),
    .B(_105_),
    .C(_111_),
    .D(_115_),
    .Y(_104_)
);

NAND2X1 _1329_ (
    .A(_106_),
    .B(_107_),
    .Y(_105_)
);

OAI21X1 _1330_ (
    .A(_127_),
    .B(_126_),
    .C(_128_),
    .Y(_106_)
);

OAI21X1 _1331_ (
    .A(_127_),
    .B(_110_),
    .C(_108_),
    .Y(_107_)
);

INVX1 _1332_ (
    .A(_109_),
    .Y(_108_)
);

NAND2X1 _1333_ (
    .A(\u_alien.x_pos [0]),
    .B(alien_flip),
    .Y(_109_)
);

AND2X2 _1334_ (
    .A(\u_alien.rom_addr [0]),
    .B(\u_alien.rom_addr [2]),
    .Y(_110_)
);

NAND2X1 _1335_ (
    .A(_113_),
    .B(_112_),
    .Y(_111_)
);

NAND3X1 _1336_ (
    .A(alien_flip),
    .B(_124_),
    .C(_125_),
    .Y(_112_)
);

NAND2X1 _1337_ (
    .A(_128_),
    .B(_114_),
    .Y(_113_)
);

OAI21X1 _1338_ (
    .A(\u_alien.rom_addr [0]),
    .B(_126_),
    .C(\u_alien.rom_addr [1]),
    .Y(_114_)
);

NOR2X1 _1339_ (
    .A(_140_),
    .B(_116_),
    .Y(_115_)
);

AOI21X1 _1340_ (
    .A(_117_),
    .B(alien_flip),
    .C(\u_alien.x_pos [0]),
    .Y(_116_)
);

NAND2X1 _1341_ (
    .A(\u_alien.rom_addr [0]),
    .B(\u_alien.rom_addr [2]),
    .Y(_117_)
);

NAND2X1 _1342_ (
    .A(_119_),
    .B(_122_),
    .Y(_118_)
);

AOI21X1 _1343_ (
    .A(_120_),
    .B(_139_),
    .C(\u_alien.x_pos [1]),
    .Y(_119_)
);

OAI21X1 _1344_ (
    .A(\u_alien.rom_addr [0]),
    .B(_121_),
    .C(_128_),
    .Y(_120_)
);

NAND2X1 _1345_ (
    .A(\u_alien.rom_addr [1]),
    .B(\u_alien.rom_addr [2]),
    .Y(_121_)
);

NAND2X1 _1346_ (
    .A(\u_alien.x_pos [0]),
    .B(_123_),
    .Y(_122_)
);

NAND3X1 _1347_ (
    .A(_128_),
    .B(_124_),
    .C(_125_),
    .Y(_123_)
);

OAI21X1 _1348_ (
    .A(\u_alien.rom_addr [0]),
    .B(\u_alien.rom_addr [1]),
    .C(\u_alien.rom_addr [2]),
    .Y(_124_)
);

NAND3X1 _1349_ (
    .A(_185_),
    .B(_127_),
    .C(_126_),
    .Y(_125_)
);

INVX1 _1350_ (
    .A(\u_alien.rom_addr [2]),
    .Y(_126_)
);

INVX2 _1351_ (
    .A(\u_alien.rom_addr [1]),
    .Y(_127_)
);

INVX1 _1352_ (
    .A(alien_flip),
    .Y(_128_)
);

INVX1 _1353_ (
    .A(\u_alien.x_pos [3]),
    .Y(_129_)
);

AOI21X1 _1354_ (
    .A(_144_),
    .B(_160_),
    .C(_130_),
    .Y(pixel_bullet)
);

NAND3X1 _1355_ (
    .A(_137_),
    .B(_141_),
    .C(_131_),
    .Y(_130_)
);

NOR2X1 _1356_ (
    .A(_135_),
    .B(_132_),
    .Y(_131_)
);

OAI22X1 _1357_ (
    .A(\u_alien.x_bullet [4]),
    .B(_134_),
    .C(\u_alien.x_pos [5]),
    .D(_133_),
    .Y(_132_)
);

INVX1 _1358_ (
    .A(\u_alien.x_bullet [5]),
    .Y(_133_)
);

INVX2 _1359_ (
    .A(\u_alien.x_pos [4]),
    .Y(_134_)
);

OAI21X1 _1360_ (
    .A(\u_alien.x_bullet [5]),
    .B(_136_),
    .C(\u_alien.x_pos [3]),
    .Y(_135_)
);

INVX1 _1361_ (
    .A(\u_alien.x_pos [5]),
    .Y(_136_)
);

NOR2X1 _1362_ (
    .A(\u_alien.x_pos [2]),
    .B(_138_),
    .Y(_137_)
);

NAND2X1 _1363_ (
    .A(_140_),
    .B(_139_),
    .Y(_138_)
);

INVX2 _1364_ (
    .A(\u_alien.x_pos [0]),
    .Y(_139_)
);

INVX2 _1365_ (
    .A(\u_alien.x_pos [1]),
    .Y(_140_)
);

AOI21X1 _1366_ (
    .A(_206_),
    .B(\u_alien.x_pos [6]),
    .C(_142_),
    .Y(_141_)
);

OAI22X1 _1367_ (
    .A(\u_alien.x_pos [4]),
    .B(_143_),
    .C(_206_),
    .D(\u_alien.x_pos [6]),
    .Y(_142_)
);

INVX1 _1368_ (
    .A(\u_alien.x_bullet [4]),
    .Y(_143_)
);

NAND3X1 _1369_ (
    .A(_157_),
    .B(_153_),
    .C(_145_),
    .Y(_144_)
);

NOR3X1 _1370_ (
    .A(_151_),
    .B(_146_),
    .C(_152_),
    .Y(_145_)
);

NAND3X1 _1371_ (
    .A(_148_),
    .B(_150_),
    .C(_147_),
    .Y(_146_)
);

NAND3X1 _1372_ (
    .A(_229_),
    .B(_179_),
    .C(_180_),
    .Y(_147_)
);

OAI21X1 _1373_ (
    .A(_181_),
    .B(_149_),
    .C(\u_alien.y_bullet [0]),
    .Y(_148_)
);

INVX1 _1374_ (
    .A(_179_),
    .Y(_149_)
);

OAI21X1 _1375_ (
    .A(_167_),
    .B(_168_),
    .C(_219_),
    .Y(_150_)
);

AOI22X1 _1376_ (
    .A(_175_),
    .B(_176_),
    .C(\u_alien.y_bullet [4]),
    .D(_195_),
    .Y(_151_)
);

AOI21X1 _1377_ (
    .A(_177_),
    .B(\u_alien.y_pos [5]),
    .C(_190_),
    .Y(_152_)
);

NOR2X1 _1378_ (
    .A(_156_),
    .B(_154_),
    .Y(_153_)
);

OAI21X1 _1379_ (
    .A(_219_),
    .B(_166_),
    .C(_155_),
    .Y(_154_)
);

NAND2X1 _1380_ (
    .A(_210_),
    .B(_162_),
    .Y(_155_)
);

OAI21X1 _1381_ (
    .A(_210_),
    .B(_162_),
    .C(_182_),
    .Y(_156_)
);

NAND2X1 _1382_ (
    .A(_159_),
    .B(_158_),
    .Y(_157_)
);

OR2X2 _1383_ (
    .A(_170_),
    .B(_195_),
    .Y(_158_)
);

NAND2X1 _1384_ (
    .A(_195_),
    .B(_170_),
    .Y(_159_)
);

NAND3X1 _1385_ (
    .A(_178_),
    .B(_161_),
    .C(_169_),
    .Y(_160_)
);

AND2X2 _1386_ (
    .A(_166_),
    .B(_162_),
    .Y(_161_)
);

NAND2X1 _1387_ (
    .A(_165_),
    .B(_163_),
    .Y(_162_)
);

NAND2X1 _1388_ (
    .A(_196_),
    .B(_164_),
    .Y(_163_)
);

INVX1 _1389_ (
    .A(\u_alien.y_pos [3]),
    .Y(_164_)
);

NAND2X1 _1390_ (
    .A(\u_alien.y_bullet [3]),
    .B(\u_alien.y_pos [3]),
    .Y(_165_)
);

OR2X2 _1391_ (
    .A(_168_),
    .B(_167_),
    .Y(_166_)
);

NOR2X1 _1392_ (
    .A(\u_alien.y_bullet [2]),
    .B(\u_alien.rom_addr [2]),
    .Y(_167_)
);

AND2X2 _1393_ (
    .A(\u_alien.y_bullet [2]),
    .B(\u_alien.rom_addr [2]),
    .Y(_168_)
);

NOR2X1 _1394_ (
    .A(_170_),
    .B(_174_),
    .Y(_169_)
);

NAND2X1 _1395_ (
    .A(_172_),
    .B(_171_),
    .Y(_170_)
);

NAND2X1 _1396_ (
    .A(\u_alien.y_pos [4]),
    .B(_191_),
    .Y(_171_)
);

NAND2X1 _1397_ (
    .A(\u_alien.y_bullet [4]),
    .B(_173_),
    .Y(_172_)
);

INVX1 _1398_ (
    .A(\u_alien.y_pos [4]),
    .Y(_173_)
);

NAND2X1 _1399_ (
    .A(_176_),
    .B(_175_),
    .Y(_174_)
);

OR2X2 _1400_ (
    .A(_177_),
    .B(\u_alien.y_pos [5]),
    .Y(_175_)
);

NAND2X1 _1401_ (
    .A(\u_alien.y_pos [5]),
    .B(_177_),
    .Y(_176_)
);

INVX1 _1402_ (
    .A(\u_alien.y_bullet [5]),
    .Y(_177_)
);

AOI21X1 _1403_ (
    .A(_180_),
    .B(_179_),
    .C(_182_),
    .Y(_178_)
);

NAND2X1 _1404_ (
    .A(\u_alien.y_bullet [1]),
    .B(\u_alien.rom_addr [1]),
    .Y(_179_)
);

INVX1 _1405_ (
    .A(_181_),
    .Y(_180_)
);

NOR2X1 _1406_ (
    .A(\u_alien.y_bullet [1]),
    .B(\u_alien.rom_addr [1]),
    .Y(_181_)
);

NAND2X1 _1407_ (
    .A(_184_),
    .B(_183_),
    .Y(_182_)
);

NAND2X1 _1408_ (
    .A(\u_alien.rom_addr [0]),
    .B(_229_),
    .Y(_183_)
);

NAND2X1 _1409_ (
    .A(\u_alien.y_bullet [0]),
    .B(_185_),
    .Y(_184_)
);

INVX1 _1410_ (
    .A(\u_alien.rom_addr [0]),
    .Y(_185_)
);

INVX2 _1411_ (
    .A(_239_),
    .Y(en_lfsr4)
);

OAI21X1 _1412_ (
    .A(_191_),
    .B(_220_),
    .C(_186_),
    .Y(_275_)
);

NAND2X1 _1413_ (
    .A(_187_),
    .B(_220_),
    .Y(_186_)
);

NOR2X1 _1414_ (
    .A(_188_),
    .B(_189_),
    .Y(_187_)
);

OAI21X1 _1415_ (
    .A(\u_alien.y_bullet [4]),
    .B(_195_),
    .C(_223_),
    .Y(_188_)
);

INVX1 _1416_ (
    .A(_190_),
    .Y(_189_)
);

NAND2X1 _1417_ (
    .A(\u_alien.y_bullet [4]),
    .B(_195_),
    .Y(_190_)
);

INVX1 _1418_ (
    .A(\u_alien.y_bullet [4]),
    .Y(_191_)
);

NAND2X1 _1419_ (
    .A(_197_),
    .B(_192_),
    .Y(_276_)
);

NAND3X1 _1420_ (
    .A(_223_),
    .B(_193_),
    .C(_220_),
    .Y(_192_)
);

OAI22X1 _1421_ (
    .A(_195_),
    .B(_194_),
    .C(_239_),
    .D(_201_),
    .Y(_193_)
);

NOR2X1 _1422_ (
    .A(\u_alien.y_bullet [3]),
    .B(_210_),
    .Y(_194_)
);

NOR2X1 _1423_ (
    .A(_196_),
    .B(_211_),
    .Y(_195_)
);

INVX1 _1424_ (
    .A(\u_alien.y_bullet [3]),
    .Y(_196_)
);

NAND3X1 _1425_ (
    .A(\u_alien.y_bullet [3]),
    .B(_228_),
    .C(_230_),
    .Y(_197_)
);

OAI21X1 _1426_ (
    .A(_206_),
    .B(_200_),
    .C(_198_),
    .Y(_277_)
);

NAND3X1 _1427_ (
    .A(lfsr4[2]),
    .B(_223_),
    .C(_199_),
    .Y(_198_)
);

NOR2X1 _1428_ (
    .A(_239_),
    .B(_201_),
    .Y(_199_)
);

NOR3X1 _1429_ (
    .A(game_init),
    .B(_239_),
    .C(_201_),
    .Y(_200_)
);

MUX2X1 _1430_ (
    .A(_222_),
    .B(_202_),
    .S(_251_),
    .Y(_201_)
);

NAND2X1 _1431_ (
    .A(_204_),
    .B(_203_),
    .Y(_202_)
);

NAND2X1 _1432_ (
    .A(lfsr4[0]),
    .B(_233_),
    .Y(_203_)
);

NAND2X1 _1433_ (
    .A(_205_),
    .B(_236_),
    .Y(_204_)
);

INVX1 _1434_ (
    .A(lfsr4[0]),
    .Y(_205_)
);

INVX1 _1435_ (
    .A(\u_alien.x_bullet [6]),
    .Y(_206_)
);

OAI21X1 _1436_ (
    .A(_212_),
    .B(_220_),
    .C(_207_),
    .Y(_278_)
);

NAND2X1 _1437_ (
    .A(_208_),
    .B(_220_),
    .Y(_207_)
);

NOR2X1 _1438_ (
    .A(_210_),
    .B(_209_),
    .Y(_208_)
);

OAI21X1 _1439_ (
    .A(\u_alien.y_bullet [2]),
    .B(_219_),
    .C(_223_),
    .Y(_209_)
);

INVX1 _1440_ (
    .A(_211_),
    .Y(_210_)
);

NAND3X1 _1441_ (
    .A(\u_alien.y_bullet [0]),
    .B(\u_alien.y_bullet [1]),
    .C(\u_alien.y_bullet [2]),
    .Y(_211_)
);

INVX1 _1442_ (
    .A(\u_alien.y_bullet [2]),
    .Y(_212_)
);

INVX1 _1443_ (
    .A(_213_),
    .Y(_279_)
);

OAI21X1 _1444_ (
    .A(_256_),
    .B(_214_),
    .C(\u_alien.regAliens [7]),
    .Y(_213_)
);

INVX1 _1445_ (
    .A(_215_),
    .Y(_214_)
);

NOR2X1 _1446_ (
    .A(_260_),
    .B(_253_),
    .Y(_215_)
);

OAI21X1 _1447_ (
    .A(_224_),
    .B(_220_),
    .C(_216_),
    .Y(_280_)
);

NAND2X1 _1448_ (
    .A(_217_),
    .B(_220_),
    .Y(_216_)
);

NOR2X1 _1449_ (
    .A(_218_),
    .B(_219_),
    .Y(_217_)
);

OAI21X1 _1450_ (
    .A(\u_alien.y_bullet [0]),
    .B(\u_alien.y_bullet [1]),
    .C(_223_),
    .Y(_218_)
);

NOR2X1 _1451_ (
    .A(_229_),
    .B(_224_),
    .Y(_219_)
);

NAND3X1 _1452_ (
    .A(_223_),
    .B(_228_),
    .C(_221_),
    .Y(_220_)
);

OAI21X1 _1453_ (
    .A(lfsr4[1]),
    .B(_222_),
    .C(_231_),
    .Y(_221_)
);

NAND2X1 _1454_ (
    .A(_244_),
    .B(_248_),
    .Y(_222_)
);

INVX2 _1455_ (
    .A(game_init),
    .Y(_223_)
);

INVX1 _1456_ (
    .A(\u_alien.y_bullet [1]),
    .Y(_224_)
);

AND2X2 _1457_ (
    .A(_225_),
    .B(_230_),
    .Y(_281_)
);

AND2X2 _1458_ (
    .A(_226_),
    .B(_227_),
    .Y(_225_)
);

OR2X2 _1459_ (
    .A(_228_),
    .B(_229_),
    .Y(_226_)
);

NAND2X1 _1460_ (
    .A(_229_),
    .B(_228_),
    .Y(_227_)
);

NAND2X1 _1461_ (
    .A(_859_),
    .B(_239_),
    .Y(_228_)
);

INVX1 _1462_ (
    .A(\u_alien.y_bullet [0]),
    .Y(_229_)
);

AOI21X1 _1463_ (
    .A(_231_),
    .B(_243_),
    .C(game_init),
    .Y(_230_)
);

AOI21X1 _1464_ (
    .A(_232_),
    .B(lfsr4[1]),
    .C(_239_),
    .Y(_231_)
);

MUX2X1 _1465_ (
    .A(_233_),
    .B(_236_),
    .S(lfsr4[0]),
    .Y(_232_)
);

OAI21X1 _1466_ (
    .A(lfsr4[2]),
    .B(_235_),
    .C(_234_),
    .Y(_233_)
);

NAND2X1 _1467_ (
    .A(\u_alien.regAliens [7]),
    .B(lfsr4[2]),
    .Y(_234_)
);

INVX1 _1468_ (
    .A(\u_alien.regAliens [3]),
    .Y(_235_)
);

OAI21X1 _1469_ (
    .A(lfsr4[2]),
    .B(_238_),
    .C(_237_),
    .Y(_236_)
);

NAND2X1 _1470_ (
    .A(\u_alien.regAliens [6]),
    .B(lfsr4[2]),
    .Y(_237_)
);

INVX1 _1471_ (
    .A(\u_alien.regAliens [2]),
    .Y(_238_)
);

NAND3X1 _1472_ (
    .A(_242_),
    .B(_241_),
    .C(_240_),
    .Y(_239_)
);

NOR2X1 _1473_ (
    .A(\u_alien.y_bullet [4]),
    .B(\u_alien.y_bullet [5]),
    .Y(_240_)
);

NOR2X1 _1474_ (
    .A(\u_alien.y_bullet [2]),
    .B(\u_alien.y_bullet [3]),
    .Y(_241_)
);

NOR2X1 _1475_ (
    .A(\u_alien.y_bullet [0]),
    .B(\u_alien.y_bullet [1]),
    .Y(_242_)
);

NAND3X1 _1476_ (
    .A(_251_),
    .B(_244_),
    .C(_248_),
    .Y(_243_)
);

NAND2X1 _1477_ (
    .A(lfsr4[0]),
    .B(_245_),
    .Y(_244_)
);

OAI21X1 _1478_ (
    .A(lfsr4[2]),
    .B(_247_),
    .C(_246_),
    .Y(_245_)
);

NAND2X1 _1479_ (
    .A(\u_alien.regAliens [5]),
    .B(lfsr4[2]),
    .Y(_246_)
);

INVX1 _1480_ (
    .A(\u_alien.regAliens [1]),
    .Y(_247_)
);

OAI21X1 _1481_ (
    .A(lfsr4[2]),
    .B(\u_alien.regAliens [0]),
    .C(_249_),
    .Y(_248_)
);

AOI21X1 _1482_ (
    .A(_250_),
    .B(lfsr4[2]),
    .C(lfsr4[0]),
    .Y(_249_)
);

INVX1 _1483_ (
    .A(\u_alien.regAliens [4]),
    .Y(_250_)
);

INVX1 _1484_ (
    .A(lfsr4[1]),
    .Y(_251_)
);

AOI21X1 _1485_ (
    .A(_255_),
    .B(_252_),
    .C(_254_),
    .Y(_282_)
);

NOR2X1 _1486_ (
    .A(\u_alien.x_ball [4]),
    .B(_253_),
    .Y(_252_)
);

INVX1 _1487_ (
    .A(\u_alien.x_ball [5]),
    .Y(_253_)
);

INVX1 _1488_ (
    .A(\u_alien.regAliens [6]),
    .Y(_254_)
);

AOI21X1 _1489_ (
    .A(_255_),
    .B(_259_),
    .C(_261_),
    .Y(_283_)
);

INVX1 _1490_ (
    .A(_256_),
    .Y(_255_)
);

NAND2X1 _1491_ (
    .A(\u_alien.x_ball [6]),
    .B(_257_),
    .Y(_256_)
);

INVX1 _1492_ (
    .A(_258_),
    .Y(_257_)
);

NAND2X1 _1493_ (
    .A(_859_),
    .B(hit_alien),
    .Y(_258_)
);

NOR2X1 _1494_ (
    .A(\u_alien.x_ball [5]),
    .B(_260_),
    .Y(_259_)
);

INVX1 _1495_ (
    .A(\u_alien.x_ball [4]),
    .Y(_260_)
);

INVX1 _1496_ (
    .A(\u_alien.regAliens [5]),
    .Y(_261_)
);

DFFSR _1497_ (
    .CLK(clk_bF$buf2),
    .D(_364_),
    .Q(\u_ball.sign_x ),
    .R(_354__bF$buf1),
    .S(vdd)
);

DFFSR _1498_ (
    .CLK(clk_bF$buf1),
    .D(_543_),
    .Q(\u_ball.x_paddle [6]),
    .R(_538_),
    .S(vdd)
);

DFFSR _1499_ (
    .CLK(clk_bF$buf0),
    .D(_537_),
    .Q(\u_ball.x_paddle [2]),
    .R(_538_),
    .S(vdd)
);

DFFSR _1500_ (
    .CLK(clk_bF$buf7),
    .D(_542_),
    .Q(\u_ball.x_paddle [4]),
    .R(_538_),
    .S(vdd)
);

DFFSR _1501_ (
    .CLK(clk_bF$buf6),
    .D(_540_),
    .Q(\u_ball.x_paddle [1]),
    .R(_538_),
    .S(vdd)
);

DFFSR _1502_ (
    .CLK(clk_bF$buf5),
    .D(_541_),
    .Q(\u_ball.x_paddle [5]),
    .R(_538_),
    .S(vdd)
);

OAI21X1 _1503_ (
    .A(_517_),
    .B(_523_),
    .C(_426_),
    .Y(_536_)
);

NAND3X1 _1504_ (
    .A(_523_),
    .B(_509_),
    .C(_427_),
    .Y(_426_)
);

OR2X2 _1505_ (
    .A(_511_),
    .B(_510_),
    .Y(_427_)
);

OAI21X1 _1506_ (
    .A(_484_),
    .B(_523_),
    .C(_428_),
    .Y(_537_)
);

NAND3X1 _1507_ (
    .A(_523_),
    .B(_429_),
    .C(_430_),
    .Y(_428_)
);

NAND2X1 _1508_ (
    .A(_514_),
    .B(_431_),
    .Y(_429_)
);

OR2X2 _1509_ (
    .A(_431_),
    .B(_514_),
    .Y(_430_)
);

OAI21X1 _1510_ (
    .A(_484_),
    .B(btn_left),
    .C(_432_),
    .Y(_431_)
);

INVX1 _1511_ (
    .A(_512_),
    .Y(_432_)
);

INVX2 _1512_ (
    .A(reset),
    .Y(_538_)
);

NOR3X1 _1513_ (
    .A(_440_),
    .B(_433_),
    .C(_456_),
    .Y(pixel_paddle)
);

OAI21X1 _1514_ (
    .A(_450_),
    .B(_435_),
    .C(_434_),
    .Y(_433_)
);

AND2X2 _1515_ (
    .A(\u_alien.y_pos [4]),
    .B(\u_alien.y_pos [3]),
    .Y(_434_)
);

AOI21X1 _1516_ (
    .A(_438_),
    .B(_437_),
    .C(_436_),
    .Y(_435_)
);

OAI21X1 _1517_ (
    .A(_520_),
    .B(\u_alien.x_pos [4]),
    .C(_454_),
    .Y(_436_)
);

NAND2X1 _1518_ (
    .A(\u_alien.x_pos [4]),
    .B(_520_),
    .Y(_437_)
);

AOI21X1 _1519_ (
    .A(_439_),
    .B(_473_),
    .C(_475_),
    .Y(_438_)
);

OAI21X1 _1520_ (
    .A(\u_ball.x_paddle [2]),
    .B(_480_),
    .C(_470_),
    .Y(_439_)
);

OAI21X1 _1521_ (
    .A(_449_),
    .B(_443_),
    .C(_441_),
    .Y(_440_)
);

AOI21X1 _1522_ (
    .A(_453_),
    .B(\u_ball.x_paddle [6]),
    .C(_442_),
    .Y(_441_)
);

INVX1 _1523_ (
    .A(\u_alien.y_pos [5]),
    .Y(_442_)
);

AOI21X1 _1524_ (
    .A(_448_),
    .B(_447_),
    .C(_444_),
    .Y(_443_)
);

NAND2X1 _1525_ (
    .A(_446_),
    .B(_445_),
    .Y(_444_)
);

OAI21X1 _1526_ (
    .A(_520_),
    .B(\u_alien.x_pos [4]),
    .C(_450_),
    .Y(_445_)
);

OAI21X1 _1527_ (
    .A(_522_),
    .B(\u_alien.x_pos [5]),
    .C(_452_),
    .Y(_446_)
);

OR2X2 _1528_ (
    .A(\u_ball.x_paddle [4]),
    .B(\u_alien.x_pos [4]),
    .Y(_447_)
);

OAI21X1 _1529_ (
    .A(\u_ball.x_paddle [3]),
    .B(_476_),
    .C(_472_),
    .Y(_448_)
);

AOI21X1 _1530_ (
    .A(_520_),
    .B(_454_),
    .C(_450_),
    .Y(_449_)
);

OAI21X1 _1531_ (
    .A(\u_ball.x_paddle [5]),
    .B(_455_),
    .C(_451_),
    .Y(_450_)
);

INVX1 _1532_ (
    .A(_452_),
    .Y(_451_)
);

NOR2X1 _1533_ (
    .A(\u_ball.x_paddle [6]),
    .B(_453_),
    .Y(_452_)
);

INVX1 _1534_ (
    .A(\u_alien.x_pos [6]),
    .Y(_453_)
);

NAND2X1 _1535_ (
    .A(\u_ball.x_paddle [5]),
    .B(_455_),
    .Y(_454_)
);

INVX1 _1536_ (
    .A(\u_alien.x_pos [5]),
    .Y(_455_)
);

AOI21X1 _1537_ (
    .A(_462_),
    .B(_458_),
    .C(_457_),
    .Y(_456_)
);

OR2X2 _1538_ (
    .A(\u_alien.rom_addr [1]),
    .B(\u_alien.rom_addr [2]),
    .Y(_457_)
);

AOI21X1 _1539_ (
    .A(_467_),
    .B(_459_),
    .C(_466_),
    .Y(_458_)
);

NOR2X1 _1540_ (
    .A(_460_),
    .B(_470_),
    .Y(_459_)
);

OAI21X1 _1541_ (
    .A(\u_ball.x_paddle [1]),
    .B(_481_),
    .C(_461_),
    .Y(_460_)
);

INVX1 _1542_ (
    .A(\u_alien.x_pos [0]),
    .Y(_461_)
);

OR2X2 _1543_ (
    .A(_463_),
    .B(_467_),
    .Y(_462_)
);

OR2X2 _1544_ (
    .A(_464_),
    .B(_477_),
    .Y(_463_)
);

OAI21X1 _1545_ (
    .A(\u_alien.x_pos [0]),
    .B(_466_),
    .C(_465_),
    .Y(_464_)
);

OAI21X1 _1546_ (
    .A(\u_ball.x_paddle [1]),
    .B(_481_),
    .C(_478_),
    .Y(_465_)
);

INVX1 _1547_ (
    .A(\u_alien.rom_addr [0]),
    .Y(_466_)
);

NAND2X1 _1548_ (
    .A(_472_),
    .B(_468_),
    .Y(_467_)
);

NAND3X1 _1549_ (
    .A(_483_),
    .B(_470_),
    .C(_469_),
    .Y(_468_)
);

INVX1 _1550_ (
    .A(_473_),
    .Y(_469_)
);

OAI21X1 _1551_ (
    .A(_514_),
    .B(\u_alien.x_pos [1]),
    .C(_471_),
    .Y(_470_)
);

AND2X2 _1552_ (
    .A(_483_),
    .B(_479_),
    .Y(_471_)
);

OAI21X1 _1553_ (
    .A(_482_),
    .B(_477_),
    .C(_473_),
    .Y(_472_)
);

NOR2X1 _1554_ (
    .A(_475_),
    .B(_474_),
    .Y(_473_)
);

NOR2X1 _1555_ (
    .A(\u_alien.x_pos [3]),
    .B(_517_),
    .Y(_474_)
);

NOR2X1 _1556_ (
    .A(\u_ball.x_paddle [3]),
    .B(_476_),
    .Y(_475_)
);

INVX1 _1557_ (
    .A(\u_alien.x_pos [3]),
    .Y(_476_)
);

AOI21X1 _1558_ (
    .A(\u_ball.x_paddle [1]),
    .B(_481_),
    .C(_478_),
    .Y(_477_)
);

NAND2X1 _1559_ (
    .A(_483_),
    .B(_479_),
    .Y(_478_)
);

NAND2X1 _1560_ (
    .A(\u_ball.x_paddle [2]),
    .B(_480_),
    .Y(_479_)
);

INVX1 _1561_ (
    .A(\u_alien.x_pos [2]),
    .Y(_480_)
);

INVX1 _1562_ (
    .A(\u_alien.x_pos [1]),
    .Y(_481_)
);

INVX1 _1563_ (
    .A(_483_),
    .Y(_482_)
);

NAND2X1 _1564_ (
    .A(\u_alien.x_pos [2]),
    .B(_484_),
    .Y(_483_)
);

INVX1 _1565_ (
    .A(\u_ball.x_paddle [2]),
    .Y(_484_)
);

NAND2X1 _1566_ (
    .A(_486_),
    .B(_485_),
    .Y(_540_)
);

NAND2X1 _1567_ (
    .A(_514_),
    .B(_523_),
    .Y(_485_)
);

OAI21X1 _1568_ (
    .A(_534_),
    .B(_524_),
    .C(\u_ball.x_paddle [1]),
    .Y(_486_)
);

NAND2X1 _1569_ (
    .A(_487_),
    .B(_488_),
    .Y(_541_)
);

OAI21X1 _1570_ (
    .A(_534_),
    .B(_524_),
    .C(\u_ball.x_paddle [5]),
    .Y(_487_)
);

NAND3X1 _1571_ (
    .A(_523_),
    .B(_491_),
    .C(_489_),
    .Y(_488_)
);

OR2X2 _1572_ (
    .A(_498_),
    .B(_490_),
    .Y(_489_)
);

OAI21X1 _1573_ (
    .A(_522_),
    .B(_532_),
    .C(_521_),
    .Y(_490_)
);

OAI21X1 _1574_ (
    .A(_501_),
    .B(_507_),
    .C(_498_),
    .Y(_491_)
);

OAI21X1 _1575_ (
    .A(_520_),
    .B(_523_),
    .C(_492_),
    .Y(_542_)
);

NAND3X1 _1576_ (
    .A(_523_),
    .B(_493_),
    .C(_494_),
    .Y(_492_)
);

NAND2X1 _1577_ (
    .A(_495_),
    .B(_500_),
    .Y(_493_)
);

OR2X2 _1578_ (
    .A(_500_),
    .B(_495_),
    .Y(_494_)
);

OAI21X1 _1579_ (
    .A(_520_),
    .B(btn_left),
    .C(_506_),
    .Y(_495_)
);

NAND2X1 _1580_ (
    .A(_503_),
    .B(_496_),
    .Y(_543_)
);

OAI21X1 _1581_ (
    .A(_502_),
    .B(_497_),
    .C(\u_ball.x_paddle [6]),
    .Y(_496_)
);

AOI22X1 _1582_ (
    .A(_498_),
    .B(_507_),
    .C(_501_),
    .D(_499_),
    .Y(_497_)
);

AOI22X1 _1583_ (
    .A(_520_),
    .B(_527_),
    .C(_500_),
    .D(_518_),
    .Y(_498_)
);

AND2X2 _1584_ (
    .A(_500_),
    .B(_518_),
    .Y(_499_)
);

AOI22X1 _1585_ (
    .A(\u_ball.x_paddle [3]),
    .B(_532_),
    .C(_511_),
    .D(_510_),
    .Y(_500_)
);

INVX1 _1586_ (
    .A(_521_),
    .Y(_501_)
);

INVX1 _1587_ (
    .A(_523_),
    .Y(_502_)
);

NAND3X1 _1588_ (
    .A(_535_),
    .B(_523_),
    .C(_504_),
    .Y(_503_)
);

OAI21X1 _1589_ (
    .A(_521_),
    .B(_508_),
    .C(_505_),
    .Y(_504_)
);

NAND3X1 _1590_ (
    .A(_507_),
    .B(_506_),
    .C(_508_),
    .Y(_505_)
);

NAND2X1 _1591_ (
    .A(_520_),
    .B(_527_),
    .Y(_506_)
);

NOR2X1 _1592_ (
    .A(_522_),
    .B(_532_),
    .Y(_507_)
);

NAND3X1 _1593_ (
    .A(_518_),
    .B(_515_),
    .C(_509_),
    .Y(_508_)
);

NAND2X1 _1594_ (
    .A(_510_),
    .B(_511_),
    .Y(_509_)
);

AOI21X1 _1595_ (
    .A(_527_),
    .B(_517_),
    .C(_516_),
    .Y(_510_)
);

OAI21X1 _1596_ (
    .A(_514_),
    .B(_512_),
    .C(_513_),
    .Y(_511_)
);

AOI21X1 _1597_ (
    .A(_528_),
    .B(_532_),
    .C(\u_ball.x_paddle [2]),
    .Y(_512_)
);

NAND2X1 _1598_ (
    .A(\u_ball.x_paddle [2]),
    .B(_532_),
    .Y(_513_)
);

INVX1 _1599_ (
    .A(\u_ball.x_paddle [1]),
    .Y(_514_)
);

INVX1 _1600_ (
    .A(_516_),
    .Y(_515_)
);

NOR2X1 _1601_ (
    .A(btn_left),
    .B(_517_),
    .Y(_516_)
);

INVX1 _1602_ (
    .A(\u_ball.x_paddle [3]),
    .Y(_517_)
);

INVX1 _1603_ (
    .A(_519_),
    .Y(_518_)
);

NOR2X1 _1604_ (
    .A(btn_left),
    .B(_520_),
    .Y(_519_)
);

INVX2 _1605_ (
    .A(\u_ball.x_paddle [4]),
    .Y(_520_)
);

NAND2X1 _1606_ (
    .A(_522_),
    .B(_526_),
    .Y(_521_)
);

INVX1 _1607_ (
    .A(\u_ball.x_paddle [5]),
    .Y(_522_)
);

NOR2X1 _1608_ (
    .A(_534_),
    .B(_524_),
    .Y(_523_)
);

AOI21X1 _1609_ (
    .A(_533_),
    .B(_525_),
    .C(_526_),
    .Y(_524_)
);

NAND3X1 _1610_ (
    .A(\u_ball.x_paddle [6]),
    .B(\u_ball.x_paddle [4]),
    .C(\u_ball.x_paddle [5]),
    .Y(_525_)
);

INVX1 _1611_ (
    .A(_527_),
    .Y(_526_)
);

NAND2X1 _1612_ (
    .A(_532_),
    .B(_528_),
    .Y(_527_)
);

NAND3X1 _1613_ (
    .A(_531_),
    .B(_530_),
    .C(_529_),
    .Y(_528_)
);

NOR2X1 _1614_ (
    .A(\u_ball.x_paddle [2]),
    .B(\u_ball.x_paddle [3]),
    .Y(_529_)
);

NOR2X1 _1615_ (
    .A(\u_ball.x_paddle [5]),
    .B(\u_ball.x_paddle [1]),
    .Y(_530_)
);

NOR2X1 _1616_ (
    .A(\u_ball.x_paddle [6]),
    .B(\u_ball.x_paddle [4]),
    .Y(_531_)
);

INVX2 _1617_ (
    .A(btn_left),
    .Y(_532_)
);

INVX1 _1618_ (
    .A(btn_right),
    .Y(_533_)
);

INVX1 _1619_ (
    .A(_859_),
    .Y(_534_)
);

INVX1 _1620_ (
    .A(\u_ball.x_paddle [6]),
    .Y(_535_)
);

DFFSR _1621_ (
    .CLK(clk_bF$buf4),
    .D(_817_),
    .Q(hit_alien),
    .R(_354__bF$buf0),
    .S(vdd)
);

DFFSR _1622_ (
    .CLK(clk_bF$buf3),
    .D(_618_),
    .Q(\u_ctrl.State [3]),
    .R(_800__bF$buf4),
    .S(vdd)
);

DFFSR _1623_ (
    .CLK(clk_bF$buf2),
    .D(_789_),
    .Q(\u_alien.y_pos [4]),
    .R(vdd),
    .S(_800__bF$buf3)
);

DFFSR _1624_ (
    .CLK(clk_bF$buf1),
    .D(_806_),
    .Q(game_init),
    .R(_800__bF$buf2),
    .S(vdd)
);

DFFSR _1625_ (
    .CLK(clk_bF$buf0),
    .D(_790_),
    .Q(\u_alien.y_pos [3]),
    .R(vdd),
    .S(_800__bF$buf1)
);

DFFSR _1626_ (
    .CLK(clk_bF$buf7),
    .D(_815_),
    .Q(\u_alien.x_pos [1]),
    .R(vdd),
    .S(_800__bF$buf0)
);

DFFSR _1627_ (
    .CLK(clk_bF$buf6),
    .D(_791_),
    .Q(\u_alien.rom_addr [2]),
    .R(vdd),
    .S(_800__bF$buf4)
);

DFFSR _1628_ (
    .CLK(clk_bF$buf5),
    .D(_807_),
    .Q(_859_),
    .R(_800__bF$buf3),
    .S(vdd)
);

DFFSR _1629_ (
    .CLK(clk_bF$buf4),
    .D(_792_),
    .Q(\u_alien.rom_addr [1]),
    .R(vdd),
    .S(_800__bF$buf2)
);

DFFSR _1630_ (
    .CLK(clk_bF$buf3),
    .D(_616_),
    .Q(\u_ctrl.State [4]),
    .R(_800__bF$buf1),
    .S(vdd)
);

DFFSR _1631_ (
    .CLK(clk_bF$buf2),
    .D(_793_),
    .Q(\u_alien.rom_addr [0]),
    .R(vdd),
    .S(_800__bF$buf0)
);

DFFSR _1632_ (
    .CLK(clk_bF$buf1),
    .D(_808_),
    .Q(\u_alien.x_pos [5]),
    .R(vdd),
    .S(_800__bF$buf4)
);

DFFSR _1633_ (
    .CLK(clk_bF$buf0),
    .D(_794_),
    .Q(\u_ctrl.cnt_alien_flip [1]),
    .R(_800__bF$buf3),
    .S(vdd)
);

DFFSR _1634_ (
    .CLK(clk_bF$buf7),
    .D(_812_),
    .Q(\u_alien.x_pos [6]),
    .R(vdd),
    .S(_800__bF$buf2)
);

DFFSR _1635_ (
    .CLK(clk_bF$buf6),
    .D(_795_),
    .Q(\u_ctrl.cnt_alien_flip [0]),
    .R(_800__bF$buf1),
    .S(vdd)
);

DFFSR _1636_ (
    .CLK(clk_bF$buf5),
    .D(_809_),
    .Q(\u_alien.x_pos [4]),
    .R(vdd),
    .S(_800__bF$buf0)
);

DFFSR _1637_ (
    .CLK(clk_bF$buf4),
    .D(_620_),
    .Q(\u_ctrl.State [2]),
    .R(_800__bF$buf4),
    .S(vdd)
);

DFFSR _1638_ (
    .CLK(clk_bF$buf3),
    .D(_796_),
    .Q(\u_ctrl.cnt_v_sync [1]),
    .R(_800__bF$buf3),
    .S(vdd)
);

DFFSR _1639_ (
    .CLK(clk_bF$buf2),
    .D(_814_),
    .Q(\u_alien.x_pos [2]),
    .R(vdd),
    .S(_800__bF$buf2)
);

DFFSR _1640_ (
    .CLK(clk_bF$buf1),
    .D(_797_),
    .Q(\u_ctrl.cnt_v_sync [0]),
    .R(_800__bF$buf1),
    .S(vdd)
);

DFFSR _1641_ (
    .CLK(clk_bF$buf0),
    .D(_810_),
    .Q(\u_alien.x_pos [3]),
    .R(vdd),
    .S(_800__bF$buf0)
);

DFFSR _1642_ (
    .CLK(clk_bF$buf7),
    .D(_798_),
    .Q(alien_flip),
    .R(_800__bF$buf4),
    .S(vdd)
);

DFFSR _1643_ (
    .CLK(clk_bF$buf6),
    .D(_813_),
    .Q(\u_ctrl.cnt_v_sync [2]),
    .R(_800__bF$buf3),
    .S(vdd)
);

DFFSR _1644_ (
    .CLK(clk_bF$buf5),
    .D(_799_),
    .Q(\u_alien.y_pos [5]),
    .R(vdd),
    .S(_800__bF$buf2)
);

DFFSR _1645_ (
    .CLK(clk_bF$buf4),
    .D(_811_),
    .Q(_857_),
    .R(_800__bF$buf1),
    .S(vdd)
);

DFFSR _1646_ (
    .CLK(clk_bF$buf3),
    .D(_621_),
    .Q(\u_ctrl.State [1]),
    .R(_800__bF$buf0),
    .S(vdd)
);

DFFSR _1647_ (
    .CLK(clk_bF$buf2),
    .D(_634_),
    .Q(\u_ctrl.State [0]),
    .R(vdd),
    .S(_800__bF$buf4)
);

OAI21X1 _1648_ (
    .A(\u_ctrl.State_3_bF$buf3 ),
    .B(_785_),
    .C(_670_),
    .Y(_788_)
);

OAI21X1 _1649_ (
    .A(\u_ctrl.State_3_bF$buf2 ),
    .B(\u_ctrl.State [0]),
    .C(_785_),
    .Y(_670_)
);

AOI22X1 _1650_ (
    .A(_741_),
    .B(_671_),
    .C(_683_),
    .D(_740_),
    .Y(_789_)
);

NAND3X1 _1651_ (
    .A(_708_),
    .B(_672_),
    .C(_766_),
    .Y(_671_)
);

OAI21X1 _1652_ (
    .A(_742_),
    .B(_776_),
    .C(\u_ctrl.State_3_bF$buf1 ),
    .Y(_672_)
);

AOI22X1 _1653_ (
    .A(_742_),
    .B(_685_),
    .C(_683_),
    .D(_673_),
    .Y(_790_)
);

NAND2X1 _1654_ (
    .A(_674_),
    .B(_707_),
    .Y(_673_)
);

OAI21X1 _1655_ (
    .A(_677_),
    .B(_681_),
    .C(_742_),
    .Y(_674_)
);

AOI22X1 _1656_ (
    .A(_677_),
    .B(_685_),
    .C(_683_),
    .D(_675_),
    .Y(_791_)
);

NAND2X1 _1657_ (
    .A(_776_),
    .B(_676_),
    .Y(_675_)
);

OAI21X1 _1658_ (
    .A(_682_),
    .B(_680_),
    .C(_677_),
    .Y(_676_)
);

INVX1 _1659_ (
    .A(\u_alien.rom_addr [2]),
    .Y(_677_)
);

AOI22X1 _1660_ (
    .A(_682_),
    .B(_685_),
    .C(_683_),
    .D(_678_),
    .Y(_792_)
);

NAND2X1 _1661_ (
    .A(_681_),
    .B(_679_),
    .Y(_678_)
);

NAND2X1 _1662_ (
    .A(_682_),
    .B(_680_),
    .Y(_679_)
);

INVX1 _1663_ (
    .A(\u_alien.rom_addr [0]),
    .Y(_680_)
);

NAND2X1 _1664_ (
    .A(\u_alien.rom_addr [1]),
    .B(\u_alien.rom_addr [0]),
    .Y(_681_)
);

INVX1 _1665_ (
    .A(\u_alien.rom_addr [1]),
    .Y(_682_)
);

MUX2X1 _1666_ (
    .A(_683_),
    .B(_685_),
    .S(\u_alien.rom_addr [0]),
    .Y(_793_)
);

AND2X2 _1667_ (
    .A(_684_),
    .B(_752_),
    .Y(_683_)
);

NOR2X1 _1668_ (
    .A(_736_),
    .B(_769_),
    .Y(_684_)
);

OAI21X1 _1669_ (
    .A(\u_ctrl.State_3_bF$buf0 ),
    .B(\u_ctrl.State [0]),
    .C(_766_),
    .Y(_685_)
);

OAI21X1 _1670_ (
    .A(_701_),
    .B(_703_),
    .C(_686_),
    .Y(_794_)
);

OAI21X1 _1671_ (
    .A(_688_),
    .B(_687_),
    .C(_703_),
    .Y(_686_)
);

NOR2X1 _1672_ (
    .A(\u_ctrl.cnt_alien_flip [1]),
    .B(_702_),
    .Y(_687_)
);

NOR2X1 _1673_ (
    .A(\u_ctrl.cnt_alien_flip [0]),
    .B(_701_),
    .Y(_688_)
);

NAND2X1 _1674_ (
    .A(_690_),
    .B(_689_),
    .Y(_795_)
);

NAND2X1 _1675_ (
    .A(_702_),
    .B(_703_),
    .Y(_689_)
);

OAI21X1 _1676_ (
    .A(_767_),
    .B(_711_),
    .C(\u_ctrl.cnt_alien_flip [0]),
    .Y(_690_)
);

OAI21X1 _1677_ (
    .A(_763_),
    .B(_692_),
    .C(_691_),
    .Y(_796_)
);

OAI21X1 _1678_ (
    .A(_750_),
    .B(_751_),
    .C(\u_ctrl.cnt_v_sync [1]),
    .Y(_691_)
);

AOI21X1 _1679_ (
    .A(_693_),
    .B(\u_ctrl.State [1]),
    .C(\u_ctrl.State_3_bF$buf3 ),
    .Y(_692_)
);

NAND2X1 _1680_ (
    .A(_694_),
    .B(_762_),
    .Y(_693_)
);

NAND2X1 _1681_ (
    .A(\u_ctrl.cnt_v_sync [0]),
    .B(\u_ctrl.cnt_v_sync [1]),
    .Y(_694_)
);

OAI21X1 _1682_ (
    .A(_763_),
    .B(_696_),
    .C(_695_),
    .Y(_797_)
);

OAI21X1 _1683_ (
    .A(_750_),
    .B(_751_),
    .C(\u_ctrl.cnt_v_sync [0]),
    .Y(_695_)
);

AOI21X1 _1684_ (
    .A(_697_),
    .B(\u_ctrl.State [1]),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_696_)
);

INVX1 _1685_ (
    .A(\u_ctrl.cnt_v_sync [0]),
    .Y(_697_)
);

MUX2X1 _1686_ (
    .A(_698_),
    .B(_704_),
    .S(_703_),
    .Y(_798_)
);

AND2X2 _1687_ (
    .A(_700_),
    .B(_699_),
    .Y(_698_)
);

NAND3X1 _1688_ (
    .A(\u_ctrl.cnt_alien_flip [0]),
    .B(\u_ctrl.cnt_alien_flip [1]),
    .C(_704_),
    .Y(_699_)
);

OAI21X1 _1689_ (
    .A(_702_),
    .B(_701_),
    .C(alien_flip),
    .Y(_700_)
);

INVX1 _1690_ (
    .A(\u_ctrl.cnt_alien_flip [1]),
    .Y(_701_)
);

INVX1 _1691_ (
    .A(\u_ctrl.cnt_alien_flip [0]),
    .Y(_702_)
);

NOR2X1 _1692_ (
    .A(_767_),
    .B(_711_),
    .Y(_703_)
);

INVX1 _1693_ (
    .A(alien_flip),
    .Y(_704_)
);

AOI22X1 _1694_ (
    .A(_768_),
    .B(_720_),
    .C(_705_),
    .D(_777_),
    .Y(_799_)
);

NAND3X1 _1695_ (
    .A(_708_),
    .B(_706_),
    .C(_766_),
    .Y(_705_)
);

OAI21X1 _1696_ (
    .A(_741_),
    .B(_707_),
    .C(\u_ctrl.State_3_bF$buf1 ),
    .Y(_706_)
);

NAND2X1 _1697_ (
    .A(\u_alien.y_pos [3]),
    .B(_775_),
    .Y(_707_)
);

INVX1 _1698_ (
    .A(_782_),
    .Y(_708_)
);

INVX8 _1699_ (
    .A(reset),
    .Y(_800_)
);

OAI21X1 _1700_ (
    .A(_716_),
    .B(_713_),
    .C(_709_),
    .Y(_634_)
);

OAI21X1 _1701_ (
    .A(\u_ctrl.State [2]),
    .B(_735_),
    .C(_767_),
    .Y(_709_)
);

NOR2X1 _1702_ (
    .A(_767_),
    .B(_737_),
    .Y(_621_)
);

AOI21X1 _1703_ (
    .A(_710_),
    .B(_753_),
    .C(_767_),
    .Y(_620_)
);

AND2X2 _1704_ (
    .A(_773_),
    .B(_711_),
    .Y(_710_)
);

NAND2X1 _1705_ (
    .A(\u_ctrl.State [1]),
    .B(_761_),
    .Y(_711_)
);

OAI21X1 _1706_ (
    .A(_716_),
    .B(_714_),
    .C(_712_),
    .Y(_618_)
);

NAND2X1 _1707_ (
    .A(\u_ctrl.State [2]),
    .B(_768_),
    .Y(_712_)
);

AOI21X1 _1708_ (
    .A(_714_),
    .B(_713_),
    .C(game_new),
    .Y(_616_)
);

INVX1 _1709_ (
    .A(\u_ctrl.State [0]),
    .Y(_713_)
);

INVX1 _1710_ (
    .A(\u_ctrl.State [4]),
    .Y(_714_)
);

AOI21X1 _1711_ (
    .A(\u_ctrl.State [4]),
    .B(_717_),
    .C(_715_),
    .Y(_806_)
);

AOI21X1 _1712_ (
    .A(_716_),
    .B(\u_ctrl.State [0]),
    .C(game_init),
    .Y(_715_)
);

INVX1 _1713_ (
    .A(game_new),
    .Y(_716_)
);

NAND2X1 _1714_ (
    .A(game_new),
    .B(\u_ctrl.State [0]),
    .Y(_717_)
);

OAI21X1 _1715_ (
    .A(_767_),
    .B(_719_),
    .C(_718_),
    .Y(_807_)
);

OAI21X1 _1716_ (
    .A(_733_),
    .B(_751_),
    .C(_859_),
    .Y(_718_)
);

INVX1 _1717_ (
    .A(_720_),
    .Y(_719_)
);

NOR2X1 _1718_ (
    .A(_769_),
    .B(_739_),
    .Y(_720_)
);

AOI22X1 _1719_ (
    .A(_748_),
    .B(_782_),
    .C(_721_),
    .D(\u_ctrl.State_3_bF$buf0 ),
    .Y(_808_)
);

NAND2X1 _1720_ (
    .A(_754_),
    .B(_722_),
    .Y(_721_)
);

OAI21X1 _1721_ (
    .A(_771_),
    .B(_727_),
    .C(_748_),
    .Y(_722_)
);

AOI22X1 _1722_ (
    .A(_771_),
    .B(_782_),
    .C(_723_),
    .D(\u_ctrl.State_3_bF$buf3 ),
    .Y(_809_)
);

NAND2X1 _1723_ (
    .A(_724_),
    .B(_747_),
    .Y(_723_)
);

OAI21X1 _1724_ (
    .A(_772_),
    .B(_780_),
    .C(_771_),
    .Y(_724_)
);

AOI22X1 _1725_ (
    .A(_772_),
    .B(_782_),
    .C(_725_),
    .D(\u_ctrl.State_3_bF$buf2 ),
    .Y(_810_)
);

NAND2X1 _1726_ (
    .A(_726_),
    .B(_727_),
    .Y(_725_)
);

OAI21X1 _1727_ (
    .A(_781_),
    .B(_786_),
    .C(_772_),
    .Y(_726_)
);

INVX1 _1728_ (
    .A(_755_),
    .Y(_727_)
);

NAND2X1 _1729_ (
    .A(_728_),
    .B(_731_),
    .Y(_811_)
);

OAI21X1 _1730_ (
    .A(_730_),
    .B(_729_),
    .C(_857_),
    .Y(_728_)
);

INVX1 _1731_ (
    .A(_732_),
    .Y(_729_)
);

OAI22X1 _1732_ (
    .A(_765_),
    .B(_761_),
    .C(_769_),
    .D(_739_),
    .Y(_730_)
);

NAND3X1 _1733_ (
    .A(_744_),
    .B(_732_),
    .C(_737_),
    .Y(_731_)
);

AOI21X1 _1734_ (
    .A(_767_),
    .B(_735_),
    .C(_733_),
    .Y(_732_)
);

NOR2X1 _1735_ (
    .A(_735_),
    .B(_734_),
    .Y(_733_)
);

INVX1 _1736_ (
    .A(_744_),
    .Y(_734_)
);

NAND2X1 _1737_ (
    .A(_736_),
    .B(_765_),
    .Y(_735_)
);

INVX1 _1738_ (
    .A(\u_ctrl.State_3_bF$buf1 ),
    .Y(_736_)
);

AOI22X1 _1739_ (
    .A(\u_ctrl.State [1]),
    .B(_760_),
    .C(_743_),
    .D(_738_),
    .Y(_737_)
);

INVX1 _1740_ (
    .A(_739_),
    .Y(_738_)
);

NAND3X1 _1741_ (
    .A(\u_ctrl.State_3_bF$buf0 ),
    .B(\u_alien.y_pos [5]),
    .C(_740_),
    .Y(_739_)
);

NOR3X1 _1742_ (
    .A(_742_),
    .B(_741_),
    .C(_776_),
    .Y(_740_)
);

INVX1 _1743_ (
    .A(\u_alien.y_pos [4]),
    .Y(_741_)
);

INVX1 _1744_ (
    .A(\u_alien.y_pos [3]),
    .Y(_742_)
);

INVX1 _1745_ (
    .A(_769_),
    .Y(_743_)
);

NOR2X1 _1746_ (
    .A(\u_ctrl.State [0]),
    .B(\u_ctrl.State [2]),
    .Y(_744_)
);

AOI22X1 _1747_ (
    .A(_756_),
    .B(_782_),
    .C(_745_),
    .D(\u_ctrl.State_3_bF$buf3 ),
    .Y(_812_)
);

NAND2X1 _1748_ (
    .A(_769_),
    .B(_746_),
    .Y(_745_)
);

OAI21X1 _1749_ (
    .A(_748_),
    .B(_747_),
    .C(_756_),
    .Y(_746_)
);

INVX1 _1750_ (
    .A(_770_),
    .Y(_747_)
);

INVX1 _1751_ (
    .A(\u_alien.x_pos [5]),
    .Y(_748_)
);

OAI21X1 _1752_ (
    .A(_763_),
    .B(_757_),
    .C(_749_),
    .Y(_813_)
);

OAI21X1 _1753_ (
    .A(_750_),
    .B(_751_),
    .C(\u_ctrl.cnt_v_sync [2]),
    .Y(_749_)
);

INVX1 _1754_ (
    .A(_764_),
    .Y(_750_)
);

NAND3X1 _1755_ (
    .A(_773_),
    .B(_752_),
    .C(_753_),
    .Y(_751_)
);

OAI21X1 _1756_ (
    .A(_856_),
    .B(_0_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_752_)
);

OAI21X1 _1757_ (
    .A(_756_),
    .B(_754_),
    .C(\u_ctrl.State_3_bF$buf1 ),
    .Y(_753_)
);

NAND3X1 _1758_ (
    .A(\u_alien.x_pos [4]),
    .B(\u_alien.x_pos [5]),
    .C(_755_),
    .Y(_754_)
);

NOR2X1 _1759_ (
    .A(_772_),
    .B(_780_),
    .Y(_755_)
);

INVX1 _1760_ (
    .A(\u_alien.x_pos [6]),
    .Y(_756_)
);

NOR2X1 _1761_ (
    .A(\u_ctrl.State_3_bF$buf0 ),
    .B(_758_),
    .Y(_757_)
);

OAI21X1 _1762_ (
    .A(_765_),
    .B(_760_),
    .C(_759_),
    .Y(_758_)
);

NAND3X1 _1763_ (
    .A(\u_ctrl.cnt_v_sync [2]),
    .B(\u_ctrl.State [1]),
    .C(_762_),
    .Y(_759_)
);

INVX1 _1764_ (
    .A(_761_),
    .Y(_760_)
);

NOR2X1 _1765_ (
    .A(\u_ctrl.cnt_v_sync [2]),
    .B(_762_),
    .Y(_761_)
);

OR2X2 _1766_ (
    .A(\u_ctrl.cnt_v_sync [0]),
    .B(\u_ctrl.cnt_v_sync [1]),
    .Y(_762_)
);

NAND3X1 _1767_ (
    .A(_773_),
    .B(_764_),
    .C(_766_),
    .Y(_763_)
);

NAND2X1 _1768_ (
    .A(_765_),
    .B(_782_),
    .Y(_764_)
);

INVX1 _1769_ (
    .A(\u_ctrl.State [1]),
    .Y(_765_)
);

OAI21X1 _1770_ (
    .A(_767_),
    .B(_769_),
    .C(\u_ctrl.State_3_bF$buf3 ),
    .Y(_766_)
);

INVX2 _1771_ (
    .A(_768_),
    .Y(_767_)
);

NOR2X1 _1772_ (
    .A(_856_),
    .B(_0_),
    .Y(_768_)
);

NAND3X1 _1773_ (
    .A(\u_alien.x_pos [6]),
    .B(\u_alien.x_pos [5]),
    .C(_770_),
    .Y(_769_)
);

NOR3X1 _1774_ (
    .A(_772_),
    .B(_771_),
    .C(_780_),
    .Y(_770_)
);

INVX1 _1775_ (
    .A(\u_alien.x_pos [4]),
    .Y(_771_)
);

INVX2 _1776_ (
    .A(\u_alien.x_pos [3]),
    .Y(_772_)
);

OAI21X1 _1777_ (
    .A(_777_),
    .B(_774_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_773_)
);

NAND3X1 _1778_ (
    .A(\u_alien.y_pos [3]),
    .B(\u_alien.y_pos [4]),
    .C(_775_),
    .Y(_774_)
);

INVX1 _1779_ (
    .A(_776_),
    .Y(_775_)
);

NAND3X1 _1780_ (
    .A(\u_alien.rom_addr [1]),
    .B(\u_alien.rom_addr [0]),
    .C(\u_alien.rom_addr [2]),
    .Y(_776_)
);

INVX1 _1781_ (
    .A(\u_alien.y_pos [5]),
    .Y(_777_)
);

AOI22X1 _1782_ (
    .A(_781_),
    .B(_782_),
    .C(_778_),
    .D(\u_ctrl.State_3_bF$buf1 ),
    .Y(_814_)
);

NAND2X1 _1783_ (
    .A(_780_),
    .B(_779_),
    .Y(_778_)
);

OAI21X1 _1784_ (
    .A(_787_),
    .B(_785_),
    .C(_781_),
    .Y(_779_)
);

NAND3X1 _1785_ (
    .A(\u_alien.x_pos [1]),
    .B(\u_alien.x_pos [2]),
    .C(\u_alien.x_pos [0]),
    .Y(_780_)
);

INVX1 _1786_ (
    .A(\u_alien.x_pos [2]),
    .Y(_781_)
);

AOI22X1 _1787_ (
    .A(_787_),
    .B(_782_),
    .C(_783_),
    .D(\u_ctrl.State_3_bF$buf0 ),
    .Y(_815_)
);

NOR2X1 _1788_ (
    .A(\u_ctrl.State_3_bF$buf3 ),
    .B(\u_ctrl.State [0]),
    .Y(_782_)
);

NAND2X1 _1789_ (
    .A(_786_),
    .B(_784_),
    .Y(_783_)
);

NAND2X1 _1790_ (
    .A(_787_),
    .B(_785_),
    .Y(_784_)
);

INVX1 _1791_ (
    .A(\u_alien.x_pos [0]),
    .Y(_785_)
);

NAND2X1 _1792_ (
    .A(\u_alien.x_pos [1]),
    .B(\u_alien.x_pos [0]),
    .Y(_786_)
);

INVX1 _1793_ (
    .A(\u_alien.x_pos [1]),
    .Y(_787_)
);

NOR2X1 _1794_ (
    .A(pixel_ball),
    .B(pixel_bullet),
    .Y(_847_)
);

NOR2X1 _1795_ (
    .A(pixel_paddle),
    .B(pixel_alien),
    .Y(_848_)
);

NAND2X1 _1796_ (
    .A(_847_),
    .B(_848_),
    .Y(_858_)
);

DFFSR _1797_ (
    .CLK(clk_bF$buf1),
    .D(_346_),
    .Q(\u_ball.y_ball [5]),
    .R(_354__bF$buf3),
    .S(vdd)
);

DFFSR _1798_ (
    .CLK(clk_bF$buf0),
    .D(_549_),
    .Q(lfsr4[2]),
    .R(vdd),
    .S(_550_)
);

DFFSR _1799_ (
    .CLK(clk_bF$buf7),
    .D(_283_),
    .Q(\u_alien.regAliens [5]),
    .R(vdd),
    .S(_270__bF$buf3)
);

DFFSR _1800_ (
    .CLK(clk_bF$buf6),
    .D(_536_),
    .Q(\u_ball.x_paddle [3]),
    .R(_538_),
    .S(vdd)
);

DFFSR _1801_ (
    .CLK(clk_bF$buf5),
    .D(_788_),
    .Q(\u_alien.x_pos [0]),
    .R(vdd),
    .S(_800__bF$buf3)
);

BUFX2 _861_ (
    .A(_859_),
    .Y(v_sync)
);

BUFX2 _862_ (
    .A(_858_),
    .Y(pixel)
);

BUFX2 _863_ (
    .A(_857_),
    .Y(p_tick)
);

BUFX2 _864_ (
    .A(_856_),
    .Y(game_over)
);

BUFX2 _865_ (
    .A(_0_),
    .Y(game_complete)
);

DFFSR _866_ (
    .CLK(clk_bF$buf4),
    .D(_348_),
    .Q(\u_alien.x_ball [6]),
    .R(_354__bF$buf2),
    .S(vdd)
);

DFFSR _867_ (
    .CLK(clk_bF$buf3),
    .D(_362_),
    .Q(\u_alien.x_ball [5]),
    .R(_354__bF$buf1),
    .S(vdd)
);

DFFSR _868_ (
    .CLK(clk_bF$buf2),
    .D(_349_),
    .Q(\u_alien.x_ball [3]),
    .R(_354__bF$buf0),
    .S(vdd)
);

DFFSR _869_ (
    .CLK(clk_bF$buf1),
    .D(_366_),
    .Q(\u_ball.sign_y ),
    .R(_354__bF$buf3),
    .S(vdd)
);

DFFSR _870_ (
    .CLK(clk_bF$buf0),
    .D(_350_),
    .Q(\u_alien.x_ball [2]),
    .R(_354__bF$buf2),
    .S(vdd)
);

DFFSR _871_ (
    .CLK(clk_bF$buf7),
    .D(_359_),
    .Q(\u_ball.y_ball [2]),
    .R(vdd),
    .S(_354__bF$buf1)
);

DFFSR _872_ (
    .CLK(clk_bF$buf6),
    .D(_351_),
    .Q(\u_alien.x_ball [1]),
    .R(_354__bF$buf0),
    .S(vdd)
);

DFFSR _873_ (
    .CLK(clk_bF$buf5),
    .D(_363_),
    .Q(\u_ball.x2 ),
    .R(_354__bF$buf3),
    .S(vdd)
);

DFFSR _874_ (
    .CLK(clk_bF$buf4),
    .D(_352_),
    .Q(\u_alien.x_ball [0]),
    .R(_354__bF$buf2),
    .S(vdd)
);

DFFSR _875_ (
    .CLK(clk_bF$buf3),
    .D(_360_),
    .Q(\u_ball.y_ball [1]),
    .R(_354__bF$buf1),
    .S(vdd)
);

DFFSR _876_ (
    .CLK(clk_bF$buf2),
    .D(_353_),
    .Q(\u_ball.y_ball [4]),
    .R(vdd),
    .S(_354__bF$buf0)
);

DFFSR _877_ (
    .CLK(clk_bF$buf1),
    .D(_365_),
    .Q(\u_alien.x_ball [4]),
    .R(_354__bF$buf3),
    .S(vdd)
);

DFFSR _878_ (
    .CLK(clk_bF$buf0),
    .D(_358_),
    .Q(\u_ball.y_ball [3]),
    .R(_354__bF$buf2),
    .S(vdd)
);

DFFSR _879_ (
    .CLK(clk_bF$buf7),
    .D(_361_),
    .Q(\u_ball.y_ball [0]),
    .R(_354__bF$buf1),
    .S(vdd)
);

AOI21X1 _880_ (
    .A(_333_),
    .B(_20_),
    .C(_21_),
    .Y(_346_)
);

OAI21X1 _881_ (
    .A(_333_),
    .B(_20_),
    .C(_345_),
    .Y(_21_)
);

OR2X2 _882_ (
    .A(_19_),
    .B(_329_),
    .Y(_20_)
);

MUX2X1 _883_ (
    .A(_849_),
    .B(_846_),
    .S(_852_),
    .Y(_19_)
);

AOI21X1 _884_ (
    .A(_17_),
    .B(_18_),
    .C(game_init),
    .Y(_347_)
);

AOI21X1 _885_ (
    .A(pixel_bullet),
    .B(pixel_paddle),
    .C(_856_),
    .Y(_18_)
);

NAND3X1 _886_ (
    .A(\u_ball.y_ball [4]),
    .B(\u_ball.y_ball [5]),
    .C(_605_),
    .Y(_17_)
);

OAI21X1 _887_ (
    .A(_30_),
    .B(_343_),
    .C(_16_),
    .Y(_348_)
);

NAND3X1 _888_ (
    .A(_328_),
    .B(_14_),
    .C(_15_),
    .Y(_16_)
);

OR2X2 _889_ (
    .A(_10_),
    .B(_13_),
    .Y(_15_)
);

NAND2X1 _890_ (
    .A(_13_),
    .B(_10_),
    .Y(_14_)
);

NAND2X1 _891_ (
    .A(_11_),
    .B(_12_),
    .Y(_13_)
);

NAND2X1 _892_ (
    .A(_326_),
    .B(_30_),
    .Y(_12_)
);

NAND2X1 _893_ (
    .A(\u_ball.sign_x ),
    .B(\u_alien.x_ball [6]),
    .Y(_11_)
);

AOI21X1 _894_ (
    .A(_402_),
    .B(_403_),
    .C(_404_),
    .Y(_10_)
);

OAI21X1 _895_ (
    .A(_344_),
    .B(_9_),
    .C(_6_),
    .Y(_349_)
);

OAI21X1 _896_ (
    .A(_309_),
    .B(_7_),
    .C(_8_),
    .Y(_9_)
);

AOI21X1 _897_ (
    .A(_7_),
    .B(_309_),
    .C(game_init),
    .Y(_8_)
);

OAI21X1 _898_ (
    .A(_326_),
    .B(_317_),
    .C(_3_),
    .Y(_7_)
);

NAND2X1 _899_ (
    .A(\u_alien.x_ball [3]),
    .B(_344_),
    .Y(_6_)
);

OAI22X1 _900_ (
    .A(_317_),
    .B(_343_),
    .C(_327_),
    .D(_5_),
    .Y(_350_)
);

NAND2X1 _901_ (
    .A(_4_),
    .B(_3_),
    .Y(_5_)
);

NAND2X1 _902_ (
    .A(_314_),
    .B(_319_),
    .Y(_4_)
);

INVX1 _903_ (
    .A(_313_),
    .Y(_3_)
);

OAI22X1 _904_ (
    .A(_323_),
    .B(_343_),
    .C(_2_),
    .D(_1_),
    .Y(_351_)
);

OAI21X1 _905_ (
    .A(_855_),
    .B(_321_),
    .C(_328_),
    .Y(_2_)
);

INVX1 _906_ (
    .A(_320_),
    .Y(_1_)
);

OAI22X1 _907_ (
    .A(_285_),
    .B(_860_),
    .C(_855_),
    .D(_327_),
    .Y(_352_)
);

OAI21X1 _908_ (
    .A(\u_ball.x2 ),
    .B(_329_),
    .C(_345_),
    .Y(_860_)
);

NAND2X1 _909_ (
    .A(_325_),
    .B(_285_),
    .Y(_855_)
);

OAI21X1 _910_ (
    .A(_344_),
    .B(_854_),
    .C(_845_),
    .Y(_353_)
);

AOI21X1 _911_ (
    .A(_850_),
    .B(_852_),
    .C(_853_),
    .Y(_854_)
);

OAI21X1 _912_ (
    .A(_850_),
    .B(_852_),
    .C(_345_),
    .Y(_853_)
);

OAI21X1 _913_ (
    .A(_410_),
    .B(_335_),
    .C(_851_),
    .Y(_852_)
);

OAI21X1 _914_ (
    .A(\u_ball.sign_y ),
    .B(\u_ball.y_ball [3]),
    .C(_556_),
    .Y(_851_)
);

NOR2X1 _915_ (
    .A(_846_),
    .B(_849_),
    .Y(_850_)
);

NOR2X1 _916_ (
    .A(\u_ball.sign_y ),
    .B(_334_),
    .Y(_849_)
);

NOR2X1 _917_ (
    .A(\u_ball.y_ball [4]),
    .B(_410_),
    .Y(_846_)
);

NAND2X1 _918_ (
    .A(\u_ball.y_ball [4]),
    .B(_344_),
    .Y(_845_)
);

INVX8 _919_ (
    .A(reset),
    .Y(_354_)
);

AOI21X1 _920_ (
    .A(_844_),
    .B(_299_),
    .C(_343_),
    .Y(_803_)
);

NAND3X1 _921_ (
    .A(pixel_paddle),
    .B(_645_),
    .C(_842_),
    .Y(_844_)
);

AOI21X1 _922_ (
    .A(_843_),
    .B(_339_),
    .C(_343_),
    .Y(_817_)
);

NAND3X1 _923_ (
    .A(pixel_alien),
    .B(_645_),
    .C(_842_),
    .Y(_843_)
);

AND2X2 _924_ (
    .A(_842_),
    .B(_645_),
    .Y(pixel_ball)
);

OAI22X1 _925_ (
    .A(_841_),
    .B(_840_),
    .C(_827_),
    .D(_837_),
    .Y(_842_)
);

OAI21X1 _926_ (
    .A(_820_),
    .B(_660_),
    .C(_825_),
    .Y(_841_)
);

AOI22X1 _927_ (
    .A(_645_),
    .B(_659_),
    .C(_839_),
    .D(_838_),
    .Y(_840_)
);

NAND3X1 _928_ (
    .A(_829_),
    .B(_834_),
    .C(_645_),
    .Y(_839_)
);

NAND2X1 _929_ (
    .A(_820_),
    .B(_830_),
    .Y(_838_)
);

AOI21X1 _930_ (
    .A(_836_),
    .B(_835_),
    .C(_660_),
    .Y(_837_)
);

NAND3X1 _931_ (
    .A(_820_),
    .B(_829_),
    .C(_645_),
    .Y(_836_)
);

NAND2X1 _932_ (
    .A(_834_),
    .B(_830_),
    .Y(_835_)
);

OAI22X1 _933_ (
    .A(_666_),
    .B(_833_),
    .C(_667_),
    .D(_831_),
    .Y(_834_)
);

OAI21X1 _934_ (
    .A(_832_),
    .B(_802_),
    .C(_667_),
    .Y(_833_)
);

NOR2X1 _935_ (
    .A(\u_ball.y_ball [0]),
    .B(_612_),
    .Y(_832_)
);

OAI21X1 _936_ (
    .A(\u_ball.y_ball [0]),
    .B(_612_),
    .C(_666_),
    .Y(_831_)
);

NAND3X1 _937_ (
    .A(_829_),
    .B(_648_),
    .C(_651_),
    .Y(_830_)
);

NAND2X1 _938_ (
    .A(_828_),
    .B(_657_),
    .Y(_829_)
);

NAND2X1 _939_ (
    .A(\u_alien.x_pos [0]),
    .B(_285_),
    .Y(_828_)
);

OAI21X1 _940_ (
    .A(_820_),
    .B(_661_),
    .C(_826_),
    .Y(_827_)
);

INVX1 _941_ (
    .A(_825_),
    .Y(_826_)
);

NAND2X1 _942_ (
    .A(_823_),
    .B(_824_),
    .Y(_825_)
);

OR2X2 _943_ (
    .A(_821_),
    .B(_822_),
    .Y(_824_)
);

NAND2X1 _944_ (
    .A(_822_),
    .B(_821_),
    .Y(_823_)
);

NAND2X1 _945_ (
    .A(_564_),
    .B(_595_),
    .Y(_822_)
);

OAI21X1 _946_ (
    .A(_656_),
    .B(_657_),
    .C(_653_),
    .Y(_821_)
);

NAND2X1 _947_ (
    .A(_805_),
    .B(_819_),
    .Y(_820_)
);

NAND2X1 _948_ (
    .A(_818_),
    .B(_816_),
    .Y(_819_)
);

NOR2X1 _949_ (
    .A(_668_),
    .B(_804_),
    .Y(_818_)
);

INVX1 _950_ (
    .A(_666_),
    .Y(_816_)
);

OAI21X1 _951_ (
    .A(_668_),
    .B(_804_),
    .C(_666_),
    .Y(_805_)
);

NOR2X1 _952_ (
    .A(_669_),
    .B(_802_),
    .Y(_804_)
);

NOR2X1 _953_ (
    .A(_610_),
    .B(_801_),
    .Y(_802_)
);

NOR2X1 _954_ (
    .A(\u_alien.rom_addr [1]),
    .B(_338_),
    .Y(_801_)
);

NAND2X1 _955_ (
    .A(\u_ball.y_ball [0]),
    .B(_612_),
    .Y(_669_)
);

INVX1 _956_ (
    .A(_667_),
    .Y(_668_)
);

OAI21X1 _957_ (
    .A(\u_ball.y_ball [1]),
    .B(_609_),
    .C(_613_),
    .Y(_667_)
);

AND2X2 _958_ (
    .A(_665_),
    .B(_663_),
    .Y(_666_)
);

NAND3X1 _959_ (
    .A(_611_),
    .B(_614_),
    .C(_664_),
    .Y(_665_)
);

INVX1 _960_ (
    .A(_662_),
    .Y(_664_)
);

OAI21X1 _961_ (
    .A(_610_),
    .B(_613_),
    .C(_662_),
    .Y(_663_)
);

NAND2X1 _962_ (
    .A(_615_),
    .B(_630_),
    .Y(_662_)
);

INVX1 _963_ (
    .A(_660_),
    .Y(_661_)
);

NAND3X1 _964_ (
    .A(_659_),
    .B(_648_),
    .C(_651_),
    .Y(_660_)
);

NAND2X1 _965_ (
    .A(_658_),
    .B(_655_),
    .Y(_659_)
);

OAI21X1 _966_ (
    .A(_652_),
    .B(_656_),
    .C(_657_),
    .Y(_658_)
);

INVX1 _967_ (
    .A(_654_),
    .Y(_657_)
);

INVX1 _968_ (
    .A(_565_),
    .Y(_656_)
);

NAND3X1 _969_ (
    .A(_565_),
    .B(_654_),
    .C(_653_),
    .Y(_655_)
);

NOR2X1 _970_ (
    .A(\u_alien.x_pos [0]),
    .B(_285_),
    .Y(_654_)
);

INVX1 _971_ (
    .A(_652_),
    .Y(_653_)
);

NOR2X1 _972_ (
    .A(\u_alien.x_pos [1]),
    .B(_323_),
    .Y(_652_)
);

NOR3X1 _973_ (
    .A(_642_),
    .B(_649_),
    .C(_650_),
    .Y(_651_)
);

AND2X2 _974_ (
    .A(_624_),
    .B(_629_),
    .Y(_650_)
);

AOI21X1 _975_ (
    .A(_599_),
    .B(_601_),
    .C(_594_),
    .Y(_649_)
);

OAI21X1 _976_ (
    .A(_647_),
    .B(_646_),
    .C(_390_),
    .Y(_648_)
);

INVX1 _977_ (
    .A(_592_),
    .Y(_647_)
);

AOI21X1 _978_ (
    .A(_582_),
    .B(_586_),
    .C(_591_),
    .Y(_646_)
);

AOI21X1 _979_ (
    .A(_593_),
    .B(_390_),
    .C(_644_),
    .Y(_645_)
);

OAI21X1 _980_ (
    .A(_594_),
    .B(_602_),
    .C(_643_),
    .Y(_644_)
);

AOI21X1 _981_ (
    .A(_624_),
    .B(_629_),
    .C(_642_),
    .Y(_643_)
);

OAI21X1 _982_ (
    .A(_635_),
    .B(_636_),
    .C(_641_),
    .Y(_642_)
);

AOI21X1 _983_ (
    .A(_637_),
    .B(_638_),
    .C(_640_),
    .Y(_641_)
);

OAI22X1 _984_ (
    .A(_333_),
    .B(\u_alien.y_pos [5]),
    .C(_639_),
    .D(_605_),
    .Y(_640_)
);

NAND2X1 _985_ (
    .A(\u_alien.y_pos [4]),
    .B(_334_),
    .Y(_639_)
);

NAND3X1 _986_ (
    .A(\u_ball.y_ball [4]),
    .B(_626_),
    .C(_605_),
    .Y(_638_)
);

INVX1 _987_ (
    .A(_625_),
    .Y(_637_)
);

OAI21X1 _988_ (
    .A(\u_ball.y_ball [4]),
    .B(_626_),
    .C(_625_),
    .Y(_636_)
);

AOI21X1 _989_ (
    .A(_631_),
    .B(_632_),
    .C(_633_),
    .Y(_635_)
);

OAI22X1 _990_ (
    .A(\u_alien.y_pos [3]),
    .B(_335_),
    .C(_334_),
    .D(\u_alien.y_pos [4]),
    .Y(_633_)
);

AOI22X1 _991_ (
    .A(_337_),
    .B(\u_alien.rom_addr [2]),
    .C(_335_),
    .D(\u_alien.y_pos [3]),
    .Y(_632_)
);

OAI21X1 _992_ (
    .A(_610_),
    .B(_613_),
    .C(_630_),
    .Y(_631_)
);

OR2X2 _993_ (
    .A(_337_),
    .B(\u_alien.rom_addr [2]),
    .Y(_630_)
);

AOI22X1 _994_ (
    .A(_608_),
    .B(_603_),
    .C(_625_),
    .D(_628_),
    .Y(_629_)
);

OAI21X1 _995_ (
    .A(_334_),
    .B(\u_alien.y_pos [4]),
    .C(_627_),
    .Y(_628_)
);

OAI21X1 _996_ (
    .A(\u_ball.y_ball [4]),
    .B(_626_),
    .C(_605_),
    .Y(_627_)
);

INVX1 _997_ (
    .A(\u_alien.y_pos [4]),
    .Y(_626_)
);

NAND2X1 _998_ (
    .A(\u_alien.y_pos [5]),
    .B(_333_),
    .Y(_625_)
);

OAI21X1 _999_ (
    .A(_603_),
    .B(_608_),
    .C(_623_),
    .Y(_624_)
);

endmodule
