*SPICE netlist created from verilog structural netlist module invaders by vlog2Spice (qflow)
*This file may contain array delimiters, not for use in simulation.

** Start of included library /usr/local/share/qflow/tech/etri050/etri050_stdcells.sp
* NGSPICE file created from khu_etri050_stdcells.ext - technology: scmos

.subckt AOI22X1 A B C D Y vdd gnd
M1000 gnd C a_56_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=1.8p ps=6.6u
M1001 vdd A a_7_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1002 Y D a_7_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 a_28_14# A gnd gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1004 Y B a_28_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=1.8p ps=6.6u
M1005 a_7_146# C Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1006 a_7_146# B vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1007 a_56_14# D Y gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=7.2p ps=8.4u
.ends

.subckt CLKBUF3 A Y vdd gnd
M1000 a_145_14# a_105_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1001 a_65_14# a_25_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1002 a_105_14# a_65_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 a_145_14# a_105_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1004 gnd a_145_14# a_185_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1005 a_25_14# A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1006 a_65_14# a_25_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1007 a_265_14# a_225_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1008 a_265_14# a_225_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1009 a_225_14# a_185_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1010 gnd a_265_14# Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1011 a_25_14# A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1012 gnd a_25_14# a_65_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1013 a_105_14# a_65_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1014 Y a_265_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1015 gnd a_105_14# a_145_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1016 vdd a_65_14# a_105_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1017 vdd a_105_14# a_145_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1018 a_225_14# a_185_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1019 gnd a_225_14# a_265_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1020 vdd a_25_14# a_65_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1021 gnd A a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1022 vdd A a_25_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1023 vdd a_185_14# a_225_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1024 vdd a_225_14# a_265_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1025 vdd a_145_14# a_185_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1026 gnd a_65_14# a_105_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1027 a_185_14# a_145_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1028 gnd a_185_14# a_225_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1029 Y a_265_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1030 vdd a_265_14# Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1031 a_185_14# a_145_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
.ends

.subckt INVX8 A Y vdd gnd
M1000 Y A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1001 Y A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1002 Y A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 Y A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1004 gnd A Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 vdd A Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1006 gnd A Y gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1007 vdd A Y vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
.ends

.subckt NOR3X1 A B C Y vdd gnd
M1000 gnd B Y gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=3.6p ps=5.4u
M1001 a_7_166# A vdd vdd pfet w=9u l=0.6u
+  ad=10.8p pd=11.4u as=10.8p ps=11.4u
M1002 a_7_166# B a_65_166# vdd pfet w=9u l=0.6u
+  ad=18.9p pd=22.2u as=10.8p ps=11.4u
M1003 a_65_166# C Y vdd pfet w=9u l=0.6u
+  ad=18.9p pd=22.2u as=10.8p ps=11.4u
M1004 Y C gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1005 a_65_166# B a_7_166# vdd pfet w=9u l=0.6u
+  ad=10.8p pd=11.4u as=10.8p ps=11.4u
M1006 vdd A a_7_166# vdd pfet w=9u l=0.6u
+  ad=10.8p pd=11.4u as=18.9p ps=22.2u
M1007 Y C a_65_166# vdd pfet w=9u l=0.6u
+  ad=10.8p pd=11.4u as=18.9p ps=22.2u
M1008 Y A gnd gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=7.2p ps=10.8u
.ends

.subckt CLKBUF1 A Y vdd gnd
M1000 Y a_105_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1001 a_65_14# a_25_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1002 a_105_14# a_65_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 Y a_105_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1004 a_25_14# A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1005 a_65_14# a_25_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1006 a_25_14# A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1007 gnd a_25_14# a_65_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1008 a_105_14# a_65_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1009 gnd a_105_14# Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1010 vdd a_65_14# a_105_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1011 vdd a_105_14# Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1012 vdd a_25_14# a_65_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1013 gnd A a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1014 vdd A a_25_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1015 gnd a_65_14# a_105_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
.ends

.subckt MUX2X1 A B S Y vdd gnd
M1000 a_75_22# S Y gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1001 gnd S a_7_22# gnd nfet w=3u l=0.6u
+  ad=6.3p pd=8.4u as=6.3p ps=10.2u
M1002 Y S a_45_138# vdd pfet w=12u l=0.6u
+  ad=14.49p pd=15.6u as=5.4p ps=12.9u
M1003 gnd A a_75_22# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=2.7p ps=6.9u
M1004 vdd A a_75_146# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=5.4p ps=12.9u
M1005 a_45_138# B vdd vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=11.7p ps=14.4u
M1006 a_45_22# B gnd gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=6.3p ps=8.4u
M1007 Y a_7_22# a_45_22# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1008 a_75_146# a_7_22# Y vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.49p ps=15.6u
M1009 vdd S a_7_22# vdd pfet w=6u l=0.6u
+  ad=11.7p pd=14.4u as=12.6p ps=16.2u
.ends

.subckt NAND3X1 A B C Y vdd gnd
M1000 Y C a_34_14# gnd nfet w=9u l=0.6u
+  ad=18.9p pd=22.2u as=2.7p ps=9.6u
M1001 a_26_14# A gnd gnd nfet w=9u l=0.6u
+  ad=2.7p pd=9.6u as=18.9p ps=22.2u
M1002 vdd B Y vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1003 a_34_14# B a_26_14# gnd nfet w=9u l=0.6u
+  ad=2.7p pd=9.6u as=2.7p ps=9.6u
M1004 Y C vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 Y A vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
.ends

.subckt XOR2X1 A B Y vdd gnd
M1000 a_74_166# a_6_14# Y vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.4p ps=14.4u
M1001 a_28_58# B vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1002 a_74_14# A Y gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1003 gnd A a_6_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1004 vdd A a_6_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1005 gnd B a_74_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1006 a_28_58# B gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1007 Y A a_44_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
M1008 a_44_14# a_28_58# gnd gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1009 vdd B a_74_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
M1010 Y a_6_14# a_44_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1011 a_44_166# a_28_58# vdd vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.4p ps=14.4u
.ends

.subckt BUFX4 A Y vdd gnd
M1000 Y a_7_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=15.3p ps=14.7u
M1001 gnd A a_7_14# gnd nfet w=4.5u l=0.6u
+  ad=7.65p pd=8.7u as=9.45p ps=13.2u
M1002 vdd a_7_14# Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1003 vdd A a_7_14# vdd pfet w=9u l=0.6u
+  ad=15.3p pd=14.7u as=18.9p ps=22.2u
M1004 Y a_7_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.65p ps=8.7u
M1005 gnd a_7_14# Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
.ends

.subckt INVX4 A Y vdd gnd
M1000 Y A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1001 Y A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1002 gnd A Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1003 vdd A Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
.ends

.subckt OAI21X1 A B C Y vdd gnd
M1000 Y C a_7_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1001 a_30_146# A vdd vdd pfet w=12u l=0.6u
+  ad=3.6p pd=12.6u as=25.2p ps=28.2u
M1002 vdd C Y vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=14.4p ps=14.7u
M1003 gnd A a_7_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1004 Y B a_30_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.7u as=3.6p ps=12.6u
M1005 a_7_14# B gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
.ends

.subckt TBUFX2 A EN Y vdd gnd
M1000 vdd A a_44_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1001 Y a_22_14# a_44_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1002 a_22_14# EN vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=25.2p ps=28.2u
M1003 gnd A a_44_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1004 a_44_14# A gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 a_44_166# A vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1006 a_44_166# a_22_14# Y vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1007 Y EN a_44_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1008 a_22_14# EN gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
M1009 a_44_14# EN Y gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
.ends

.subckt DFFNEGX1 D CLK Q vdd gnd
M1000 a_163_14# a_7_14# a_153_14# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=1.35p ps=3.9u
M1001 a_77_186# CLK a_57_14# vdd pfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=7.2p ps=8.4u
M1002 a_77_14# a_7_14# a_57_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=3.6p ps=5.4u
M1003 vdd a_83_10# a_77_186# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=3.6p ps=7.2u
M1004 vdd CLK a_7_14# vdd pfet w=12u l=0.6u
+  ad=12.15p pd=14.4u as=25.2p ps=28.2u
M1005 Q a_163_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=11.025p ps=14.4u
M1006 a_83_10# a_57_14# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=4.05p ps=5.7u
M1007 gnd CLK a_7_14# gnd nfet w=6u l=0.6u
+  ad=6.075p pd=8.4u as=12.6p ps=16.2u
M1008 gnd a_83_10# a_77_14# gnd nfet w=3u l=0.6u
+  ad=4.05p pd=5.7u as=1.35p ps=3.9u
M1009 vdd Q a_183_206# vdd pfet w=3u l=0.6u
+  ad=11.025p pd=14.4u as=1.35p ps=3.9u
M1010 a_154_186# a_83_10# vdd vdd pfet w=6u l=0.6u
+  ad=2.25p pd=6.75u as=12.6p ps=16.2u
M1011 a_183_14# CLK a_163_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=3.6p ps=5.4u
M1012 a_45_186# D vdd vdd pfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=12.15p ps=14.4u
M1013 a_83_10# a_57_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1014 a_57_14# a_7_14# a_45_186# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=3.6p ps=7.2u
M1015 gnd Q a_183_14# gnd nfet w=3u l=0.6u
+  ad=6.075p pd=8.4u as=1.35p ps=3.9u
M1016 a_183_206# a_7_14# a_163_14# vdd pfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=5.85p ps=8.4u
M1017 a_45_14# D gnd gnd nfet w=3u l=0.6u
+  ad=1.8p pd=4.2u as=6.075p ps=8.4u
M1018 a_57_14# CLK a_45_14# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=1.8p ps=4.2u
M1019 a_153_14# a_83_10# gnd gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=6.3p ps=10.2u
M1020 Q a_163_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=6.075p ps=8.4u
M1021 a_163_14# CLK a_154_186# vdd pfet w=6u l=0.6u
+  ad=5.85p pd=8.4u as=2.25p ps=6.75u
.ends

.subckt AOI21X1 A B C Y vdd gnd
M1000 vdd A a_7_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1001 Y C a_7_146# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1002 a_28_14# A gnd gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1003 Y B a_28_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.7u as=1.8p ps=6.6u
M1004 a_7_146# B vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1005 gnd C Y gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=7.2p ps=8.7u
.ends

.subckt BUFX2 A Y vdd gnd
M1000 Y a_7_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.7u
M1001 gnd A a_7_14# gnd nfet w=3u l=0.6u
+  ad=7.2p pd=8.7u as=6.3p ps=10.2u
M1002 Y a_7_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.7u
M1003 vdd A a_7_14# vdd pfet w=6u l=0.6u
+  ad=14.4p pd=14.7u as=12.6p ps=16.2u
.ends

.subckt INVX2 A Y vdd gnd
M1000 Y A vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=25.2p ps=28.2u
M1001 Y A gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
.ends

.subckt FAX1 A B C YS YC vdd gnd
M1000 a_64_14# C a_6_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1001 YS a_174_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=14.13p ps=16.8u
M1002 a_206_14# B a_196_14# gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=2.7p ps=6.9u
M1003 gnd a_64_14# YC gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1004 gnd A a_206_14# gnd nfet w=6u l=0.6u
+  ad=5.85p pd=8.4u as=2.7p ps=6.9u
M1005 vdd A a_206_150# vdd pfet w=14.4u l=0.6u
+  ad=14.13p pd=16.8u as=6.48p ps=15.3u
M1006 gnd A a_6_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1007 a_114_14# C gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1008 a_64_14# C a_6_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1009 vdd A a_6_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1010 a_84_14# B a_64_14# gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1011 a_174_14# a_64_14# a_114_166# vdd pfet w=10.8u l=0.6u
+  ad=17.82p pd=17.1u as=12.96p ps=13.2u
M1012 vdd B a_114_166# vdd pfet w=10.8u l=0.6u
+  ad=12.96p pd=13.2u as=13.86p ps=14.4u
M1013 a_196_150# C a_174_14# vdd pfet w=14.4u l=0.6u
+  ad=6.48p pd=15.3u as=17.82p ps=17.1u
M1014 a_206_150# B a_196_150# vdd pfet w=14.4u l=0.6u
+  ad=6.48p pd=15.3u as=6.48p ps=15.3u
M1015 gnd A a_84_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1016 vdd A a_84_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
M1017 a_114_14# A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1018 YS a_174_14# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=5.85p ps=8.4u
M1019 a_174_14# a_64_14# a_114_14# gnd nfet w=6u l=0.6u
+  ad=8.1p pd=8.7u as=7.2p ps=8.4u
M1020 a_6_14# B gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1021 YC a_64_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
M1022 a_84_166# B a_64_14# vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.4p ps=14.4u
M1023 a_6_166# B vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1024 a_114_166# A vdd vdd pfet w=12u l=0.6u
+  ad=13.86p pd=14.4u as=14.4p ps=14.4u
M1025 a_114_166# C vdd vdd pfet w=10.8u l=0.6u
+  ad=12.96p pd=13.2u as=12.96p ps=13.2u
M1026 gnd B a_114_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1027 a_196_14# C a_174_14# gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=8.1p ps=8.7u
.ends

.subckt NOR2X1 A B Y vdd gnd
M1000 a_25_146# A vdd vdd pfet w=12u l=0.6u
+  ad=3.6p pd=12.6u as=25.2p ps=28.2u
M1001 Y A gnd gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1002 Y B a_25_146# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=3.6p ps=12.6u
M1003 gnd B Y gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
.ends

.subckt AND2X1 A B Y vdd gnd
M1000 gnd B a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.7u as=1.8p ps=6.6u
M1001 a_25_14# A a_7_14# gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1002 vdd B a_7_14# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1003 Y a_7_14# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=7.2p ps=8.7u
M1004 Y a_7_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 a_7_14# A vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
.ends

.subckt DFFPOSX1 D CLK Q vdd gnd
M1000 vdd Q a_189_206# vdd pfet w=3u l=0.6u
+  ad=10.125p pd=14.7u as=0.9p ps=3.6u
M1001 a_83_186# a_11_14# a_59_14# vdd pfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=7.2p ps=8.4u
M1002 a_87_10# a_59_14# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=4.05p ps=5.7u
M1003 gnd CLK a_11_14# gnd nfet w=6u l=0.6u
+  ad=5.85p pd=8.4u as=12.6p ps=16.2u
M1004 gnd a_87_10# a_81_14# gnd nfet w=3u l=0.6u
+  ad=4.05p pd=5.7u as=1.35p ps=3.9u
M1005 a_159_14# a_87_10# gnd gnd nfet w=3u l=0.6u
+  ad=0.9p pd=3.6u as=6.3p ps=10.2u
M1006 a_49_186# D vdd vdd pfet w=6u l=0.6u
+  ad=4.5p pd=7.5u as=11.25p ps=14.4u
M1007 vdd a_87_10# a_83_186# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=3.6p ps=7.2u
M1008 Q a_167_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=6.975p ps=8.7u
M1009 Q a_167_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=10.125p ps=14.7u
M1010 a_167_14# CLK a_159_14# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=0.9p ps=3.6u
M1011 a_49_14# D gnd gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=5.85p ps=8.4u
M1012 a_87_10# a_59_14# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1013 a_59_14# CLK a_49_186# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=4.5p ps=7.5u
M1014 a_161_186# a_87_10# vdd vdd pfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1015 a_189_206# CLK a_167_14# vdd pfet w=3u l=0.6u
+  ad=0.9p pd=3.6u as=6.075p ps=8.4u
M1016 a_59_14# a_11_14# a_49_14# gnd nfet w=3u l=0.6u
+  ad=4.05p pd=5.7u as=1.35p ps=3.9u
M1017 a_187_14# a_11_14# a_167_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=3.6p ps=5.4u
M1018 vdd CLK a_11_14# vdd pfet w=12u l=0.6u
+  ad=11.25p pd=14.4u as=25.2p ps=28.2u
M1019 gnd Q a_187_14# gnd nfet w=3u l=0.6u
+  ad=6.975p pd=8.7u as=1.35p ps=3.9u
M1020 a_167_14# a_11_14# a_161_186# vdd pfet w=6u l=0.6u
+  ad=6.075p pd=8.4u as=1.8p ps=6.6u
M1021 a_81_14# CLK a_59_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=4.05p ps=5.7u
.ends

.subckt NAND2X1 A B Y vdd gnd
M1000 a_27_14# A gnd gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=12.6p ps=16.2u
M1001 Y B a_27_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=2.7p ps=6.9u
M1002 vdd B Y vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1003 Y A vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
.ends

.subckt OR2X1 A B Y vdd gnd
M1000 Y a_7_146# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1001 a_25_146# A a_7_146# vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=25.2p ps=28.2u
M1002 a_7_146# A gnd gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1003 Y a_7_146# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=14.4p ps=14.7u
M1004 gnd B a_7_146# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=3.6p ps=5.4u
M1005 vdd B a_25_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.7u as=5.4p ps=12.9u
.ends

.subckt CLKBUF2 A Y vdd gnd
M1000 a_145_14# a_105_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1001 a_65_14# a_25_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1002 a_105_14# a_65_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1003 a_145_14# a_105_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1004 gnd a_145_14# a_185_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1005 a_25_14# A vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1006 a_65_14# a_25_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1007 Y a_185_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1008 a_25_14# A gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1009 gnd a_25_14# a_65_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1010 a_105_14# a_65_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1011 gnd a_105_14# a_145_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1012 vdd a_65_14# a_105_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1013 vdd a_105_14# a_145_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1014 Y a_185_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1015 vdd a_25_14# a_65_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1016 gnd A a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1017 vdd A a_25_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1018 vdd a_185_14# Y vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1019 vdd a_145_14# a_185_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
M1020 gnd a_65_14# a_105_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1021 a_185_14# a_145_14# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1022 gnd a_185_14# Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1023 a_185_14# a_145_14# vdd vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=14.4p ps=14.4u
.ends

.subckt LATCH D CLK Q vdd gnd
M1000 a_48_206# D vdd vdd pfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=14.4p ps=14.7u
M1001 a_86_226# CLK a_58_14# vdd pfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=9.225p ps=9.6u
M1002 gnd CLK a_8_14# gnd nfet w=6u l=0.6u
+  ad=6.3p pd=8.4u as=12.6p ps=16.2u
M1003 a_86_14# a_8_14# a_58_14# gnd nfet w=3u l=0.6u
+  ad=1.35p pd=3.9u as=5.4p ps=6.6u
M1004 Q a_58_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.7u
M1005 gnd Q a_86_14# gnd nfet w=3u l=0.6u
+  ad=7.2p pd=8.7u as=1.35p ps=3.9u
M1006 a_46_14# D gnd gnd nfet w=3u l=0.6u
+  ad=1.8p pd=4.2u as=6.3p ps=8.4u
M1007 Q a_58_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=13.5p ps=14.7u
M1008 a_58_14# CLK a_46_14# gnd nfet w=3u l=0.6u
+  ad=5.4p pd=6.6u as=1.8p ps=4.2u
M1009 vdd CLK a_8_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.7u as=25.2p ps=28.2u
M1010 a_58_14# a_8_14# a_48_206# vdd pfet w=6u l=0.6u
+  ad=9.225p pd=9.6u as=2.7p ps=6.9u
M1011 vdd Q a_86_226# vdd pfet w=3u l=0.6u
+  ad=13.5p pd=14.7u as=1.35p ps=3.9u
.ends

.subckt HAX1 A B YS YC vdd gnd
M1000 a_6_206# B a_24_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=1.8p ps=6.6u
M1001 vdd a_6_206# YC vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1002 gnd a_6_206# YC gnd nfet w=3u l=0.6u
+  ad=6.075p pd=8.4u as=6.21p ps=10.2u
M1003 a_24_14# A gnd gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=12.6p ps=16.2u
M1004 a_6_206# B vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 a_128_166# B a_108_206# vdd pfet w=12u l=0.6u
+  ad=3.6p pd=12.6u as=13.5p ps=14.4u
M1006 a_108_206# a_6_206# vdd vdd pfet w=6u l=0.6u
+  ad=13.5p pd=14.4u as=7.2p ps=8.4u
M1007 YS a_108_206# gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1008 a_96_14# a_6_206# gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=6.075p ps=8.4u
M1009 a_108_206# B a_96_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1010 vdd A a_128_166# vdd pfet w=12u l=0.6u
+  ad=11.25p pd=14.4u as=3.6p ps=12.6u
M1011 YS a_108_206# vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=11.25p ps=14.4u
M1012 a_96_14# A a_108_206# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1013 vdd A a_6_206# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
.ends

.subckt DFFSR R S D CLK Q vdd gnd
M1000 a_146_14# a_122_10# a_60_10# vdd pfet w=3u l=0.6u
+  ad=6.3p pd=8.4u as=3.6p ps=5.4u
M1001 a_64_14# a_60_10# gnd gnd nfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=9p ps=9u
M1002 vdd S a_301_14# vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1003 a_146_14# a_115_95# a_60_10# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=3.6p ps=5.4u
M1004 a_36_10# a_60_10# vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1005 a_391_14# a_334_14# gnd gnd nfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=9.45p ps=9.15u
M1006 a_8_14# R vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1007 a_36_10# S a_64_14# gnd nfet w=6u l=0.6u
+  ad=14.4p pd=16.8u as=3.6p ps=7.2u
M1008 gnd a_334_14# Q gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1009 a_281_14# a_122_10# a_36_10# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1010 a_28_14# R a_8_14# gnd nfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=14.4p ps=16.8u
M1011 a_301_14# S a_391_14# gnd nfet w=6u l=0.6u
+  ad=14.4p pd=16.8u as=3.6p ps=7.2u
M1012 gnd a_36_10# a_28_14# gnd nfet w=6u l=0.6u
+  ad=9p pd=9u as=3.6p ps=7.2u
M1013 gnd a_115_95# a_122_10# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1014 a_301_14# a_334_14# vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1015 vdd D a_146_14# vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=6.3p ps=8.4u
M1016 a_334_14# a_281_14# vdd vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1017 vdd a_115_95# a_122_10# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1018 a_301_14# a_122_10# a_281_14# vdd pfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1019 gnd D a_146_14# gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1020 a_60_10# a_115_95# a_8_14# vdd pfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1021 a_301_14# a_115_95# a_281_14# gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1022 vdd S a_36_10# vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1023 vdd a_36_10# a_8_14# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1024 a_115_95# CLK gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=3.6p ps=5.4u
M1025 a_60_10# a_122_10# a_8_14# gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1026 a_354_14# a_281_14# a_334_14# gnd nfet w=6u l=0.6u
+  ad=3.6p pd=7.2u as=14.4p ps=16.8u
M1027 vdd R a_334_14# vdd pfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1028 a_115_95# CLK vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1029 a_281_14# a_115_95# a_36_10# vdd pfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1030 gnd R a_354_14# gnd nfet w=6u l=0.6u
+  ad=9.45p pd=9.15u as=3.6p ps=7.2u
M1031 vdd a_334_14# Q vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
.ends

.subckt TBUFX1 A EN Y vdd gnd
M1000 a_68_166# a_26_14# Y vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=25.2p ps=28.2u
M1001 gnd A a_68_14# gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=2.7p ps=6.9u
M1002 a_26_14# EN gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1003 a_26_14# EN vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
M1004 vdd A a_68_166# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=5.4p ps=12.9u
M1005 a_68_14# EN Y gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=12.6p ps=16.2u
.ends

.subckt XNOR2X1 A B Y vdd gnd
M1000 a_74_166# A Y vdd pfet w=12u l=0.6u
+  ad=3.6p pd=12.6u as=14.4p ps=14.4u
M1001 a_29_58# B vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=16.2p ps=14.7u
M1002 gnd A a_6_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1003 vdd A a_6_14# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=25.2p ps=28.2u
M1004 Y A a_44_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=1.8p ps=6.6u
M1005 a_29_58# B gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=8.1p ps=8.7u
M1006 vdd B a_74_166# vdd pfet w=12u l=0.6u
+  ad=16.2p pd=14.7u as=3.6p ps=12.6u
M1007 Y a_6_14# a_44_166# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
M1008 a_44_14# a_29_58# gnd gnd nfet w=6u l=0.6u
+  ad=1.8p pd=6.6u as=7.2p ps=8.4u
M1009 a_72_14# a_6_14# Y gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=7.2p ps=8.4u
M1010 a_44_166# a_29_58# vdd vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=14.4p ps=14.4u
M1011 gnd B a_72_14# gnd nfet w=6u l=0.6u
+  ad=8.1p pd=8.7u as=2.7p ps=6.9u
.ends

.subckt AND2X2 A B Y vdd gnd
M1000 a_25_14# A a_7_14# gnd nfet w=6u l=0.6u
+  ad=2.7p pd=6.9u as=12.6p ps=16.2u
M1001 gnd B a_25_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=2.7p ps=6.9u
M1002 vdd B a_7_14# vdd pfet w=6u l=0.6u
+  ad=14.4p pd=14.7u as=8.1p ps=8.7u
M1003 Y a_7_14# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1004 Y a_7_14# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.7u
M1005 a_7_14# A vdd vdd pfet w=6u l=0.6u
+  ad=8.1p pd=8.7u as=12.6p ps=16.2u
.ends

.subckt INVX1 A Y vdd gnd
M1000 Y A gnd gnd nfet w=3u l=0.6u
+  ad=6.3p pd=10.2u as=6.3p ps=10.2u
M1001 Y A vdd vdd pfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=12.6p ps=16.2u
.ends

.subckt OAI22X1 A B C D Y vdd gnd
M1000 Y D a_7_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1001 a_25_146# A vdd vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=25.2p ps=28.2u
M1002 a_65_146# D Y vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=23.4p ps=15.9u
M1003 gnd A a_7_14# gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=12.6p ps=16.2u
M1004 a_7_14# C Y gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=7.2p ps=8.4u
M1005 a_7_14# B gnd gnd nfet w=6u l=0.6u
+  ad=7.2p pd=8.4u as=7.2p ps=8.4u
M1006 Y B a_25_146# vdd pfet w=12u l=0.6u
+  ad=23.4p pd=15.9u as=5.4p ps=12.9u
M1007 vdd C a_65_146# vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=5.4p ps=12.9u
.ends

.subckt OR2X2 A B Y vdd gnd
M1000 Y a_7_146# gnd gnd nfet w=6u l=0.6u
+  ad=12.6p pd=16.2u as=6.3p ps=8.4u
M1001 a_25_146# A a_7_146# vdd pfet w=12u l=0.6u
+  ad=5.4p pd=12.9u as=25.2p ps=28.2u
M1002 a_7_146# A gnd gnd nfet w=3u l=0.6u
+  ad=3.6p pd=5.4u as=6.3p ps=10.2u
M1003 Y a_7_146# vdd vdd pfet w=12u l=0.6u
+  ad=25.2p pd=28.2u as=14.4p ps=14.4u
M1004 gnd B a_7_146# gnd nfet w=3u l=0.6u
+  ad=6.3p pd=8.4u as=3.6p ps=5.4u
M1005 vdd B a_25_146# vdd pfet w=12u l=0.6u
+  ad=14.4p pd=14.4u as=5.4p ps=12.9u
.ends

.subckt khu_etri050_stdcells vdd gnd
XAOI22X1_0 AOI22X1_0/A AOI22X1_0/B AOI22X1_0/C AOI22X1_0/D AOI22X1_0/Y vdd gnd AOI22X1
XCLKBUF3_0 CLKBUF3_0/A CLKBUF3_0/Y vdd gnd CLKBUF3
XINVX8_0 INVX8_0/A INVX8_0/Y vdd gnd INVX8
XNOR3X1_0 NOR3X1_0/A NOR3X1_0/B NOR3X1_0/C NOR3X1_0/Y vdd gnd NOR3X1
XCLKBUF1_0 CLKBUF1_0/A CLKBUF1_0/Y vdd gnd CLKBUF1
XMUX2X1_0 MUX2X1_0/A MUX2X1_0/B MUX2X1_0/S MUX2X1_0/Y vdd gnd MUX2X1
XNAND3X1_0 NAND3X1_0/A NAND3X1_0/B NAND3X1_0/C NAND3X1_0/Y vdd gnd NAND3X1
XXOR2X1_0 XOR2X1_0/A XOR2X1_0/B XOR2X1_0/Y vdd gnd XOR2X1
XBUFX4_0 BUFX4_0/A BUFX4_0/Y vdd gnd BUFX4
XINVX4_0 INVX4_0/A INVX4_0/Y vdd gnd INVX4
XOAI21X1_0 OAI21X1_0/A OAI21X1_0/B OAI21X1_0/C OAI21X1_0/Y vdd gnd OAI21X1
XTBUFX2_0 TBUFX2_0/A TBUFX2_0/EN TBUFX2_0/Y vdd gnd TBUFX2
XDFFNEGX1_0 DFFNEGX1_0/D DFFNEGX1_0/CLK DFFNEGX1_0/Q vdd gnd DFFNEGX1
XAOI21X1_0 AOI21X1_0/A AOI21X1_0/B AOI21X1_0/C AOI21X1_0/Y vdd gnd AOI21X1
XBUFX2_0 BUFX2_0/A BUFX2_0/Y vdd gnd BUFX2
XINVX2_0 INVX2_0/A INVX2_0/Y vdd gnd INVX2
XFAX1_0 FAX1_0/A FAX1_0/B FAX1_0/C FAX1_0/YS FAX1_0/YC vdd gnd FAX1
XNOR2X1_0 NOR2X1_0/A NOR2X1_0/B NOR2X1_0/Y vdd gnd NOR2X1
XAND2X1_0 AND2X1_0/A AND2X1_0/B AND2X1_0/Y vdd gnd AND2X1
XDFFPOSX1_0 DFFPOSX1_0/D DFFPOSX1_0/CLK DFFPOSX1_0/Q vdd gnd DFFPOSX1
XNAND2X1_0 NAND2X1_0/A NAND2X1_0/B NAND2X1_0/Y vdd gnd NAND2X1
XOR2X1_0 OR2X1_0/A OR2X1_0/B OR2X1_0/Y vdd gnd OR2X1
XCLKBUF2_0 CLKBUF2_0/A CLKBUF2_0/Y vdd gnd CLKBUF2
XLATCH_0 LATCH_0/D LATCH_0/CLK LATCH_0/Q vdd gnd LATCH
XHAX1_0 HAX1_0/A HAX1_0/B HAX1_0/YS HAX1_0/YC vdd gnd HAX1
XDFFSR_0 DFFSR_0/R DFFSR_0/S DFFSR_0/D DFFSR_0/CLK DFFSR_0/Q vdd gnd DFFSR
XTBUFX1_0 TBUFX1_0/A TBUFX1_0/EN TBUFX1_0/Y vdd gnd TBUFX1
XXNOR2X1_0 XNOR2X1_0/A XNOR2X1_0/B XNOR2X1_0/Y vdd gnd XNOR2X1
XAND2X2_0 AND2X2_0/A AND2X2_0/B AND2X2_0/Y vdd gnd AND2X2
XINVX1_0 INVX1_0/A INVX1_0/Y vdd gnd INVX1
XOAI22X1_0 OAI22X1_0/A OAI22X1_0/B OAI22X1_0/C OAI22X1_0/D OAI22X1_0/Y vdd gnd OAI22X1
XOR2X2_0 OR2X2_0/A OR2X2_0/B OR2X2_0/Y vdd gnd OR2X2
.ends

** End of included library /usr/local/share/qflow/tech/etri050/etri050_stdcells.sp

.subckt invaders vdd gnd clk reset v_sync pixel p_tick
+ btn_left btn_right game_over game_complete game_new 

X_1677_ _763_ _692_ _691_ _796_ vdd gnd OAI21X1
X_1257_ _270__bF$buf2 vdd _267_ clk_bF$buf3 _u_alien.y_bullet_[5] vdd 
+ gnd
+ DFFSR
X_1486_ _u_alien.x_ball_[4] _253_ _252_ vdd gnd NOR2X1
X_1066_ _329_ _u_ball.y_ball_[2] game_init _555_ vdd gnd AOI21X1
X_1295_ _u_alien.y_pos_[5] _u_alien.y_pos_[4] _71_ vdd gnd NOR2X1
X_1389_ _u_alien.y_pos_[3] _164_ vdd gnd INVX1
X_1601_ btn_left _517_ _516_ vdd gnd NOR2X1
X_932_ _834_ _830_ _835_ vdd gnd NAND2X1
X_1198_ _u_ball.sign_x_ _317_ _316_ vdd gnd NAND2X1
XFILL77550x28950 gnd vdd FILL
X_1410_ _u_alien.rom_addr_[0] _185_ vdd gnd INVX1
X_970_ _u_alien.x_pos_[0] _285_ _654_ vdd gnd NOR2X1
X_1504_ _523_ _509_ _427_ _426_ vdd gnd NAND3X1
X_1733_ _744_ _732_ _737_ _731_ vdd gnd NAND3X1
X_1313_ _127_ _126_ alien_flip _89_ vdd gnd OAI21X1
X_1542_ _u_alien.x_pos_[0] _461_ vdd gnd INVX1
X_1122_ gnd _285_ _372_ vdd gnd NOR2X1
X_873_ _354__bF$buf1 vdd _363_ clk_bF$buf0 _u_ball.x2_ vdd 
+ gnd
+ DFFSR
X_929_ _820_ _830_ _838_ vdd gnd NAND2X1
X_1771_ _768_ _767_ vdd gnd INVX2
X_1351_ _u_alien.rom_addr_[1] _127_ vdd gnd INVX2
X_1407_ _184_ _183_ _182_ vdd gnd NAND2X1
X_1580_ _503_ _496_ _543_ vdd gnd NAND2X1
X_1160_ _u_ball.x_paddle_[4] _51_ vdd gnd INVX2
XFILL77850x36150 gnd vdd FILL
X_1636_ vdd _800__bF$buf0 _809_ clk_bF$buf1 _u_alien.x_pos_[4] vdd 
+ gnd
+ DFFSR
X_1216_ _u_ball.y_ball_[5] _333_ vdd gnd INVX1
X_967_ _654_ _657_ vdd gnd INVX1
X_1445_ _215_ _214_ vdd gnd INVX1
X_1025_ _u_alien.x_ball_[6] _589_ _594_ vdd gnd NOR2X1
X_1674_ _690_ _689_ _795_ vdd gnd NAND2X1
X_1254_ _270__bF$buf2 vdd _280_ clk_bF$buf3 _u_alien.y_bullet_[1] vdd 
+ gnd
+ DFFSR
X_1483_ _u_alien.regAliens_[4] _250_ vdd gnd INVX1
X_1063_ _u_ball.sign_y_ _u_ball.y_ball_[3] _557_ vdd gnd NOR2X1
X_1539_ _467_ _459_ _466_ _458_ vdd gnd AOI21X1
X_1119_ _u_alien.x_ball_[3] _368_ _374_ _371_ _375_ vdd 
+ gnd
+ OAI22X1
X_1292_ _78_ _72_ _69_ _68_ vdd gnd NAND3X1
X_1768_ _765_ _782_ _764_ vdd gnd NAND2X1
X_1348_ _u_alien.rom_addr_[0] _u_alien.rom_addr_[1] _u_alien.rom_addr_[2] _124_ vdd gnd OAI21X1
X_1577_ _495_ _500_ _493_ vdd gnd NAND2X1
X_1157_ _49_ _50_ _48_ vdd gnd NAND2X1
XFILL78150x36150 gnd vdd FILL
X_1386_ _166_ _162_ _161_ vdd gnd AND2X2
X_1195_ _314_ _319_ _313_ vdd gnd NOR2X1
X_1289_ _66_ pixel_alien vdd gnd INVX1
X_1501_ _538_ vdd _540_ clk_bF$buf4 _u_ball.x_paddle_[1] vdd 
+ gnd
+ DFFSR
X_1098_ _344_ _395_ _396_ vdd gnd NOR2X1
X_1730_ _730_ _729_ _857_ _728_ vdd gnd OAI21X1
X_1310_ _90_ _87_ _u_alien.x_pos_[3] _86_ vdd gnd AOI21X1
X_870_ _354__bF$buf3 vdd _350_ clk_bF$buf6 _u_alien.x_ball_[2] vdd 
+ gnd
+ DFFSR
X_926_ _820_ _660_ _825_ _841_ vdd gnd OAI21X1
X_1404_ _u_alien.y_bullet_[1] _u_alien.rom_addr_[1] _179_ vdd gnd NAND2X1
X_1633_ _800__bF$buf4 vdd _794_ clk_bF$buf1 _u_ctrl.cnt_alien_flip_[1] vdd 
+ gnd
+ DFFSR
X_1213_ _859_ _331_ _340_ _366_ vdd gnd AOI21X1
X_964_ _659_ _648_ _651_ _660_ vdd gnd NAND3X1
XFILL77850x57750 gnd vdd FILL
X_1442_ _u_alien.y_bullet_[2] _212_ vdd gnd INVX1
X_1022_ _u_alien.x_pos_[3] _312_ _330_ _u_alien.x_pos_[4] _597_ vdd 
+ gnd
+ OAI22X1
X_1671_ _688_ _687_ _703_ _686_ vdd gnd OAI21X1
X_1251_ vdd _270__bF$buf3 _264_ clk_bF$buf5 _u_alien.regAliens_[4] vdd 
+ gnd
+ DFFSR
X_1727_ _781_ _786_ _772_ _726_ vdd gnd OAI21X1
X_1307_ _84_ _136_ _83_ vdd gnd NAND2X1
X_1480_ _u_alien.regAliens_[1] _247_ vdd gnd INVX1
X_1060_ _556_ _559_ _560_ vdd gnd AND2X2
X_1536_ _u_alien.x_pos_[5] _455_ vdd gnd INVX1
X_1116_ _u_alien.x_ball_[4] _357_ _355_ _u_alien.x_ball_[5] _378_ vdd 
+ gnd
+ AOI22X1
X_867_ _354__bF$buf0 vdd _362_ clk_bF$buf4 _u_alien.x_ball_[5] vdd 
+ gnd
+ DFFSR
X_1765_ _u_ctrl.cnt_v_sync_[2] _762_ _761_ vdd gnd NOR2X1
X_1345_ _u_alien.rom_addr_[1] _u_alien.rom_addr_[2] _121_ vdd gnd NAND2X1
X_1574_ _501_ _507_ _498_ _491_ vdd gnd OAI21X1
X_1154_ _u_alien.x_ball_[5] _45_ vdd gnd INVX2
X_1383_ _170_ _195_ _158_ vdd gnd OR2X2
XFILL78150x57750 gnd vdd FILL
X_1439_ _u_alien.y_bullet_[2] _219_ _223_ _209_ vdd gnd OAI21X1
X_1019_ _u_alien.x_pos_[5] _600_ vdd gnd INVX1
X_1192_ _u_alien.x_ball_[3] _326_ _310_ vdd gnd NAND2X1
X_1668_ _736_ _769_ _684_ vdd gnd NOR2X1
X_1248_ _354__bF$buf3 vdd _347_ clk_bF$buf1 _856_ vdd 
+ gnd
+ DFFSR
X_999_ _603_ _608_ _623_ _624_ vdd gnd OAI21X1
X_1477_ lfsr4[0] _245_ _244_ vdd gnd NAND2X1
X_1057_ _307_ _386_ _562_ vdd gnd AND2X2
XFILL78450x7350 gnd vdd FILL
X_1286_ _u_alien.regAliens_[5] _u_alien.regAliens_[6] _63_ vdd gnd NOR2X1
X_1095_ _392_ _391_ _398_ _399_ vdd gnd AOI21X1
X_923_ pixel_alien _645_ _842_ _843_ vdd gnd NAND3X1
X_1189_ _u_alien.x_ball_[2] _u_alien.x_ball_[3] _307_ vdd gnd NOR2X1
X_1401_ _u_alien.y_pos_[5] _177_ _176_ vdd gnd NAND2X1
X_1630_ _800__bF$buf1 vdd _616_ clk_bF$buf7 _u_ctrl.State_[4] vdd 
+ gnd
+ DFFSR
X_1210_ game_init _329_ _328_ vdd gnd NOR2X1
X_961_ _610_ _613_ _662_ _663_ vdd gnd OAI21X1
X_1724_ _772_ _780_ _771_ _724_ vdd gnd OAI21X1
X_1304_ _235_ _u_alien.x_pos_[5] _134_ _80_ vdd gnd AOI21X1
X_1533_ _u_ball.x_paddle_[6] _453_ _452_ vdd gnd NOR2X1
X_1113_ _u_alien.x_ball_[6] _379_ _380_ _381_ vdd gnd OAI21X1
X_864_ _856_ game_over vdd gnd BUFX2
X_1762_ _765_ _760_ _759_ _758_ vdd gnd OAI21X1
X_1342_ _119_ _122_ _118_ vdd gnd NAND2X1
XFILL77850x43350 gnd vdd FILL
X_1571_ _523_ _491_ _489_ _488_ vdd gnd NAND3X1
X_1151_ _51_ _293_ _44_ _42_ vdd gnd OAI21X1
X_1627_ vdd _800__bF$buf1 _791_ clk_bF$buf6 _u_alien.rom_addr_[2] vdd 
+ gnd
+ DFFSR
X_1207_ _u_ball.x2_ _325_ vdd gnd INVX1
X_958_ _665_ _663_ _666_ vdd gnd AND2X2
X_1380_ _210_ _162_ _155_ vdd gnd NAND2X1
X_1436_ _212_ _220_ _207_ _278_ vdd gnd OAI21X1
X_1016_ _u_alien.y_pos_[3] _603_ vdd gnd INVX1
X_1665_ _u_alien.rom_addr_[1] _682_ vdd gnd INVX1
X_1245_ lfsr4[3] _547_ _546_ vdd gnd NAND2X1
X_996_ _u_ball.y_ball_[4] _626_ _605_ _627_ vdd gnd OAI21X1
X_1474_ _u_alien.y_bullet_[2] _u_alien.y_bullet_[3] _241_ vdd gnd NOR2X1
X_1054_ _u_alien.x_pos_[1] _323_ _565_ vdd gnd NAND2X1
X_1283_ reset _270_ vdd gnd INVX8
X_1759_ _772_ _780_ _755_ vdd gnd NOR2X1
X_1339_ _140_ _116_ _115_ vdd gnd NOR2X1
X_1092_ _u_ball.hit_paddle_ _328_ _385_ _401_ vdd gnd NAND3X1
X_1568_ _534_ _524_ _u_ball.x_paddle_[1] _486_ vdd gnd OAI21X1
X_1148_ _46_ _40_ _39_ vdd gnd OR2X2
X_899_ _u_alien.x_ball_[3] _344_ _6_ vdd gnd NAND2X1
XFILL78150x43350 gnd vdd FILL
X_1797_ _354__bF$buf2 vdd _346_ clk_bF$buf1 _u_ball.y_ball_[5] vdd 
+ gnd
+ DFFSR
X_1377_ _177_ _u_alien.y_pos_[5] _190_ _152_ vdd gnd AOI21X1
X_920_ _844_ _299_ _343_ _803_ vdd gnd AOI21X1
X_1186_ _u_ball.sign_x_ _330_ _304_ vdd gnd NAND2X1
X_1089_ _326_ _45_ _403_ vdd gnd NAND2X1
X_1721_ _771_ _727_ _748_ _722_ vdd gnd OAI21X1
X_1301_ _250_ _134_ _u_alien.x_pos_[5] _77_ vdd gnd AOI21X1
X_1530_ _520_ _454_ _450_ _449_ vdd gnd AOI21X1
X_1110_ _u_alien.x_ball_[6] _379_ _384_ vdd gnd NAND2X1
X_861_ _859_ v_sync vdd gnd BUFX2
XFILL78450x18150 gnd vdd FILL
X_917_ _u_ball.y_ball_[4] _410_ _846_ vdd gnd NOR2X1
XFILL77850x64950 gnd vdd FILL
X_1624_ _800__bF$buf1 vdd _806_ clk_bF$buf2 game_init vdd 
+ gnd
+ DFFSR
X_1204_ _u_ball.x2_ _326_ _323_ _322_ vdd gnd OAI21X1
X_955_ _u_ball.y_ball_[0] _612_ _669_ vdd gnd NAND2X1
X_1433_ _205_ _236_ _204_ vdd gnd NAND2X1
X_1013_ _337_ _335_ _604_ _606_ vdd gnd NAND3X1
X_1662_ _682_ _680_ _679_ vdd gnd NAND2X1
X_1242_ lfsr4[3] lfsr4[2] _544_ vdd gnd OR2X2
X_993_ _337_ _u_alien.rom_addr_[2] _630_ vdd gnd OR2X2
X_1718_ _769_ _739_ _720_ vdd gnd NOR2X1
X_1471_ _u_alien.regAliens_[2] _238_ vdd gnd INVX1
X_1051_ _u_alien.x_pos_[2] _568_ vdd gnd INVX1
X_1527_ _522_ _u_alien.x_pos_[5] _452_ _446_ vdd gnd OAI21X1
X_1107_ _386_ _317_ _312_ _387_ vdd gnd AOI21X1
X_1280_ _258_ _60_ _59_ vdd gnd NOR2X1
X_1756_ _856_ _0_ _u_ctrl.State_3_bF$buf2_ _752_ vdd gnd OAI21X1
X_1336_ alien_flip _124_ _125_ _112_ vdd gnd NAND3X1
X_1565_ _u_ball.x_paddle_[2] _484_ vdd gnd INVX1
X_1145_ _37_ _38_ _u_alien.x_ball_[5] _36_ vdd gnd OAI21X1
X_896_ _309_ _7_ _8_ _9_ vdd gnd OAI21X1
XFILL78150x64950 gnd vdd FILL
X_1794_ pixel_ball pixel_bullet _847_ vdd gnd NOR2X1
X_1374_ _179_ _149_ vdd gnd INVX1
X_1183_ _303_ _306_ _301_ vdd gnd NAND2X1
X_1659_ _u_alien.rom_addr_[2] _677_ vdd gnd INVX1
X_1239_ _425_ _539_ _552_ vdd gnd NAND2X1
X_1468_ _u_alien.regAliens_[3] _235_ vdd gnd INVX1
X_1048_ _570_ _567_ _571_ vdd gnd NAND2X1
X_1697_ _u_alien.y_pos_[3] _775_ _707_ vdd gnd NAND2X1
X_1277_ _58_ _259_ _247_ _268_ vdd gnd AOI21X1
X_1086_ _403_ _405_ _406_ vdd gnd NAND2X1
X_914_ _u_ball.sign_y_ _u_ball.y_ball_[3] _556_ _851_ vdd gnd OAI21X1
XFILL78450x72150 gnd vdd FILL
XFILL78450x39750 gnd vdd FILL
X_1621_ _354__bF$buf3 vdd _817_ clk_bF$buf6 hit_alien vdd 
+ gnd
+ DFFSR
X_1201_ _320_ _324_ _319_ vdd gnd AND2X2
X_952_ _669_ _802_ _804_ vdd gnd NOR2X1
X_1430_ _222_ _202_ _251_ _201_ vdd gnd MUX2X1
X_1010_ _u_alien.rom_addr_[1] _609_ vdd gnd INVX1
X_990_ _u_alien.y_pos_[3] _335_ _334_ _u_alien.y_pos_[4] _633_ vdd 
+ gnd
+ OAI22X1
X_1715_ _767_ _719_ _718_ _807_ vdd gnd OAI21X1
X_1524_ _448_ _447_ _444_ _443_ vdd gnd AOI21X1
X_1104_ _u_alien.x_ball_[6] _389_ _390_ vdd gnd NAND2X1
X_1753_ _750_ _751_ _u_ctrl.cnt_v_sync_[2] _749_ vdd gnd OAI21X1
X_1333_ _u_alien.x_pos_[0] alien_flip _109_ vdd gnd NAND2X1
X_1562_ _u_alien.x_pos_[1] _481_ vdd gnd INVX1
X_1142_ _u_ball.x_paddle_[6] _38_ _33_ vdd gnd NOR2X1
X_893_ _u_ball.sign_x_ _u_alien.x_ball_[6] _11_ vdd gnd NAND2X1
X_1618_ btn_right _533_ vdd gnd INVX1
X_949_ _668_ _804_ _818_ vdd gnd NOR2X1
X_1791_ _u_alien.x_pos_[0] _785_ vdd gnd INVX1
X_1371_ _148_ _150_ _147_ _146_ vdd gnd NAND3X1
X_1427_ lfsr4[2] _223_ _199_ _198_ vdd gnd NAND3X1
X_1007_ _u_alien.rom_addr_[0] _612_ vdd gnd INVX1
X_1180_ _u_ball.hit_paddle_ _299_ vdd gnd INVX1
X_1656_ _677_ _685_ _683_ _675_ _791_ vdd 
+ gnd
+ AOI22X1
X_1236_ en_lfsr4 _424_ _423_ _551_ vdd gnd OAI21X1
X_987_ _625_ _637_ vdd gnd INVX1
X_1465_ _233_ _236_ lfsr4[0] _232_ vdd gnd MUX2X1
X_1045_ _323_ _285_ _317_ _574_ vdd gnd NAND3X1
X_1694_ _768_ _720_ _705_ _777_ _799_ vdd 
+ gnd
+ AOI22X1
X_1274_ _56_ _57_ game_init _55_ vdd gnd AOI21X1
X_1083_ _407_ _408_ _328_ _409_ vdd gnd OAI21X1
X_1559_ _483_ _479_ _478_ vdd gnd NAND2X1
X_1139_ _u_alien.x_ball_[6] _30_ vdd gnd INVX1
X_1788_ _u_ctrl.State_3_bF$buf2_ _u_ctrl.State_[0] _782_ vdd gnd NOR2X1
X_1368_ _u_alien.x_bullet_[4] _143_ vdd gnd INVX1
X_911_ _850_ _852_ _853_ _854_ vdd gnd AOI21X1
X_1597_ _528_ _532_ _u_ball.x_paddle_[2] _512_ vdd gnd AOI21X1
X_1177_ _u_ball.x_paddle_[1] _296_ vdd gnd INVX1
X_1712_ _716_ _u_ctrl.State_[0] game_init _715_ vdd gnd AOI21X1
X_1521_ _449_ _443_ _441_ _440_ vdd gnd OAI21X1
X_1101_ _330_ _45_ _307_ _393_ vdd gnd NAND3X1
XFILL78450x25350 gnd vdd FILL
X_908_ _u_ball.x2_ _329_ _345_ _860_ vdd gnd OAI21X1
X_1750_ _770_ _747_ vdd gnd INVX1
X_1330_ _127_ _126_ _128_ _106_ vdd gnd OAI21X1
X_890_ _13_ _10_ _14_ vdd gnd NAND2X1
X_1615_ _u_ball.x_paddle_[5] _u_ball.x_paddle_[1] _530_ vdd gnd NOR2X1
X_946_ _656_ _657_ _653_ _821_ vdd gnd OAI21X1
X_1424_ _u_alien.y_bullet_[3] _196_ vdd gnd INVX1
X_1004_ _u_alien.rom_addr_[2] _337_ _615_ vdd gnd NAND2X1
X_1653_ _742_ _685_ _683_ _673_ _790_ vdd 
+ gnd
+ AOI22X1
X_1233_ en_lfsr4 _548_ _422_ _549_ vdd gnd OAI21X1
X_984_ _333_ _u_alien.y_pos_[5] _639_ _605_ _640_ vdd 
+ gnd
+ OAI22X1
X_1709_ _u_ctrl.State_[0] _713_ vdd gnd INVX1
X_1462_ _u_alien.y_bullet_[0] _229_ vdd gnd INVX1
X_1042_ _312_ _576_ _330_ _577_ vdd gnd OAI21X1
X_1518_ _u_alien.x_pos_[4] _520_ _437_ vdd gnd NAND2X1
X_1691_ _u_ctrl.cnt_alien_flip_[0] _702_ vdd gnd INVX1
X_1271_ _58_ _252_ _238_ _266_ vdd gnd AOI21X1
X_1747_ _756_ _782_ _745_ _u_ctrl.State_3_bF$buf3_ _812_ vdd 
+ gnd
+ AOI22X1
X_1327_ _140_ _116_ _u_alien.rom_addr_[1] _103_ vdd gnd OAI21X1
X_1080_ _u_ball.sign_y_ _410_ vdd gnd INVX2
X_1556_ _u_ball.x_paddle_[3] _476_ _475_ vdd gnd NOR2X1
X_1136_ _39_ _31_ _28_ _27_ vdd gnd AOI21X1
X_887_ _30_ _343_ _16_ _348_ vdd gnd OAI21X1
X_1785_ _u_alien.x_pos_[1] _u_alien.x_pos_[2] _u_alien.x_pos_[0] _780_ vdd gnd NAND3X1
X_1365_ _u_alien.x_pos_[1] _140_ vdd gnd INVX2
X_1594_ _510_ _511_ _509_ vdd gnd NAND2X1
X_1174_ _u_ball.x_paddle_[3] _294_ _293_ vdd gnd NAND2X1
X_1459_ _228_ _229_ _226_ vdd gnd OR2X2
X_1039_ _387_ _562_ _580_ vdd gnd NOR2X1
X_1688_ _u_ctrl.cnt_alien_flip_[0] _u_ctrl.cnt_alien_flip_[1] _704_ _699_ vdd gnd NAND3X1
X_1268_ lfsr4[0] _223_ _199_ _53_ vdd gnd NAND3X1
X_1497_ _354__bF$buf1 vdd _364_ clk_bF$buf0 _u_ball.sign_x_ vdd 
+ gnd
+ DFFSR
X_1077_ _411_ _412_ _413_ vdd gnd NAND2X1
XFILL78450x46950 gnd vdd FILL
X_905_ _855_ _321_ _328_ _2_ vdd gnd OAI21X1
X_1612_ _532_ _528_ _527_ vdd gnd NAND2X1
X_943_ _821_ _822_ _824_ vdd gnd OR2X2
X_1421_ _195_ _194_ _239_ _201_ _193_ vdd 
+ gnd
+ OAI22X1
X_1001_ _337_ _604_ _619_ _622_ vdd gnd AOI21X1
X_1650_ _741_ _671_ _683_ _740_ _789_ vdd 
+ gnd
+ AOI22X1
X_1230_ vdd _550_ _552_ clk_bF$buf3 lfsr4[0] vdd 
+ gnd
+ DFFSR
X_981_ _624_ _629_ _642_ _643_ vdd gnd AOI21X1
X_1706_ _716_ _714_ _712_ _618_ vdd gnd OAI21X1
X_1515_ _u_alien.y_pos_[4] _u_alien.y_pos_[3] _434_ vdd gnd AND2X2
X_1744_ _u_alien.y_pos_[3] _742_ vdd gnd INVX1
X_1324_ alien_flip _114_ _100_ vdd gnd NAND2X1
X_1553_ _482_ _477_ _473_ _472_ vdd gnd OAI21X1
X_1133_ _44_ _25_ _24_ vdd gnd NOR2X1
X_884_ _17_ _18_ game_init _347_ vdd gnd AOI21X1
X_1609_ _533_ _525_ _526_ _524_ vdd gnd AOI21X1
X_1782_ _781_ _782_ _778_ _u_ctrl.State_3_bF$buf3_ _814_ vdd 
+ gnd
+ AOI22X1
X_1362_ _u_alien.x_pos_[2] _138_ _137_ vdd gnd NOR2X1
X_1418_ _u_alien.y_bullet_[4] _191_ vdd gnd INVX1
X_1591_ _520_ _527_ _506_ vdd gnd NAND2X1
X_1171_ _291_ _293_ _290_ vdd gnd NAND2X1
X_1647_ vdd _800__bF$buf1 _634_ clk_bF$buf7 _u_ctrl.State_[0] vdd 
+ gnd
+ DFFSR
X_1227_ game_init _859_ _344_ vdd gnd NOR2X1
X_978_ _582_ _586_ _591_ _646_ vdd gnd AOI21X1
X_1456_ _u_alien.y_bullet_[1] _224_ vdd gnd INVX1
X_1036_ _575_ _577_ _583_ vdd gnd NAND2X1
X_1685_ _u_ctrl.cnt_v_sync_[0] _697_ vdd gnd INVX1
X_1265_ _133_ _200_ _52_ _262_ vdd gnd OAI21X1
X_1494_ _u_alien.x_ball_[5] _260_ _259_ vdd gnd NOR2X1
X_1074_ _338_ _343_ _415_ _360_ vdd gnd OAI21X1
XBUFX2_insert0 _800_ _800__bF$buf4 vdd gnd BUFX2
XBUFX2_insert1 _800_ _800__bF$buf3 vdd gnd BUFX2
XBUFX2_insert2 _800_ _800__bF$buf2 vdd gnd BUFX2
XBUFX2_insert3 _800_ _800__bF$buf1 vdd gnd BUFX2
XBUFX2_insert4 _800_ _800__bF$buf0 vdd gnd BUFX2
X_1779_ _776_ _775_ vdd gnd INVX1
X_1359_ _u_alien.x_pos_[4] _134_ vdd gnd INVX2
X_902_ _314_ _319_ _4_ vdd gnd NAND2X1
X_1588_ _535_ _523_ _504_ _503_ vdd gnd NAND3X1
X_1168_ _294_ _289_ _287_ vdd gnd OR2X2
X_1800_ _538_ vdd _536_ clk_bF$buf4 _u_ball.x_paddle_[3] vdd 
+ gnd
+ DFFSR
X_1397_ _u_alien.y_bullet_[4] _173_ _172_ vdd gnd NAND2X1
X_940_ _820_ _661_ _826_ _827_ vdd gnd OAI21X1
X_1703_ _710_ _753_ _767_ _620_ vdd gnd AOI21X1
XFILL78450x150 gnd vdd FILL
XFILL78450x32550 gnd vdd FILL
X_1512_ reset _538_ vdd gnd INVX2
X_1741_ _u_ctrl.State_3_bF$buf0_ _u_alien.y_pos_[5] _740_ _739_ vdd gnd NAND3X1
X_1321_ _u_alien.x_pos_[0] _128_ _98_ _97_ vdd gnd NAND3X1
X_1550_ _473_ _469_ vdd gnd INVX1
X_1130_ _24_ _22_ _355_ vdd gnd OR2X2
X_881_ _333_ _20_ _345_ _21_ vdd gnd OAI21X1
X_1606_ _522_ _526_ _521_ vdd gnd NAND2X1
X_937_ _829_ _648_ _651_ _830_ vdd gnd NAND3X1
XFILL77550x57750 gnd vdd FILL
X_1415_ _u_alien.y_bullet_[4] _195_ _223_ _188_ vdd gnd OAI21X1
X_1644_ vdd _800__bF$buf4 _799_ clk_bF$buf1 _u_alien.y_pos_[5] vdd 
+ gnd
+ DFFSR
X_1224_ _342_ _341_ vdd gnd INVX1
X_975_ _599_ _601_ _594_ _649_ vdd gnd AOI21X1
X_1453_ lfsr4[1] _222_ _231_ _221_ vdd gnd OAI21X1
X_1033_ _u_alien.x_pos_[4] _583_ _585_ _u_alien.x_pos_[5] _586_ vdd 
+ gnd
+ AOI22X1
X_1509_ _431_ _514_ _430_ vdd gnd OR2X2
X_1682_ _763_ _696_ _695_ _797_ vdd gnd OAI21X1
X_1262_ _270__bF$buf2 vdd _281_ clk_bF$buf3 _u_alien.y_bullet_[0] vdd 
+ gnd
+ DFFSR
X_1738_ _u_ctrl.State_3_bF$buf0_ _736_ vdd gnd INVX1
X_1318_ _139_ _128_ _114_ _94_ vdd gnd NAND3X1
X_1491_ _u_alien.x_ball_[6] _257_ _256_ vdd gnd NAND2X1
X_1071_ _u_ball.sign_y_ _u_ball.y_ball_[2] _418_ vdd gnd NAND2X1
X_1547_ _u_alien.rom_addr_[0] _466_ vdd gnd INVX1
X_1127_ _292_ _289_ _367_ vdd gnd NAND2X1
X_878_ _354__bF$buf2 vdd _358_ clk_bF$buf0 _u_ball.y_ball_[3] vdd 
+ gnd
+ DFFSR
X_1776_ _u_alien.x_pos_[3] _772_ vdd gnd INVX2
X_1356_ _135_ _132_ _131_ vdd gnd NOR2X1
X_1585_ _u_ball.x_paddle_[3] _532_ _511_ _510_ _500_ vdd 
+ gnd
+ AOI22X1
X_1165_ _u_alien.x_ball_[1] _u_ball.x_paddle_[1] _284_ vdd gnd NOR2X1
X_1394_ _170_ _174_ _169_ vdd gnd NOR2X1
X_1679_ _693_ _u_ctrl.State_[1] _u_ctrl.State_3_bF$buf0_ _692_ vdd gnd AOI21X1
X_1259_ vdd _270__bF$buf0 _268_ clk_bF$buf5 _u_alien.regAliens_[1] vdd 
+ gnd
+ DFFSR
X_1488_ _u_alien.regAliens_[6] _254_ vdd gnd INVX1
X_1068_ _418_ _419_ _417_ _421_ vdd gnd NAND3X1
X_1700_ _716_ _713_ _709_ _634_ vdd gnd OAI21X1
X_1297_ _u_alien.regAliens_[6] _u_alien.x_pos_[4] _74_ _73_ vdd gnd OAI21X1
X_1603_ _519_ _518_ vdd gnd INVX1
X_934_ _832_ _802_ _667_ _833_ vdd gnd OAI21X1
X_1412_ _191_ _220_ _186_ _275_ vdd gnd OAI21X1
X_1641_ vdd _800__bF$buf3 _810_ clk_bF$buf2 _u_alien.x_pos_[3] vdd 
+ gnd
+ DFFSR
X_1221_ _u_ball.y_ball_[1] _338_ vdd gnd INVX1
X_972_ _u_alien.x_pos_[1] _323_ _652_ vdd gnd NOR2X1
X_1450_ _u_alien.y_bullet_[0] _u_alien.y_bullet_[1] _223_ _218_ vdd gnd OAI21X1
X_1030_ _u_alien.x_pos_[6] _589_ vdd gnd INVX1
X_1506_ _484_ _523_ _428_ _537_ vdd gnd OAI21X1
X_1735_ _735_ _734_ _733_ vdd gnd NOR2X1
X_1315_ _96_ _99_ _92_ _91_ vdd gnd OAI21X1
X_1544_ _464_ _477_ _463_ vdd gnd OR2X2
X_1124_ _287_ _317_ _370_ vdd gnd AND2X2
X_875_ _354__bF$buf1 vdd _360_ clk_bF$buf0 _u_ball.y_ball_[1] vdd 
+ gnd
+ DFFSR
X_1773_ _u_alien.x_pos_[6] _u_alien.x_pos_[5] _770_ _769_ vdd gnd NAND3X1
X_1353_ _u_alien.x_pos_[3] _129_ vdd gnd INVX1
X_1409_ _u_alien.y_bullet_[0] _185_ _184_ vdd gnd NAND2X1
X_1582_ _498_ _507_ _501_ _499_ _497_ vdd 
+ gnd
+ AOI22X1
X_1162_ _273_ _286_ _288_ _272_ vdd gnd OAI21X1
X_1638_ _800__bF$buf4 vdd _796_ clk_bF$buf7 _u_ctrl.cnt_v_sync_[1] vdd 
+ gnd
+ DFFSR
X_1218_ _u_ball.y_ball_[3] _335_ vdd gnd INVX2
X_969_ _565_ _654_ _653_ _655_ vdd gnd NAND3X1
X_1391_ _168_ _167_ _166_ vdd gnd OR2X2
X_1447_ _224_ _220_ _216_ _280_ vdd gnd OAI21X1
X_1027_ _u_alien.x_pos_[6] _588_ _592_ vdd gnd NAND2X1
X_1676_ _767_ _711_ _u_ctrl.cnt_alien_flip_[0] _690_ vdd gnd OAI21X1
X_1256_ _270__bF$buf1 vdd _276_ clk_bF$buf3 _u_alien.y_bullet_[3] vdd 
+ gnd
+ DFFSR
X_1485_ _255_ _252_ _254_ _282_ vdd gnd AOI21X1
X_1065_ _420_ _554_ _555_ _359_ vdd gnd OAI21X1
X_1294_ _164_ _71_ _125_ _70_ vdd gnd NAND3X1
XFILL77850x18150 gnd vdd FILL
X_1579_ _520_ btn_left _506_ _495_ vdd gnd OAI21X1
X_1159_ _293_ _51_ _50_ vdd gnd OR2X2
X_1388_ _196_ _164_ _163_ vdd gnd NAND2X1
X_1600_ _516_ _515_ vdd gnd INVX1
X_931_ _820_ _829_ _645_ _836_ vdd gnd NAND3X1
X_1197_ _318_ _316_ _315_ vdd gnd NAND2X1
XBUFX2_insert20 _354_ _354__bF$buf0 vdd gnd BUFX2
XBUFX2_insert21 _u_ctrl.State_[3] _u_ctrl.State_3_bF$buf3_ vdd gnd BUFX2
XBUFX2_insert22 _u_ctrl.State_[3] _u_ctrl.State_3_bF$buf2_ vdd gnd BUFX2
XBUFX2_insert23 _u_ctrl.State_[3] _u_ctrl.State_3_bF$buf1_ vdd gnd BUFX2
XBUFX2_insert24 _u_ctrl.State_[3] _u_ctrl.State_3_bF$buf0_ vdd gnd BUFX2
X_1503_ _517_ _523_ _426_ _536_ vdd gnd OAI21X1
XFILL78150x18150 gnd vdd FILL
X_1732_ _765_ _761_ _769_ _739_ _730_ vdd 
+ gnd
+ OAI22X1
X_1312_ _127_ _u_alien.x_pos_[2] _139_ _88_ vdd gnd AOI21X1
X_1541_ _u_ball.x_paddle_[1] _481_ _461_ _460_ vdd gnd OAI21X1
X_1121_ _u_alien.x_ball_[1] _u_ball.x_paddle_[1] _372_ _373_ vdd gnd OAI21X1
X_872_ _354__bF$buf1 vdd _351_ clk_bF$buf0 _u_alien.x_ball_[1] vdd 
+ gnd
+ DFFSR
X_928_ _829_ _834_ _645_ _839_ vdd gnd NAND3X1
X_1770_ _767_ _769_ _u_ctrl.State_3_bF$buf2_ _766_ vdd gnd OAI21X1
X_1350_ _u_alien.rom_addr_[2] _126_ vdd gnd INVX1
X_1406_ _u_alien.y_bullet_[1] _u_alien.rom_addr_[1] _181_ vdd gnd NOR2X1
X_1635_ _800__bF$buf0 vdd _795_ clk_bF$buf1 _u_ctrl.cnt_alien_flip_[0] vdd 
+ gnd
+ DFFSR
X_1215_ _335_ _334_ _333_ _332_ vdd gnd NAND3X1
X_966_ _652_ _656_ _657_ _658_ vdd gnd OAI21X1
X_1444_ _256_ _214_ _u_alien.regAliens_[7] _213_ vdd gnd OAI21X1
X_1024_ _u_alien.x_ball_[2] _568_ _595_ vdd gnd NAND2X1
X_1673_ _u_ctrl.cnt_alien_flip_[0] _701_ _688_ vdd gnd NOR2X1
X_1253_ vdd _270__bF$buf3 _265_ clk_bF$buf5 _u_alien.regAliens_[3] vdd 
+ gnd
+ DFFSR
X_1729_ _728_ _731_ _811_ vdd gnd NAND2X1
X_1309_ _u_alien.x_pos_[6] _85_ vdd gnd INVX1
X_1482_ _250_ lfsr4[2] lfsr4[0] _249_ vdd gnd AOI21X1
X_1062_ _410_ _335_ _558_ vdd gnd NOR2X1
X_1538_ _u_alien.rom_addr_[1] _u_alien.rom_addr_[2] _457_ vdd gnd OR2X2
X_1118_ _370_ _375_ _369_ _376_ vdd gnd OAI21X1
X_869_ _354__bF$buf1 vdd _366_ clk_bF$buf0 _u_ball.sign_y_ vdd 
+ gnd
+ DFFSR
X_1291_ _91_ _86_ _68_ _67_ vdd gnd AOI21X1
X_1767_ _773_ _764_ _766_ _763_ vdd gnd NAND3X1
X_1347_ _128_ _124_ _125_ _123_ vdd gnd NAND3X1
XFILL77850x72150 gnd vdd FILL
XFILL77850x39750 gnd vdd FILL
X_1576_ _523_ _493_ _494_ _492_ vdd gnd NAND3X1
X_1156_ _u_alien.x_ball_[3] _290_ _48_ _u_alien.x_ball_[4] _47_ vdd 
+ gnd
+ AOI22X1
X_1385_ _178_ _161_ _169_ _160_ vdd gnd NAND3X1
X_1194_ _u_alien.x_ball_[3] _312_ vdd gnd INVX2
X_1479_ _u_alien.regAliens_[5] lfsr4[2] _246_ vdd gnd NAND2X1
X_1059_ _559_ _556_ _328_ _561_ vdd gnd OAI21X1
X_1288_ _u_alien.regAliens_[1] _u_alien.regAliens_[0] _65_ vdd gnd NOR2X1
X_1500_ _538_ vdd _542_ clk_bF$buf4 _u_ball.x_paddle_[4] vdd 
+ gnd
+ DFFSR
X_1097_ _297_ _385_ _396_ _397_ vdd gnd OAI21X1
XFILL78150x72150 gnd vdd FILL
XFILL78150x39750 gnd vdd FILL
X_925_ _841_ _840_ _827_ _837_ _842_ vdd 
+ gnd
+ OAI22X1
X_1403_ _180_ _179_ _182_ _178_ vdd gnd AOI21X1
X_1632_ vdd _800__bF$buf3 _808_ clk_bF$buf6 _u_alien.x_pos_[5] vdd 
+ gnd
+ DFFSR
X_1212_ _u_alien.x_ball_[4] _330_ vdd gnd INVX2
X_963_ _660_ _661_ vdd gnd INVX1
X_1441_ _u_alien.y_bullet_[0] _u_alien.y_bullet_[1] _u_alien.y_bullet_[2] _211_ vdd gnd NAND3X1
X_1021_ _330_ _u_alien.x_pos_[4] _45_ _u_alien.x_pos_[5] _598_ vdd 
+ gnd
+ AOI22X1
X_1670_ _701_ _703_ _686_ _794_ vdd gnd OAI21X1
X_1250_ vdd _270__bF$buf3 _279_ clk_bF$buf5 _u_alien.regAliens_[7] vdd 
+ gnd
+ DFFSR
X_1726_ _726_ _727_ _725_ vdd gnd NAND2X1
X_1306_ _u_alien.x_pos_[5] _238_ _82_ vdd gnd NAND2X1
X_1535_ _u_ball.x_paddle_[5] _455_ _454_ vdd gnd NAND2X1
X_1115_ _u_ball.x_paddle_[6] _24_ _379_ vdd gnd NOR2X1
X_866_ _354__bF$buf3 vdd _348_ clk_bF$buf6 _u_alien.x_ball_[6] vdd 
+ gnd
+ DFFSR
X_1764_ _761_ _760_ vdd gnd INVX1
X_1344_ _u_alien.rom_addr_[0] _121_ _128_ _120_ vdd gnd OAI21X1
X_1573_ _522_ _532_ _521_ _490_ vdd gnd OAI21X1
X_1153_ _u_ball.x_paddle_[5] _44_ vdd gnd INVX1
X_1629_ vdd _800__bF$buf3 _792_ clk_bF$buf2 _u_alien.rom_addr_[1] vdd 
+ gnd
+ DFFSR
X_1209_ _328_ _327_ vdd gnd INVX2
X_1382_ _159_ _158_ _157_ vdd gnd NAND2X1
X_1438_ _210_ _209_ _208_ vdd gnd NOR2X1
X_1018_ _600_ _u_alien.x_ball_[5] _u_alien.x_ball_[6] _589_ _601_ vdd 
+ gnd
+ AOI22X1
X_1191_ _311_ _310_ _309_ vdd gnd NAND2X1
X_1667_ _684_ _752_ _683_ vdd gnd AND2X2
X_1247_ lfsr4[2] _548_ vdd gnd INVX1
X_998_ _u_alien.y_pos_[5] _333_ _625_ vdd gnd NAND2X1
X_1476_ _251_ _244_ _248_ _243_ vdd gnd NAND3X1
X_1056_ _387_ _562_ _u_alien.x_pos_[3] _563_ vdd gnd OAI21X1
X_1285_ _75_ _235_ _63_ _62_ vdd gnd NAND3X1
X_1094_ _u_ball.sign_x_ _397_ _400_ vdd gnd NAND2X1
X_1799_ vdd _270__bF$buf0 _283_ clk_bF$buf5 _u_alien.regAliens_[5] vdd 
+ gnd
+ DFFSR
X_1379_ _219_ _166_ _155_ _154_ vdd gnd OAI21X1
X_922_ _843_ _339_ _343_ _817_ vdd gnd AOI21X1
X_1188_ _326_ _307_ _308_ _306_ vdd gnd OAI21X1
X_1400_ _177_ _u_alien.y_pos_[5] _175_ vdd gnd OR2X2
X_960_ _662_ _664_ vdd gnd INVX1
XFILL78150x25350 gnd vdd FILL
X_1723_ _724_ _747_ _723_ vdd gnd NAND2X1
X_1303_ _u_alien.regAliens_[1] _u_alien.x_pos_[5] _80_ _79_ vdd gnd OAI21X1
X_1532_ _452_ _451_ vdd gnd INVX1
X_1112_ _377_ _378_ _381_ _382_ vdd gnd AOI21X1
X_863_ _857_ p_tick vdd gnd BUFX2
XFILL78450x68550 gnd vdd FILL
X_919_ reset _354_ vdd gnd INVX8
X_1761_ _u_ctrl.State_3_bF$buf0_ _758_ _757_ vdd gnd NOR2X1
X_1341_ _u_alien.rom_addr_[0] _u_alien.rom_addr_[2] _117_ vdd gnd NAND2X1
X_1570_ _534_ _524_ _u_ball.x_paddle_[5] _487_ vdd gnd OAI21X1
X_1150_ _45_ _42_ _43_ _41_ vdd gnd NAND3X1
X_1626_ vdd _800__bF$buf0 _815_ clk_bF$buf1 _u_alien.x_pos_[1] vdd 
+ gnd
+ DFFSR
X_1206_ _u_ball.sign_x_ _u_alien.x_ball_[1] _325_ _324_ vdd gnd NAND3X1
X_957_ _u_ball.y_ball_[1] _609_ _613_ _667_ vdd gnd OAI21X1
X_1435_ _u_alien.x_bullet_[6] _206_ vdd gnd INVX1
X_1015_ _u_ball.y_ball_[0] _u_ball.y_ball_[1] _604_ vdd gnd NOR2X1
X_1664_ _u_alien.rom_addr_[1] _u_alien.rom_addr_[0] _681_ vdd gnd NAND2X1
X_1244_ _548_ _547_ _546_ _553_ vdd gnd OAI21X1
X_995_ _334_ _u_alien.y_pos_[4] _627_ _628_ vdd gnd OAI21X1
X_1473_ _u_alien.y_bullet_[4] _u_alien.y_bullet_[5] _240_ vdd gnd NOR2X1
X_1053_ _u_alien.x_pos_[1] _323_ _285_ _u_alien.x_pos_[0] _566_ vdd 
+ gnd
+ OAI22X1
X_1529_ _u_ball.x_paddle_[3] _476_ _472_ _448_ vdd gnd OAI21X1
X_1109_ _383_ _384_ _27_ _385_ vdd gnd NAND3X1
X_1282_ _u_alien.x_ball_[6] _61_ vdd gnd INVX1
XFILL77850x46950 gnd vdd FILL
X_1758_ _u_alien.x_pos_[4] _u_alien.x_pos_[5] _755_ _754_ vdd gnd NAND3X1
X_1338_ _u_alien.rom_addr_[0] _126_ _u_alien.rom_addr_[1] _114_ vdd gnd OAI21X1
X_1091_ _325_ _341_ _401_ _363_ vdd gnd OAI21X1
X_1567_ _514_ _523_ _485_ vdd gnd NAND2X1
X_1147_ _44_ _50_ _38_ vdd gnd NOR2X1
X_898_ _326_ _317_ _3_ _7_ vdd gnd OAI21X1
X_1796_ _847_ _848_ _858_ vdd gnd NAND2X1
X_1376_ _175_ _176_ _u_alien.y_bullet_[4] _195_ _151_ vdd 
+ gnd
+ AOI22X1
X_1185_ _305_ _304_ _303_ vdd gnd NAND2X1
X_1699_ reset _800_ vdd gnd INVX8
X_1279_ _59_ _61_ _84_ _269_ vdd gnd AOI21X1
X_1088_ _326_ _45_ _404_ vdd gnd NOR2X1
XFILL78150x46950 gnd vdd FILL
XFILL78150x7350 gnd vdd FILL
X_1720_ _754_ _722_ _721_ vdd gnd NAND2X1
X_1300_ _u_alien.regAliens_[5] _134_ _77_ _76_ vdd gnd OAI21X1
X_916_ _u_ball.sign_y_ _334_ _849_ vdd gnd NOR2X1
X_1623_ vdd _800__bF$buf2 _789_ clk_bF$buf7 _u_alien.y_pos_[4] vdd 
+ gnd
+ DFFSR
X_1203_ _322_ _324_ _321_ vdd gnd AND2X2
X_954_ _u_alien.rom_addr_[1] _338_ _801_ vdd gnd NOR2X1
X_1432_ lfsr4[0] _233_ _203_ vdd gnd NAND2X1
X_1012_ _606_ _607_ vdd gnd INVX1
X_1661_ _681_ _679_ _678_ vdd gnd NAND2X1
X_1241_ en_lfsr4 _545_ _544_ _539_ vdd gnd NAND3X1
X_992_ _610_ _613_ _630_ _631_ vdd gnd OAI21X1
X_1717_ _720_ _719_ vdd gnd INVX1
X_1470_ _u_alien.regAliens_[6] lfsr4[2] _237_ vdd gnd NAND2X1
X_1050_ _u_alien.x_ball_[1] _u_alien.x_ball_[0] _317_ _569_ vdd gnd OAI21X1
XFILL78450x54150 gnd vdd FILL
X_1526_ _520_ _u_alien.x_pos_[4] _450_ _445_ vdd gnd OAI21X1
X_1106_ _u_alien.x_ball_[4] _u_alien.x_ball_[5] _387_ _388_ vdd gnd NAND3X1
X_1755_ _773_ _752_ _753_ _751_ vdd gnd NAND3X1
X_1335_ _113_ _112_ _111_ vdd gnd NAND2X1
X_1564_ _u_alien.x_pos_[2] _484_ _483_ vdd gnd NAND2X1
X_1144_ _u_ball.x_paddle_[6] _35_ vdd gnd INVX1
X_895_ _344_ _9_ _6_ _349_ vdd gnd OAI21X1
X_1793_ _u_alien.x_pos_[1] _787_ vdd gnd INVX1
X_1373_ _181_ _149_ _u_alien.y_bullet_[0] _148_ vdd gnd OAI21X1
X_1429_ game_init _239_ _201_ _200_ vdd gnd NOR3X1
X_1009_ _u_ball.y_ball_[1] _609_ _610_ vdd gnd NOR2X1
X_1182_ _301_ _302_ _300_ vdd gnd NAND2X1
X_1658_ _682_ _680_ _677_ _676_ vdd gnd OAI21X1
X_1238_ lfsr4[1] _424_ vdd gnd INVX1
X_989_ _631_ _632_ _633_ _635_ vdd gnd AOI21X1
X_1467_ _u_alien.regAliens_[7] lfsr4[2] _234_ vdd gnd NAND2X1
X_1047_ _563_ _571_ _572_ vdd gnd NAND2X1
X_1696_ _741_ _707_ _u_ctrl.State_3_bF$buf1_ _706_ vdd gnd OAI21X1
X_1276_ _u_alien.y_bullet_[5] _190_ _57_ vdd gnd NAND2X1
X_1085_ _406_ _402_ _407_ vdd gnd NOR2X1
X_913_ _410_ _335_ _851_ _852_ vdd gnd OAI21X1
X_1599_ _u_ball.x_paddle_[1] _514_ vdd gnd INVX1
X_1179_ game_init _299_ _298_ vdd gnd NOR2X1
X_1620_ _u_ball.x_paddle_[6] _535_ vdd gnd INVX1
X_1200_ _u_alien.x_ball_[2] _326_ _318_ vdd gnd NAND2X1
X_951_ _668_ _804_ _666_ _805_ vdd gnd OAI21X1
XFILL78150x32550 gnd vdd FILL
X_1714_ game_new _u_ctrl.State_[0] _717_ vdd gnd NAND2X1
X_1523_ _u_alien.y_pos_[5] _442_ vdd gnd INVX1
X_1103_ _390_ _391_ vdd gnd INVX1
XFILL78450x75750 gnd vdd FILL
X_1752_ _763_ _757_ _749_ _813_ vdd gnd OAI21X1
X_1332_ _109_ _108_ vdd gnd INVX1
X_1561_ _u_alien.x_pos_[2] _480_ vdd gnd INVX1
X_1141_ _33_ _34_ _u_alien.x_ball_[6] _32_ vdd gnd OAI21X1
X_892_ _326_ _30_ _12_ vdd gnd NAND2X1
X_1617_ btn_left _532_ vdd gnd INVX2
X_948_ _818_ _816_ _819_ vdd gnd NAND2X1
X_1790_ _787_ _785_ _784_ vdd gnd NAND2X1
X_1370_ _151_ _146_ _152_ _145_ vdd gnd NOR3X1
X_1426_ _206_ _200_ _198_ _277_ vdd gnd OAI21X1
X_1006_ _609_ _u_ball.y_ball_[1] _u_ball.y_ball_[0] _612_ _613_ vdd 
+ gnd
+ AOI22X1
XFILL77850x7350 gnd vdd FILL
X_1655_ _677_ _681_ _742_ _674_ vdd gnd OAI21X1
X_1235_ reset _550_ vdd gnd INVX2
X_986_ _u_ball.y_ball_[4] _626_ _605_ _638_ vdd gnd NAND3X1
X_1464_ _232_ lfsr4[1] _239_ _231_ vdd gnd AOI21X1
X_1044_ _u_alien.x_ball_[4] _u_alien.x_ball_[3] _574_ _575_ vdd gnd NAND3X1
X_1693_ alien_flip _704_ vdd gnd INVX1
X_1273_ _55_ _220_ _54_ vdd gnd NAND2X1
X_1749_ _748_ _747_ _756_ _746_ vdd gnd OAI21X1
X_1329_ _106_ _107_ _105_ vdd gnd NAND2X1
X_1082_ _45_ _343_ _409_ _362_ vdd gnd OAI21X1
X_1558_ _u_ball.x_paddle_[1] _481_ _478_ _477_ vdd gnd AOI21X1
X_1138_ _u_ball.x_paddle_[6] _38_ _30_ _29_ vdd gnd OAI21X1
X_889_ _10_ _13_ _15_ vdd gnd OR2X2
X_1787_ _787_ _782_ _783_ _u_ctrl.State_3_bF$buf3_ _815_ vdd 
+ gnd
+ AOI22X1
X_1367_ _u_alien.x_pos_[4] _143_ _206_ _u_alien.x_pos_[6] _142_ vdd 
+ gnd
+ OAI22X1
X_910_ _344_ _854_ _845_ _353_ vdd gnd OAI21X1
X_1596_ _514_ _512_ _513_ _511_ vdd gnd OAI21X1
X_1176_ _u_ball.x_paddle_[2] _295_ vdd gnd INVX1
X_1499_ _538_ vdd _537_ clk_bF$buf4 _u_ball.x_paddle_[2] vdd 
+ gnd
+ DFFSR
X_1079_ _u_ball.y_ball_[1] _410_ _411_ vdd gnd NAND2X1
X_1711_ _u_ctrl.State_[4] _717_ _715_ _806_ vdd gnd AOI21X1
X_1520_ _u_ball.x_paddle_[2] _480_ _470_ _439_ vdd gnd OAI21X1
X_1100_ _u_alien.x_ball_[6] _393_ _392_ _394_ vdd gnd OAI21X1
XFILL78450x3750 gnd vdd FILL
X_907_ _285_ _860_ _855_ _327_ _352_ vdd 
+ gnd
+ OAI22X1
X_1614_ _u_ball.x_paddle_[2] _u_ball.x_paddle_[3] _529_ vdd gnd NOR2X1
X_945_ _564_ _595_ _822_ vdd gnd NAND2X1
X_1423_ _196_ _211_ _195_ vdd gnd NOR2X1
X_1003_ _615_ _611_ _614_ _617_ vdd gnd NAND3X1
X_1652_ _742_ _776_ _u_ctrl.State_3_bF$buf1_ _672_ vdd gnd OAI21X1
X_1232_ vdd _550_ _553_ clk_bF$buf3 lfsr4[3] vdd 
+ gnd
+ DFFSR
X_983_ _637_ _638_ _640_ _641_ vdd gnd AOI21X1
X_1708_ _714_ _713_ game_new _616_ vdd gnd AOI21X1
XFILL78450x61350 gnd vdd FILL
X_1461_ _859_ _239_ _228_ vdd gnd NAND2X1
X_1041_ _573_ _575_ _577_ _578_ vdd gnd NAND3X1
XFILL78450x28950 gnd vdd FILL
X_1517_ _520_ _u_alien.x_pos_[4] _454_ _436_ vdd gnd OAI21X1
X_1690_ _u_ctrl.cnt_alien_flip_[1] _701_ vdd gnd INVX1
X_1270_ _58_ _215_ _235_ _265_ vdd gnd AOI21X1
X_1746_ _u_ctrl.State_[0] _u_ctrl.State_[2] _744_ vdd gnd NOR2X1
X_1326_ _103_ _139_ _u_alien.x_pos_[2] _102_ vdd gnd AOI21X1
X_1555_ _u_alien.x_pos_[3] _517_ _474_ vdd gnd NOR2X1
X_1135_ _u_ball.x_paddle_[1] _u_ball.x_paddle_[2] _u_ball.x_paddle_[3] _26_ vdd gnd OAI21X1
X_886_ _u_ball.y_ball_[4] _u_ball.y_ball_[5] _605_ _17_ vdd gnd NAND3X1
X_1784_ _787_ _785_ _781_ _779_ vdd gnd OAI21X1
X_1364_ _u_alien.x_pos_[0] _139_ vdd gnd INVX2
X_1593_ _518_ _515_ _509_ _508_ vdd gnd NAND3X1
X_1173_ _u_ball.x_paddle_[3] _292_ vdd gnd INVX1
X_1649_ _u_ctrl.State_3_bF$buf1_ _u_ctrl.State_[0] _785_ _670_ vdd gnd OAI21X1
X_1229_ _354__bF$buf2 vdd _803_ clk_bF$buf0 _u_ball.hit_paddle_ vdd 
+ gnd
+ DFFSR
X_1458_ _226_ _227_ _225_ vdd gnd AND2X2
X_1038_ _579_ _580_ _581_ vdd gnd NAND2X1
X_1687_ _700_ _699_ _698_ vdd gnd AND2X2
X_1267_ _143_ _200_ _53_ _263_ vdd gnd OAI21X1
X_1496_ _u_alien.regAliens_[5] _261_ vdd gnd INVX1
X_1076_ _u_ball.y_ball_[0] _413_ _327_ _414_ vdd gnd AOI21X1
X_904_ _323_ _343_ _2_ _1_ _351_ vdd 
+ gnd
+ OAI22X1
X_1399_ _176_ _175_ _174_ vdd gnd NAND2X1
X_1611_ _527_ _526_ vdd gnd INVX1
X_942_ _823_ _824_ _825_ vdd gnd NAND2X1
XCLKBUF1_insert10 clk clk_bF$buf2 vdd gnd CLKBUF1
XCLKBUF1_insert11 clk clk_bF$buf1 vdd gnd CLKBUF1
XCLKBUF1_insert12 clk clk_bF$buf0 vdd gnd CLKBUF1
X_1420_ _223_ _193_ _220_ _192_ vdd gnd NAND3X1
X_1000_ _622_ _617_ _623_ vdd gnd NAND2X1
X_980_ _594_ _602_ _643_ _644_ vdd gnd OAI21X1
X_1705_ _u_ctrl.State_[1] _761_ _711_ vdd gnd NAND2X1
X_1514_ _450_ _435_ _434_ _433_ vdd gnd OAI21X1
X_1743_ _u_alien.y_pos_[4] _741_ vdd gnd INVX1
X_1323_ _123_ _100_ _u_alien.x_pos_[0] _99_ vdd gnd AOI21X1
X_1552_ _483_ _479_ _471_ vdd gnd AND2X2
X_1132_ _51_ _26_ _44_ _23_ vdd gnd OAI21X1
X_883_ _849_ _846_ _852_ _19_ vdd gnd MUX2X1
X_1608_ _534_ _524_ _523_ vdd gnd NOR2X1
X_939_ _u_alien.x_pos_[0] _285_ _828_ vdd gnd NAND2X1
X_1781_ _u_alien.y_pos_[5] _777_ vdd gnd INVX1
X_1361_ _u_alien.x_pos_[5] _136_ vdd gnd INVX1
X_1417_ _u_alien.y_bullet_[4] _195_ _190_ vdd gnd NAND2X1
X_1590_ _507_ _506_ _508_ _505_ vdd gnd NAND3X1
X_1170_ _u_ball.x_paddle_[1] _u_ball.x_paddle_[2] _289_ vdd gnd NOR2X1
X_1646_ _800__bF$buf2 vdd _621_ clk_bF$buf7 _u_ctrl.State_[1] vdd 
+ gnd
+ DFFSR
X_1226_ _344_ _343_ vdd gnd INVX4
X_977_ _592_ _647_ vdd gnd INVX1
X_1455_ game_init _223_ vdd gnd INVX2
X_1035_ _45_ _575_ _584_ vdd gnd NAND2X1
X_1684_ _697_ _u_ctrl.State_[1] _u_ctrl.State_3_bF$buf0_ _696_ vdd gnd AOI21X1
X_1264_ _270__bF$buf2 vdd _278_ clk_bF$buf3 _u_alien.y_bullet_[2] vdd 
+ gnd
+ DFFSR
X_1493_ _859_ hit_alien _258_ vdd gnd NAND2X1
X_1073_ _u_ball.y_ball_[0] _413_ _416_ vdd gnd NAND2X1
XFILL77550x72150 gnd vdd FILL
X_1549_ _483_ _470_ _469_ _468_ vdd gnd NAND3X1
X_1129_ _292_ _289_ _51_ _356_ vdd gnd OAI21X1
X_1778_ _u_alien.y_pos_[3] _u_alien.y_pos_[4] _775_ _774_ vdd gnd NAND3X1
X_1358_ _u_alien.x_bullet_[5] _133_ vdd gnd INVX1
X_901_ _4_ _3_ _5_ vdd gnd NAND2X1
X_1587_ _523_ _502_ vdd gnd INVX1
X_1167_ _u_alien.x_ball_[2] _287_ _286_ vdd gnd NOR2X1
X_1396_ _u_alien.y_pos_[4] _191_ _171_ vdd gnd NAND2X1
X_1702_ _767_ _737_ _621_ vdd gnd NOR2X1
X_1299_ _u_alien.regAliens_[7] _75_ vdd gnd INVX1
X_1511_ _512_ _432_ vdd gnd INVX1
X_1740_ _739_ _738_ vdd gnd INVX1
X_1320_ _140_ _107_ _97_ _96_ vdd gnd NAND3X1
X_880_ _333_ _20_ _21_ _346_ vdd gnd AOI21X1
X_1605_ _u_ball.x_paddle_[4] _520_ vdd gnd INVX2
X_936_ _u_ball.y_ball_[0] _612_ _666_ _831_ vdd gnd OAI21X1
X_1414_ _188_ _189_ _187_ vdd gnd NOR2X1
X_1643_ _800__bF$buf4 vdd _813_ clk_bF$buf7 _u_ctrl.cnt_v_sync_[2] vdd 
+ gnd
+ DFFSR
X_1223_ _u_ball.sign_y_ _341_ _345_ _340_ vdd gnd OAI21X1
X_974_ _624_ _629_ _650_ vdd gnd AND2X2
X_1452_ _223_ _228_ _221_ _220_ vdd gnd NAND3X1
X_1032_ _586_ _582_ _587_ vdd gnd AND2X2
X_1508_ _514_ _431_ _429_ vdd gnd NAND2X1
X_1681_ _u_ctrl.cnt_v_sync_[0] _u_ctrl.cnt_v_sync_[1] _694_ vdd gnd NAND2X1
X_1261_ vdd _270__bF$buf3 _269_ clk_bF$buf5 _u_alien.regAliens_[0] vdd 
+ gnd
+ DFFSR
X_1737_ _736_ _765_ _735_ vdd gnd NAND2X1
X_1317_ _121_ alien_flip _140_ _93_ vdd gnd AOI21X1
X_1490_ _256_ _255_ vdd gnd INVX1
X_1070_ _410_ _337_ _419_ vdd gnd NAND2X1
X_1546_ _u_ball.x_paddle_[1] _481_ _478_ _465_ vdd gnd OAI21X1
X_1126_ _26_ _367_ _368_ vdd gnd NAND2X1
X_877_ _354__bF$buf0 vdd _365_ clk_bF$buf4 _u_alien.x_ball_[4] vdd 
+ gnd
+ DFFSR
X_1775_ _u_alien.x_pos_[4] _771_ vdd gnd INVX1
X_1355_ _137_ _141_ _131_ _130_ vdd gnd NAND3X1
X_1584_ _500_ _518_ _499_ vdd gnd AND2X2
X_1164_ _285_ gnd _284_ _274_ vdd gnd AOI21X1
X_1393_ _u_alien.y_bullet_[2] _u_alien.rom_addr_[2] _168_ vdd gnd AND2X2
X_1449_ _218_ _219_ _217_ vdd gnd NOR2X1
X_1029_ _30_ _388_ _589_ _590_ vdd gnd OAI21X1
X_1678_ _750_ _751_ _u_ctrl.cnt_v_sync_[1] _691_ vdd gnd OAI21X1
X_1258_ _270__bF$buf0 vdd _262_ clk_bF$buf2 _u_alien.x_bullet_[5] vdd 
+ gnd
+ DFFSR
X_1487_ _u_alien.x_ball_[5] _253_ vdd gnd INVX1
X_1067_ _859_ _421_ _554_ vdd gnd NAND2X1
X_1296_ _u_alien.x_pos_[6] _73_ _76_ _72_ vdd gnd NAND3X1
X_1602_ _u_ball.x_paddle_[3] _517_ vdd gnd INVX1
X_933_ _666_ _833_ _667_ _831_ _834_ vdd 
+ gnd
+ OAI22X1
X_1199_ _u_alien.x_ball_[2] _317_ vdd gnd INVX2
X_1411_ _239_ en_lfsr4 vdd gnd INVX2
X_1640_ _800__bF$buf4 vdd _797_ clk_bF$buf7 _u_ctrl.cnt_v_sync_[0] vdd 
+ gnd
+ DFFSR
X_1220_ _u_ball.y_ball_[2] _337_ vdd gnd INVX2
X_971_ _652_ _653_ vdd gnd INVX1
X_1505_ _511_ _510_ _427_ vdd gnd OR2X2
XFILL78150x68550 gnd vdd FILL
X_1734_ _767_ _735_ _733_ _732_ vdd gnd AOI21X1
X_1314_ _u_alien.x_pos_[2] _112_ _139_ _90_ vdd gnd OAI21X1
X_1543_ _463_ _467_ _462_ vdd gnd OR2X2
X_1123_ _317_ _287_ _371_ vdd gnd NOR2X1
X_874_ _354__bF$buf3 vdd _352_ clk_bF$buf6 _u_alien.x_ball_[0] vdd 
+ gnd
+ DFFSR
X_1772_ _856_ _0_ _768_ vdd gnd NOR2X1
X_1352_ alien_flip _128_ vdd gnd INVX1
X_1408_ _u_alien.rom_addr_[0] _229_ _183_ vdd gnd NAND2X1
X_1581_ _502_ _497_ _u_ball.x_paddle_[6] _496_ vdd gnd OAI21X1
X_1161_ _u_alien.x_ball_[3] _290_ _272_ _271_ vdd gnd OAI21X1
X_1637_ _800__bF$buf2 vdd _620_ clk_bF$buf7 _u_ctrl.State_[2] vdd 
+ gnd
+ DFFSR
X_1217_ _u_ball.y_ball_[4] _334_ vdd gnd INVX1
X_968_ _565_ _656_ vdd gnd INVX1
X_1390_ _u_alien.y_bullet_[3] _u_alien.y_pos_[3] _165_ vdd gnd NAND2X1
X_1446_ _260_ _253_ _215_ vdd gnd NOR2X1
X_1026_ _591_ _587_ _592_ _593_ vdd gnd OAI21X1
X_1675_ _702_ _703_ _689_ vdd gnd NAND2X1
X_1255_ vdd _270__bF$buf0 _266_ clk_bF$buf5 _u_alien.regAliens_[2] vdd 
+ gnd
+ DFFSR
XFILL77550x46950 gnd vdd FILL
X_1484_ lfsr4[1] _251_ vdd gnd INVX1
X_1064_ _410_ _337_ _421_ _556_ vdd gnd OAI21X1
X_1293_ _137_ _129_ _70_ _69_ vdd gnd AOI21X1
X_1769_ _u_ctrl.State_[1] _765_ vdd gnd INVX1
X_1349_ _185_ _127_ _126_ _125_ vdd gnd NAND3X1
X_1578_ _500_ _495_ _494_ vdd gnd OR2X2
X_1158_ _51_ _293_ _49_ vdd gnd NAND2X1
X_1387_ _165_ _163_ _162_ vdd gnd NAND2X1
X_930_ _836_ _835_ _660_ _837_ vdd gnd AOI21X1
X_1196_ _315_ _314_ vdd gnd INVX1
XBUFX2_insert13 _270_ _270__bF$buf3 vdd gnd BUFX2
XBUFX2_insert14 _270_ _270__bF$buf2 vdd gnd BUFX2
XBUFX2_insert15 _270_ _270__bF$buf1 vdd gnd BUFX2
XBUFX2_insert16 _270_ _270__bF$buf0 vdd gnd BUFX2
XBUFX2_insert17 _354_ _354__bF$buf3 vdd gnd BUFX2
XBUFX2_insert18 _354_ _354__bF$buf2 vdd gnd BUFX2
XBUFX2_insert19 _354_ _354__bF$buf1 vdd gnd BUFX2
XFILL77850x54150 gnd vdd FILL
X_1502_ _538_ vdd _541_ clk_bF$buf5 _u_ball.x_paddle_[5] vdd 
+ gnd
+ DFFSR
X_1099_ _394_ _391_ _395_ vdd gnd NOR2X1
X_1731_ _732_ _729_ vdd gnd INVX1
X_1311_ _89_ _88_ _140_ _87_ vdd gnd AOI21X1
X_1540_ _460_ _470_ _459_ vdd gnd NOR2X1
X_1120_ _323_ _296_ _373_ _374_ vdd gnd OAI21X1
X_871_ vdd _354__bF$buf2 _359_ clk_bF$buf0 _u_ball.y_ball_[2] vdd 
+ gnd
+ DFFSR
X_927_ _645_ _659_ _839_ _838_ _840_ vdd 
+ gnd
+ AOI22X1
X_1405_ _181_ _180_ vdd gnd INVX1
X_1634_ vdd _800__bF$buf0 _812_ clk_bF$buf6 _u_alien.x_pos_[6] vdd 
+ gnd
+ DFFSR
X_1214_ _336_ _332_ _339_ _331_ vdd gnd OAI21X1
X_965_ _658_ _655_ _659_ vdd gnd NAND2X1
X_1443_ _213_ _279_ vdd gnd INVX1
X_1023_ _312_ _u_alien.x_pos_[3] _567_ _595_ _596_ vdd 
+ gnd
+ AOI22X1
XFILL78150x54150 gnd vdd FILL
X_1672_ _u_ctrl.cnt_alien_flip_[1] _702_ _687_ vdd gnd NOR2X1
X_1252_ vdd _270__bF$buf3 _282_ clk_bF$buf5 _u_alien.regAliens_[6] vdd 
+ gnd
+ DFFSR
X_1728_ _755_ _727_ vdd gnd INVX1
X_1308_ _u_alien.regAliens_[0] _84_ vdd gnd INVX1
X_1481_ lfsr4[2] _u_alien.regAliens_[0] _249_ _248_ vdd gnd OAI21X1
X_1061_ _557_ _558_ _559_ vdd gnd NOR2X1
X_1537_ _462_ _458_ _457_ _456_ vdd gnd AOI21X1
X_1117_ _u_alien.x_ball_[4] _357_ _376_ _377_ vdd gnd OAI21X1
X_868_ _354__bF$buf0 vdd _349_ clk_bF$buf4 _u_alien.x_ball_[3] vdd 
+ gnd
+ DFFSR
X_1290_ _129_ _101_ _67_ _66_ vdd gnd OAI21X1
X_1766_ _u_ctrl.cnt_v_sync_[0] _u_ctrl.cnt_v_sync_[1] _762_ vdd gnd OR2X2
X_1346_ _u_alien.x_pos_[0] _123_ _122_ vdd gnd NAND2X1
X_1575_ _520_ _523_ _492_ _542_ vdd gnd OAI21X1
X_1155_ _271_ _47_ _46_ vdd gnd AND2X2
X_1384_ _195_ _170_ _159_ vdd gnd NAND2X1
X_1193_ _u_ball.sign_x_ _312_ _311_ vdd gnd NAND2X1
X_1669_ _u_ctrl.State_3_bF$buf1_ _u_ctrl.State_[0] _766_ _685_ vdd gnd OAI21X1
X_1249_ _270__bF$buf1 vdd _263_ clk_bF$buf2 _u_alien.x_bullet_[4] vdd 
+ gnd
+ DFFSR
X_1478_ lfsr4[2] _247_ _246_ _245_ vdd gnd OAI21X1
X_1058_ _335_ _343_ _561_ _560_ _358_ vdd 
+ gnd
+ OAI22X1
X_1287_ _238_ _250_ _65_ _64_ vdd gnd NAND3X1
X_1096_ _297_ _27_ _398_ vdd gnd NOR2X1
X_924_ _842_ _645_ pixel_ball vdd gnd AND2X2
X_1402_ _u_alien.y_bullet_[5] _177_ vdd gnd INVX1
X_1631_ vdd _800__bF$buf3 _793_ clk_bF$buf2 _u_alien.rom_addr_[0] vdd 
+ gnd
+ DFFSR
X_1211_ _859_ _329_ vdd gnd INVX1
X_962_ _615_ _630_ _662_ vdd gnd NAND2X1
X_1440_ _211_ _210_ vdd gnd INVX1
X_1020_ _597_ _596_ _598_ _599_ vdd gnd OAI21X1
XFILL78150x75750 gnd vdd FILL
X_1725_ _772_ _782_ _725_ _u_ctrl.State_3_bF$buf3_ _810_ vdd 
+ gnd
+ AOI22X1
X_1305_ _134_ _82_ _83_ _81_ vdd gnd NAND3X1
X_1534_ _u_alien.x_pos_[6] _453_ vdd gnd INVX1
X_1114_ _u_ball.x_paddle_[6] _24_ _380_ vdd gnd NAND2X1
X_865_ _0_ game_complete vdd gnd BUFX2
X_1763_ _u_ctrl.cnt_v_sync_[2] _u_ctrl.State_[1] _762_ _759_ vdd gnd NAND3X1
X_1343_ _120_ _139_ _u_alien.x_pos_[1] _119_ vdd gnd AOI21X1
X_1572_ _498_ _490_ _489_ vdd gnd OR2X2
X_1152_ _50_ _44_ _43_ vdd gnd OR2X2
X_1628_ _800__bF$buf2 vdd _807_ clk_bF$buf7 _859_ vdd 
+ gnd
+ DFFSR
X_1208_ _u_ball.sign_x_ _326_ vdd gnd INVX2
X_959_ _611_ _614_ _664_ _665_ vdd gnd NAND3X1
X_1381_ _210_ _162_ _182_ _156_ vdd gnd OAI21X1
X_1437_ _208_ _220_ _207_ vdd gnd NAND2X1
X_1017_ _599_ _601_ _602_ vdd gnd AND2X2
X_1190_ _309_ _313_ _308_ vdd gnd NAND2X1
X_1666_ _683_ _685_ _u_alien.rom_addr_[0] _793_ vdd gnd MUX2X1
X_1246_ en_lfsr4 _547_ vdd gnd INVX1
X_997_ _u_alien.y_pos_[4] _626_ vdd gnd INVX1
X_1475_ _u_alien.y_bullet_[0] _u_alien.y_bullet_[1] _242_ vdd gnd NOR2X1
X_1055_ _u_alien.x_pos_[2] _317_ _564_ vdd gnd NAND2X1
X_1284_ _64_ _62_ _0_ vdd gnd NOR2X1
X_1093_ _397_ _399_ _400_ _364_ vdd gnd OAI21X1
X_1569_ _487_ _488_ _541_ vdd gnd NAND2X1
X_1149_ _u_alien.x_ball_[4] _48_ _41_ _40_ vdd gnd OAI21X1
X_1798_ vdd _550_ _549_ clk_bF$buf3 lfsr4[2] vdd 
+ gnd
+ DFFSR
X_1378_ _156_ _154_ _153_ vdd gnd NOR2X1
X_921_ pixel_paddle _645_ _842_ _844_ vdd gnd NAND3X1
X_1187_ _u_alien.x_ball_[4] _326_ _305_ vdd gnd NAND2X1
XFILL77850x28950 gnd vdd FILL
X_1722_ _771_ _782_ _723_ _u_ctrl.State_3_bF$buf3_ _809_ vdd 
+ gnd
+ AOI22X1
X_1302_ _85_ _81_ _79_ _78_ vdd gnd NAND3X1
X_1531_ _u_ball.x_paddle_[5] _455_ _451_ _450_ vdd gnd OAI21X1
X_1111_ _u_alien.x_ball_[5] _355_ _382_ _383_ vdd gnd OAI21X1
X_862_ _858_ pixel vdd gnd BUFX2
X_918_ _u_ball.y_ball_[4] _344_ _845_ vdd gnd NAND2X1
X_1760_ _u_alien.x_pos_[6] _756_ vdd gnd INVX1
X_1340_ _117_ alien_flip _u_alien.x_pos_[0] _116_ vdd gnd AOI21X1
X_1625_ vdd _800__bF$buf4 _790_ clk_bF$buf1 _u_alien.y_pos_[3] vdd 
+ gnd
+ DFFSR
X_1205_ _u_alien.x_ball_[1] _323_ vdd gnd INVX2
X_956_ _667_ _668_ vdd gnd INVX1
XFILL78150x61350 gnd vdd FILL
X_1434_ lfsr4[0] _205_ vdd gnd INVX1
X_1014_ _604_ _337_ _335_ _605_ vdd gnd AOI21X1
XFILL78150x28950 gnd vdd FILL
X_1663_ _u_alien.rom_addr_[0] _680_ vdd gnd INVX1
X_1243_ lfsr4[3] lfsr4[2] _545_ vdd gnd NAND2X1
X_994_ _608_ _603_ _625_ _628_ _629_ vdd 
+ gnd
+ AOI22X1
X_1719_ _748_ _782_ _721_ _u_ctrl.State_3_bF$buf3_ _808_ vdd 
+ gnd
+ AOI22X1
X_1472_ _242_ _241_ _240_ _239_ vdd gnd NAND3X1
X_1052_ _564_ _565_ _566_ _567_ vdd gnd NAND3X1
X_1528_ _u_ball.x_paddle_[4] _u_alien.x_pos_[4] _447_ vdd gnd OR2X2
X_1108_ _u_alien.x_ball_[1] _u_alien.x_ball_[0] _386_ vdd gnd NOR2X1
X_1281_ _260_ _253_ _60_ vdd gnd NAND2X1
X_1757_ _756_ _754_ _u_ctrl.State_3_bF$buf2_ _753_ vdd gnd OAI21X1
X_1337_ _128_ _114_ _113_ vdd gnd NAND2X1
X_1090_ _330_ _326_ _301_ _402_ vdd gnd OAI21X1
X_1566_ _486_ _485_ _540_ vdd gnd NAND2X1
X_1146_ _42_ _37_ vdd gnd INVX1
X_897_ _7_ _309_ game_init _8_ vdd gnd AOI21X1
X_1795_ pixel_paddle pixel_alien _848_ vdd gnd NOR2X1
X_1375_ _167_ _168_ _219_ _150_ vdd gnd OAI21X1
X_1184_ _306_ _303_ _302_ vdd gnd OR2X2
XFILL78450x36150 gnd vdd FILL
X_1469_ lfsr4[2] _238_ _237_ _236_ vdd gnd OAI21X1
X_1049_ _317_ _568_ _569_ _570_ vdd gnd OAI21X1
X_1698_ _782_ _708_ vdd gnd INVX1
X_1278_ _u_alien.x_ball_[6] _258_ _58_ vdd gnd NOR2X1
X_1087_ _404_ _405_ vdd gnd INVX1
X_915_ _846_ _849_ _850_ vdd gnd NOR2X1
X_1622_ _800__bF$buf1 vdd _618_ clk_bF$buf2 _u_ctrl.State_[3] vdd 
+ gnd
+ DFFSR
X_1202_ _u_ball.x2_ _u_alien.x_ball_[0] _321_ _320_ vdd gnd OAI21X1
X_953_ _610_ _801_ _802_ vdd gnd NOR2X1
X_1431_ _204_ _203_ _202_ vdd gnd NAND2X1
X_1011_ _605_ _607_ _608_ vdd gnd NOR2X1
X_1660_ _682_ _685_ _683_ _678_ _792_ vdd 
+ gnd
+ AOI22X1
X_1240_ lfsr4[0] _547_ _425_ vdd gnd NAND2X1
X_991_ _337_ _u_alien.rom_addr_[2] _335_ _u_alien.y_pos_[3] _632_ vdd 
+ gnd
+ AOI22X1
X_1716_ _733_ _751_ _859_ _718_ vdd gnd OAI21X1
X_1525_ _446_ _445_ _444_ vdd gnd NAND2X1
X_1105_ _388_ _389_ vdd gnd INVX1
X_1754_ _764_ _750_ vdd gnd INVX1
X_1334_ _u_alien.rom_addr_[0] _u_alien.rom_addr_[2] _110_ vdd gnd AND2X2
X_1563_ _483_ _482_ vdd gnd INVX1
X_1143_ _35_ _43_ _34_ vdd gnd NOR2X1
X_894_ _402_ _403_ _404_ _10_ vdd gnd AOI21X1
X_1619_ _859_ _534_ vdd gnd INVX1
X_1792_ _u_alien.x_pos_[1] _u_alien.x_pos_[0] _786_ vdd gnd NAND2X1
X_1372_ _229_ _179_ _180_ _147_ vdd gnd NAND3X1
X_1428_ _239_ _201_ _199_ vdd gnd NOR2X1
X_1008_ _610_ _611_ vdd gnd INVX1
X_1181_ _330_ _343_ _327_ _300_ _365_ vdd 
+ gnd
+ OAI22X1
X_1657_ _776_ _676_ _675_ vdd gnd NAND2X1
X_1237_ en_lfsr4 lfsr4[0] _423_ vdd gnd NAND2X1
X_988_ _u_ball.y_ball_[4] _626_ _625_ _636_ vdd gnd OAI21X1
XFILL78450x57750 gnd vdd FILL
X_1466_ lfsr4[2] _235_ _234_ _233_ vdd gnd OAI21X1
X_1046_ _u_alien.x_pos_[4] _573_ vdd gnd INVX1
X_1695_ _708_ _706_ _766_ _705_ vdd gnd NAND3X1
X_1275_ _177_ _189_ _56_ vdd gnd NAND2X1
X_1084_ _402_ _406_ _408_ vdd gnd AND2X2
X_1789_ _786_ _784_ _783_ vdd gnd NAND2X1
X_1369_ _157_ _153_ _145_ _144_ vdd gnd NAND3X1
X_912_ _850_ _852_ _345_ _853_ vdd gnd OAI21X1
X_1598_ _u_ball.x_paddle_[2] _532_ _513_ vdd gnd NAND2X1
X_1178_ _298_ _297_ vdd gnd INVX1
X_950_ _666_ _816_ vdd gnd INVX1
X_1713_ game_new _716_ vdd gnd INVX1
X_1522_ _453_ _u_ball.x_paddle_[6] _442_ _441_ vdd gnd AOI21X1
X_1102_ game_init _u_ball.hit_paddle_ _392_ vdd gnd NOR2X1
X_909_ _325_ _285_ _855_ vdd gnd NAND2X1
X_1751_ _u_alien.x_pos_[5] _748_ vdd gnd INVX1
X_1331_ _127_ _110_ _108_ _107_ vdd gnd OAI21X1
X_1560_ _u_ball.x_paddle_[2] _480_ _479_ vdd gnd NAND2X1
X_1140_ _32_ _36_ _31_ vdd gnd AND2X2
X_891_ _11_ _12_ _13_ vdd gnd NAND2X1
X_1616_ _u_ball.x_paddle_[6] _u_ball.x_paddle_[4] _531_ vdd gnd NOR2X1
X_947_ _805_ _819_ _820_ vdd gnd NAND2X1
X_1425_ _u_alien.y_bullet_[3] _228_ _230_ _197_ vdd gnd NAND3X1
X_1005_ _613_ _614_ vdd gnd INVX1
X_1654_ _674_ _707_ _673_ vdd gnd NAND2X1
X_1234_ en_lfsr4 lfsr4[1] _422_ vdd gnd NAND2X1
X_985_ _u_alien.y_pos_[4] _334_ _639_ vdd gnd NAND2X1
X_1463_ _231_ _243_ game_init _230_ vdd gnd AOI21X1
X_1043_ _u_alien.x_ball_[1] _u_alien.x_ball_[0] _u_alien.x_ball_[2] _576_ vdd gnd NOR3X1
X_1519_ _439_ _473_ _475_ _438_ vdd gnd AOI21X1
X_1692_ _767_ _711_ _703_ vdd gnd NOR2X1
X_1272_ _177_ _220_ _54_ _267_ vdd gnd OAI21X1
X_1748_ _769_ _746_ _745_ vdd gnd NAND2X1
X_1328_ _140_ _105_ _111_ _115_ _104_ vdd 
+ gnd
+ AOI22X1
X_1081_ _343_ _327_ _u_ball.y_ball_[0] _361_ vdd gnd MUX2X1
X_1557_ _u_alien.x_pos_[3] _476_ vdd gnd INVX1
X_1137_ _35_ _43_ _29_ _28_ vdd gnd OAI21X1
X_888_ _328_ _14_ _15_ _16_ vdd gnd NAND3X1
X_1786_ _u_alien.x_pos_[2] _781_ vdd gnd INVX1
X_1366_ _206_ _u_alien.x_pos_[6] _142_ _141_ vdd gnd AOI21X1
X_1595_ _527_ _517_ _516_ _510_ vdd gnd AOI21X1
X_1175_ _296_ _295_ _294_ vdd gnd NOR2X1
XFILL78450x43350 gnd vdd FILL
X_1689_ _702_ _701_ alien_flip _700_ vdd gnd OAI21X1
X_1269_ _59_ _u_alien.x_ball_[6] _250_ _264_ vdd gnd AOI21X1
X_1498_ _538_ vdd _543_ clk_bF$buf4 _u_ball.x_paddle_[6] vdd 
+ gnd
+ DFFSR
X_1078_ _u_ball.sign_y_ _338_ _412_ vdd gnd NAND2X1
X_1710_ _u_ctrl.State_[4] _714_ vdd gnd INVX1
X_906_ _320_ _1_ vdd gnd INVX1
X_1613_ _531_ _530_ _529_ _528_ vdd gnd NAND3X1
X_944_ _822_ _821_ _823_ vdd gnd NAND2X1
X_1422_ _u_alien.y_bullet_[3] _210_ _194_ vdd gnd NOR2X1
X_1002_ _u_alien.rom_addr_[2] _337_ _619_ vdd gnd NOR2X1
X_1651_ _708_ _672_ _766_ _671_ vdd gnd NAND3X1
X_1231_ vdd _550_ _551_ clk_bF$buf3 lfsr4[1] vdd 
+ gnd
+ DFFSR
X_982_ _635_ _636_ _641_ _642_ vdd gnd OAI21X1
X_1707_ _u_ctrl.State_[2] _768_ _712_ vdd gnd NAND2X1
X_1460_ _229_ _228_ _227_ vdd gnd NAND2X1
X_1040_ _u_alien.x_pos_[3] _579_ vdd gnd INVX1
X_1516_ _438_ _437_ _436_ _435_ vdd gnd AOI21X1
X_1745_ _769_ _743_ vdd gnd INVX1
X_1325_ _u_alien.x_pos_[2] _118_ _104_ _102_ _101_ vdd 
+ gnd
+ AOI22X1
X_1554_ _475_ _474_ _473_ vdd gnd NOR2X1
X_1134_ _26_ _51_ _25_ vdd gnd OR2X2
X_885_ pixel_bullet pixel_paddle _856_ _18_ vdd gnd AOI21X1
X_1783_ _780_ _779_ _778_ vdd gnd NAND2X1
X_1363_ _140_ _139_ _138_ vdd gnd NAND2X1
X_1419_ _197_ _192_ _276_ vdd gnd NAND2X1
X_1592_ _522_ _532_ _507_ vdd gnd NOR2X1
X_1172_ _296_ _295_ _292_ _291_ vdd gnd OAI21X1
X_1648_ _u_ctrl.State_3_bF$buf1_ _785_ _670_ _788_ vdd gnd OAI21X1
X_1228_ game_init _345_ vdd gnd INVX1
XFILL78450x64950 gnd vdd FILL
X_979_ _593_ _390_ _644_ _645_ vdd gnd AOI21X1
X_1457_ _225_ _230_ _281_ vdd gnd AND2X2
X_1037_ _578_ _581_ _572_ _582_ vdd gnd NAND3X1
X_1686_ _698_ _704_ _703_ _798_ vdd gnd MUX2X1
X_1266_ lfsr4[1] _223_ _199_ _52_ vdd gnd NAND3X1
X_1495_ _u_alien.x_ball_[4] _260_ vdd gnd INVX1
X_1075_ _u_ball.y_ball_[0] _413_ _414_ _415_ vdd gnd OAI21X1
X_903_ _313_ _3_ vdd gnd INVX1
X_1589_ _521_ _508_ _505_ _504_ vdd gnd OAI21X1
X_1169_ _289_ _294_ _u_alien.x_ball_[2] _288_ vdd gnd OAI21X1
X_1801_ vdd _800__bF$buf3 _788_ clk_bF$buf6 _u_alien.x_pos_[0] vdd 
+ gnd
+ DFFSR
X_1398_ _u_alien.y_pos_[4] _173_ vdd gnd INVX1
X_1610_ _u_ball.x_paddle_[6] _u_ball.x_paddle_[4] _u_ball.x_paddle_[5] _525_ vdd gnd NAND3X1
X_941_ _825_ _826_ vdd gnd INVX1
X_1704_ _773_ _711_ _710_ vdd gnd AND2X2
X_1513_ _440_ _433_ _456_ pixel_paddle vdd gnd NOR3X1
X_1742_ _742_ _741_ _776_ _740_ vdd gnd NOR3X1
X_1322_ _u_alien.rom_addr_[1] _u_alien.rom_addr_[2] _185_ _98_ vdd gnd NAND3X1
X_1551_ _514_ _u_alien.x_pos_[1] _471_ _470_ vdd gnd OAI21X1
X_1131_ _23_ _22_ vdd gnd INVX1
X_882_ _19_ _329_ _20_ vdd gnd OR2X2
X_1607_ _u_ball.x_paddle_[5] _522_ vdd gnd INVX1
X_938_ _828_ _657_ _829_ vdd gnd NAND2X1
X_1780_ _u_alien.rom_addr_[1] _u_alien.rom_addr_[0] _u_alien.rom_addr_[2] _776_ vdd gnd NAND3X1
X_1360_ _u_alien.x_bullet_[5] _136_ _u_alien.x_pos_[3] _135_ vdd gnd OAI21X1
X_1416_ _190_ _189_ vdd gnd INVX1
X_1645_ _800__bF$buf2 vdd _811_ clk_bF$buf7 _857_ vdd 
+ gnd
+ DFFSR
X_1225_ game_init _u_ball.hit_paddle_ _343_ _342_ vdd gnd OAI21X1
X_976_ _647_ _646_ _390_ _648_ vdd gnd OAI21X1
X_1454_ _244_ _248_ _222_ vdd gnd NAND2X1
X_1034_ _388_ _584_ _585_ vdd gnd NAND2X1
X_1683_ _750_ _751_ _u_ctrl.cnt_v_sync_[0] _695_ vdd gnd OAI21X1
X_1263_ _270__bF$buf1 vdd _275_ clk_bF$buf2 _u_alien.y_bullet_[4] vdd 
+ gnd
+ DFFSR
X_1739_ _u_ctrl.State_[1] _760_ _743_ _738_ _737_ vdd 
+ gnd
+ AOI22X1
X_1319_ _u_alien.x_pos_[2] _95_ vdd gnd INVX1
X_1492_ _258_ _257_ vdd gnd INVX1
X_1072_ _410_ _338_ _416_ _417_ vdd gnd OAI21X1
X_1548_ _472_ _468_ _467_ vdd gnd NAND2X1
X_1128_ _356_ _25_ _357_ vdd gnd NAND2X1
X_879_ _354__bF$buf0 vdd _361_ clk_bF$buf4 _u_ball.y_ball_[0] vdd 
+ gnd
+ DFFSR
X_1777_ _777_ _774_ _u_ctrl.State_3_bF$buf2_ _773_ vdd gnd OAI21X1
X_1357_ _u_alien.x_bullet_[4] _134_ _u_alien.x_pos_[5] _133_ _132_ vdd 
+ gnd
+ OAI22X1
X_900_ _317_ _343_ _327_ _5_ _350_ vdd 
+ gnd
+ OAI22X1
X_1586_ _521_ _501_ vdd gnd INVX1
X_1166_ _u_alien.x_ball_[0] _285_ vdd gnd INVX2
XCLKBUF1_insert5 clk clk_bF$buf7 vdd gnd CLKBUF1
XCLKBUF1_insert6 clk clk_bF$buf6 vdd gnd CLKBUF1
XCLKBUF1_insert7 clk clk_bF$buf5 vdd gnd CLKBUF1
XCLKBUF1_insert8 clk clk_bF$buf4 vdd gnd CLKBUF1
XCLKBUF1_insert9 clk clk_bF$buf3 vdd gnd CLKBUF1
X_1395_ _172_ _171_ _170_ vdd gnd NAND2X1
X_1489_ _255_ _259_ _261_ _283_ vdd gnd AOI21X1
X_1069_ _418_ _419_ _417_ _420_ vdd gnd AOI21X1
X_1701_ _u_ctrl.State_[2] _735_ _767_ _709_ vdd gnd OAI21X1
X_1298_ _75_ _u_alien.x_pos_[4] _136_ _74_ vdd gnd AOI21X1
X_1510_ _484_ btn_left _432_ _431_ vdd gnd OAI21X1
X_1604_ btn_left _520_ _519_ vdd gnd NOR2X1
X_935_ _u_ball.y_ball_[0] _612_ _832_ vdd gnd NOR2X1
X_1413_ _187_ _220_ _186_ vdd gnd NAND2X1
X_1642_ _800__bF$buf0 vdd _798_ clk_bF$buf1 alien_flip vdd 
+ gnd
+ DFFSR
X_1222_ hit_alien _339_ vdd gnd INVX1
X_973_ _642_ _649_ _650_ _651_ vdd gnd NOR3X1
X_1451_ _229_ _224_ _219_ vdd gnd NOR2X1
X_1031_ _388_ _30_ _588_ vdd gnd AND2X2
X_1507_ _523_ _429_ _430_ _428_ vdd gnd NAND3X1
X_1680_ _694_ _762_ _693_ vdd gnd NAND2X1
X_1260_ vdd _270__bF$buf1 _277_ clk_bF$buf2 _u_alien.x_bullet_[6] vdd 
+ gnd
+ DFFSR
X_1736_ _744_ _734_ vdd gnd INVX1
X_1316_ _94_ _93_ _95_ _92_ vdd gnd AOI21X1
X_1545_ _u_alien.x_pos_[0] _466_ _465_ _464_ vdd gnd OAI21X1
X_1125_ _u_alien.x_ball_[3] _368_ _369_ vdd gnd NAND2X1
X_876_ vdd _354__bF$buf2 _353_ clk_bF$buf0 _u_ball.y_ball_[4] vdd 
+ gnd
+ DFFSR
X_1774_ _772_ _771_ _780_ _770_ vdd gnd NOR3X1
X_1354_ _144_ _160_ _130_ pixel_bullet vdd gnd AOI21X1
X_1583_ _520_ _527_ _500_ _518_ _498_ vdd 
+ gnd
+ AOI22X1
X_1163_ _u_alien.x_ball_[1] _u_ball.x_paddle_[1] _274_ _273_ vdd gnd AOI21X1
X_1639_ vdd _800__bF$buf3 _814_ clk_bF$buf6 _u_alien.x_pos_[2] vdd 
+ gnd
+ DFFSR
X_1219_ _338_ _337_ _336_ vdd gnd NAND2X1
X_1392_ _u_alien.y_bullet_[2] _u_alien.rom_addr_[2] _167_ vdd gnd NOR2X1
X_1448_ _217_ _220_ _216_ vdd gnd NAND2X1
X_1028_ _u_alien.x_pos_[5] _585_ _590_ _588_ _591_ vdd 
+ gnd
+ OAI22X1

.ends
.end
