/* Verilog module written by vlog2Verilog (qflow) */
/* With explicit power connections */

module invaders(
    inout vdd,
    inout gnd,
    input clk,
    input reset,
    output v_sync,
    output pixel,
    output p_tick,
    input btn_left,
    input btn_right,
    output game_over,
    output game_complete,
    input game_new
);

wire _588_ ;
wire _168_ ;
wire _800_ ;
wire _60_ ;
wire _397_ ;
wire \u_ball.sign_x  ;
wire _703_ ;
wire _19_ ;
wire _512_ ;
wire _741_ ;
wire _321_ ;
wire _57_ ;
wire _550_ ;
wire _130_ ;
wire _606_ ;
wire _835_ ;
wire _415_ ;
wire _95_ ;
wire _644_ ;
wire _224_ ;
wire _453_ ;
wire _509_ ;
wire _682_ ;
wire _262_ ;
wire _738_ ;
wire _318_ ;
wire _491_ ;
wire _547_ ;
wire _127_ ;
wire _776_ ;
wire _356_ ;
wire btn_right ;
wire _585_ ;
wire _165_ ;
wire _394_ ;
wire _679_ ;
wire _259_ ;
wire _488_ ;
wire _700_ ;
wire _297_ ;
wire _16_ ;
wire _54_ ;
wire _603_ ;
wire _832_ ;
wire _412_ ;
wire _92_ ;
wire _641_ ;
wire _221_ ;
wire _450_ ;
wire _506_ ;
wire _735_ ;
wire _315_ ;
wire _544_ ;
wire _124_ ;
wire _773_ ;
wire _353_ ;
wire _829_ ;
wire _409_ ;
wire _89_ ;
wire _582_ ;
wire _162_ ;
wire _638_ ;
wire _218_ ;
wire _391_ ;
wire _447_ ;
wire _676_ ;
wire _256_ ;
wire _485_ ;
wire _294_ ;
wire _13_ ;
wire _579_ ;
wire _159_ ;
wire _51_ ;
wire _388_ ;
wire _600_ ;
wire _197_ ;
wire _7_ ;
wire _503_ ;
wire _732_ ;
wire _312_ ;
wire _48_ ;
wire _541_ ;
wire _121_ ;
wire _770_ ;
wire _350_ ;
wire _826_ ;
wire _406_ ;
wire _86_ ;
wire _635_ ;
wire _215_ ;
wire _444_ ;
wire _673_ ;
wire _253_ ;
wire _729_ ;
wire _309_ ;
wire _482_ ;
wire _538_ ;
wire _118_ ;
wire _291_ ;
wire _10_ ;
wire _767_ ;
wire _347_ ;
wire _576_ ;
wire _156_ ;
wire _385_ ;
wire pixel ;
wire _194_ ;
wire _479_ ;
wire _288_ ;
wire _4_ ;
wire _500_ ;
wire _45_ ;
wire _823_ ;
wire _403_ ;
wire _83_ ;
wire _632_ ;
wire _212_ ;
wire _441_ ;
wire _670_ ;
wire _250_ ;
wire _726_ ;
wire _306_ ;
wire _535_ ;
wire _115_ ;
wire _764_ ;
wire _344_ ;
wire _573_ ;
wire _153_ ;
wire _629_ ;
wire _209_ ;
wire _382_ ;
wire _858_ ;
wire _438_ ;
wire _191_ ;
wire _667_ ;
wire _247_ ;
wire _476_ ;
wire clk_bF$buf0 ;
wire clk_bF$buf1 ;
wire clk_bF$buf2 ;
wire clk_bF$buf3 ;
wire clk_bF$buf4 ;
wire clk_bF$buf5 ;
wire clk_bF$buf6 ;
wire clk_bF$buf7 ;
wire _285_ ;
wire _1_ ;
wire [6:0] \u_alien.x_pos  ;
wire _42_ ;
wire _799_ ;
wire _379_ ;
wire _188_ ;
wire _820_ ;
wire _400_ ;
wire _80_ ;
wire pixel_bullet ;
wire _723_ ;
wire _303_ ;
wire _39_ ;
wire _532_ ;
wire _112_ ;
wire _761_ ;
wire _341_ ;
wire clk ;
wire _817_ ;
wire _77_ ;
wire _570_ ;
wire _150_ ;
wire _626_ ;
wire _206_ ;
wire _855_ ;
wire _435_ ;
wire _664_ ;
wire _244_ ;
wire _473_ ;
wire _529_ ;
wire _109_ ;
wire _282_ ;
wire _758_ ;
wire _338_ ;
wire _567_ ;
wire _147_ ;
wire _796_ ;
wire _376_ ;
wire _185_ ;
wire _699_ ;
wire _279_ ;
wire _720_ ;
wire _300_ ;
wire _36_ ;
wire _814_ ;
wire _74_ ;
wire _623_ ;
wire _203_ ;
wire _852_ ;
wire _432_ ;
wire pixel_paddle ;
wire _661_ ;
wire _241_ ;
wire _717_ ;
wire _470_ ;
wire _526_ ;
wire _106_ ;
wire _755_ ;
wire _335_ ;
wire _564_ ;
wire _144_ ;
wire [2:0] \u_ctrl.cnt_v_sync  ;
wire _793_ ;
wire _373_ ;
wire _849_ ;
wire _429_ ;
wire _182_ ;
wire _658_ ;
wire _238_ ;
wire _467_ ;
wire _696_ ;
wire _276_ ;
wire _33_ ;
wire \u_ball.hit_paddle  ;
wire _599_ ;
wire _179_ ;
wire _811_ ;
wire _71_ ;
wire _620_ ;
wire _200_ ;
wire _714_ ;
wire _523_ ;
wire _103_ ;
wire \u_ctrl.State_3_bF$buf3  ;
wire _752_ ;
wire _332_ ;
wire _808_ ;
wire _68_ ;
wire _561_ ;
wire _141_ ;
wire _617_ ;
wire _790_ ;
wire _370_ ;
wire _846_ ;
wire _426_ ;
wire _655_ ;
wire _235_ ;
wire _464_ ;
wire [6:4] \u_alien.x_bullet  ;
wire _693_ ;
wire _273_ ;
wire _749_ ;
wire _329_ ;
wire _558_ ;
wire _138_ ;
wire _30_ ;
wire _787_ ;
wire _367_ ;
wire _596_ ;
wire _176_ ;
wire _499_ ;
wire _711_ ;
wire _27_ ;
wire _520_ ;
wire _100_ ;
wire \u_ctrl.State_3_bF$buf0  ;
wire _805_ ;
wire _65_ ;
wire _614_ ;
wire _843_ ;
wire _423_ ;
wire _652_ ;
wire _232_ ;
wire _708_ ;
wire _461_ ;
wire _517_ ;
wire _690_ ;
wire _270_ ;
wire _746_ ;
wire _326_ ;
wire _555_ ;
wire _135_ ;
wire _784_ ;
wire _364_ ;
wire _593_ ;
wire _173_ ;
wire _649_ ;
wire _229_ ;
wire _458_ ;
wire _687_ ;
wire _267_ ;
wire _496_ ;
wire _24_ ;
wire _802_ ;
wire _62_ ;
wire [6:0] \u_alien.x_ball  ;
wire _399_ ;
wire _611_ ;
wire _840_ ;
wire _420_ ;
wire _705_ ;
wire _514_ ;
wire _743_ ;
wire _323_ ;
wire _59_ ;
wire _552_ ;
wire _132_ ;
wire _608_ ;
wire _781_ ;
wire _361_ ;
wire _837_ ;
wire _417_ ;
wire _97_ ;
wire _590_ ;
wire _170_ ;
wire _646_ ;
wire _226_ ;
wire _455_ ;
wire _684_ ;
wire _264_ ;
wire _493_ ;
wire _549_ ;
wire _129_ ;
wire _21_ ;
wire _778_ ;
wire _358_ ;
wire _587_ ;
wire _167_ ;
wire _396_ ;
wire \u_ball.x2  ;
wire en_lfsr4 ;
wire _702_ ;
wire _299_ ;
wire _18_ ;
wire _511_ ;
wire _740_ ;
wire _320_ ;
wire _56_ ;
wire _605_ ;
wire _834_ ;
wire _414_ ;
wire _94_ ;
wire _643_ ;
wire _223_ ;
wire _452_ ;
wire _508_ ;
wire _681_ ;
wire _261_ ;
wire _737_ ;
wire _317_ ;
wire _490_ ;
wire _546_ ;
wire _126_ ;
wire _775_ ;
wire _355_ ;
wire game_over ;
wire _584_ ;
wire _164_ ;
wire _393_ ;
wire _449_ ;
wire _678_ ;
wire _258_ ;
wire _487_ ;
wire _296_ ;
wire _15_ ;
wire [7:0] \u_alien.regAliens  ;
wire _53_ ;
wire _602_ ;
wire _199_ ;
wire _831_ ;
wire _411_ ;
wire _91_ ;
wire _640_ ;
wire _220_ ;
wire _9_ ;
wire _505_ ;
wire _734_ ;
wire _314_ ;
wire _543_ ;
wire _123_ ;
wire _772_ ;
wire _352_ ;
wire _828_ ;
wire _408_ ;
wire _88_ ;
wire _581_ ;
wire _161_ ;
wire _637_ ;
wire _217_ ;
wire _390_ ;
wire _446_ ;
wire _675_ ;
wire _255_ ;
wire _484_ ;
wire _293_ ;
wire _12_ ;
wire _769_ ;
wire _349_ ;
wire _578_ ;
wire _158_ ;
wire _50_ ;
wire _387_ ;
wire _196_ ;
wire [1:0] \u_ctrl.cnt_alien_flip  ;
wire _6_ ;
wire _502_ ;
wire _731_ ;
wire _311_ ;
wire _47_ ;
wire _540_ ;
wire _120_ ;
wire [6:1] \u_ball.x_paddle  ;
wire _825_ ;
wire _405_ ;
wire _85_ ;
wire _634_ ;
wire _214_ ;
wire _443_ ;
wire _672_ ;
wire _252_ ;
wire _728_ ;
wire _308_ ;
wire _481_ ;
wire _537_ ;
wire _117_ ;
wire _290_ ;
wire _766_ ;
wire _346_ ;
wire _575_ ;
wire _155_ ;
wire _384_ ;
wire _193_ ;
wire _669_ ;
wire _249_ ;
wire _478_ ;
wire _287_ ;
wire _3_ ;
wire game_complete ;
wire _44_ ;
wire _822_ ;
wire _402_ ;
wire _82_ ;
wire _631_ ;
wire _211_ ;
wire _860_ ;
wire _440_ ;
wire _725_ ;
wire _305_ ;
wire _534_ ;
wire _114_ ;
wire _763_ ;
wire _343_ ;
wire _819_ ;
wire _79_ ;
wire _572_ ;
wire _152_ ;
wire _628_ ;
wire _208_ ;
wire _381_ ;
wire _857_ ;
wire _437_ ;
wire _190_ ;
wire _354__bF$buf0 ;
wire _354__bF$buf1 ;
wire _354__bF$buf2 ;
wire _354__bF$buf3 ;
wire _666_ ;
wire _246_ ;
wire pixel_ball ;
wire _475_ ;
wire _284_ ;
wire _0_ ;
wire v_sync ;
wire _569_ ;
wire _149_ ;
wire _41_ ;
wire _798_ ;
wire _378_ ;
wire _187_ ;
wire [5:3] \u_alien.y_pos  ;
wire _722_ ;
wire _302_ ;
wire _38_ ;
wire _531_ ;
wire _111_ ;
wire _760_ ;
wire _340_ ;
wire _816_ ;
wire _76_ ;
wire _625_ ;
wire _205_ ;
wire _854_ ;
wire _434_ ;
wire _663_ ;
wire _243_ ;
wire _719_ ;
wire _472_ ;
wire _528_ ;
wire _108_ ;
wire _281_ ;
wire _757_ ;
wire _337_ ;
wire _566_ ;
wire _146_ ;
wire _795_ ;
wire _375_ ;
wire _184_ ;
wire _469_ ;
wire _698_ ;
wire _278_ ;
wire _35_ ;
wire _813_ ;
wire _73_ ;
wire _622_ ;
wire _202_ ;
wire _851_ ;
wire _431_ ;
wire _660_ ;
wire _240_ ;
wire _716_ ;
wire _525_ ;
wire _105_ ;
wire _754_ ;
wire _334_ ;
wire _563_ ;
wire _143_ ;
wire _619_ ;
wire _792_ ;
wire _372_ ;
wire _848_ ;
wire _428_ ;
wire _181_ ;
wire _657_ ;
wire _237_ ;
wire _466_ ;
wire _695_ ;
wire _275_ ;
wire _32_ ;
wire _789_ ;
wire _369_ ;
wire _598_ ;
wire _178_ ;
wire _810_ ;
wire _70_ ;
wire _713_ ;
wire _29_ ;
wire _522_ ;
wire _102_ ;
wire \u_ctrl.State_3_bF$buf2  ;
wire _751_ ;
wire _331_ ;
wire _807_ ;
wire _67_ ;
wire _560_ ;
wire _140_ ;
wire _616_ ;
wire _845_ ;
wire _425_ ;
wire _654_ ;
wire _234_ ;
wire _463_ ;
wire _519_ ;
wire _692_ ;
wire _272_ ;
wire game_init ;
wire _748_ ;
wire _328_ ;
wire _557_ ;
wire _137_ ;
wire [4:0] \u_ctrl.State  ;
wire _786_ ;
wire _366_ ;
wire _595_ ;
wire _175_ ;
wire _689_ ;
wire _269_ ;
wire _498_ ;
wire _710_ ;
wire _26_ ;
wire _804_ ;
wire _64_ ;
wire _613_ ;
wire _842_ ;
wire _422_ ;
wire _651_ ;
wire _231_ ;
wire _707_ ;
wire _460_ ;
wire _516_ ;
wire [5:0] \u_ball.y_ball  ;
wire _745_ ;
wire _325_ ;
wire _554_ ;
wire _134_ ;
wire _783_ ;
wire _363_ ;
wire [2:0] \u_alien.rom_addr  ;
wire _839_ ;
wire _419_ ;
wire _99_ ;
wire _592_ ;
wire _172_ ;
wire _648_ ;
wire _228_ ;
wire _457_ ;
wire _686_ ;
wire _266_ ;
wire _495_ ;
wire _23_ ;
wire _589_ ;
wire _169_ ;
wire _801_ ;
wire _61_ ;
wire _398_ ;
wire _610_ ;
wire \u_ball.sign_y  ;
wire _704_ ;
wire [3:0] lfsr4 ;
wire _513_ ;
wire _742_ ;
wire _322_ ;
wire _58_ ;
wire _551_ ;
wire _131_ ;
wire _607_ ;
wire _780_ ;
wire _360_ ;
wire _836_ ;
wire _416_ ;
wire _96_ ;
wire _645_ ;
wire _225_ ;
wire game_new ;
wire _454_ ;
wire _683_ ;
wire _263_ ;
wire _739_ ;
wire _319_ ;
wire _492_ ;
wire _548_ ;
wire _128_ ;
wire _20_ ;
wire _777_ ;
wire _357_ ;
wire _586_ ;
wire _166_ ;
wire _395_ ;
wire _489_ ;
wire _701_ ;
wire _298_ ;
wire _17_ ;
wire _510_ ;
wire _55_ ;
wire _604_ ;
wire _833_ ;
wire _413_ ;
wire _93_ ;
wire _642_ ;
wire _222_ ;
wire _451_ ;
wire _507_ ;
wire _680_ ;
wire _260_ ;
wire _736_ ;
wire _316_ ;
wire _545_ ;
wire _125_ ;
wire _774_ ;
wire _354_ ;
wire _583_ ;
wire _163_ ;
wire _639_ ;
wire _219_ ;
wire _392_ ;
wire _448_ ;
wire _677_ ;
wire _257_ ;
wire _486_ ;
wire _295_ ;
wire _14_ ;
wire _52_ ;
wire _389_ ;
wire _601_ ;
wire _198_ ;
wire _830_ ;
wire _410_ ;
wire _90_ ;
wire _8_ ;
wire _504_ ;
wire _733_ ;
wire _313_ ;
wire _49_ ;
wire _542_ ;
wire _122_ ;
wire _771_ ;
wire _351_ ;
wire _827_ ;
wire _407_ ;
wire _87_ ;
wire _580_ ;
wire _160_ ;
wire _636_ ;
wire _216_ ;
wire _445_ ;
wire btn_left ;
wire _674_ ;
wire _254_ ;
wire _483_ ;
wire _539_ ;
wire _119_ ;
wire _292_ ;
wire _11_ ;
wire _768_ ;
wire _348_ ;
wire _577_ ;
wire _157_ ;
wire _386_ ;
wire _195_ ;
wire pixel_alien ;
wire _289_ ;
wire _5_ ;
wire _501_ ;
wire _730_ ;
wire _310_ ;
wire _46_ ;
wire _824_ ;
wire _404_ ;
wire _84_ ;
wire _633_ ;
wire _213_ ;
wire _442_ ;
wire _671_ ;
wire _251_ ;
wire _727_ ;
wire _307_ ;
wire _480_ ;
wire _536_ ;
wire _116_ ;
wire _765_ ;
wire _345_ ;
wire _574_ ;
wire _154_ ;
wire _383_ ;
wire _859_ ;
wire _439_ ;
wire _192_ ;
wire _668_ ;
wire _248_ ;
wire _477_ ;
wire _286_ ;
wire _2_ ;
wire _43_ ;
wire _189_ ;
wire _821_ ;
wire _401_ ;
wire _81_ ;
wire _630_ ;
wire _210_ ;
wire _724_ ;
wire _304_ ;
wire _533_ ;
wire _113_ ;
wire _762_ ;
wire _342_ ;
wire _818_ ;
wire _78_ ;
wire _571_ ;
wire _151_ ;
wire _627_ ;
wire _207_ ;
wire _380_ ;
wire _856_ ;
wire _436_ ;
wire _665_ ;
wire _245_ ;
wire _474_ ;
wire _283_ ;
wire _759_ ;
wire _339_ ;
wire _568_ ;
wire _148_ ;
wire _40_ ;
wire _797_ ;
wire _377_ ;
wire _186_ ;
wire [5:0] \u_alien.y_bullet  ;
wire _721_ ;
wire _301_ ;
wire _37_ ;
wire _530_ ;
wire _110_ ;
wire _815_ ;
wire _75_ ;
wire _624_ ;
wire _204_ ;
wire _853_ ;
wire _433_ ;
wire _662_ ;
wire _242_ ;
wire _718_ ;
wire _471_ ;
wire _527_ ;
wire _107_ ;
wire _280_ ;
wire _756_ ;
wire _336_ ;
wire hit_alien ;
wire _565_ ;
wire _145_ ;
wire _270__bF$buf0 ;
wire _270__bF$buf1 ;
wire _270__bF$buf2 ;
wire _270__bF$buf3 ;
wire _794_ ;
wire _374_ ;
wire _183_ ;
wire _659_ ;
wire _239_ ;
wire _468_ ;
wire _697_ ;
wire _277_ ;
wire _34_ ;
wire _812_ ;
wire _72_ ;
wire _621_ ;
wire _201_ ;
wire _850_ ;
wire _430_ ;
wire _715_ ;
wire _524_ ;
wire _104_ ;
wire alien_flip ;
wire _753_ ;
wire _333_ ;
wire _809_ ;
wire _69_ ;
wire _562_ ;
wire _142_ ;
wire _618_ ;
wire _791_ ;
wire _371_ ;
wire _847_ ;
wire _427_ ;
wire _180_ ;
wire _656_ ;
wire _236_ ;
wire _465_ ;
wire _694_ ;
wire _274_ ;
wire _559_ ;
wire _139_ ;
wire _31_ ;
wire _788_ ;
wire _368_ ;
wire _597_ ;
wire _177_ ;
wire _712_ ;
wire _28_ ;
wire _521_ ;
wire _101_ ;
wire \u_ctrl.State_3_bF$buf1  ;
wire _750_ ;
wire _330_ ;
wire _806_ ;
wire _66_ ;
wire _615_ ;
wire _844_ ;
wire _424_ ;
wire _653_ ;
wire _233_ ;
wire _709_ ;
wire _462_ ;
wire _518_ ;
wire _691_ ;
wire _271_ ;
wire p_tick ;
wire _747_ ;
wire _327_ ;
wire _556_ ;
wire _136_ ;
wire _785_ ;
wire _365_ ;
wire _594_ ;
wire _174_ ;
wire _459_ ;
wire _800__bF$buf0 ;
wire _800__bF$buf1 ;
wire _800__bF$buf2 ;
wire _800__bF$buf3 ;
wire _800__bF$buf4 ;
wire _688_ ;
wire _268_ ;
wire _497_ ;
wire _25_ ;
wire _803_ ;
wire _63_ ;
wire _612_ ;
wire reset ;
wire _841_ ;
wire _421_ ;
wire _650_ ;
wire _230_ ;
wire _706_ ;
wire _515_ ;
wire _744_ ;
wire _324_ ;
wire _553_ ;
wire _133_ ;
wire _609_ ;
wire _782_ ;
wire _362_ ;
wire _838_ ;
wire _418_ ;
wire _98_ ;
wire _591_ ;
wire _171_ ;
wire _647_ ;
wire _227_ ;
wire _456_ ;
wire _685_ ;
wire _265_ ;
wire _494_ ;
wire _22_ ;
wire _779_ ;
wire _359_ ;

OAI21X1 _1677_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_763_),
    .B(_692_),
    .C(_691_),
    .Y(_796_)
);

DFFSR _1257_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_270__bF$buf2),
    .S(vdd),
    .D(_267_),
    .CLK(clk_bF$buf3),
    .Q(\u_alien.y_bullet [5])
);

NOR2X1 _1486_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [4]),
    .B(_253_),
    .Y(_252_)
);

AOI21X1 _1066_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_329_),
    .B(\u_ball.y_ball [2]),
    .C(game_init),
    .Y(_555_)
);

NOR2X1 _1295_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [5]),
    .B(\u_alien.y_pos [4]),
    .Y(_71_)
);

INVX1 _1389_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [3]),
    .Y(_164_)
);

NOR2X1 _1601_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_left),
    .B(_517_),
    .Y(_516_)
);

NAND2X1 _932_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_834_),
    .B(_830_),
    .Y(_835_)
);

NAND2X1 _1198_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(_317_),
    .Y(_316_)
);

FILL FILL77550x28950 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1410_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [0]),
    .Y(_185_)
);

NOR2X1 _970_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [0]),
    .B(_285_),
    .Y(_654_)
);

NAND3X1 _1504_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_523_),
    .B(_509_),
    .C(_427_),
    .Y(_426_)
);

NAND3X1 _1733_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_744_),
    .B(_732_),
    .C(_737_),
    .Y(_731_)
);

OAI21X1 _1313_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_127_),
    .B(_126_),
    .C(alien_flip),
    .Y(_89_)
);

INVX1 _1542_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [0]),
    .Y(_461_)
);

NOR2X1 _1122_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(gnd),
    .B(_285_),
    .Y(_372_)
);

DFFSR _873_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf1),
    .S(vdd),
    .D(_363_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.x2 )
);

NAND2X1 _929_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_820_),
    .B(_830_),
    .Y(_838_)
);

INVX2 _1771_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_768_),
    .Y(_767_)
);

INVX2 _1351_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [1]),
    .Y(_127_)
);

NAND2X1 _1407_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_184_),
    .B(_183_),
    .Y(_182_)
);

NAND2X1 _1580_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_503_),
    .B(_496_),
    .Y(_543_)
);

INVX2 _1160_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [4]),
    .Y(_51_)
);

FILL FILL77850x36150 (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1636_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_800__bF$buf0),
    .D(_809_),
    .CLK(clk_bF$buf1),
    .Q(\u_alien.x_pos [4])
);

INVX1 _1216_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [5]),
    .Y(_333_)
);

INVX1 _967_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_654_),
    .Y(_657_)
);

INVX1 _1445_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_215_),
    .Y(_214_)
);

NOR2X1 _1025_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [6]),
    .B(_589_),
    .Y(_594_)
);

NAND2X1 _1674_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_690_),
    .B(_689_),
    .Y(_795_)
);

DFFSR _1254_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_270__bF$buf2),
    .S(vdd),
    .D(_280_),
    .CLK(clk_bF$buf3),
    .Q(\u_alien.y_bullet [1])
);

INVX1 _1483_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.regAliens [4]),
    .Y(_250_)
);

NOR2X1 _1063_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .B(\u_ball.y_ball [3]),
    .Y(_557_)
);

AOI21X1 _1539_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_467_),
    .B(_459_),
    .C(_466_),
    .Y(_458_)
);

OAI22X1 _1119_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [3]),
    .B(_368_),
    .C(_374_),
    .D(_371_),
    .Y(_375_)
);

NAND3X1 _1292_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_78_),
    .B(_72_),
    .C(_69_),
    .Y(_68_)
);

NAND2X1 _1768_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765_),
    .B(_782_),
    .Y(_764_)
);

OAI21X1 _1348_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [0]),
    .B(\u_alien.rom_addr [1]),
    .C(\u_alien.rom_addr [2]),
    .Y(_124_)
);

NAND2X1 _1577_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_495_),
    .B(_500_),
    .Y(_493_)
);

NAND2X1 _1157_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_49_),
    .B(_50_),
    .Y(_48_)
);

FILL FILL78150x36150 (
    .gnd(gnd),
    .vdd(vdd)
);

AND2X2 _1386_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_166_),
    .B(_162_),
    .Y(_161_)
);

NOR2X1 _1195_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_314_),
    .B(_319_),
    .Y(_313_)
);

INVX1 _1289_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_66_),
    .Y(pixel_alien)
);

DFFSR _1501_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_538_),
    .S(vdd),
    .D(_540_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.x_paddle [1])
);

NOR2X1 _1098_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_344_),
    .B(_395_),
    .Y(_396_)
);

OAI21X1 _1730_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_730_),
    .B(_729_),
    .C(_857_),
    .Y(_728_)
);

AOI21X1 _1310_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_90_),
    .B(_87_),
    .C(\u_alien.x_pos [3]),
    .Y(_86_)
);

DFFSR _870_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf3),
    .S(vdd),
    .D(_350_),
    .CLK(clk_bF$buf6),
    .Q(\u_alien.x_ball [2])
);

OAI21X1 _926_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_820_),
    .B(_660_),
    .C(_825_),
    .Y(_841_)
);

NAND2X1 _1404_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [1]),
    .B(\u_alien.rom_addr [1]),
    .Y(_179_)
);

DFFSR _1633_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_800__bF$buf4),
    .S(vdd),
    .D(_794_),
    .CLK(clk_bF$buf1),
    .Q(\u_ctrl.cnt_alien_flip [1])
);

AOI21X1 _1213_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_859_),
    .B(_331_),
    .C(_340_),
    .Y(_366_)
);

NAND3X1 _964_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_659_),
    .B(_648_),
    .C(_651_),
    .Y(_660_)
);

FILL FILL77850x57750 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1442_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [2]),
    .Y(_212_)
);

OAI22X1 _1022_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [3]),
    .B(_312_),
    .C(_330_),
    .D(\u_alien.x_pos [4]),
    .Y(_597_)
);

OAI21X1 _1671_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_688_),
    .B(_687_),
    .C(_703_),
    .Y(_686_)
);

DFFSR _1251_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_270__bF$buf3),
    .D(_264_),
    .CLK(clk_bF$buf5),
    .Q(\u_alien.regAliens [4])
);

OAI21X1 _1727_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_781_),
    .B(_786_),
    .C(_772_),
    .Y(_726_)
);

NAND2X1 _1307_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_84_),
    .B(_136_),
    .Y(_83_)
);

INVX1 _1480_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.regAliens [1]),
    .Y(_247_)
);

AND2X2 _1060_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_556_),
    .B(_559_),
    .Y(_560_)
);

INVX1 _1536_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [5]),
    .Y(_455_)
);

AOI22X1 _1116_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [4]),
    .B(_357_),
    .C(_355_),
    .D(\u_alien.x_ball [5]),
    .Y(_378_)
);

DFFSR _867_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf0),
    .S(vdd),
    .D(_362_),
    .CLK(clk_bF$buf4),
    .Q(\u_alien.x_ball [5])
);

NOR2X1 _1765_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [2]),
    .B(_762_),
    .Y(_761_)
);

NAND2X1 _1345_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [1]),
    .B(\u_alien.rom_addr [2]),
    .Y(_121_)
);

OAI21X1 _1574_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_501_),
    .B(_507_),
    .C(_498_),
    .Y(_491_)
);

INVX2 _1154_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [5]),
    .Y(_45_)
);

OR2X2 _1383_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_170_),
    .B(_195_),
    .Y(_158_)
);

FILL FILL78150x57750 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1439_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [2]),
    .B(_219_),
    .C(_223_),
    .Y(_209_)
);

INVX1 _1019_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [5]),
    .Y(_600_)
);

NAND2X1 _1192_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [3]),
    .B(_326_),
    .Y(_310_)
);

NOR2X1 _1668_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_736_),
    .B(_769_),
    .Y(_684_)
);

DFFSR _1248_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf3),
    .S(vdd),
    .D(_347_),
    .CLK(clk_bF$buf1),
    .Q(_856_)
);

OAI21X1 _999_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_603_),
    .B(_608_),
    .C(_623_),
    .Y(_624_)
);

NAND2X1 _1477_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[0]),
    .B(_245_),
    .Y(_244_)
);

AND2X2 _1057_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_307_),
    .B(_386_),
    .Y(_562_)
);

FILL FILL78450x7350 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1286_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.regAliens [5]),
    .B(\u_alien.regAliens [6]),
    .Y(_63_)
);

AOI21X1 _1095_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_392_),
    .B(_391_),
    .C(_398_),
    .Y(_399_)
);

NAND3X1 _923_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(pixel_alien),
    .B(_645_),
    .C(_842_),
    .Y(_843_)
);

NOR2X1 _1189_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [2]),
    .B(\u_alien.x_ball [3]),
    .Y(_307_)
);

NAND2X1 _1401_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [5]),
    .B(_177_),
    .Y(_176_)
);

DFFSR _1630_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_800__bF$buf1),
    .S(vdd),
    .D(_616_),
    .CLK(clk_bF$buf7),
    .Q(\u_ctrl.State [4])
);

NOR2X1 _1210_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(_329_),
    .Y(_328_)
);

OAI21X1 _961_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_610_),
    .B(_613_),
    .C(_662_),
    .Y(_663_)
);

OAI21X1 _1724_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_772_),
    .B(_780_),
    .C(_771_),
    .Y(_724_)
);

AOI21X1 _1304_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_235_),
    .B(\u_alien.x_pos [5]),
    .C(_134_),
    .Y(_80_)
);

NOR2X1 _1533_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(_453_),
    .Y(_452_)
);

OAI21X1 _1113_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [6]),
    .B(_379_),
    .C(_380_),
    .Y(_381_)
);

BUFX2 _864_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_856_),
    .Y(game_over)
);

OAI21X1 _1762_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765_),
    .B(_760_),
    .C(_759_),
    .Y(_758_)
);

NAND2X1 _1342_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_119_),
    .B(_122_),
    .Y(_118_)
);

FILL FILL77850x43350 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1571_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_523_),
    .B(_491_),
    .C(_489_),
    .Y(_488_)
);

OAI21X1 _1151_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_51_),
    .B(_293_),
    .C(_44_),
    .Y(_42_)
);

DFFSR _1627_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_800__bF$buf1),
    .D(_791_),
    .CLK(clk_bF$buf6),
    .Q(\u_alien.rom_addr [2])
);

INVX1 _1207_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x2 ),
    .Y(_325_)
);

AND2X2 _958_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_665_),
    .B(_663_),
    .Y(_666_)
);

NAND2X1 _1380_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_210_),
    .B(_162_),
    .Y(_155_)
);

OAI21X1 _1436_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_212_),
    .B(_220_),
    .C(_207_),
    .Y(_278_)
);

INVX1 _1016_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [3]),
    .Y(_603_)
);

INVX1 _1665_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [1]),
    .Y(_682_)
);

NAND2X1 _1245_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[3]),
    .B(_547_),
    .Y(_546_)
);

OAI21X1 _996_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .B(_626_),
    .C(_605_),
    .Y(_627_)
);

NOR2X1 _1474_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [2]),
    .B(\u_alien.y_bullet [3]),
    .Y(_241_)
);

NAND2X1 _1054_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [1]),
    .B(_323_),
    .Y(_565_)
);

INVX8 _1283_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_270_)
);

NOR2X1 _1759_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_772_),
    .B(_780_),
    .Y(_755_)
);

NOR2X1 _1339_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_140_),
    .B(_116_),
    .Y(_115_)
);

NAND3X1 _1092_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.hit_paddle ),
    .B(_328_),
    .C(_385_),
    .Y(_401_)
);

OAI21X1 _1568_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_534_),
    .B(_524_),
    .C(\u_ball.x_paddle [1]),
    .Y(_486_)
);

OR2X2 _1148_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_46_),
    .B(_40_),
    .Y(_39_)
);

NAND2X1 _899_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [3]),
    .B(_344_),
    .Y(_6_)
);

FILL FILL78150x43350 (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1797_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf2),
    .S(vdd),
    .D(_346_),
    .CLK(clk_bF$buf1),
    .Q(\u_ball.y_ball [5])
);

AOI21X1 _1377_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_177_),
    .B(\u_alien.y_pos [5]),
    .C(_190_),
    .Y(_152_)
);

AOI21X1 _920_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_844_),
    .B(_299_),
    .C(_343_),
    .Y(_803_)
);

NAND2X1 _1186_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(_330_),
    .Y(_304_)
);

NAND2X1 _1089_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_326_),
    .B(_45_),
    .Y(_403_)
);

OAI21X1 _1721_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_771_),
    .B(_727_),
    .C(_748_),
    .Y(_722_)
);

AOI21X1 _1301_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_250_),
    .B(_134_),
    .C(\u_alien.x_pos [5]),
    .Y(_77_)
);

AOI21X1 _1530_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_520_),
    .B(_454_),
    .C(_450_),
    .Y(_449_)
);

NAND2X1 _1110_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [6]),
    .B(_379_),
    .Y(_384_)
);

BUFX2 _861_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_859_),
    .Y(v_sync)
);

FILL FILL78450x18150 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _917_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .B(_410_),
    .Y(_846_)
);

FILL FILL77850x64950 (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1624_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_800__bF$buf1),
    .S(vdd),
    .D(_806_),
    .CLK(clk_bF$buf2),
    .Q(game_init)
);

OAI21X1 _1204_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x2 ),
    .B(_326_),
    .C(_323_),
    .Y(_322_)
);

NAND2X1 _955_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(_612_),
    .Y(_669_)
);

NAND2X1 _1433_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_205_),
    .B(_236_),
    .Y(_204_)
);

NAND3X1 _1013_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_337_),
    .B(_335_),
    .C(_604_),
    .Y(_606_)
);

NAND2X1 _1662_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_682_),
    .B(_680_),
    .Y(_679_)
);

OR2X2 _1242_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[3]),
    .B(lfsr4[2]),
    .Y(_544_)
);

OR2X2 _993_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_337_),
    .B(\u_alien.rom_addr [2]),
    .Y(_630_)
);

NOR2X1 _1718_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_769_),
    .B(_739_),
    .Y(_720_)
);

INVX1 _1471_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.regAliens [2]),
    .Y(_238_)
);

INVX1 _1051_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [2]),
    .Y(_568_)
);

OAI21X1 _1527_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_522_),
    .B(\u_alien.x_pos [5]),
    .C(_452_),
    .Y(_446_)
);

AOI21X1 _1107_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_386_),
    .B(_317_),
    .C(_312_),
    .Y(_387_)
);

NOR2X1 _1280_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_258_),
    .B(_60_),
    .Y(_59_)
);

OAI21X1 _1756_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_856_),
    .B(_0_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_752_)
);

NAND3X1 _1336_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(alien_flip),
    .B(_124_),
    .C(_125_),
    .Y(_112_)
);

INVX1 _1565_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .Y(_484_)
);

OAI21X1 _1145_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_37_),
    .B(_38_),
    .C(\u_alien.x_ball [5]),
    .Y(_36_)
);

OAI21X1 _896_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_309_),
    .B(_7_),
    .C(_8_),
    .Y(_9_)
);

FILL FILL78150x64950 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1794_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(pixel_ball),
    .B(pixel_bullet),
    .Y(_847_)
);

INVX1 _1374_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_179_),
    .Y(_149_)
);

NAND2X1 _1183_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_303_),
    .B(_306_),
    .Y(_301_)
);

INVX1 _1659_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [2]),
    .Y(_677_)
);

NAND2X1 _1239_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_425_),
    .B(_539_),
    .Y(_552_)
);

INVX1 _1468_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.regAliens [3]),
    .Y(_235_)
);

NAND2X1 _1048_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_570_),
    .B(_567_),
    .Y(_571_)
);

NAND2X1 _1697_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [3]),
    .B(_775_),
    .Y(_707_)
);

AOI21X1 _1277_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_58_),
    .B(_259_),
    .C(_247_),
    .Y(_268_)
);

NAND2X1 _1086_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_403_),
    .B(_405_),
    .Y(_406_)
);

OAI21X1 _914_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .B(\u_ball.y_ball [3]),
    .C(_556_),
    .Y(_851_)
);

FILL FILL78450x72150 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78450x39750 (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1621_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf3),
    .S(vdd),
    .D(_817_),
    .CLK(clk_bF$buf6),
    .Q(hit_alien)
);

AND2X2 _1201_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_320_),
    .B(_324_),
    .Y(_319_)
);

NOR2X1 _952_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_669_),
    .B(_802_),
    .Y(_804_)
);

MUX2X1 _1430_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_222_),
    .B(_202_),
    .S(_251_),
    .Y(_201_)
);

INVX1 _1010_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [1]),
    .Y(_609_)
);

OAI22X1 _990_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [3]),
    .B(_335_),
    .C(_334_),
    .D(\u_alien.y_pos [4]),
    .Y(_633_)
);

OAI21X1 _1715_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_767_),
    .B(_719_),
    .C(_718_),
    .Y(_807_)
);

AOI21X1 _1524_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_448_),
    .B(_447_),
    .C(_444_),
    .Y(_443_)
);

NAND2X1 _1104_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [6]),
    .B(_389_),
    .Y(_390_)
);

OAI21X1 _1753_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_750_),
    .B(_751_),
    .C(\u_ctrl.cnt_v_sync [2]),
    .Y(_749_)
);

NAND2X1 _1333_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [0]),
    .B(alien_flip),
    .Y(_109_)
);

INVX1 _1562_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [1]),
    .Y(_481_)
);

NOR2X1 _1142_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(_38_),
    .Y(_33_)
);

NAND2X1 _893_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_alien.x_ball [6]),
    .Y(_11_)
);

INVX1 _1618_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_right),
    .Y(_533_)
);

NOR2X1 _949_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_668_),
    .B(_804_),
    .Y(_818_)
);

INVX1 _1791_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [0]),
    .Y(_785_)
);

NAND3X1 _1371_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_148_),
    .B(_150_),
    .C(_147_),
    .Y(_146_)
);

NAND3X1 _1427_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[2]),
    .B(_223_),
    .C(_199_),
    .Y(_198_)
);

INVX1 _1007_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [0]),
    .Y(_612_)
);

INVX1 _1180_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.hit_paddle ),
    .Y(_299_)
);

AOI22X1 _1656_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_677_),
    .B(_685_),
    .C(_683_),
    .D(_675_),
    .Y(_791_)
);

OAI21X1 _1236_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(en_lfsr4),
    .B(_424_),
    .C(_423_),
    .Y(_551_)
);

INVX1 _987_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_625_),
    .Y(_637_)
);

MUX2X1 _1465_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_233_),
    .B(_236_),
    .S(lfsr4[0]),
    .Y(_232_)
);

NAND3X1 _1045_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_323_),
    .B(_285_),
    .C(_317_),
    .Y(_574_)
);

AOI22X1 _1694_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_768_),
    .B(_720_),
    .C(_705_),
    .D(_777_),
    .Y(_799_)
);

AOI21X1 _1274_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_56_),
    .B(_57_),
    .C(game_init),
    .Y(_55_)
);

OAI21X1 _1083_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_407_),
    .B(_408_),
    .C(_328_),
    .Y(_409_)
);

NAND2X1 _1559_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_483_),
    .B(_479_),
    .Y(_478_)
);

INVX1 _1139_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [6]),
    .Y(_30_)
);

NOR2X1 _1788_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf2 ),
    .B(\u_ctrl.State [0]),
    .Y(_782_)
);

INVX1 _1368_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_bullet [4]),
    .Y(_143_)
);

AOI21X1 _911_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_850_),
    .B(_852_),
    .C(_853_),
    .Y(_854_)
);

AOI21X1 _1597_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_528_),
    .B(_532_),
    .C(\u_ball.x_paddle [2]),
    .Y(_512_)
);

INVX1 _1177_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .Y(_296_)
);

AOI21X1 _1712_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_716_),
    .B(\u_ctrl.State [0]),
    .C(game_init),
    .Y(_715_)
);

OAI21X1 _1521_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_449_),
    .B(_443_),
    .C(_441_),
    .Y(_440_)
);

NAND3X1 _1101_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_330_),
    .B(_45_),
    .C(_307_),
    .Y(_393_)
);

FILL FILL78450x25350 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _908_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x2 ),
    .B(_329_),
    .C(_345_),
    .Y(_860_)
);

INVX1 _1750_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_770_),
    .Y(_747_)
);

OAI21X1 _1330_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_127_),
    .B(_126_),
    .C(_128_),
    .Y(_106_)
);

NAND2X1 _890_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_13_),
    .B(_10_),
    .Y(_14_)
);

NOR2X1 _1615_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [5]),
    .B(\u_ball.x_paddle [1]),
    .Y(_530_)
);

OAI21X1 _946_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_656_),
    .B(_657_),
    .C(_653_),
    .Y(_821_)
);

INVX1 _1424_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [3]),
    .Y(_196_)
);

NAND2X1 _1004_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [2]),
    .B(_337_),
    .Y(_615_)
);

AOI22X1 _1653_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_742_),
    .B(_685_),
    .C(_683_),
    .D(_673_),
    .Y(_790_)
);

OAI21X1 _1233_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(en_lfsr4),
    .B(_548_),
    .C(_422_),
    .Y(_549_)
);

OAI22X1 _984_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_333_),
    .B(\u_alien.y_pos [5]),
    .C(_639_),
    .D(_605_),
    .Y(_640_)
);

INVX1 _1709_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [0]),
    .Y(_713_)
);

INVX1 _1462_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [0]),
    .Y(_229_)
);

OAI21X1 _1042_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_312_),
    .B(_576_),
    .C(_330_),
    .Y(_577_)
);

NAND2X1 _1518_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [4]),
    .B(_520_),
    .Y(_437_)
);

INVX1 _1691_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_alien_flip [0]),
    .Y(_702_)
);

AOI21X1 _1271_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_58_),
    .B(_252_),
    .C(_238_),
    .Y(_266_)
);

AOI22X1 _1747_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_756_),
    .B(_782_),
    .C(_745_),
    .D(\u_ctrl.State_3_bF$buf3 ),
    .Y(_812_)
);

OAI21X1 _1327_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_140_),
    .B(_116_),
    .C(\u_alien.rom_addr [1]),
    .Y(_103_)
);

INVX2 _1080_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .Y(_410_)
);

NOR2X1 _1556_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [3]),
    .B(_476_),
    .Y(_475_)
);

AOI21X1 _1136_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_39_),
    .B(_31_),
    .C(_28_),
    .Y(_27_)
);

OAI21X1 _887_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_30_),
    .B(_343_),
    .C(_16_),
    .Y(_348_)
);

NAND3X1 _1785_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [1]),
    .B(\u_alien.x_pos [2]),
    .C(\u_alien.x_pos [0]),
    .Y(_780_)
);

INVX2 _1365_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [1]),
    .Y(_140_)
);

NAND2X1 _1594_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_510_),
    .B(_511_),
    .Y(_509_)
);

NAND2X1 _1174_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [3]),
    .B(_294_),
    .Y(_293_)
);

OR2X2 _1459_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_228_),
    .B(_229_),
    .Y(_226_)
);

NOR2X1 _1039_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_387_),
    .B(_562_),
    .Y(_580_)
);

NAND3X1 _1688_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_alien_flip [0]),
    .B(\u_ctrl.cnt_alien_flip [1]),
    .C(_704_),
    .Y(_699_)
);

NAND3X1 _1268_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[0]),
    .B(_223_),
    .C(_199_),
    .Y(_53_)
);

DFFSR _1497_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf1),
    .S(vdd),
    .D(_364_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.sign_x )
);

NAND2X1 _1077_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_411_),
    .B(_412_),
    .Y(_413_)
);

FILL FILL78450x46950 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _905_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_855_),
    .B(_321_),
    .C(_328_),
    .Y(_2_)
);

NAND2X1 _1612_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_532_),
    .B(_528_),
    .Y(_527_)
);

OR2X2 _943_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_821_),
    .B(_822_),
    .Y(_824_)
);

OAI22X1 _1421_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_195_),
    .B(_194_),
    .C(_239_),
    .D(_201_),
    .Y(_193_)
);

AOI21X1 _1001_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_337_),
    .B(_604_),
    .C(_619_),
    .Y(_622_)
);

AOI22X1 _1650_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_741_),
    .B(_671_),
    .C(_683_),
    .D(_740_),
    .Y(_789_)
);

DFFSR _1230_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_550_),
    .D(_552_),
    .CLK(clk_bF$buf3),
    .Q(lfsr4[0])
);

AOI21X1 _981_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_624_),
    .B(_629_),
    .C(_642_),
    .Y(_643_)
);

OAI21X1 _1706_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_716_),
    .B(_714_),
    .C(_712_),
    .Y(_618_)
);

AND2X2 _1515_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [4]),
    .B(\u_alien.y_pos [3]),
    .Y(_434_)
);

INVX1 _1744_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [3]),
    .Y(_742_)
);

NAND2X1 _1324_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(alien_flip),
    .B(_114_),
    .Y(_100_)
);

OAI21X1 _1553_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_482_),
    .B(_477_),
    .C(_473_),
    .Y(_472_)
);

NOR2X1 _1133_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_44_),
    .B(_25_),
    .Y(_24_)
);

AOI21X1 _884_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_17_),
    .B(_18_),
    .C(game_init),
    .Y(_347_)
);

AOI21X1 _1609_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_533_),
    .B(_525_),
    .C(_526_),
    .Y(_524_)
);

AOI22X1 _1782_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_781_),
    .B(_782_),
    .C(_778_),
    .D(\u_ctrl.State_3_bF$buf3 ),
    .Y(_814_)
);

NOR2X1 _1362_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [2]),
    .B(_138_),
    .Y(_137_)
);

INVX1 _1418_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [4]),
    .Y(_191_)
);

NAND2X1 _1591_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_520_),
    .B(_527_),
    .Y(_506_)
);

NAND2X1 _1171_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_291_),
    .B(_293_),
    .Y(_290_)
);

DFFSR _1647_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_800__bF$buf1),
    .D(_634_),
    .CLK(clk_bF$buf7),
    .Q(\u_ctrl.State [0])
);

NOR2X1 _1227_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(_859_),
    .Y(_344_)
);

AOI21X1 _978_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_582_),
    .B(_586_),
    .C(_591_),
    .Y(_646_)
);

INVX1 _1456_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [1]),
    .Y(_224_)
);

NAND2X1 _1036_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_575_),
    .B(_577_),
    .Y(_583_)
);

INVX1 _1685_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [0]),
    .Y(_697_)
);

OAI21X1 _1265_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_133_),
    .B(_200_),
    .C(_52_),
    .Y(_262_)
);

NOR2X1 _1494_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [5]),
    .B(_260_),
    .Y(_259_)
);

OAI21X1 _1074_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_338_),
    .B(_343_),
    .C(_415_),
    .Y(_360_)
);

BUFX2 BUFX2_insert0 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_800_),
    .Y(_800__bF$buf4)
);

BUFX2 BUFX2_insert1 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_800_),
    .Y(_800__bF$buf3)
);

BUFX2 BUFX2_insert2 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_800_),
    .Y(_800__bF$buf2)
);

BUFX2 BUFX2_insert3 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_800_),
    .Y(_800__bF$buf1)
);

BUFX2 BUFX2_insert4 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_800_),
    .Y(_800__bF$buf0)
);

INVX1 _1779_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_776_),
    .Y(_775_)
);

INVX2 _1359_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [4]),
    .Y(_134_)
);

NAND2X1 _902_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_314_),
    .B(_319_),
    .Y(_4_)
);

NAND3X1 _1588_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_535_),
    .B(_523_),
    .C(_504_),
    .Y(_503_)
);

OR2X2 _1168_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_294_),
    .B(_289_),
    .Y(_287_)
);

DFFSR _1800_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_538_),
    .S(vdd),
    .D(_536_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.x_paddle [3])
);

NAND2X1 _1397_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [4]),
    .B(_173_),
    .Y(_172_)
);

OAI21X1 _940_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_820_),
    .B(_661_),
    .C(_826_),
    .Y(_827_)
);

AOI21X1 _1703_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_710_),
    .B(_753_),
    .C(_767_),
    .Y(_620_)
);

FILL FILL78450x150 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78450x32550 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX2 _1512_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_538_)
);

NAND3X1 _1741_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf0 ),
    .B(\u_alien.y_pos [5]),
    .C(_740_),
    .Y(_739_)
);

NAND3X1 _1321_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [0]),
    .B(_128_),
    .C(_98_),
    .Y(_97_)
);

INVX1 _1550_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_473_),
    .Y(_469_)
);

OR2X2 _1130_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_24_),
    .B(_22_),
    .Y(_355_)
);

OAI21X1 _881_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_333_),
    .B(_20_),
    .C(_345_),
    .Y(_21_)
);

NAND2X1 _1606_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_522_),
    .B(_526_),
    .Y(_521_)
);

NAND3X1 _937_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_829_),
    .B(_648_),
    .C(_651_),
    .Y(_830_)
);

FILL FILL77550x57750 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1415_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [4]),
    .B(_195_),
    .C(_223_),
    .Y(_188_)
);

DFFSR _1644_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_800__bF$buf4),
    .D(_799_),
    .CLK(clk_bF$buf1),
    .Q(\u_alien.y_pos [5])
);

INVX1 _1224_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_342_),
    .Y(_341_)
);

AOI21X1 _975_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_599_),
    .B(_601_),
    .C(_594_),
    .Y(_649_)
);

OAI21X1 _1453_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[1]),
    .B(_222_),
    .C(_231_),
    .Y(_221_)
);

AOI22X1 _1033_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [4]),
    .B(_583_),
    .C(_585_),
    .D(\u_alien.x_pos [5]),
    .Y(_586_)
);

OR2X2 _1509_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_431_),
    .B(_514_),
    .Y(_430_)
);

OAI21X1 _1682_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_763_),
    .B(_696_),
    .C(_695_),
    .Y(_797_)
);

DFFSR _1262_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_270__bF$buf2),
    .S(vdd),
    .D(_281_),
    .CLK(clk_bF$buf3),
    .Q(\u_alien.y_bullet [0])
);

INVX1 _1738_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf0 ),
    .Y(_736_)
);

NAND3X1 _1318_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_139_),
    .B(_128_),
    .C(_114_),
    .Y(_94_)
);

NAND2X1 _1491_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [6]),
    .B(_257_),
    .Y(_256_)
);

NAND2X1 _1071_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .B(\u_ball.y_ball [2]),
    .Y(_418_)
);

INVX1 _1547_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [0]),
    .Y(_466_)
);

NAND2X1 _1127_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_292_),
    .B(_289_),
    .Y(_367_)
);

DFFSR _878_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf2),
    .S(vdd),
    .D(_358_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.y_ball [3])
);

INVX2 _1776_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [3]),
    .Y(_772_)
);

NOR2X1 _1356_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_135_),
    .B(_132_),
    .Y(_131_)
);

AOI22X1 _1585_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [3]),
    .B(_532_),
    .C(_511_),
    .D(_510_),
    .Y(_500_)
);

NOR2X1 _1165_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [1]),
    .B(\u_ball.x_paddle [1]),
    .Y(_284_)
);

NOR2X1 _1394_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_170_),
    .B(_174_),
    .Y(_169_)
);

AOI21X1 _1679_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_693_),
    .B(\u_ctrl.State [1]),
    .C(\u_ctrl.State_3_bF$buf0 ),
    .Y(_692_)
);

DFFSR _1259_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_270__bF$buf0),
    .D(_268_),
    .CLK(clk_bF$buf5),
    .Q(\u_alien.regAliens [1])
);

INVX1 _1488_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.regAliens [6]),
    .Y(_254_)
);

NAND3X1 _1068_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_418_),
    .B(_419_),
    .C(_417_),
    .Y(_421_)
);

OAI21X1 _1700_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_716_),
    .B(_713_),
    .C(_709_),
    .Y(_634_)
);

OAI21X1 _1297_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.regAliens [6]),
    .B(\u_alien.x_pos [4]),
    .C(_74_),
    .Y(_73_)
);

INVX1 _1603_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_519_),
    .Y(_518_)
);

OAI21X1 _934_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_832_),
    .B(_802_),
    .C(_667_),
    .Y(_833_)
);

OAI21X1 _1412_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_191_),
    .B(_220_),
    .C(_186_),
    .Y(_275_)
);

DFFSR _1641_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_800__bF$buf3),
    .D(_810_),
    .CLK(clk_bF$buf2),
    .Q(\u_alien.x_pos [3])
);

INVX1 _1221_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .Y(_338_)
);

NOR2X1 _972_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [1]),
    .B(_323_),
    .Y(_652_)
);

OAI21X1 _1450_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [0]),
    .B(\u_alien.y_bullet [1]),
    .C(_223_),
    .Y(_218_)
);

INVX1 _1030_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [6]),
    .Y(_589_)
);

OAI21X1 _1506_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_484_),
    .B(_523_),
    .C(_428_),
    .Y(_537_)
);

NOR2X1 _1735_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_735_),
    .B(_734_),
    .Y(_733_)
);

OAI21X1 _1315_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_96_),
    .B(_99_),
    .C(_92_),
    .Y(_91_)
);

OR2X2 _1544_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_464_),
    .B(_477_),
    .Y(_463_)
);

AND2X2 _1124_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_287_),
    .B(_317_),
    .Y(_370_)
);

DFFSR _875_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf1),
    .S(vdd),
    .D(_360_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.y_ball [1])
);

NAND3X1 _1773_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [6]),
    .B(\u_alien.x_pos [5]),
    .C(_770_),
    .Y(_769_)
);

INVX1 _1353_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [3]),
    .Y(_129_)
);

NAND2X1 _1409_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [0]),
    .B(_185_),
    .Y(_184_)
);

AOI22X1 _1582_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_498_),
    .B(_507_),
    .C(_501_),
    .D(_499_),
    .Y(_497_)
);

OAI21X1 _1162_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_273_),
    .B(_286_),
    .C(_288_),
    .Y(_272_)
);

DFFSR _1638_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_800__bF$buf4),
    .S(vdd),
    .D(_796_),
    .CLK(clk_bF$buf7),
    .Q(\u_ctrl.cnt_v_sync [1])
);

INVX2 _1218_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [3]),
    .Y(_335_)
);

NAND3X1 _969_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_565_),
    .B(_654_),
    .C(_653_),
    .Y(_655_)
);

OR2X2 _1391_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_168_),
    .B(_167_),
    .Y(_166_)
);

OAI21X1 _1447_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_224_),
    .B(_220_),
    .C(_216_),
    .Y(_280_)
);

NAND2X1 _1027_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [6]),
    .B(_588_),
    .Y(_592_)
);

OAI21X1 _1676_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_767_),
    .B(_711_),
    .C(\u_ctrl.cnt_alien_flip [0]),
    .Y(_690_)
);

DFFSR _1256_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_270__bF$buf1),
    .S(vdd),
    .D(_276_),
    .CLK(clk_bF$buf3),
    .Q(\u_alien.y_bullet [3])
);

AOI21X1 _1485_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_255_),
    .B(_252_),
    .C(_254_),
    .Y(_282_)
);

OAI21X1 _1065_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_420_),
    .B(_554_),
    .C(_555_),
    .Y(_359_)
);

NAND3X1 _1294_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_164_),
    .B(_71_),
    .C(_125_),
    .Y(_70_)
);

FILL FILL77850x18150 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1579_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_520_),
    .B(btn_left),
    .C(_506_),
    .Y(_495_)
);

OR2X2 _1159_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_293_),
    .B(_51_),
    .Y(_50_)
);

NAND2X1 _1388_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_196_),
    .B(_164_),
    .Y(_163_)
);

INVX1 _1600_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_516_),
    .Y(_515_)
);

NAND3X1 _931_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_820_),
    .B(_829_),
    .C(_645_),
    .Y(_836_)
);

NAND2X1 _1197_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_318_),
    .B(_316_),
    .Y(_315_)
);

BUFX2 BUFX2_insert20 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_354_),
    .Y(_354__bF$buf0)
);

BUFX2 BUFX2_insert21 (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf3 )
);

BUFX2 BUFX2_insert22 (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf2 )
);

BUFX2 BUFX2_insert23 (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf1 )
);

BUFX2 BUFX2_insert24 (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [3]),
    .Y(\u_ctrl.State_3_bF$buf0 )
);

OAI21X1 _1503_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_517_),
    .B(_523_),
    .C(_426_),
    .Y(_536_)
);

FILL FILL78150x18150 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _1732_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_765_),
    .B(_761_),
    .C(_769_),
    .D(_739_),
    .Y(_730_)
);

AOI21X1 _1312_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_127_),
    .B(\u_alien.x_pos [2]),
    .C(_139_),
    .Y(_88_)
);

OAI21X1 _1541_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(_481_),
    .C(_461_),
    .Y(_460_)
);

OAI21X1 _1121_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [1]),
    .B(\u_ball.x_paddle [1]),
    .C(_372_),
    .Y(_373_)
);

DFFSR _872_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf1),
    .S(vdd),
    .D(_351_),
    .CLK(clk_bF$buf0),
    .Q(\u_alien.x_ball [1])
);

NAND3X1 _928_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_829_),
    .B(_834_),
    .C(_645_),
    .Y(_839_)
);

OAI21X1 _1770_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_767_),
    .B(_769_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_766_)
);

INVX1 _1350_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [2]),
    .Y(_126_)
);

NOR2X1 _1406_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [1]),
    .B(\u_alien.rom_addr [1]),
    .Y(_181_)
);

DFFSR _1635_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_800__bF$buf0),
    .S(vdd),
    .D(_795_),
    .CLK(clk_bF$buf1),
    .Q(\u_ctrl.cnt_alien_flip [0])
);

NAND3X1 _1215_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_335_),
    .B(_334_),
    .C(_333_),
    .Y(_332_)
);

OAI21X1 _966_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_652_),
    .B(_656_),
    .C(_657_),
    .Y(_658_)
);

OAI21X1 _1444_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_256_),
    .B(_214_),
    .C(\u_alien.regAliens [7]),
    .Y(_213_)
);

NAND2X1 _1024_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [2]),
    .B(_568_),
    .Y(_595_)
);

NOR2X1 _1673_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_alien_flip [0]),
    .B(_701_),
    .Y(_688_)
);

DFFSR _1253_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_270__bF$buf3),
    .D(_265_),
    .CLK(clk_bF$buf5),
    .Q(\u_alien.regAliens [3])
);

NAND2X1 _1729_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_728_),
    .B(_731_),
    .Y(_811_)
);

INVX1 _1309_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [6]),
    .Y(_85_)
);

AOI21X1 _1482_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_250_),
    .B(lfsr4[2]),
    .C(lfsr4[0]),
    .Y(_249_)
);

NOR2X1 _1062_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_410_),
    .B(_335_),
    .Y(_558_)
);

OR2X2 _1538_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [1]),
    .B(\u_alien.rom_addr [2]),
    .Y(_457_)
);

OAI21X1 _1118_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_370_),
    .B(_375_),
    .C(_369_),
    .Y(_376_)
);

DFFSR _869_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf1),
    .S(vdd),
    .D(_366_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.sign_y )
);

AOI21X1 _1291_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_91_),
    .B(_86_),
    .C(_68_),
    .Y(_67_)
);

NAND3X1 _1767_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_773_),
    .B(_764_),
    .C(_766_),
    .Y(_763_)
);

NAND3X1 _1347_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_128_),
    .B(_124_),
    .C(_125_),
    .Y(_123_)
);

FILL FILL77850x72150 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL77850x39750 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1576_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_523_),
    .B(_493_),
    .C(_494_),
    .Y(_492_)
);

AOI22X1 _1156_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [3]),
    .B(_290_),
    .C(_48_),
    .D(\u_alien.x_ball [4]),
    .Y(_47_)
);

NAND3X1 _1385_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_178_),
    .B(_161_),
    .C(_169_),
    .Y(_160_)
);

INVX2 _1194_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [3]),
    .Y(_312_)
);

NAND2X1 _1479_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.regAliens [5]),
    .B(lfsr4[2]),
    .Y(_246_)
);

OAI21X1 _1059_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_559_),
    .B(_556_),
    .C(_328_),
    .Y(_561_)
);

NOR2X1 _1288_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.regAliens [1]),
    .B(\u_alien.regAliens [0]),
    .Y(_65_)
);

DFFSR _1500_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_538_),
    .S(vdd),
    .D(_542_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.x_paddle [4])
);

OAI21X1 _1097_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_297_),
    .B(_385_),
    .C(_396_),
    .Y(_397_)
);

FILL FILL78150x72150 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78150x39750 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _925_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_841_),
    .B(_840_),
    .C(_827_),
    .D(_837_),
    .Y(_842_)
);

AOI21X1 _1403_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_180_),
    .B(_179_),
    .C(_182_),
    .Y(_178_)
);

DFFSR _1632_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_800__bF$buf3),
    .D(_808_),
    .CLK(clk_bF$buf6),
    .Q(\u_alien.x_pos [5])
);

INVX2 _1212_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [4]),
    .Y(_330_)
);

INVX1 _963_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_660_),
    .Y(_661_)
);

NAND3X1 _1441_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [0]),
    .B(\u_alien.y_bullet [1]),
    .C(\u_alien.y_bullet [2]),
    .Y(_211_)
);

AOI22X1 _1021_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_330_),
    .B(\u_alien.x_pos [4]),
    .C(_45_),
    .D(\u_alien.x_pos [5]),
    .Y(_598_)
);

OAI21X1 _1670_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_701_),
    .B(_703_),
    .C(_686_),
    .Y(_794_)
);

DFFSR _1250_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_270__bF$buf3),
    .D(_279_),
    .CLK(clk_bF$buf5),
    .Q(\u_alien.regAliens [7])
);

NAND2X1 _1726_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_726_),
    .B(_727_),
    .Y(_725_)
);

NAND2X1 _1306_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [5]),
    .B(_238_),
    .Y(_82_)
);

NAND2X1 _1535_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [5]),
    .B(_455_),
    .Y(_454_)
);

NOR2X1 _1115_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(_24_),
    .Y(_379_)
);

DFFSR _866_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf3),
    .S(vdd),
    .D(_348_),
    .CLK(clk_bF$buf6),
    .Q(\u_alien.x_ball [6])
);

INVX1 _1764_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_761_),
    .Y(_760_)
);

OAI21X1 _1344_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [0]),
    .B(_121_),
    .C(_128_),
    .Y(_120_)
);

OAI21X1 _1573_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_522_),
    .B(_532_),
    .C(_521_),
    .Y(_490_)
);

INVX1 _1153_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [5]),
    .Y(_44_)
);

DFFSR _1629_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_800__bF$buf3),
    .D(_792_),
    .CLK(clk_bF$buf2),
    .Q(\u_alien.rom_addr [1])
);

INVX2 _1209_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_328_),
    .Y(_327_)
);

NAND2X1 _1382_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_159_),
    .B(_158_),
    .Y(_157_)
);

NOR2X1 _1438_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_210_),
    .B(_209_),
    .Y(_208_)
);

AOI22X1 _1018_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_600_),
    .B(\u_alien.x_ball [5]),
    .C(\u_alien.x_ball [6]),
    .D(_589_),
    .Y(_601_)
);

NAND2X1 _1191_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_311_),
    .B(_310_),
    .Y(_309_)
);

AND2X2 _1667_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_684_),
    .B(_752_),
    .Y(_683_)
);

INVX1 _1247_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[2]),
    .Y(_548_)
);

NAND2X1 _998_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [5]),
    .B(_333_),
    .Y(_625_)
);

NAND3X1 _1476_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_251_),
    .B(_244_),
    .C(_248_),
    .Y(_243_)
);

OAI21X1 _1056_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_387_),
    .B(_562_),
    .C(\u_alien.x_pos [3]),
    .Y(_563_)
);

NAND3X1 _1285_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_75_),
    .B(_235_),
    .C(_63_),
    .Y(_62_)
);

NAND2X1 _1094_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(_397_),
    .Y(_400_)
);

DFFSR _1799_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_270__bF$buf0),
    .D(_283_),
    .CLK(clk_bF$buf5),
    .Q(\u_alien.regAliens [5])
);

OAI21X1 _1379_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_219_),
    .B(_166_),
    .C(_155_),
    .Y(_154_)
);

AOI21X1 _922_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_843_),
    .B(_339_),
    .C(_343_),
    .Y(_817_)
);

OAI21X1 _1188_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_326_),
    .B(_307_),
    .C(_308_),
    .Y(_306_)
);

OR2X2 _1400_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_177_),
    .B(\u_alien.y_pos [5]),
    .Y(_175_)
);

INVX1 _960_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_662_),
    .Y(_664_)
);

FILL FILL78150x25350 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1723_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_724_),
    .B(_747_),
    .Y(_723_)
);

OAI21X1 _1303_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.regAliens [1]),
    .B(\u_alien.x_pos [5]),
    .C(_80_),
    .Y(_79_)
);

INVX1 _1532_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_452_),
    .Y(_451_)
);

AOI21X1 _1112_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_377_),
    .B(_378_),
    .C(_381_),
    .Y(_382_)
);

BUFX2 _863_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_857_),
    .Y(p_tick)
);

FILL FILL78450x68550 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX8 _919_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_354_)
);

NOR2X1 _1761_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf0 ),
    .B(_758_),
    .Y(_757_)
);

NAND2X1 _1341_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [0]),
    .B(\u_alien.rom_addr [2]),
    .Y(_117_)
);

OAI21X1 _1570_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_534_),
    .B(_524_),
    .C(\u_ball.x_paddle [5]),
    .Y(_487_)
);

NAND3X1 _1150_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_45_),
    .B(_42_),
    .C(_43_),
    .Y(_41_)
);

DFFSR _1626_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_800__bF$buf0),
    .D(_815_),
    .CLK(clk_bF$buf1),
    .Q(\u_alien.x_pos [1])
);

NAND3X1 _1206_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(\u_alien.x_ball [1]),
    .C(_325_),
    .Y(_324_)
);

OAI21X1 _957_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .B(_609_),
    .C(_613_),
    .Y(_667_)
);

INVX1 _1435_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_bullet [6]),
    .Y(_206_)
);

NOR2X1 _1015_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(\u_ball.y_ball [1]),
    .Y(_604_)
);

NAND2X1 _1664_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [1]),
    .B(\u_alien.rom_addr [0]),
    .Y(_681_)
);

OAI21X1 _1244_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_548_),
    .B(_547_),
    .C(_546_),
    .Y(_553_)
);

OAI21X1 _995_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_334_),
    .B(\u_alien.y_pos [4]),
    .C(_627_),
    .Y(_628_)
);

NOR2X1 _1473_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [4]),
    .B(\u_alien.y_bullet [5]),
    .Y(_240_)
);

OAI22X1 _1053_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [1]),
    .B(_323_),
    .C(_285_),
    .D(\u_alien.x_pos [0]),
    .Y(_566_)
);

OAI21X1 _1529_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [3]),
    .B(_476_),
    .C(_472_),
    .Y(_448_)
);

NAND3X1 _1109_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_383_),
    .B(_384_),
    .C(_27_),
    .Y(_385_)
);

INVX1 _1282_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [6]),
    .Y(_61_)
);

FILL FILL77850x46950 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1758_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [4]),
    .B(\u_alien.x_pos [5]),
    .C(_755_),
    .Y(_754_)
);

OAI21X1 _1338_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [0]),
    .B(_126_),
    .C(\u_alien.rom_addr [1]),
    .Y(_114_)
);

OAI21X1 _1091_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_325_),
    .B(_341_),
    .C(_401_),
    .Y(_363_)
);

NAND2X1 _1567_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_514_),
    .B(_523_),
    .Y(_485_)
);

NOR2X1 _1147_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_44_),
    .B(_50_),
    .Y(_38_)
);

OAI21X1 _898_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_326_),
    .B(_317_),
    .C(_3_),
    .Y(_7_)
);

NAND2X1 _1796_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_847_),
    .B(_848_),
    .Y(_858_)
);

AOI22X1 _1376_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_175_),
    .B(_176_),
    .C(\u_alien.y_bullet [4]),
    .D(_195_),
    .Y(_151_)
);

NAND2X1 _1185_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_305_),
    .B(_304_),
    .Y(_303_)
);

INVX8 _1699_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_800_)
);

AOI21X1 _1279_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_59_),
    .B(_61_),
    .C(_84_),
    .Y(_269_)
);

NOR2X1 _1088_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_326_),
    .B(_45_),
    .Y(_404_)
);

FILL FILL78150x46950 (
    .gnd(gnd),
    .vdd(vdd)
);

FILL FILL78150x7350 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1720_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_754_),
    .B(_722_),
    .Y(_721_)
);

OAI21X1 _1300_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.regAliens [5]),
    .B(_134_),
    .C(_77_),
    .Y(_76_)
);

NOR2X1 _916_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .B(_334_),
    .Y(_849_)
);

DFFSR _1623_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_800__bF$buf2),
    .D(_789_),
    .CLK(clk_bF$buf7),
    .Q(\u_alien.y_pos [4])
);

AND2X2 _1203_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_322_),
    .B(_324_),
    .Y(_321_)
);

NOR2X1 _954_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [1]),
    .B(_338_),
    .Y(_801_)
);

NAND2X1 _1432_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[0]),
    .B(_233_),
    .Y(_203_)
);

INVX1 _1012_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_606_),
    .Y(_607_)
);

NAND2X1 _1661_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_681_),
    .B(_679_),
    .Y(_678_)
);

NAND3X1 _1241_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(en_lfsr4),
    .B(_545_),
    .C(_544_),
    .Y(_539_)
);

OAI21X1 _992_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_610_),
    .B(_613_),
    .C(_630_),
    .Y(_631_)
);

INVX1 _1717_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_720_),
    .Y(_719_)
);

NAND2X1 _1470_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.regAliens [6]),
    .B(lfsr4[2]),
    .Y(_237_)
);

OAI21X1 _1050_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [1]),
    .B(\u_alien.x_ball [0]),
    .C(_317_),
    .Y(_569_)
);

FILL FILL78450x54150 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1526_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_520_),
    .B(\u_alien.x_pos [4]),
    .C(_450_),
    .Y(_445_)
);

NAND3X1 _1106_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [4]),
    .B(\u_alien.x_ball [5]),
    .C(_387_),
    .Y(_388_)
);

NAND3X1 _1755_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_773_),
    .B(_752_),
    .C(_753_),
    .Y(_751_)
);

NAND2X1 _1335_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_113_),
    .B(_112_),
    .Y(_111_)
);

NAND2X1 _1564_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [2]),
    .B(_484_),
    .Y(_483_)
);

INVX1 _1144_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .Y(_35_)
);

OAI21X1 _895_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_344_),
    .B(_9_),
    .C(_6_),
    .Y(_349_)
);

INVX1 _1793_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [1]),
    .Y(_787_)
);

OAI21X1 _1373_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_181_),
    .B(_149_),
    .C(\u_alien.y_bullet [0]),
    .Y(_148_)
);

NOR3X1 _1429_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(_239_),
    .C(_201_),
    .Y(_200_)
);

NOR2X1 _1009_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .B(_609_),
    .Y(_610_)
);

NAND2X1 _1182_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_301_),
    .B(_302_),
    .Y(_300_)
);

OAI21X1 _1658_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_682_),
    .B(_680_),
    .C(_677_),
    .Y(_676_)
);

INVX1 _1238_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[1]),
    .Y(_424_)
);

AOI21X1 _989_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_631_),
    .B(_632_),
    .C(_633_),
    .Y(_635_)
);

NAND2X1 _1467_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.regAliens [7]),
    .B(lfsr4[2]),
    .Y(_234_)
);

NAND2X1 _1047_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_563_),
    .B(_571_),
    .Y(_572_)
);

OAI21X1 _1696_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_741_),
    .B(_707_),
    .C(\u_ctrl.State_3_bF$buf1 ),
    .Y(_706_)
);

NAND2X1 _1276_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [5]),
    .B(_190_),
    .Y(_57_)
);

NOR2X1 _1085_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_406_),
    .B(_402_),
    .Y(_407_)
);

OAI21X1 _913_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_410_),
    .B(_335_),
    .C(_851_),
    .Y(_852_)
);

INVX1 _1599_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .Y(_514_)
);

NOR2X1 _1179_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(_299_),
    .Y(_298_)
);

INVX1 _1620_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .Y(_535_)
);

NAND2X1 _1200_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [2]),
    .B(_326_),
    .Y(_318_)
);

OAI21X1 _951_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_668_),
    .B(_804_),
    .C(_666_),
    .Y(_805_)
);

FILL FILL78150x32550 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1714_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_new),
    .B(\u_ctrl.State [0]),
    .Y(_717_)
);

INVX1 _1523_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [5]),
    .Y(_442_)
);

INVX1 _1103_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_390_),
    .Y(_391_)
);

FILL FILL78450x75750 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1752_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_763_),
    .B(_757_),
    .C(_749_),
    .Y(_813_)
);

INVX1 _1332_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_109_),
    .Y(_108_)
);

INVX1 _1561_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [2]),
    .Y(_480_)
);

OAI21X1 _1141_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_33_),
    .B(_34_),
    .C(\u_alien.x_ball [6]),
    .Y(_32_)
);

NAND2X1 _892_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_326_),
    .B(_30_),
    .Y(_12_)
);

INVX2 _1617_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_left),
    .Y(_532_)
);

NAND2X1 _948_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_818_),
    .B(_816_),
    .Y(_819_)
);

NAND2X1 _1790_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_787_),
    .B(_785_),
    .Y(_784_)
);

NOR3X1 _1370_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_151_),
    .B(_146_),
    .C(_152_),
    .Y(_145_)
);

OAI21X1 _1426_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_206_),
    .B(_200_),
    .C(_198_),
    .Y(_277_)
);

AOI22X1 _1006_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_609_),
    .B(\u_ball.y_ball [1]),
    .C(\u_ball.y_ball [0]),
    .D(_612_),
    .Y(_613_)
);

FILL FILL77850x7350 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1655_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_677_),
    .B(_681_),
    .C(_742_),
    .Y(_674_)
);

INVX2 _1235_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(reset),
    .Y(_550_)
);

NAND3X1 _986_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .B(_626_),
    .C(_605_),
    .Y(_638_)
);

AOI21X1 _1464_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_232_),
    .B(lfsr4[1]),
    .C(_239_),
    .Y(_231_)
);

NAND3X1 _1044_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [4]),
    .B(\u_alien.x_ball [3]),
    .C(_574_),
    .Y(_575_)
);

INVX1 _1693_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(alien_flip),
    .Y(_704_)
);

NAND2X1 _1273_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_55_),
    .B(_220_),
    .Y(_54_)
);

OAI21X1 _1749_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_748_),
    .B(_747_),
    .C(_756_),
    .Y(_746_)
);

NAND2X1 _1329_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_106_),
    .B(_107_),
    .Y(_105_)
);

OAI21X1 _1082_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_45_),
    .B(_343_),
    .C(_409_),
    .Y(_362_)
);

AOI21X1 _1558_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(_481_),
    .C(_478_),
    .Y(_477_)
);

OAI21X1 _1138_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(_38_),
    .C(_30_),
    .Y(_29_)
);

OR2X2 _889_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_10_),
    .B(_13_),
    .Y(_15_)
);

AOI22X1 _1787_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_787_),
    .B(_782_),
    .C(_783_),
    .D(\u_ctrl.State_3_bF$buf3 ),
    .Y(_815_)
);

OAI22X1 _1367_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [4]),
    .B(_143_),
    .C(_206_),
    .D(\u_alien.x_pos [6]),
    .Y(_142_)
);

OAI21X1 _910_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_344_),
    .B(_854_),
    .C(_845_),
    .Y(_353_)
);

OAI21X1 _1596_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_514_),
    .B(_512_),
    .C(_513_),
    .Y(_511_)
);

INVX1 _1176_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .Y(_295_)
);

DFFSR _1499_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_538_),
    .S(vdd),
    .D(_537_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.x_paddle [2])
);

NAND2X1 _1079_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [1]),
    .B(_410_),
    .Y(_411_)
);

AOI21X1 _1711_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [4]),
    .B(_717_),
    .C(_715_),
    .Y(_806_)
);

OAI21X1 _1520_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .B(_480_),
    .C(_470_),
    .Y(_439_)
);

OAI21X1 _1100_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [6]),
    .B(_393_),
    .C(_392_),
    .Y(_394_)
);

FILL FILL78450x3750 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI22X1 _907_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_285_),
    .B(_860_),
    .C(_855_),
    .D(_327_),
    .Y(_352_)
);

NOR2X1 _1614_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .B(\u_ball.x_paddle [3]),
    .Y(_529_)
);

NAND2X1 _945_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_564_),
    .B(_595_),
    .Y(_822_)
);

NOR2X1 _1423_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_196_),
    .B(_211_),
    .Y(_195_)
);

NAND3X1 _1003_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_615_),
    .B(_611_),
    .C(_614_),
    .Y(_617_)
);

OAI21X1 _1652_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_742_),
    .B(_776_),
    .C(\u_ctrl.State_3_bF$buf1 ),
    .Y(_672_)
);

DFFSR _1232_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_550_),
    .D(_553_),
    .CLK(clk_bF$buf3),
    .Q(lfsr4[3])
);

AOI21X1 _983_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_637_),
    .B(_638_),
    .C(_640_),
    .Y(_641_)
);

AOI21X1 _1708_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_714_),
    .B(_713_),
    .C(game_new),
    .Y(_616_)
);

FILL FILL78450x61350 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND2X1 _1461_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_859_),
    .B(_239_),
    .Y(_228_)
);

NAND3X1 _1041_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_573_),
    .B(_575_),
    .C(_577_),
    .Y(_578_)
);

FILL FILL78450x28950 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1517_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_520_),
    .B(\u_alien.x_pos [4]),
    .C(_454_),
    .Y(_436_)
);

INVX1 _1690_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_alien_flip [1]),
    .Y(_701_)
);

AOI21X1 _1270_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_58_),
    .B(_215_),
    .C(_235_),
    .Y(_265_)
);

NOR2X1 _1746_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [0]),
    .B(\u_ctrl.State [2]),
    .Y(_744_)
);

AOI21X1 _1326_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_103_),
    .B(_139_),
    .C(\u_alien.x_pos [2]),
    .Y(_102_)
);

NOR2X1 _1555_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [3]),
    .B(_517_),
    .Y(_474_)
);

OAI21X1 _1135_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .C(\u_ball.x_paddle [3]),
    .Y(_26_)
);

NAND3X1 _886_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .B(\u_ball.y_ball [5]),
    .C(_605_),
    .Y(_17_)
);

OAI21X1 _1784_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_787_),
    .B(_785_),
    .C(_781_),
    .Y(_779_)
);

INVX2 _1364_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [0]),
    .Y(_139_)
);

NAND3X1 _1593_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_518_),
    .B(_515_),
    .C(_509_),
    .Y(_508_)
);

INVX1 _1173_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [3]),
    .Y(_292_)
);

OAI21X1 _1649_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf1 ),
    .B(\u_ctrl.State [0]),
    .C(_785_),
    .Y(_670_)
);

DFFSR _1229_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf2),
    .S(vdd),
    .D(_803_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.hit_paddle )
);

AND2X2 _1458_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_226_),
    .B(_227_),
    .Y(_225_)
);

NAND2X1 _1038_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_579_),
    .B(_580_),
    .Y(_581_)
);

AND2X2 _1687_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_700_),
    .B(_699_),
    .Y(_698_)
);

OAI21X1 _1267_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_143_),
    .B(_200_),
    .C(_53_),
    .Y(_263_)
);

INVX1 _1496_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.regAliens [5]),
    .Y(_261_)
);

AOI21X1 _1076_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(_413_),
    .C(_327_),
    .Y(_414_)
);

OAI22X1 _904_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_323_),
    .B(_343_),
    .C(_2_),
    .D(_1_),
    .Y(_351_)
);

NAND2X1 _1399_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_176_),
    .B(_175_),
    .Y(_174_)
);

INVX1 _1611_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_527_),
    .Y(_526_)
);

NAND2X1 _942_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_823_),
    .B(_824_),
    .Y(_825_)
);

CLKBUF1 CLKBUF1_insert10 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf2)
);

CLKBUF1 CLKBUF1_insert11 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf1)
);

CLKBUF1 CLKBUF1_insert12 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf0)
);

NAND3X1 _1420_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_223_),
    .B(_193_),
    .C(_220_),
    .Y(_192_)
);

NAND2X1 _1000_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_622_),
    .B(_617_),
    .Y(_623_)
);

OAI21X1 _980_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_594_),
    .B(_602_),
    .C(_643_),
    .Y(_644_)
);

NAND2X1 _1705_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .B(_761_),
    .Y(_711_)
);

OAI21X1 _1514_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_450_),
    .B(_435_),
    .C(_434_),
    .Y(_433_)
);

INVX1 _1743_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [4]),
    .Y(_741_)
);

AOI21X1 _1323_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_123_),
    .B(_100_),
    .C(\u_alien.x_pos [0]),
    .Y(_99_)
);

AND2X2 _1552_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_483_),
    .B(_479_),
    .Y(_471_)
);

OAI21X1 _1132_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_51_),
    .B(_26_),
    .C(_44_),
    .Y(_23_)
);

MUX2X1 _883_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_849_),
    .B(_846_),
    .S(_852_),
    .Y(_19_)
);

NOR2X1 _1608_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_534_),
    .B(_524_),
    .Y(_523_)
);

NAND2X1 _939_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [0]),
    .B(_285_),
    .Y(_828_)
);

INVX1 _1781_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [5]),
    .Y(_777_)
);

INVX1 _1361_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [5]),
    .Y(_136_)
);

NAND2X1 _1417_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [4]),
    .B(_195_),
    .Y(_190_)
);

NAND3X1 _1590_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_507_),
    .B(_506_),
    .C(_508_),
    .Y(_505_)
);

NOR2X1 _1170_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(\u_ball.x_paddle [2]),
    .Y(_289_)
);

DFFSR _1646_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_800__bF$buf2),
    .S(vdd),
    .D(_621_),
    .CLK(clk_bF$buf7),
    .Q(\u_ctrl.State [1])
);

INVX4 _1226_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_344_),
    .Y(_343_)
);

INVX1 _977_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_592_),
    .Y(_647_)
);

INVX2 _1455_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .Y(_223_)
);

NAND2X1 _1035_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_45_),
    .B(_575_),
    .Y(_584_)
);

AOI21X1 _1684_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_697_),
    .B(\u_ctrl.State [1]),
    .C(\u_ctrl.State_3_bF$buf0 ),
    .Y(_696_)
);

DFFSR _1264_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_270__bF$buf2),
    .S(vdd),
    .D(_278_),
    .CLK(clk_bF$buf3),
    .Q(\u_alien.y_bullet [2])
);

NAND2X1 _1493_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_859_),
    .B(hit_alien),
    .Y(_258_)
);

NAND2X1 _1073_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(_413_),
    .Y(_416_)
);

FILL FILL77550x72150 (
    .gnd(gnd),
    .vdd(vdd)
);

NAND3X1 _1549_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_483_),
    .B(_470_),
    .C(_469_),
    .Y(_468_)
);

OAI21X1 _1129_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_292_),
    .B(_289_),
    .C(_51_),
    .Y(_356_)
);

NAND3X1 _1778_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [3]),
    .B(\u_alien.y_pos [4]),
    .C(_775_),
    .Y(_774_)
);

INVX1 _1358_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_bullet [5]),
    .Y(_133_)
);

NAND2X1 _901_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_4_),
    .B(_3_),
    .Y(_5_)
);

INVX1 _1587_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_523_),
    .Y(_502_)
);

NOR2X1 _1167_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [2]),
    .B(_287_),
    .Y(_286_)
);

NAND2X1 _1396_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [4]),
    .B(_191_),
    .Y(_171_)
);

NOR2X1 _1702_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_767_),
    .B(_737_),
    .Y(_621_)
);

INVX1 _1299_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.regAliens [7]),
    .Y(_75_)
);

INVX1 _1511_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_512_),
    .Y(_432_)
);

INVX1 _1740_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_739_),
    .Y(_738_)
);

NAND3X1 _1320_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_140_),
    .B(_107_),
    .C(_97_),
    .Y(_96_)
);

AOI21X1 _880_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_333_),
    .B(_20_),
    .C(_21_),
    .Y(_346_)
);

INVX2 _1605_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [4]),
    .Y(_520_)
);

OAI21X1 _936_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(_612_),
    .C(_666_),
    .Y(_831_)
);

NOR2X1 _1414_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_188_),
    .B(_189_),
    .Y(_187_)
);

DFFSR _1643_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_800__bF$buf4),
    .S(vdd),
    .D(_813_),
    .CLK(clk_bF$buf7),
    .Q(\u_ctrl.cnt_v_sync [2])
);

OAI21X1 _1223_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .B(_341_),
    .C(_345_),
    .Y(_340_)
);

AND2X2 _974_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_624_),
    .B(_629_),
    .Y(_650_)
);

NAND3X1 _1452_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_223_),
    .B(_228_),
    .C(_221_),
    .Y(_220_)
);

AND2X2 _1032_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_586_),
    .B(_582_),
    .Y(_587_)
);

NAND2X1 _1508_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_514_),
    .B(_431_),
    .Y(_429_)
);

NAND2X1 _1681_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [0]),
    .B(\u_ctrl.cnt_v_sync [1]),
    .Y(_694_)
);

DFFSR _1261_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_270__bF$buf3),
    .D(_269_),
    .CLK(clk_bF$buf5),
    .Q(\u_alien.regAliens [0])
);

NAND2X1 _1737_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_736_),
    .B(_765_),
    .Y(_735_)
);

AOI21X1 _1317_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_121_),
    .B(alien_flip),
    .C(_140_),
    .Y(_93_)
);

INVX1 _1490_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_256_),
    .Y(_255_)
);

NAND2X1 _1070_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_410_),
    .B(_337_),
    .Y(_419_)
);

OAI21X1 _1546_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [1]),
    .B(_481_),
    .C(_478_),
    .Y(_465_)
);

NAND2X1 _1126_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_26_),
    .B(_367_),
    .Y(_368_)
);

DFFSR _877_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf0),
    .S(vdd),
    .D(_365_),
    .CLK(clk_bF$buf4),
    .Q(\u_alien.x_ball [4])
);

INVX1 _1775_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [4]),
    .Y(_771_)
);

NAND3X1 _1355_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_137_),
    .B(_141_),
    .C(_131_),
    .Y(_130_)
);

AND2X2 _1584_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_500_),
    .B(_518_),
    .Y(_499_)
);

AOI21X1 _1164_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_285_),
    .B(gnd),
    .C(_284_),
    .Y(_274_)
);

AND2X2 _1393_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [2]),
    .B(\u_alien.rom_addr [2]),
    .Y(_168_)
);

NOR2X1 _1449_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_218_),
    .B(_219_),
    .Y(_217_)
);

OAI21X1 _1029_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_30_),
    .B(_388_),
    .C(_589_),
    .Y(_590_)
);

OAI21X1 _1678_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_750_),
    .B(_751_),
    .C(\u_ctrl.cnt_v_sync [1]),
    .Y(_691_)
);

DFFSR _1258_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_270__bF$buf0),
    .S(vdd),
    .D(_262_),
    .CLK(clk_bF$buf2),
    .Q(\u_alien.x_bullet [5])
);

INVX1 _1487_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [5]),
    .Y(_253_)
);

NAND2X1 _1067_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_859_),
    .B(_421_),
    .Y(_554_)
);

NAND3X1 _1296_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [6]),
    .B(_73_),
    .C(_76_),
    .Y(_72_)
);

INVX1 _1602_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [3]),
    .Y(_517_)
);

OAI22X1 _933_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_666_),
    .B(_833_),
    .C(_667_),
    .D(_831_),
    .Y(_834_)
);

INVX2 _1199_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [2]),
    .Y(_317_)
);

INVX2 _1411_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_239_),
    .Y(en_lfsr4)
);

DFFSR _1640_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_800__bF$buf4),
    .S(vdd),
    .D(_797_),
    .CLK(clk_bF$buf7),
    .Q(\u_ctrl.cnt_v_sync [0])
);

INVX2 _1220_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [2]),
    .Y(_337_)
);

INVX1 _971_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_652_),
    .Y(_653_)
);

OR2X2 _1505_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_511_),
    .B(_510_),
    .Y(_427_)
);

FILL FILL78150x68550 (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _1734_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_767_),
    .B(_735_),
    .C(_733_),
    .Y(_732_)
);

OAI21X1 _1314_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [2]),
    .B(_112_),
    .C(_139_),
    .Y(_90_)
);

OR2X2 _1543_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_463_),
    .B(_467_),
    .Y(_462_)
);

NOR2X1 _1123_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_317_),
    .B(_287_),
    .Y(_371_)
);

DFFSR _874_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf3),
    .S(vdd),
    .D(_352_),
    .CLK(clk_bF$buf6),
    .Q(\u_alien.x_ball [0])
);

NOR2X1 _1772_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_856_),
    .B(_0_),
    .Y(_768_)
);

INVX1 _1352_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(alien_flip),
    .Y(_128_)
);

NAND2X1 _1408_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [0]),
    .B(_229_),
    .Y(_183_)
);

OAI21X1 _1581_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_502_),
    .B(_497_),
    .C(\u_ball.x_paddle [6]),
    .Y(_496_)
);

OAI21X1 _1161_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [3]),
    .B(_290_),
    .C(_272_),
    .Y(_271_)
);

DFFSR _1637_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_800__bF$buf2),
    .S(vdd),
    .D(_620_),
    .CLK(clk_bF$buf7),
    .Q(\u_ctrl.State [2])
);

INVX1 _1217_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .Y(_334_)
);

INVX1 _968_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_565_),
    .Y(_656_)
);

NAND2X1 _1390_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [3]),
    .B(\u_alien.y_pos [3]),
    .Y(_165_)
);

NOR2X1 _1446_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_260_),
    .B(_253_),
    .Y(_215_)
);

OAI21X1 _1026_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_591_),
    .B(_587_),
    .C(_592_),
    .Y(_593_)
);

NAND2X1 _1675_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_702_),
    .B(_703_),
    .Y(_689_)
);

DFFSR _1255_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_270__bF$buf0),
    .D(_266_),
    .CLK(clk_bF$buf5),
    .Q(\u_alien.regAliens [2])
);

FILL FILL77550x46950 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1484_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[1]),
    .Y(_251_)
);

OAI21X1 _1064_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_410_),
    .B(_337_),
    .C(_421_),
    .Y(_556_)
);

AOI21X1 _1293_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_137_),
    .B(_129_),
    .C(_70_),
    .Y(_69_)
);

INVX1 _1769_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .Y(_765_)
);

NAND3X1 _1349_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_185_),
    .B(_127_),
    .C(_126_),
    .Y(_125_)
);

OR2X2 _1578_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_500_),
    .B(_495_),
    .Y(_494_)
);

NAND2X1 _1158_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_51_),
    .B(_293_),
    .Y(_49_)
);

NAND2X1 _1387_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_165_),
    .B(_163_),
    .Y(_162_)
);

AOI21X1 _930_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_836_),
    .B(_835_),
    .C(_660_),
    .Y(_837_)
);

INVX1 _1196_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_315_),
    .Y(_314_)
);

BUFX2 BUFX2_insert13 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_270_),
    .Y(_270__bF$buf3)
);

BUFX2 BUFX2_insert14 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_270_),
    .Y(_270__bF$buf2)
);

BUFX2 BUFX2_insert15 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_270_),
    .Y(_270__bF$buf1)
);

BUFX2 BUFX2_insert16 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_270_),
    .Y(_270__bF$buf0)
);

BUFX2 BUFX2_insert17 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_354_),
    .Y(_354__bF$buf3)
);

BUFX2 BUFX2_insert18 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_354_),
    .Y(_354__bF$buf2)
);

BUFX2 BUFX2_insert19 (
    .gnd(gnd),
    .vdd(vdd),
    .A(_354_),
    .Y(_354__bF$buf1)
);

FILL FILL77850x54150 (
    .gnd(gnd),
    .vdd(vdd)
);

DFFSR _1502_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_538_),
    .S(vdd),
    .D(_541_),
    .CLK(clk_bF$buf5),
    .Q(\u_ball.x_paddle [5])
);

NOR2X1 _1099_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_394_),
    .B(_391_),
    .Y(_395_)
);

INVX1 _1731_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_732_),
    .Y(_729_)
);

AOI21X1 _1311_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_89_),
    .B(_88_),
    .C(_140_),
    .Y(_87_)
);

NOR2X1 _1540_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_460_),
    .B(_470_),
    .Y(_459_)
);

OAI21X1 _1120_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_323_),
    .B(_296_),
    .C(_373_),
    .Y(_374_)
);

DFFSR _871_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_354__bF$buf2),
    .D(_359_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.y_ball [2])
);

AOI22X1 _927_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_645_),
    .B(_659_),
    .C(_839_),
    .D(_838_),
    .Y(_840_)
);

INVX1 _1405_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_181_),
    .Y(_180_)
);

DFFSR _1634_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_800__bF$buf0),
    .D(_812_),
    .CLK(clk_bF$buf6),
    .Q(\u_alien.x_pos [6])
);

OAI21X1 _1214_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_336_),
    .B(_332_),
    .C(_339_),
    .Y(_331_)
);

NAND2X1 _965_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_658_),
    .B(_655_),
    .Y(_659_)
);

INVX1 _1443_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_213_),
    .Y(_279_)
);

AOI22X1 _1023_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_312_),
    .B(\u_alien.x_pos [3]),
    .C(_567_),
    .D(_595_),
    .Y(_596_)
);

FILL FILL78150x54150 (
    .gnd(gnd),
    .vdd(vdd)
);

NOR2X1 _1672_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_alien_flip [1]),
    .B(_702_),
    .Y(_687_)
);

DFFSR _1252_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_270__bF$buf3),
    .D(_282_),
    .CLK(clk_bF$buf5),
    .Q(\u_alien.regAliens [6])
);

INVX1 _1728_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_755_),
    .Y(_727_)
);

INVX1 _1308_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.regAliens [0]),
    .Y(_84_)
);

OAI21X1 _1481_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[2]),
    .B(\u_alien.regAliens [0]),
    .C(_249_),
    .Y(_248_)
);

NOR2X1 _1061_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_557_),
    .B(_558_),
    .Y(_559_)
);

AOI21X1 _1537_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_462_),
    .B(_458_),
    .C(_457_),
    .Y(_456_)
);

OAI21X1 _1117_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [4]),
    .B(_357_),
    .C(_376_),
    .Y(_377_)
);

DFFSR _868_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf0),
    .S(vdd),
    .D(_349_),
    .CLK(clk_bF$buf4),
    .Q(\u_alien.x_ball [3])
);

OAI21X1 _1290_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_129_),
    .B(_101_),
    .C(_67_),
    .Y(_66_)
);

OR2X2 _1766_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [0]),
    .B(\u_ctrl.cnt_v_sync [1]),
    .Y(_762_)
);

NAND2X1 _1346_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [0]),
    .B(_123_),
    .Y(_122_)
);

OAI21X1 _1575_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_520_),
    .B(_523_),
    .C(_492_),
    .Y(_542_)
);

AND2X2 _1155_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_271_),
    .B(_47_),
    .Y(_46_)
);

NAND2X1 _1384_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_195_),
    .B(_170_),
    .Y(_159_)
);

NAND2X1 _1193_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .B(_312_),
    .Y(_311_)
);

OAI21X1 _1669_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf1 ),
    .B(\u_ctrl.State [0]),
    .C(_766_),
    .Y(_685_)
);

DFFSR _1249_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_270__bF$buf1),
    .S(vdd),
    .D(_263_),
    .CLK(clk_bF$buf2),
    .Q(\u_alien.x_bullet [4])
);

OAI21X1 _1478_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[2]),
    .B(_247_),
    .C(_246_),
    .Y(_245_)
);

OAI22X1 _1058_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_335_),
    .B(_343_),
    .C(_561_),
    .D(_560_),
    .Y(_358_)
);

NAND3X1 _1287_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_238_),
    .B(_250_),
    .C(_65_),
    .Y(_64_)
);

NOR2X1 _1096_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_297_),
    .B(_27_),
    .Y(_398_)
);

AND2X2 _924_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_842_),
    .B(_645_),
    .Y(pixel_ball)
);

INVX1 _1402_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [5]),
    .Y(_177_)
);

DFFSR _1631_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_800__bF$buf3),
    .D(_793_),
    .CLK(clk_bF$buf2),
    .Q(\u_alien.rom_addr [0])
);

INVX1 _1211_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_859_),
    .Y(_329_)
);

NAND2X1 _962_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_615_),
    .B(_630_),
    .Y(_662_)
);

INVX1 _1440_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_211_),
    .Y(_210_)
);

OAI21X1 _1020_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_597_),
    .B(_596_),
    .C(_598_),
    .Y(_599_)
);

FILL FILL78150x75750 (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1725_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_772_),
    .B(_782_),
    .C(_725_),
    .D(\u_ctrl.State_3_bF$buf3 ),
    .Y(_810_)
);

NAND3X1 _1305_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_134_),
    .B(_82_),
    .C(_83_),
    .Y(_81_)
);

INVX1 _1534_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [6]),
    .Y(_453_)
);

NAND2X1 _1114_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(_24_),
    .Y(_380_)
);

BUFX2 _865_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_0_),
    .Y(game_complete)
);

NAND3X1 _1763_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.cnt_v_sync [2]),
    .B(\u_ctrl.State [1]),
    .C(_762_),
    .Y(_759_)
);

AOI21X1 _1343_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_120_),
    .B(_139_),
    .C(\u_alien.x_pos [1]),
    .Y(_119_)
);

OR2X2 _1572_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_498_),
    .B(_490_),
    .Y(_489_)
);

OR2X2 _1152_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_50_),
    .B(_44_),
    .Y(_43_)
);

DFFSR _1628_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_800__bF$buf2),
    .S(vdd),
    .D(_807_),
    .CLK(clk_bF$buf7),
    .Q(_859_)
);

INVX2 _1208_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_x ),
    .Y(_326_)
);

NAND3X1 _959_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_611_),
    .B(_614_),
    .C(_664_),
    .Y(_665_)
);

OAI21X1 _1381_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_210_),
    .B(_162_),
    .C(_182_),
    .Y(_156_)
);

NAND2X1 _1437_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_208_),
    .B(_220_),
    .Y(_207_)
);

AND2X2 _1017_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_599_),
    .B(_601_),
    .Y(_602_)
);

NAND2X1 _1190_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_309_),
    .B(_313_),
    .Y(_308_)
);

MUX2X1 _1666_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_683_),
    .B(_685_),
    .S(\u_alien.rom_addr [0]),
    .Y(_793_)
);

INVX1 _1246_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(en_lfsr4),
    .Y(_547_)
);

INVX1 _997_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [4]),
    .Y(_626_)
);

NOR2X1 _1475_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [0]),
    .B(\u_alien.y_bullet [1]),
    .Y(_242_)
);

NAND2X1 _1055_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [2]),
    .B(_317_),
    .Y(_564_)
);

NOR2X1 _1284_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_64_),
    .B(_62_),
    .Y(_0_)
);

OAI21X1 _1093_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_397_),
    .B(_399_),
    .C(_400_),
    .Y(_364_)
);

NAND2X1 _1569_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_487_),
    .B(_488_),
    .Y(_541_)
);

OAI21X1 _1149_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [4]),
    .B(_48_),
    .C(_41_),
    .Y(_40_)
);

DFFSR _1798_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_550_),
    .D(_549_),
    .CLK(clk_bF$buf3),
    .Q(lfsr4[2])
);

NOR2X1 _1378_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_156_),
    .B(_154_),
    .Y(_153_)
);

NAND3X1 _921_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(pixel_paddle),
    .B(_645_),
    .C(_842_),
    .Y(_844_)
);

NAND2X1 _1187_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [4]),
    .B(_326_),
    .Y(_305_)
);

FILL FILL77850x28950 (
    .gnd(gnd),
    .vdd(vdd)
);

AOI22X1 _1722_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_771_),
    .B(_782_),
    .C(_723_),
    .D(\u_ctrl.State_3_bF$buf3 ),
    .Y(_809_)
);

NAND3X1 _1302_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_85_),
    .B(_81_),
    .C(_79_),
    .Y(_78_)
);

OAI21X1 _1531_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [5]),
    .B(_455_),
    .C(_451_),
    .Y(_450_)
);

OAI21X1 _1111_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [5]),
    .B(_355_),
    .C(_382_),
    .Y(_383_)
);

BUFX2 _862_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_858_),
    .Y(pixel)
);

NAND2X1 _918_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .B(_344_),
    .Y(_845_)
);

INVX1 _1760_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [6]),
    .Y(_756_)
);

AOI21X1 _1340_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_117_),
    .B(alien_flip),
    .C(\u_alien.x_pos [0]),
    .Y(_116_)
);

DFFSR _1625_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_800__bF$buf4),
    .D(_790_),
    .CLK(clk_bF$buf1),
    .Q(\u_alien.y_pos [3])
);

INVX2 _1205_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [1]),
    .Y(_323_)
);

INVX1 _956_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_667_),
    .Y(_668_)
);

FILL FILL78150x61350 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1434_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[0]),
    .Y(_205_)
);

AOI21X1 _1014_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_604_),
    .B(_337_),
    .C(_335_),
    .Y(_605_)
);

FILL FILL78150x28950 (
    .gnd(gnd),
    .vdd(vdd)
);

INVX1 _1663_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [0]),
    .Y(_680_)
);

NAND2X1 _1243_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[3]),
    .B(lfsr4[2]),
    .Y(_545_)
);

AOI22X1 _994_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_608_),
    .B(_603_),
    .C(_625_),
    .D(_628_),
    .Y(_629_)
);

AOI22X1 _1719_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_748_),
    .B(_782_),
    .C(_721_),
    .D(\u_ctrl.State_3_bF$buf3 ),
    .Y(_808_)
);

NAND3X1 _1472_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_242_),
    .B(_241_),
    .C(_240_),
    .Y(_239_)
);

NAND3X1 _1052_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_564_),
    .B(_565_),
    .C(_566_),
    .Y(_567_)
);

OR2X2 _1528_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [4]),
    .B(\u_alien.x_pos [4]),
    .Y(_447_)
);

NOR2X1 _1108_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [1]),
    .B(\u_alien.x_ball [0]),
    .Y(_386_)
);

NAND2X1 _1281_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_260_),
    .B(_253_),
    .Y(_60_)
);

OAI21X1 _1757_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_756_),
    .B(_754_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_753_)
);

NAND2X1 _1337_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_128_),
    .B(_114_),
    .Y(_113_)
);

OAI21X1 _1090_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_330_),
    .B(_326_),
    .C(_301_),
    .Y(_402_)
);

NAND2X1 _1566_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_486_),
    .B(_485_),
    .Y(_540_)
);

INVX1 _1146_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_42_),
    .Y(_37_)
);

AOI21X1 _897_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_7_),
    .B(_309_),
    .C(game_init),
    .Y(_8_)
);

NOR2X1 _1795_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(pixel_paddle),
    .B(pixel_alien),
    .Y(_848_)
);

OAI21X1 _1375_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_167_),
    .B(_168_),
    .C(_219_),
    .Y(_150_)
);

OR2X2 _1184_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_306_),
    .B(_303_),
    .Y(_302_)
);

FILL FILL78450x36150 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1469_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[2]),
    .B(_238_),
    .C(_237_),
    .Y(_236_)
);

OAI21X1 _1049_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_317_),
    .B(_568_),
    .C(_569_),
    .Y(_570_)
);

INVX1 _1698_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_782_),
    .Y(_708_)
);

NOR2X1 _1278_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [6]),
    .B(_258_),
    .Y(_58_)
);

INVX1 _1087_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_404_),
    .Y(_405_)
);

NOR2X1 _915_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_846_),
    .B(_849_),
    .Y(_850_)
);

DFFSR _1622_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_800__bF$buf1),
    .S(vdd),
    .D(_618_),
    .CLK(clk_bF$buf2),
    .Q(\u_ctrl.State [3])
);

OAI21X1 _1202_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x2 ),
    .B(\u_alien.x_ball [0]),
    .C(_321_),
    .Y(_320_)
);

NOR2X1 _953_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_610_),
    .B(_801_),
    .Y(_802_)
);

NAND2X1 _1431_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_204_),
    .B(_203_),
    .Y(_202_)
);

NOR2X1 _1011_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_605_),
    .B(_607_),
    .Y(_608_)
);

AOI22X1 _1660_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_682_),
    .B(_685_),
    .C(_683_),
    .D(_678_),
    .Y(_792_)
);

NAND2X1 _1240_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[0]),
    .B(_547_),
    .Y(_425_)
);

AOI22X1 _991_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_337_),
    .B(\u_alien.rom_addr [2]),
    .C(_335_),
    .D(\u_alien.y_pos [3]),
    .Y(_632_)
);

OAI21X1 _1716_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_733_),
    .B(_751_),
    .C(_859_),
    .Y(_718_)
);

NAND2X1 _1525_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_446_),
    .B(_445_),
    .Y(_444_)
);

INVX1 _1105_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_388_),
    .Y(_389_)
);

INVX1 _1754_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_764_),
    .Y(_750_)
);

AND2X2 _1334_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [0]),
    .B(\u_alien.rom_addr [2]),
    .Y(_110_)
);

INVX1 _1563_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_483_),
    .Y(_482_)
);

NOR2X1 _1143_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_35_),
    .B(_43_),
    .Y(_34_)
);

AOI21X1 _894_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_402_),
    .B(_403_),
    .C(_404_),
    .Y(_10_)
);

INVX1 _1619_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_859_),
    .Y(_534_)
);

NAND2X1 _1792_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [1]),
    .B(\u_alien.x_pos [0]),
    .Y(_786_)
);

NAND3X1 _1372_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_229_),
    .B(_179_),
    .C(_180_),
    .Y(_147_)
);

NOR2X1 _1428_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_239_),
    .B(_201_),
    .Y(_199_)
);

INVX1 _1008_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_610_),
    .Y(_611_)
);

OAI22X1 _1181_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_330_),
    .B(_343_),
    .C(_327_),
    .D(_300_),
    .Y(_365_)
);

NAND2X1 _1657_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_776_),
    .B(_676_),
    .Y(_675_)
);

NAND2X1 _1237_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(en_lfsr4),
    .B(lfsr4[0]),
    .Y(_423_)
);

OAI21X1 _988_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [4]),
    .B(_626_),
    .C(_625_),
    .Y(_636_)
);

FILL FILL78450x57750 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1466_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[2]),
    .B(_235_),
    .C(_234_),
    .Y(_233_)
);

INVX1 _1046_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [4]),
    .Y(_573_)
);

NAND3X1 _1695_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_708_),
    .B(_706_),
    .C(_766_),
    .Y(_705_)
);

NAND2X1 _1275_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_177_),
    .B(_189_),
    .Y(_56_)
);

AND2X2 _1084_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_402_),
    .B(_406_),
    .Y(_408_)
);

NAND2X1 _1789_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_786_),
    .B(_784_),
    .Y(_783_)
);

NAND3X1 _1369_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_157_),
    .B(_153_),
    .C(_145_),
    .Y(_144_)
);

OAI21X1 _912_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_850_),
    .B(_852_),
    .C(_345_),
    .Y(_853_)
);

NAND2X1 _1598_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .B(_532_),
    .Y(_513_)
);

INVX1 _1178_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_298_),
    .Y(_297_)
);

INVX1 _950_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_666_),
    .Y(_816_)
);

INVX1 _1713_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_new),
    .Y(_716_)
);

AOI21X1 _1522_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_453_),
    .B(\u_ball.x_paddle [6]),
    .C(_442_),
    .Y(_441_)
);

NOR2X1 _1102_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(\u_ball.hit_paddle ),
    .Y(_392_)
);

NAND2X1 _909_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_325_),
    .B(_285_),
    .Y(_855_)
);

INVX1 _1751_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [5]),
    .Y(_748_)
);

OAI21X1 _1331_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_127_),
    .B(_110_),
    .C(_108_),
    .Y(_107_)
);

NAND2X1 _1560_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [2]),
    .B(_480_),
    .Y(_479_)
);

AND2X2 _1140_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_32_),
    .B(_36_),
    .Y(_31_)
);

NAND2X1 _891_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_11_),
    .B(_12_),
    .Y(_13_)
);

NOR2X1 _1616_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(\u_ball.x_paddle [4]),
    .Y(_531_)
);

NAND2X1 _947_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_805_),
    .B(_819_),
    .Y(_820_)
);

NAND3X1 _1425_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [3]),
    .B(_228_),
    .C(_230_),
    .Y(_197_)
);

INVX1 _1005_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_613_),
    .Y(_614_)
);

NAND2X1 _1654_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_674_),
    .B(_707_),
    .Y(_673_)
);

NAND2X1 _1234_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(en_lfsr4),
    .B(lfsr4[1]),
    .Y(_422_)
);

NAND2X1 _985_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [4]),
    .B(_334_),
    .Y(_639_)
);

AOI21X1 _1463_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_231_),
    .B(_243_),
    .C(game_init),
    .Y(_230_)
);

NOR3X1 _1043_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [1]),
    .B(\u_alien.x_ball [0]),
    .C(\u_alien.x_ball [2]),
    .Y(_576_)
);

AOI21X1 _1519_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_439_),
    .B(_473_),
    .C(_475_),
    .Y(_438_)
);

NOR2X1 _1692_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_767_),
    .B(_711_),
    .Y(_703_)
);

OAI21X1 _1272_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_177_),
    .B(_220_),
    .C(_54_),
    .Y(_267_)
);

NAND2X1 _1748_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_769_),
    .B(_746_),
    .Y(_745_)
);

AOI22X1 _1328_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_140_),
    .B(_105_),
    .C(_111_),
    .D(_115_),
    .Y(_104_)
);

MUX2X1 _1081_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_343_),
    .B(_327_),
    .S(\u_ball.y_ball [0]),
    .Y(_361_)
);

INVX1 _1557_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [3]),
    .Y(_476_)
);

OAI21X1 _1137_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_35_),
    .B(_43_),
    .C(_29_),
    .Y(_28_)
);

NAND3X1 _888_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_328_),
    .B(_14_),
    .C(_15_),
    .Y(_16_)
);

INVX1 _1786_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [2]),
    .Y(_781_)
);

AOI21X1 _1366_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_206_),
    .B(\u_alien.x_pos [6]),
    .C(_142_),
    .Y(_141_)
);

AOI21X1 _1595_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_527_),
    .B(_517_),
    .C(_516_),
    .Y(_510_)
);

NOR2X1 _1175_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_296_),
    .B(_295_),
    .Y(_294_)
);

FILL FILL78450x43350 (
    .gnd(gnd),
    .vdd(vdd)
);

OAI21X1 _1689_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_702_),
    .B(_701_),
    .C(alien_flip),
    .Y(_700_)
);

AOI21X1 _1269_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_59_),
    .B(\u_alien.x_ball [6]),
    .C(_250_),
    .Y(_264_)
);

DFFSR _1498_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_538_),
    .S(vdd),
    .D(_543_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.x_paddle [6])
);

NAND2X1 _1078_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.sign_y ),
    .B(_338_),
    .Y(_412_)
);

INVX1 _1710_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [4]),
    .Y(_714_)
);

INVX1 _906_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_320_),
    .Y(_1_)
);

NAND3X1 _1613_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_531_),
    .B(_530_),
    .C(_529_),
    .Y(_528_)
);

NAND2X1 _944_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_822_),
    .B(_821_),
    .Y(_823_)
);

NOR2X1 _1422_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [3]),
    .B(_210_),
    .Y(_194_)
);

NOR2X1 _1002_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [2]),
    .B(_337_),
    .Y(_619_)
);

NAND3X1 _1651_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_708_),
    .B(_672_),
    .C(_766_),
    .Y(_671_)
);

DFFSR _1231_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_550_),
    .D(_551_),
    .CLK(clk_bF$buf3),
    .Q(lfsr4[1])
);

OAI21X1 _982_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_635_),
    .B(_636_),
    .C(_641_),
    .Y(_642_)
);

NAND2X1 _1707_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [2]),
    .B(_768_),
    .Y(_712_)
);

NAND2X1 _1460_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_229_),
    .B(_228_),
    .Y(_227_)
);

INVX1 _1040_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [3]),
    .Y(_579_)
);

AOI21X1 _1516_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_438_),
    .B(_437_),
    .C(_436_),
    .Y(_435_)
);

INVX1 _1745_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_769_),
    .Y(_743_)
);

AOI22X1 _1325_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [2]),
    .B(_118_),
    .C(_104_),
    .D(_102_),
    .Y(_101_)
);

NOR2X1 _1554_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_475_),
    .B(_474_),
    .Y(_473_)
);

OR2X2 _1134_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_26_),
    .B(_51_),
    .Y(_25_)
);

AOI21X1 _885_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(pixel_bullet),
    .B(pixel_paddle),
    .C(_856_),
    .Y(_18_)
);

NAND2X1 _1783_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_780_),
    .B(_779_),
    .Y(_778_)
);

NAND2X1 _1363_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_140_),
    .B(_139_),
    .Y(_138_)
);

NAND2X1 _1419_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_197_),
    .B(_192_),
    .Y(_276_)
);

NOR2X1 _1592_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_522_),
    .B(_532_),
    .Y(_507_)
);

OAI21X1 _1172_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_296_),
    .B(_295_),
    .C(_292_),
    .Y(_291_)
);

OAI21X1 _1648_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State_3_bF$buf1 ),
    .B(_785_),
    .C(_670_),
    .Y(_788_)
);

INVX1 _1228_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .Y(_345_)
);

FILL FILL78450x64950 (
    .gnd(gnd),
    .vdd(vdd)
);

AOI21X1 _979_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_593_),
    .B(_390_),
    .C(_644_),
    .Y(_645_)
);

AND2X2 _1457_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_225_),
    .B(_230_),
    .Y(_281_)
);

NAND3X1 _1037_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_578_),
    .B(_581_),
    .C(_572_),
    .Y(_582_)
);

MUX2X1 _1686_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_698_),
    .B(_704_),
    .S(_703_),
    .Y(_798_)
);

NAND3X1 _1266_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(lfsr4[1]),
    .B(_223_),
    .C(_199_),
    .Y(_52_)
);

INVX1 _1495_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [4]),
    .Y(_260_)
);

OAI21X1 _1075_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(_413_),
    .C(_414_),
    .Y(_415_)
);

INVX1 _903_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_313_),
    .Y(_3_)
);

OAI21X1 _1589_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_521_),
    .B(_508_),
    .C(_505_),
    .Y(_504_)
);

OAI21X1 _1169_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_289_),
    .B(_294_),
    .C(\u_alien.x_ball [2]),
    .Y(_288_)
);

DFFSR _1801_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_800__bF$buf3),
    .D(_788_),
    .CLK(clk_bF$buf6),
    .Q(\u_alien.x_pos [0])
);

INVX1 _1398_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_pos [4]),
    .Y(_173_)
);

NAND3X1 _1610_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [6]),
    .B(\u_ball.x_paddle [4]),
    .C(\u_ball.x_paddle [5]),
    .Y(_525_)
);

INVX1 _941_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_825_),
    .Y(_826_)
);

AND2X2 _1704_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_773_),
    .B(_711_),
    .Y(_710_)
);

NOR3X1 _1513_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_440_),
    .B(_433_),
    .C(_456_),
    .Y(pixel_paddle)
);

NOR3X1 _1742_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_742_),
    .B(_741_),
    .C(_776_),
    .Y(_740_)
);

NAND3X1 _1322_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [1]),
    .B(\u_alien.rom_addr [2]),
    .C(_185_),
    .Y(_98_)
);

OAI21X1 _1551_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_514_),
    .B(\u_alien.x_pos [1]),
    .C(_471_),
    .Y(_470_)
);

INVX1 _1131_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_23_),
    .Y(_22_)
);

OR2X2 _882_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_19_),
    .B(_329_),
    .Y(_20_)
);

INVX1 _1607_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.x_paddle [5]),
    .Y(_522_)
);

NAND2X1 _938_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_828_),
    .B(_657_),
    .Y(_829_)
);

NAND3X1 _1780_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.rom_addr [1]),
    .B(\u_alien.rom_addr [0]),
    .C(\u_alien.rom_addr [2]),
    .Y(_776_)
);

OAI21X1 _1360_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_bullet [5]),
    .B(_136_),
    .C(\u_alien.x_pos [3]),
    .Y(_135_)
);

INVX1 _1416_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_190_),
    .Y(_189_)
);

DFFSR _1645_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_800__bF$buf2),
    .S(vdd),
    .D(_811_),
    .CLK(clk_bF$buf7),
    .Q(_857_)
);

OAI21X1 _1225_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(game_init),
    .B(\u_ball.hit_paddle ),
    .C(_343_),
    .Y(_342_)
);

OAI21X1 _976_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_647_),
    .B(_646_),
    .C(_390_),
    .Y(_648_)
);

NAND2X1 _1454_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_244_),
    .B(_248_),
    .Y(_222_)
);

NAND2X1 _1034_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_388_),
    .B(_584_),
    .Y(_585_)
);

OAI21X1 _1683_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_750_),
    .B(_751_),
    .C(\u_ctrl.cnt_v_sync [0]),
    .Y(_695_)
);

DFFSR _1263_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_270__bF$buf1),
    .S(vdd),
    .D(_275_),
    .CLK(clk_bF$buf2),
    .Q(\u_alien.y_bullet [4])
);

AOI22X1 _1739_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [1]),
    .B(_760_),
    .C(_743_),
    .D(_738_),
    .Y(_737_)
);

INVX1 _1319_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [2]),
    .Y(_95_)
);

INVX1 _1492_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_258_),
    .Y(_257_)
);

OAI21X1 _1072_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_410_),
    .B(_338_),
    .C(_416_),
    .Y(_417_)
);

NAND2X1 _1548_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_472_),
    .B(_468_),
    .Y(_467_)
);

NAND2X1 _1128_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_356_),
    .B(_25_),
    .Y(_357_)
);

DFFSR _879_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_354__bF$buf0),
    .S(vdd),
    .D(_361_),
    .CLK(clk_bF$buf4),
    .Q(\u_ball.y_ball [0])
);

OAI21X1 _1777_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_777_),
    .B(_774_),
    .C(\u_ctrl.State_3_bF$buf2 ),
    .Y(_773_)
);

OAI22X1 _1357_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_bullet [4]),
    .B(_134_),
    .C(\u_alien.x_pos [5]),
    .D(_133_),
    .Y(_132_)
);

OAI22X1 _900_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_317_),
    .B(_343_),
    .C(_327_),
    .D(_5_),
    .Y(_350_)
);

INVX1 _1586_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_521_),
    .Y(_501_)
);

INVX2 _1166_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [0]),
    .Y(_285_)
);

CLKBUF1 CLKBUF1_insert5 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf7)
);

CLKBUF1 CLKBUF1_insert6 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf6)
);

CLKBUF1 CLKBUF1_insert7 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf5)
);

CLKBUF1 CLKBUF1_insert8 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf4)
);

CLKBUF1 CLKBUF1_insert9 (
    .gnd(gnd),
    .vdd(vdd),
    .A(clk),
    .Y(clk_bF$buf3)
);

NAND2X1 _1395_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_172_),
    .B(_171_),
    .Y(_170_)
);

AOI21X1 _1489_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_255_),
    .B(_259_),
    .C(_261_),
    .Y(_283_)
);

AOI21X1 _1069_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_418_),
    .B(_419_),
    .C(_417_),
    .Y(_420_)
);

OAI21X1 _1701_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ctrl.State [2]),
    .B(_735_),
    .C(_767_),
    .Y(_709_)
);

AOI21X1 _1298_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_75_),
    .B(\u_alien.x_pos [4]),
    .C(_136_),
    .Y(_74_)
);

OAI21X1 _1510_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_484_),
    .B(btn_left),
    .C(_432_),
    .Y(_431_)
);

NOR2X1 _1604_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(btn_left),
    .B(_520_),
    .Y(_519_)
);

NOR2X1 _935_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_ball.y_ball [0]),
    .B(_612_),
    .Y(_832_)
);

NAND2X1 _1413_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_187_),
    .B(_220_),
    .Y(_186_)
);

DFFSR _1642_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(_800__bF$buf0),
    .S(vdd),
    .D(_798_),
    .CLK(clk_bF$buf1),
    .Q(alien_flip)
);

INVX1 _1222_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(hit_alien),
    .Y(_339_)
);

NOR3X1 _973_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_642_),
    .B(_649_),
    .C(_650_),
    .Y(_651_)
);

NOR2X1 _1451_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_229_),
    .B(_224_),
    .Y(_219_)
);

AND2X2 _1031_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_388_),
    .B(_30_),
    .Y(_588_)
);

NAND3X1 _1507_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_523_),
    .B(_429_),
    .C(_430_),
    .Y(_428_)
);

NAND2X1 _1680_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_694_),
    .B(_762_),
    .Y(_693_)
);

DFFSR _1260_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_270__bF$buf1),
    .D(_277_),
    .CLK(clk_bF$buf2),
    .Q(\u_alien.x_bullet [6])
);

INVX1 _1736_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_744_),
    .Y(_734_)
);

AOI21X1 _1316_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_94_),
    .B(_93_),
    .C(_95_),
    .Y(_92_)
);

OAI21X1 _1545_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [0]),
    .B(_466_),
    .C(_465_),
    .Y(_464_)
);

NAND2X1 _1125_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [3]),
    .B(_368_),
    .Y(_369_)
);

DFFSR _876_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_354__bF$buf2),
    .D(_353_),
    .CLK(clk_bF$buf0),
    .Q(\u_ball.y_ball [4])
);

NOR3X1 _1774_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_772_),
    .B(_771_),
    .C(_780_),
    .Y(_770_)
);

AOI21X1 _1354_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_144_),
    .B(_160_),
    .C(_130_),
    .Y(pixel_bullet)
);

AOI22X1 _1583_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_520_),
    .B(_527_),
    .C(_500_),
    .D(_518_),
    .Y(_498_)
);

AOI21X1 _1163_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_ball [1]),
    .B(\u_ball.x_paddle [1]),
    .C(_274_),
    .Y(_273_)
);

DFFSR _1639_ (
    .gnd(gnd),
    .vdd(vdd),
    .R(vdd),
    .S(_800__bF$buf3),
    .D(_814_),
    .CLK(clk_bF$buf6),
    .Q(\u_alien.x_pos [2])
);

NAND2X1 _1219_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_338_),
    .B(_337_),
    .Y(_336_)
);

NOR2X1 _1392_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.y_bullet [2]),
    .B(\u_alien.rom_addr [2]),
    .Y(_167_)
);

NAND2X1 _1448_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(_217_),
    .B(_220_),
    .Y(_216_)
);

OAI22X1 _1028_ (
    .gnd(gnd),
    .vdd(vdd),
    .A(\u_alien.x_pos [5]),
    .B(_585_),
    .C(_590_),
    .D(_588_),
    .Y(_591_)
);

endmodule
