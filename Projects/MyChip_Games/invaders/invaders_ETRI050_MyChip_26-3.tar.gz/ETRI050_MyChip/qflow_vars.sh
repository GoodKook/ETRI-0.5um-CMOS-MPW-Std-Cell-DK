#!/bin/tcsh -f
#-------------------------------------------
# qflow variables for project ~/MyChip_Work/invaders/ETRI050
#-------------------------------------------

set qflowversion=1.4.100
set projectpath=~/MyChip_Work/invaders/ETRI050
set techdir=/usr/local/share/qflow/tech/etri050
set sourcedir=~/MyChip_Work/invaders/ETRI050/source
set synthdir=~/MyChip_Work/invaders/ETRI050/synthesis
set layoutdir=~/MyChip_Work/invaders/ETRI050/layout
set techname=etri050
set scriptdir=/usr/local/share/qflow/scripts
set bindir=/usr/local/share/qflow/bin
set logdir=~/MyChip_Work/invaders/ETRI050/log
#-------------------------------------------

