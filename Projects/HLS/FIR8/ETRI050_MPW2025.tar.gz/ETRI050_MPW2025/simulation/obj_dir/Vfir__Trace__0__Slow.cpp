// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_sc.h"
#include "Vfir__Syms.h"


VL_ATTR_COLD void Vfir___024root__trace_init_sub__TOP__0(Vfir___024root* vlSelf, VerilatedVcd* tracep) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root__trace_init_sub__TOP__0\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->pushPrefix("fir", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+130,0,"ap_ST_fsm_state1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+131,0,"ap_ST_fsm_state2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+132,0,"ap_ST_fsm_state3",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+133,0,"ap_ST_fsm_state4",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+134,0,"ap_ST_fsm_state5",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBit(c+43,0,"ap_clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+44,0,"ap_rst",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+45,0,"ap_start",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+9,0,"ap_done",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+107,0,"ap_idle",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+9,0,"ap_ready",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+17,0,"y",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBit(c+9,0,"y_ap_vld",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+46,0,"x",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+10,0,"ap_CS_fsm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBit(c+11,0,"ap_CS_fsm_state1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+48,0,"shift_reg_address0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+49,0,"shift_reg_ce0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+108,0,"shift_reg_we0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+78,0,"shift_reg_q0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBit(c+50,0,"shift_reg_ce1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+109,0,"shift_reg_we1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+79,0,"shift_reg_q1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+80,0,"x_read_reg_118",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBit(c+12,0,"grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+110,0,"grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_done",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+111,0,"grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_idle",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+51,0,"grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_ready",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+81,0,"grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_address0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+52,0,"grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+112,0,"grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_we0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+79,0,"grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_d0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+53,0,"grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_address1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+54,0,"grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+55,0,"grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_we1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+80,0,"grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_d1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBit(c+13,0,"grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+113,0,"grp_fir_Pipeline_MACC_LOOP_fu_71_ap_done",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+114,0,"grp_fir_Pipeline_MACC_LOOP_fu_71_ap_idle",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+56,0,"grp_fir_Pipeline_MACC_LOOP_fu_71_ap_ready",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+18,0,"grp_fir_Pipeline_MACC_LOOP_fu_71_acc_1_out",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 15,0);
    tracep->declBit(c+82,0,"grp_fir_Pipeline_MACC_LOOP_fu_71_acc_1_out_ap_vld",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+57,0,"grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_address0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+58,0,"grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_ce0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+12,0,"grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+14,0,"ap_CS_fsm_state2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+13,0,"grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+15,0,"ap_CS_fsm_state3",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+16,0,"ap_CS_fsm_state4",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+9,0,"ap_CS_fsm_state5",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+19,0,"trunc_ln70_fu_83_p1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 13,0);
    tracep->declBus(c+20,0,"acc_fu_93_p2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 13,0);
    tracep->declBus(c+21,0,"icmp_ln73_fu_87_p2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBus(c+22,0,"phitmp1_fu_99_p4",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+115,0,"ap_NS_fsm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBit(c+47,0,"ap_ST_fsm_state1_blk",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+116,0,"ap_ST_fsm_state2_blk",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+135,0,"ap_ST_fsm_state3_blk",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+117,0,"ap_ST_fsm_state4_blk",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+135,0,"ap_ST_fsm_state5_blk",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+136,0,"ap_ce_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->pushPrefix("grp_fir_Pipeline_MACC_LOOP_fu_71", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+137,0,"ap_ST_fsm_pp0_stage0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBit(c+43,0,"ap_clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+44,0,"ap_rst",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+13,0,"ap_start",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+113,0,"ap_done",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+114,0,"ap_idle",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+56,0,"ap_ready",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+18,0,"acc_1_out",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 15,0);
    tracep->declBit(c+82,0,"acc_1_out_ap_vld",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+57,0,"shift_reg_address0",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+58,0,"shift_reg_ce0",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+78,0,"shift_reg_q0",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+23,0,"ap_CS_fsm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBit(c+23,0,"ap_CS_fsm_pp0_stage0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+13,0,"ap_enable_reg_pp0_iter0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+24,0,"ap_enable_reg_pp0_iter1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+25,0,"ap_enable_reg_pp0_iter2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+26,0,"ap_enable_reg_pp0_iter3",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+27,0,"ap_enable_reg_pp0_iter4",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+118,0,"ap_idle_pp0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+135,0,"ap_block_pp0_stage0_subdone",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+59,0,"icmp_ln70_fu_90_p2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBit(c+56,0,"ap_condition_exit_pp0_iter0_stage0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+56,0,"ap_loop_exit_ready",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+58,0,"ap_ready_int",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+57,0,"filter_taps_address0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+83,0,"filter_taps_q0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 5,0);
    tracep->declBit(c+135,0,"ap_block_pp0_stage0_11001",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+84,0,"icmp_ln70_reg_156",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBus(c+85,0,"icmp_ln70_reg_156_pp0_iter1_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBus(c+86,0,"icmp_ln70_reg_156_pp0_iter2_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declQuad(c+60,0,"zext_ln70_fu_102_p1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 63,0);
    tracep->declBit(c+135,0,"ap_block_pp0_stage0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+18,0,"acc_fu_36",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 15,0);
    tracep->declBus(c+87,0,"grp_fu_132_p3",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 15,0);
    tracep->declBus(c+28,0,"ap_sig_allocacmp_acc_load_1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 15,0);
    tracep->declBit(c+62,0,"ap_loop_init",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+88,0,"ap_loop_exit_ready_pp0_iter1_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+89,0,"ap_loop_exit_ready_pp0_iter2_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+90,0,"ap_loop_exit_ready_pp0_iter3_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+29,0,"i_1_fu_40",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 3,0);
    tracep->declBus(c+63,0,"add_ln70_fu_96_p2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 3,0);
    tracep->declBus(c+64,0,"ap_sig_allocacmp_i",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 3,0);
    tracep->declBit(c+135,0,"ap_block_pp0_stage0_01001",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+58,0,"filter_taps_ce0_local",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+58,0,"shift_reg_ce0_local",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+78,0,"grp_fu_132_p0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+83,0,"grp_fu_132_p1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 5,0);
    tracep->declBit(c+30,0,"ap_done_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+138,0,"ap_continue_int",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+65,0,"ap_done_int",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+23,0,"ap_NS_fsm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBit(c+119,0,"ap_enable_pp0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+13,0,"ap_start_int",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+56,0,"ap_ready_sig",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+113,0,"ap_done_sig",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+91,0,"grp_fu_132_p00",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 13,0);
    tracep->declBus(c+92,0,"grp_fu_132_p10",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 13,0);
    tracep->declBit(c+139,0,"ap_ce_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->pushPrefix("filter_taps_U", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+140,0,"DataWidth",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+141,0,"AddressWidth",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+142,0,"AddressRange",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+57,0,"address0",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+58,0,"ce0",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+83,0,"q0",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 5,0);
    tracep->declBit(c+44,0,"reset",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+43,0,"clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->pushPrefix("rom0", VerilatedTracePrefixType::ARRAY_UNPACKED);
    for (int i = 0; i < 8; ++i) {
        tracep->declBus(c+1+i*1,0,"",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, true,(i+0), 5,0);
    }
    tracep->popPrefix();
    tracep->popPrefix();
    tracep->pushPrefix("flow_control_loop_pipe_sequential_init_U", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+43,0,"ap_clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+44,0,"ap_rst",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+13,0,"ap_start",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+56,0,"ap_ready",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+113,0,"ap_done",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+13,0,"ap_start_int",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+58,0,"ap_ready_int",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+65,0,"ap_done_int",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+138,0,"ap_continue_int",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+62,0,"ap_loop_init",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+120,0,"ap_loop_init_int",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+121,0,"ap_done_cache",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+56,0,"ap_loop_exit_ready",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+65,0,"ap_loop_exit_done",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->popPrefix();
    tracep->pushPrefix("mac_muladd_8ns_6ns_16ns_16_4_1_U3", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+143,0,"ID",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+144,0,"NUM_STAGE",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+142,0,"din0_WIDTH",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+140,0,"din1_WIDTH",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+145,0,"din2_WIDTH",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+145,0,"dout_WIDTH",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+43,0,"clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+44,0,"reset",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+138,0,"ce",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+78,0,"din0",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+83,0,"din1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 5,0);
    tracep->declBus(c+28,0,"din2",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 15,0);
    tracep->declBus(c+87,0,"dout",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 15,0);
    tracep->pushPrefix("fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+43,0,"clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+44,0,"rst",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+138,0,"ce",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+78,0,"in0",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+83,0,"in1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 5,0);
    tracep->declBus(c+28,0,"in2",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 15,0);
    tracep->declBus(c+87,0,"dout",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 15,0);
    tracep->declBus(c+93,0,"a",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 24,0);
    tracep->declBus(c+94,0,"b",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 17,0);
    tracep->declQuad(c+31,0,"c",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 47,0);
    tracep->declQuad(c+95,0,"m",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 42,0);
    tracep->declQuad(c+33,0,"p",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 47,0);
    tracep->declQuad(c+97,0,"m_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 42,0);
    tracep->declBus(c+99,0,"a_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 24,0);
    tracep->declBus(c+100,0,"b_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 17,0);
    tracep->declQuad(c+101,0,"p_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 47,0);
    tracep->popPrefix();
    tracep->popPrefix();
    tracep->popPrefix();
    tracep->pushPrefix("grp_fir_Pipeline_SHIFTER_LOOP_fu_63", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+137,0,"ap_ST_fsm_pp0_stage0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBit(c+43,0,"ap_clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+44,0,"ap_rst",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+12,0,"ap_start",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+110,0,"ap_done",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+111,0,"ap_idle",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+51,0,"ap_ready",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+80,0,"x",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+81,0,"shift_reg_address0",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+52,0,"shift_reg_ce0",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+112,0,"shift_reg_we0",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+79,0,"shift_reg_d0",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+53,0,"shift_reg_address1",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+54,0,"shift_reg_ce1",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+55,0,"shift_reg_we1",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+80,0,"shift_reg_d1",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+79,0,"shift_reg_q1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+122,0,"ap_CS_fsm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBit(c+122,0,"ap_CS_fsm_pp0_stage0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+12,0,"ap_enable_reg_pp0_iter0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+123,0,"ap_enable_reg_pp0_iter1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+124,0,"ap_idle_pp0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+135,0,"ap_block_pp0_stage0_subdone",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+66,0,"tmp_fu_86_p3",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBit(c+51,0,"ap_condition_exit_pp0_iter0_stage0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+51,0,"ap_loop_exit_ready",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+67,0,"ap_ready_int",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+103,0,"i_1_reg_137",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 3,0);
    tracep->declBit(c+135,0,"ap_block_pp0_stage0_11001",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+68,0,"icmp_ln62_fu_98_p2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBus(c+104,0,"icmp_ln62_reg_145",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declQuad(c+69,0,"zext_ln65_fu_110_p1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 63,0);
    tracep->declBit(c+135,0,"ap_block_pp0_stage0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declQuad(c+105,0,"zext_ln60_fu_126_p1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 63,0);
    tracep->declBus(c+125,0,"i_fu_40",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 3,0);
    tracep->declBus(c+71,0,"add_ln60_fu_115_p2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 3,0);
    tracep->declBit(c+72,0,"ap_loop_init",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+73,0,"ap_sig_allocacmp_i_1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 3,0);
    tracep->declBit(c+54,0,"shift_reg_ce1_local",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+53,0,"shift_reg_address1_local",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+55,0,"shift_reg_we1_local",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+112,0,"shift_reg_we0_local",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+52,0,"shift_reg_ce0_local",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+74,0,"trunc_ln60_fu_94_p1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+75,0,"add_ln65_fu_104_p2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+126,0,"ap_done_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+138,0,"ap_continue_int",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+76,0,"ap_done_int",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+122,0,"ap_NS_fsm",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 0,0);
    tracep->declBit(c+127,0,"ap_enable_pp0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+12,0,"ap_start_int",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+51,0,"ap_ready_sig",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+110,0,"ap_done_sig",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+77,0,"ap_condition_184",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+146,0,"ap_ce_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->pushPrefix("flow_control_loop_pipe_sequential_init_U", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+43,0,"ap_clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+44,0,"ap_rst",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+12,0,"ap_start",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+51,0,"ap_ready",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+110,0,"ap_done",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+12,0,"ap_start_int",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+67,0,"ap_ready_int",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+76,0,"ap_done_int",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+138,0,"ap_continue_int",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+72,0,"ap_loop_init",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+128,0,"ap_loop_init_int",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+129,0,"ap_done_cache",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+51,0,"ap_loop_exit_ready",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+76,0,"ap_loop_exit_done",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->popPrefix();
    tracep->popPrefix();
    tracep->pushPrefix("shift_reg_U", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+142,0,"DataWidth",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+141,0,"AddressWidth",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+142,0,"AddressRange",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+48,0,"address0",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+49,0,"ce0",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+79,0,"d0",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBit(c+108,0,"we0",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+78,0,"q0",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+53,0,"address1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+50,0,"ce1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+80,0,"d1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBit(c+109,0,"we1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+79,0,"q1",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBit(c+44,0,"reset",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+43,0,"clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->pushPrefix("ram", VerilatedTracePrefixType::ARRAY_UNPACKED);
    for (int i = 0; i < 8; ++i) {
        tracep->declBus(c+35+i*1,0,"",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, true,(i+0), 7,0);
    }
    tracep->popPrefix();
    tracep->popPrefix();
    tracep->popPrefix();
}

VL_ATTR_COLD void Vfir___024root__trace_init_top(Vfir___024root* vlSelf, VerilatedVcd* tracep) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root__trace_init_top\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Vfir___024root__trace_init_sub__TOP__0(vlSelf, tracep);
}

VL_ATTR_COLD void Vfir___024root__trace_const_0(void* voidSelf, VerilatedVcd::Buffer* bufp);
VL_ATTR_COLD void Vfir___024root__trace_full_0(void* voidSelf, VerilatedVcd::Buffer* bufp);
void Vfir___024root__trace_chg_0(void* voidSelf, VerilatedVcd::Buffer* bufp);
void Vfir___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/);

VL_ATTR_COLD void Vfir___024root__trace_register(Vfir___024root* vlSelf, VerilatedVcd* tracep) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root__trace_register\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    tracep->addConstCb(&Vfir___024root__trace_const_0, 0U, vlSelf);
    tracep->addFullCb(&Vfir___024root__trace_full_0, 0U, vlSelf);
    tracep->addChgCb(&Vfir___024root__trace_chg_0, 0U, vlSelf);
    tracep->addCleanupCb(&Vfir___024root__trace_cleanup, vlSelf);
}

VL_ATTR_COLD void Vfir___024root__trace_const_0_sub_0(Vfir___024root* vlSelf, VerilatedVcd::Buffer* bufp);

VL_ATTR_COLD void Vfir___024root__trace_const_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root__trace_const_0\n"); );
    // Init
    Vfir___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vfir___024root*>(voidSelf);
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    Vfir___024root__trace_const_0_sub_0((&vlSymsp->TOP), bufp);
}

VL_ATTR_COLD void Vfir___024root__trace_const_0_sub_0(Vfir___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root__trace_const_0_sub_0\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode);
    // Body
    bufp->fullCData(oldp+130,(1U),5);
    bufp->fullCData(oldp+131,(2U),5);
    bufp->fullCData(oldp+132,(4U),5);
    bufp->fullCData(oldp+133,(8U),5);
    bufp->fullCData(oldp+134,(0x10U),5);
    bufp->fullBit(oldp+135,(0U));
    bufp->fullBit(oldp+136,(vlSelfRef.fir__DOT__ap_ce_reg));
    bufp->fullBit(oldp+137,(1U));
    bufp->fullBit(oldp+138,(1U));
    bufp->fullBit(oldp+139,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_ce_reg));
    bufp->fullIData(oldp+140,(6U),32);
    bufp->fullIData(oldp+141,(3U),32);
    bufp->fullIData(oldp+142,(8U),32);
    bufp->fullIData(oldp+143,(1U),32);
    bufp->fullIData(oldp+144,(4U),32);
    bufp->fullIData(oldp+145,(0x10U),32);
    bufp->fullBit(oldp+146,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ce_reg));
}

VL_ATTR_COLD void Vfir___024root__trace_full_0_sub_0(Vfir___024root* vlSelf, VerilatedVcd::Buffer* bufp);

VL_ATTR_COLD void Vfir___024root__trace_full_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root__trace_full_0\n"); );
    // Init
    Vfir___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vfir___024root*>(voidSelf);
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    Vfir___024root__trace_full_0_sub_0((&vlSymsp->TOP), bufp);
}

VL_ATTR_COLD void Vfir___024root__trace_full_0_sub_0(Vfir___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root__trace_full_0_sub_0\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode);
    // Body
    bufp->fullCData(oldp+1,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[0]),6);
    bufp->fullCData(oldp+2,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[1]),6);
    bufp->fullCData(oldp+3,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[2]),6);
    bufp->fullCData(oldp+4,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[3]),6);
    bufp->fullCData(oldp+5,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[4]),6);
    bufp->fullCData(oldp+6,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[5]),6);
    bufp->fullCData(oldp+7,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[6]),6);
    bufp->fullCData(oldp+8,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[7]),6);
    bufp->fullBit(oldp+9,((1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                 >> 4U))));
    bufp->fullCData(oldp+10,(vlSelfRef.fir__DOT__ap_CS_fsm),5);
    bufp->fullBit(oldp+11,((1U & (IData)(vlSelfRef.fir__DOT__ap_CS_fsm))));
    bufp->fullBit(oldp+12,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg));
    bufp->fullBit(oldp+13,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg));
    bufp->fullBit(oldp+14,((1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                  >> 1U))));
    bufp->fullBit(oldp+15,((1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                  >> 2U))));
    bufp->fullBit(oldp+16,((1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                  >> 3U))));
    bufp->fullCData(oldp+17,(((0x2af8U > (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36))
                               ? 0xabU : (0xffU & (
                                                   ((IData)(0x1508U) 
                                                    + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)) 
                                                   >> 6U)))),8);
    bufp->fullSData(oldp+18,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36),16);
    bufp->fullSData(oldp+19,((0x3fffU & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36))),14);
    bufp->fullSData(oldp+20,((0x3fffU & ((IData)(0x1508U) 
                                         + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)))),14);
    bufp->fullBit(oldp+21,((0x2af8U > (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36))));
    bufp->fullCData(oldp+22,((0xffU & (((IData)(0x1508U) 
                                        + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)) 
                                       >> 6U))),8);
    bufp->fullBit(oldp+23,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm));
    bufp->fullBit(oldp+24,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1));
    bufp->fullBit(oldp+25,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2));
    bufp->fullBit(oldp+26,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3));
    bufp->fullBit(oldp+27,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4));
    bufp->fullSData(oldp+28,((0xffffU & ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4)
                                          ? (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg)
                                          : (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)))),16);
    bufp->fullCData(oldp+29,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40),4);
    bufp->fullBit(oldp+30,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_reg));
    bufp->fullQData(oldp+31,((QData)((IData)((0xffffU 
                                              & ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4)
                                                  ? (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg)
                                                  : (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)))))),48);
    bufp->fullQData(oldp+33,((0xffffffffffffULL & (
                                                   VL_EXTENDS_QQ(48,43, vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__m_reg) 
                                                   + (QData)((IData)(
                                                                     (0xffffU 
                                                                      & ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4)
                                                                          ? (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg)
                                                                          : (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)))))))),48);
    bufp->fullCData(oldp+35,(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[0]),8);
    bufp->fullCData(oldp+36,(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[1]),8);
    bufp->fullCData(oldp+37,(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[2]),8);
    bufp->fullCData(oldp+38,(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[3]),8);
    bufp->fullCData(oldp+39,(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[4]),8);
    bufp->fullCData(oldp+40,(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[5]),8);
    bufp->fullCData(oldp+41,(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[6]),8);
    bufp->fullCData(oldp+42,(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[7]),8);
    bufp->fullBit(oldp+43,(vlSelfRef.__Vcellinp__fir__ap_clk));
    bufp->fullBit(oldp+44,(vlSelfRef.__Vcellinp__fir__ap_rst));
    bufp->fullBit(oldp+45,(vlSelfRef.__Vcellinp__fir__ap_start));
    bufp->fullCData(oldp+46,(vlSelfRef.__Vcellinp__fir__x),8);
    bufp->fullBit(oldp+47,((1U & (~ (IData)(vlSelfRef.__Vcellinp__fir__ap_start)))));
    bufp->fullCData(oldp+48,(vlSelfRef.fir__DOT__shift_reg_address0),3);
    bufp->fullBit(oldp+49,(vlSelfRef.fir__DOT__shift_reg_ce0));
    bufp->fullBit(oldp+50,(vlSelfRef.fir__DOT__shift_reg_ce1));
    bufp->fullBit(oldp+51,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_ready));
    bufp->fullBit(oldp+52,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce0));
    bufp->fullCData(oldp+53,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_address1),3);
    bufp->fullBit(oldp+54,(((((0U != (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)) 
                              & (~ ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1) 
                                    >> 3U))) | (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT____VdfgRegularize_h8c07728a_0_7)) 
                            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int))));
    bufp->fullBit(oldp+55,(((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT____VdfgRegularize_h8c07728a_0_7) 
                            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int))));
    bufp->fullBit(oldp+56,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_ready));
    bufp->fullCData(oldp+57,((7U & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i))),3);
    bufp->fullBit(oldp+58,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_ce0));
    bufp->fullBit(oldp+59,((8U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i))));
    bufp->fullQData(oldp+60,((QData)((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i))),64);
    bufp->fullBit(oldp+62,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_init));
    bufp->fullCData(oldp+63,((0xfU & ((IData)(1U) + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i)))),4);
    bufp->fullCData(oldp+64,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i),4);
    bufp->fullBit(oldp+65,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_int));
    bufp->fullBit(oldp+66,((1U & ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1) 
                                  >> 3U))));
    bufp->fullBit(oldp+67,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int));
    bufp->fullBit(oldp+68,((0U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1))));
    bufp->fullQData(oldp+69,((QData)((IData)((7U & 
                                              ((IData)(7U) 
                                               + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)))))),64);
    bufp->fullCData(oldp+71,((0xfU & ((IData)(0xfU) 
                                      + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)))),4);
    bufp->fullBit(oldp+72,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_loop_init));
    bufp->fullCData(oldp+73,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1),4);
    bufp->fullCData(oldp+74,((7U & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1))),3);
    bufp->fullCData(oldp+75,((7U & ((IData)(7U) + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)))),3);
    bufp->fullBit(oldp+76,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_int));
    bufp->fullBit(oldp+77,(((~ ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1) 
                                >> 3U)) & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int))));
    bufp->fullCData(oldp+78,(vlSelfRef.fir__DOT__shift_reg_q0),8);
    bufp->fullCData(oldp+79,(vlSelfRef.fir__DOT__shift_reg_q1),8);
    bufp->fullCData(oldp+80,(vlSelfRef.fir__DOT__x_read_reg_118),8);
    bufp->fullCData(oldp+81,((7U & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_1_reg_137))),3);
    bufp->fullBit(oldp+82,(((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter3_reg) 
                            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156_pp0_iter2_reg))));
    bufp->fullCData(oldp+83,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_q0),6);
    bufp->fullBit(oldp+84,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156));
    bufp->fullBit(oldp+85,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156_pp0_iter1_reg));
    bufp->fullBit(oldp+86,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156_pp0_iter2_reg));
    bufp->fullSData(oldp+87,((0xffffU & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg))),16);
    bufp->fullBit(oldp+88,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter1_reg));
    bufp->fullBit(oldp+89,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter2_reg));
    bufp->fullBit(oldp+90,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter3_reg));
    bufp->fullSData(oldp+91,(vlSelfRef.fir__DOT__shift_reg_q0),14);
    bufp->fullSData(oldp+92,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_q0),14);
    bufp->fullIData(oldp+93,(vlSelfRef.fir__DOT__shift_reg_q0),25);
    bufp->fullIData(oldp+94,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_q0),18);
    bufp->fullQData(oldp+95,((0x7ffffffffffULL & VL_MULS_QQQ(43, 
                                                             (0x7ffffffffffULL 
                                                              & VL_EXTENDS_QI(43,25, vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__a_reg)), 
                                                             (0x7ffffffffffULL 
                                                              & VL_EXTENDS_QI(43,18, vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__b_reg))))),43);
    bufp->fullQData(oldp+97,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__m_reg),43);
    bufp->fullIData(oldp+99,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__a_reg),25);
    bufp->fullIData(oldp+100,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__b_reg),18);
    bufp->fullQData(oldp+101,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg),48);
    bufp->fullCData(oldp+103,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_1_reg_137),4);
    bufp->fullBit(oldp+104,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__icmp_ln62_reg_145));
    bufp->fullQData(oldp+105,((QData)((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_1_reg_137))),64);
    bufp->fullBit(oldp+107,((1U & ((~ (IData)(vlSelfRef.__Vcellinp__fir__ap_start)) 
                                   & (IData)(vlSelfRef.fir__DOT__ap_CS_fsm)))));
    bufp->fullBit(oldp+108,((((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                              >> 1U) & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__icmp_ln62_reg_145)) 
                                        & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce0)))));
    bufp->fullBit(oldp+109,((((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                              >> 1U) & ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT____VdfgRegularize_h8c07728a_0_7) 
                                        & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int)))));
    bufp->fullBit(oldp+110,(((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_int) 
                             | ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg)) 
                                & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache)))));
    bufp->fullBit(oldp+111,((((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1)) 
                              & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg))) 
                             & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm))));
    bufp->fullBit(oldp+112,(((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__icmp_ln62_reg_145)) 
                             & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce0))));
    bufp->fullBit(oldp+113,(((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_int) 
                             | ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg)) 
                                & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache)))));
    bufp->fullBit(oldp+114,(((((((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4)) 
                                 & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3))) 
                                & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2))) 
                               & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1))) 
                              & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg))) 
                             & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm))));
    bufp->fullCData(oldp+115,(vlSelfRef.fir__DOT__ap_NS_fsm),5);
    bufp->fullBit(oldp+116,((1U & (~ ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_int) 
                                      | ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg)) 
                                         & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache)))))));
    bufp->fullBit(oldp+117,((1U & (~ ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_int) 
                                      | ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg)) 
                                         & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache)))))));
    bufp->fullBit(oldp+118,((1U & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4)) 
                                   & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3)) 
                                      & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2)) 
                                         & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1)) 
                                            & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg)))))))));
    bufp->fullBit(oldp+119,((1U & (~ ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4)) 
                                      & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3)) 
                                         & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2)) 
                                            & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1)) 
                                               & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg))))))))));
    bufp->fullBit(oldp+120,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int));
    bufp->fullBit(oldp+121,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache));
    bufp->fullBit(oldp+122,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm));
    bufp->fullBit(oldp+123,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1));
    bufp->fullBit(oldp+124,((1U & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1)) 
                                   & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg))))));
    bufp->fullCData(oldp+125,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40),4);
    bufp->fullBit(oldp+126,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_reg));
    bufp->fullBit(oldp+127,((1U & (~ ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1)) 
                                      & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg)))))));
    bufp->fullBit(oldp+128,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int));
    bufp->fullBit(oldp+129,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache));
}
