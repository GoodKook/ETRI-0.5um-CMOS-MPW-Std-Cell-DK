// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vfir.h for the primary calling header

#include "Vfir__pch.h"
#include "Vfir___024root.h"

VL_ATTR_COLD void Vfir___024root___eval_static(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_static\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vtrigprevexpr___TOP____Vcellinp__fir__ap_clk__0 
        = vlSelfRef.__Vcellinp__fir__ap_clk;
}

extern const VlWide<9>/*287:0*/ Vfir__ConstPool__CONST_ha293fd61_0;
extern const VlWide<14>/*447:0*/ Vfir__ConstPool__CONST_h56654fb6_0;

VL_ATTR_COLD void Vfir___024root___eval_initial__TOP(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_initial__TOP\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    VL_READMEM_N(true, 8, 8, 0, VL_CVT_PACK_STR_NW(9, Vfir__ConstPool__CONST_ha293fd61_0)
                 ,  &(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram)
                 , 0, ~0ULL);
    VL_READMEM_N(true, 6, 8, 0, VL_CVT_PACK_STR_NW(14, Vfir__ConstPool__CONST_h56654fb6_0)
                 ,  &(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0)
                 , 0, ~0ULL);
}

VL_ATTR_COLD void Vfir___024root___eval_final(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_final\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vfir___024root___dump_triggers__stl(Vfir___024root* vlSelf);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Vfir___024root___eval_phase__stl(Vfir___024root* vlSelf);

VL_ATTR_COLD void Vfir___024root___eval_settle(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_settle\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __VstlIterCount;
    CData/*0:0*/ __VstlContinue;
    // Body
    __VstlIterCount = 0U;
    vlSelfRef.__VstlFirstIteration = 1U;
    __VstlContinue = 1U;
    while (__VstlContinue) {
        if (VL_UNLIKELY(((0x64U < __VstlIterCount)))) {
#ifdef VL_DEBUG
            Vfir___024root___dump_triggers__stl(vlSelf);
#endif
            VL_FATAL_MT("../fir/hls_component/syn/verilog/fir.v", 11, "", "Settle region did not converge.");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        __VstlContinue = 0U;
        if (Vfir___024root___eval_phase__stl(vlSelf)) {
            __VstlContinue = 1U;
        }
        vlSelfRef.__VstlFirstIteration = 0U;
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vfir___024root___dump_triggers__stl(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___dump_triggers__stl\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VstlTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VstlTriggered.word(0U))) {
        VL_DBG_MSGF("         'stl' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vfir___024root___stl_sequent__TOP__0(Vfir___024root* vlSelf);
VL_ATTR_COLD void Vfir___024root____Vm_traceActivitySetAll(Vfir___024root* vlSelf);

VL_ATTR_COLD void Vfir___024root___eval_stl(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_stl\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VstlTriggered.word(0U))) {
        Vfir___024root___stl_sequent__TOP__0(vlSelf);
        Vfir___024root____Vm_traceActivitySetAll(vlSelf);
    }
}

extern const VlUnpacked<CData/*4:0*/, 2048> Vfir__ConstPool__TABLE_h7a411543_0;

VL_ATTR_COLD void Vfir___024root___stl_sequent__TOP__0(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___stl_sequent__TOP__0\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    SData/*10:0*/ __Vtableidx1;
    __Vtableidx1 = 0;
    // Body
    VL_ASSIGN_ISU(8,vlSelfRef.__Vcellinp__fir__x, vlSelfRef.x);
    VL_ASSIGN_SII(1,vlSelfRef.y_ap_vld, (1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                               >> 4U)));
    VL_ASSIGN_SUI(8,vlSelfRef.y, ((0x2af8U > (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36))
                                   ? 0xabU : (0xffU 
                                              & (((IData)(0x1508U) 
                                                  + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)) 
                                                 >> 6U))));
    VL_ASSIGN_SII(1,vlSelfRef.ap_ready, (1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                               >> 4U)));
    VL_ASSIGN_SII(1,vlSelfRef.ap_done, (1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                              >> 4U)));
    VL_ASSIGN_ISI(1,vlSelfRef.__Vcellinp__fir__ap_rst, vlSelfRef.ap_rst);
    VL_ASSIGN_ISI(1,vlSelfRef.__Vcellinp__fir__ap_clk, vlSelfRef.ap_clk);
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_NS_fsm 
        = vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_NS_fsm 
        = vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p 
        = (0xffffffffffffULL & (VL_EXTENDS_QQ(48,43, vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__m_reg) 
                                + (QData)((IData)((0xffffU 
                                                   & ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4)
                                                       ? (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg)
                                                       : (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)))))));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce0 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_ce0 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_int 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_reg) 
           | (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter3_reg));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_init 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg));
    VL_ASSIGN_ISI(1,vlSelfRef.__Vcellinp__fir__ap_start, vlSelfRef.ap_start);
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_loop_init 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i 
        = (((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm) 
            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_init))
            ? 0U : (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40));
    if ((8U & (IData)(vlSelfRef.fir__DOT__ap_CS_fsm))) {
        vlSelfRef.fir__DOT__shift_reg_ce0 = vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_ce0;
        vlSelfRef.fir__DOT__shift_reg_address0 = (7U 
                                                  & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i));
    } else {
        vlSelfRef.fir__DOT__shift_reg_ce0 = (((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                              >> 1U) 
                                             & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce0));
        vlSelfRef.fir__DOT__shift_reg_address0 = (7U 
                                                  & ((2U 
                                                      & (IData)(vlSelfRef.fir__DOT__ap_CS_fsm))
                                                      ? (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_1_reg_137)
                                                      : 0U));
    }
    VL_ASSIGN_SII(1,vlSelfRef.ap_idle, (1U & ((~ (IData)(vlSelfRef.__Vcellinp__fir__ap_start)) 
                                              & (IData)(vlSelfRef.fir__DOT__ap_CS_fsm))));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1 
        = (((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_loop_init) 
            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm))
            ? 7U : (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_ready 
        = ((8U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i)) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_ce0));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_address1 
        = (((~ ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1) 
                >> 3U)) & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int))
            ? ((0U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1))
                ? 0U : ((0U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1))
                         ? 0U : (7U & ((IData)(7U) 
                                       + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)))))
            : 0U);
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT____VdfgRegularize_h8c07728a_0_7 
        = (IData)((0U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_ready 
        = (((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1) 
            >> 3U) & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int));
    vlSelfRef.fir__DOT__shift_reg_ce1 = (((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                          >> 1U) & 
                                         ((((0U != (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)) 
                                            & (~ ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1) 
                                                  >> 3U))) 
                                           | (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT____VdfgRegularize_h8c07728a_0_7)) 
                                          & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int)));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_int 
        = (((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_ready) 
            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm)) 
           | (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_reg));
    __Vtableidx1 = ((((IData)(vlSelfRef.__Vcellinp__fir__ap_start) 
                      << 0xaU) | ((0x200U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                             << 9U)) 
                                  | (0x100U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                               << 7U)))) 
                    | ((((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_int) 
                         | ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg)) 
                            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache))) 
                        << 7U) | ((0x40U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                            << 3U)) 
                                  | ((((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_int) 
                                       | ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg)) 
                                          & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache))) 
                                      << 5U) | (IData)(vlSelfRef.fir__DOT__ap_CS_fsm)))));
    vlSelfRef.fir__DOT__ap_NS_fsm = Vfir__ConstPool__TABLE_h7a411543_0
        [__Vtableidx1];
}

VL_ATTR_COLD void Vfir___024root___eval_triggers__stl(Vfir___024root* vlSelf);

VL_ATTR_COLD bool Vfir___024root___eval_phase__stl(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_phase__stl\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VstlExecute;
    // Body
    Vfir___024root___eval_triggers__stl(vlSelf);
    __VstlExecute = vlSelfRef.__VstlTriggered.any();
    if (__VstlExecute) {
        Vfir___024root___eval_stl(vlSelf);
    }
    return (__VstlExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vfir___024root___dump_triggers__ico(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___dump_triggers__ico\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VicoTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VicoTriggered.word(0U))) {
        VL_DBG_MSGF("         'ico' region trigger index 0 is active: Internal 'ico' trigger - first iteration\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Vfir___024root___dump_triggers__act(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___dump_triggers__act\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VactTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 0 is active: @(posedge __Vcellinp__fir__ap_clk)\n");
    }
    if ((2ULL & vlSelfRef.__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 1 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Vfir___024root___dump_triggers__nba(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___dump_triggers__nba\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1U & (~ vlSelfRef.__VnbaTriggered.any()))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 0 is active: @(posedge __Vcellinp__fir__ap_clk)\n");
    }
    if ((2ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 1 is active: @([true] __VdlySched.awaitingCurrentTime())\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vfir___024root____Vm_traceActivitySetAll(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root____Vm_traceActivitySetAll\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    vlSelfRef.__Vm_traceActivity[0U] = 1U;
    vlSelfRef.__Vm_traceActivity[1U] = 1U;
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.__Vm_traceActivity[3U] = 1U;
    vlSelfRef.__Vm_traceActivity[4U] = 1U;
    vlSelfRef.__Vm_traceActivity[5U] = 1U;
    vlSelfRef.__Vm_traceActivity[6U] = 1U;
    vlSelfRef.__Vm_traceActivity[7U] = 1U;
}

VL_ATTR_COLD void Vfir___024root___ctor_var_reset(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___ctor_var_reset\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    const uint64_t __VscopeHash = VL_MURMUR64_HASH(vlSelf->name());
    vlSelf->__Vcellinp__fir__x = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 12171758164341277058ull);
    vlSelf->__Vcellinp__fir__ap_start = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3081493549082599264ull);
    vlSelf->__Vcellinp__fir__ap_rst = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 2703228815976790291ull);
    vlSelf->__Vcellinp__fir__ap_clk = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3713569604829646604ull);
    vlSelf->fir__DOT__ap_CS_fsm = VL_SCOPED_RAND_RESET_I(5, __VscopeHash, 15566023936434504496ull);
    vlSelf->fir__DOT__shift_reg_address0 = VL_SCOPED_RAND_RESET_I(3, __VscopeHash, 17334178098069580276ull);
    vlSelf->fir__DOT__shift_reg_ce0 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10709959999641223563ull);
    vlSelf->fir__DOT__shift_reg_q0 = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 6248023463686718709ull);
    vlSelf->fir__DOT__shift_reg_ce1 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9103210350584282276ull);
    vlSelf->fir__DOT__shift_reg_q1 = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 18174166539344445441ull);
    vlSelf->fir__DOT__x_read_reg_118 = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 14693506046652752071ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_ready = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4873248709918113836ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce0 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9555610087656875135ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_address1 = VL_SCOPED_RAND_RESET_I(3, __VscopeHash, 12231827553931809807ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_ready = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9589514868941327103ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_ce0 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 18412226584765799997ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 3801527828902394841ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8052958021637495605ull);
    vlSelf->fir__DOT__ap_NS_fsm = VL_SCOPED_RAND_RESET_I(5, __VscopeHash, 12013288822062085761ull);
    vlSelf->fir__DOT__ap_ce_reg = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15695904700544641975ull);
    for (int __Vi0 = 0; __Vi0 < 8; ++__Vi0) {
        vlSelf->fir__DOT__shift_reg_U__DOT__ram[__Vi0] = VL_SCOPED_RAND_RESET_I(8, __VscopeHash, 1997723730011958881ull);
    }
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7074207146270267760ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 6442435857018581553ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10218344990114948711ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_1_reg_137 = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 6481032260849913321ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__icmp_ln62_reg_145 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 4619037045885227941ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40 = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 552577326892367108ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_loop_init = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16819834627506470513ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1 = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 8959926006144976952ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_reg = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5238509001904673203ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_int = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5118108924503094849ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_NS_fsm = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1602399239887672623ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ce_reg = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 13671160146146302474ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT____VdfgRegularize_h8c07728a_0_7 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14352729039722674268ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 10293338067169349680ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7944347036855778153ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8158977582142195306ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 9343997942398414616ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12699150031072376604ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 127233568802982996ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 2811217183326291193ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_q0 = VL_SCOPED_RAND_RESET_I(6, __VscopeHash, 16111574454209236748ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 8153761912268943002ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156_pp0_iter1_reg = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15706776085169739675ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156_pp0_iter2_reg = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1888577136734079309ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36 = VL_SCOPED_RAND_RESET_I(16, __VscopeHash, 16590976928661772038ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_init = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 14306808207344242806ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter1_reg = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1200193810596880189ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter2_reg = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 15623918211731153388ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter3_reg = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 16241474353632216396ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40 = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 7165000749251930281ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i = VL_SCOPED_RAND_RESET_I(4, __VscopeHash, 6098425242714972165ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_reg = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 720645283665350455ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_int = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 5306239206076151959ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_NS_fsm = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 2543924992148596444ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_ce_reg = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 730115092809760222ull);
    for (int __Vi0 = 0; __Vi0 < 8; ++__Vi0) {
        vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[__Vi0] = VL_SCOPED_RAND_RESET_I(6, __VscopeHash, 7571351665606012342ull);
    }
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p = VL_SCOPED_RAND_RESET_Q(48, __VscopeHash, 1264212725458364041ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__m_reg = VL_SCOPED_RAND_RESET_Q(43, __VscopeHash, 4789532125140681560ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__a_reg = VL_SCOPED_RAND_RESET_I(25, __VscopeHash, 14450860673020728925ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__b_reg = VL_SCOPED_RAND_RESET_I(18, __VscopeHash, 18326913599567170585ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg = VL_SCOPED_RAND_RESET_Q(48, __VscopeHash, 16957250232307119901ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 7755984700268318532ull);
    vlSelf->fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 12745300770683258902ull);
    vlSelf->__Vtrigprevexpr___TOP____Vcellinp__fir__ap_clk__0 = VL_SCOPED_RAND_RESET_I(1, __VscopeHash, 1576356962827790132ull);
    for (int __Vi0 = 0; __Vi0 < 8; ++__Vi0) {
        vlSelf->__Vm_traceActivity[__Vi0] = 0;
    }
}
