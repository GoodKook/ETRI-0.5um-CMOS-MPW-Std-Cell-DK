// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vfir.h for the primary calling header

#ifndef VERILATED_VFIR___024ROOT_H_
#define VERILATED_VFIR___024ROOT_H_  // guard

#include "systemc"
#include "verilated_sc.h"
#include "verilated.h"
#include "verilated_timing.h"


class Vfir__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vfir___024root final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        CData/*0:0*/ __Vcellinp__fir__ap_clk;
        CData/*7:0*/ __Vcellinp__fir__x;
        CData/*0:0*/ __Vcellinp__fir__ap_start;
        CData/*0:0*/ __Vcellinp__fir__ap_rst;
        CData/*4:0*/ fir__DOT__ap_CS_fsm;
        CData/*2:0*/ fir__DOT__shift_reg_address0;
        CData/*0:0*/ fir__DOT__shift_reg_ce0;
        CData/*7:0*/ fir__DOT__shift_reg_q0;
        CData/*0:0*/ fir__DOT__shift_reg_ce1;
        CData/*7:0*/ fir__DOT__shift_reg_q1;
        CData/*7:0*/ fir__DOT__x_read_reg_118;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_ready;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce0;
        CData/*2:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_address1;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_ready;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_ce0;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg;
        CData/*4:0*/ fir__DOT__ap_NS_fsm;
        CData/*0:0*/ fir__DOT__ap_ce_reg;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int;
        CData/*3:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_1_reg_137;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__icmp_ln62_reg_145;
        CData/*3:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_loop_init;
        CData/*3:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_reg;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_int;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_NS_fsm;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ce_reg;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT____VdfgRegularize_h8c07728a_0_7;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4;
        CData/*5:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_q0;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156_pp0_iter1_reg;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156_pp0_iter2_reg;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_init;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter1_reg;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter2_reg;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter3_reg;
        CData/*3:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40;
        CData/*3:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_reg;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_int;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_NS_fsm;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_ce_reg;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int;
        CData/*0:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache;
        CData/*0:0*/ __VstlFirstIteration;
        CData/*0:0*/ __VicoFirstIteration;
        CData/*0:0*/ __Vtrigprevexpr___TOP____Vcellinp__fir__ap_clk__0;
        CData/*0:0*/ __VactContinue;
        SData/*15:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36;
        IData/*24:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__a_reg;
        IData/*17:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__b_reg;
        IData/*31:0*/ __VactIterCount;
    };
    struct {
        QData/*47:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p;
        QData/*42:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__m_reg;
        QData/*47:0*/ fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg;
        VlUnpacked<CData/*7:0*/, 8> fir__DOT__shift_reg_U__DOT__ram;
        VlUnpacked<CData/*5:0*/, 8> fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0;
        VlUnpacked<CData/*0:0*/, 8> __Vm_traceActivity;
    };
    sc_core::sc_in<bool> ap_clk;
    sc_core::sc_in<bool> ap_rst;
    sc_core::sc_in<bool> ap_start;
    sc_core::sc_out<bool> ap_done;
    sc_core::sc_out<bool> ap_idle;
    sc_core::sc_out<bool> ap_ready;
    sc_core::sc_out<sc_dt::sc_uint<8> > y;
    sc_core::sc_out<bool> y_ap_vld;
    sc_core::sc_in<sc_dt::sc_uint<8> > x;
    VlDelayScheduler __VdlySched;
    VlTriggerVec<1> __VstlTriggered;
    VlTriggerVec<1> __VicoTriggered;
    VlTriggerVec<2> __VactTriggered;
    VlTriggerVec<2> __VnbaTriggered;

    // INTERNAL VARIABLES
    Vfir__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vfir___024root(Vfir__Syms* symsp, const char* v__name);
    ~Vfir___024root();
    VL_UNCOPYABLE(Vfir___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
