// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vfir.h for the primary calling header

#include "Vfir__pch.h"
#include "Vfir___024root.h"

VL_ATTR_COLD void Vfir___024root___eval_initial__TOP(Vfir___024root* vlSelf);
VlCoroutine Vfir___024root___eval_initial__TOP__Vtiming__0(Vfir___024root* vlSelf);
VlCoroutine Vfir___024root___eval_initial__TOP__Vtiming__1(Vfir___024root* vlSelf);
VlCoroutine Vfir___024root___eval_initial__TOP__Vtiming__2(Vfir___024root* vlSelf);
VlCoroutine Vfir___024root___eval_initial__TOP__Vtiming__3(Vfir___024root* vlSelf);
VlCoroutine Vfir___024root___eval_initial__TOP__Vtiming__4(Vfir___024root* vlSelf);

void Vfir___024root___eval_initial(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_initial\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    Vfir___024root___eval_initial__TOP(vlSelf);
    vlSelfRef.__Vm_traceActivity[1U] = 1U;
    Vfir___024root___eval_initial__TOP__Vtiming__0(vlSelf);
    Vfir___024root___eval_initial__TOP__Vtiming__1(vlSelf);
    Vfir___024root___eval_initial__TOP__Vtiming__2(vlSelf);
    Vfir___024root___eval_initial__TOP__Vtiming__3(vlSelf);
    Vfir___024root___eval_initial__TOP__Vtiming__4(vlSelf);
}

VL_INLINE_OPT VlCoroutine Vfir___024root___eval_initial__TOP__Vtiming__0(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_initial__TOP__Vtiming__0\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir.v", 
                                         94);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.fir__DOT__ap_CS_fsm = 1U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir.v", 
                                         95);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg = 0U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir.v", 
                                         96);
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg = 0U;
    vlSelfRef.__Vm_traceActivity[2U] = 1U;
}

VL_INLINE_OPT VlCoroutine Vfir___024root___eval_initial__TOP__Vtiming__1(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_initial__TOP__Vtiming__1\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir_fir_Pipeline_SHIFTER_LOOP.v", 
                                         90);
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm = 1U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir_fir_Pipeline_SHIFTER_LOOP.v", 
                                         91);
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1 = 0U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir_fir_Pipeline_SHIFTER_LOOP.v", 
                                         92);
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40 = 0U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir_fir_Pipeline_SHIFTER_LOOP.v", 
                                         93);
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_reg = 0U;
}

VL_INLINE_OPT VlCoroutine Vfir___024root___eval_initial__TOP__Vtiming__2(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_initial__TOP__Vtiming__2\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir_flow_control_loop_pipe_sequential_init.v", 
                                         53);
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 1U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir_flow_control_loop_pipe_sequential_init.v", 
                                         54);
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 0U;
}

VL_INLINE_OPT VlCoroutine Vfir___024root___eval_initial__TOP__Vtiming__3(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_initial__TOP__Vtiming__3\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir_fir_Pipeline_MACC_LOOP.v", 
                                         90);
    vlSelfRef.__Vm_traceActivity[3U] = 1U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm = 1U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir_fir_Pipeline_MACC_LOOP.v", 
                                         91);
    vlSelfRef.__Vm_traceActivity[3U] = 1U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1 = 0U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir_fir_Pipeline_MACC_LOOP.v", 
                                         92);
    vlSelfRef.__Vm_traceActivity[3U] = 1U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2 = 0U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir_fir_Pipeline_MACC_LOOP.v", 
                                         93);
    vlSelfRef.__Vm_traceActivity[3U] = 1U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3 = 0U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir_fir_Pipeline_MACC_LOOP.v", 
                                         94);
    vlSelfRef.__Vm_traceActivity[3U] = 1U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4 = 0U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir_fir_Pipeline_MACC_LOOP.v", 
                                         95);
    vlSelfRef.__Vm_traceActivity[3U] = 1U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36 = 0U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir_fir_Pipeline_MACC_LOOP.v", 
                                         96);
    vlSelfRef.__Vm_traceActivity[3U] = 1U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40 = 0U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir_fir_Pipeline_MACC_LOOP.v", 
                                         97);
    vlSelfRef.__Vm_traceActivity[3U] = 1U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_reg = 0U;
    vlSelfRef.__Vm_traceActivity[3U] = 1U;
}

VL_INLINE_OPT VlCoroutine Vfir___024root___eval_initial__TOP__Vtiming__4(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_initial__TOP__Vtiming__4\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir_flow_control_loop_pipe_sequential_init.v", 
                                         53);
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 1U;
    co_await vlSelfRef.__VdlySched.delay(0ULL, nullptr, 
                                         "../fir/hls_component/syn/verilog/fir_flow_control_loop_pipe_sequential_init.v", 
                                         54);
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 0U;
}

void Vfir___024root___ico_sequent__TOP__0(Vfir___024root* vlSelf);

void Vfir___024root___eval_ico(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_ico\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VicoTriggered.word(0U))) {
        Vfir___024root___ico_sequent__TOP__0(vlSelf);
        vlSelfRef.__Vm_traceActivity[4U] = 1U;
    }
}

extern const VlUnpacked<CData/*4:0*/, 2048> Vfir__ConstPool__TABLE_h7a411543_0;

VL_INLINE_OPT void Vfir___024root___ico_sequent__TOP__0(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___ico_sequent__TOP__0\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    SData/*10:0*/ __Vtableidx1;
    __Vtableidx1 = 0;
    // Body
    VL_ASSIGN_ISI(1,vlSelfRef.__Vcellinp__fir__ap_clk, vlSelfRef.ap_clk);
    VL_ASSIGN_ISU(8,vlSelfRef.__Vcellinp__fir__x, vlSelfRef.x);
    VL_ASSIGN_ISI(1,vlSelfRef.__Vcellinp__fir__ap_rst, vlSelfRef.ap_rst);
    VL_ASSIGN_ISI(1,vlSelfRef.__Vcellinp__fir__ap_start, vlSelfRef.ap_start);
    VL_ASSIGN_SII(1,vlSelfRef.ap_idle, (1U & ((~ (IData)(vlSelfRef.__Vcellinp__fir__ap_start)) 
                                              & (IData)(vlSelfRef.fir__DOT__ap_CS_fsm))));
    __Vtableidx1 = ((((IData)(vlSelfRef.__Vcellinp__fir__ap_start) 
                      << 0xaU) | ((0x200U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                             << 9U)) 
                                  | (0x100U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                               << 7U)))) 
                    | ((((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_int) 
                         | ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg)) 
                            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache))) 
                        << 7U) | ((0x40U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                            << 3U)) 
                                  | ((((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_int) 
                                       | ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg)) 
                                          & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache))) 
                                      << 5U) | (IData)(vlSelfRef.fir__DOT__ap_CS_fsm)))));
    vlSelfRef.fir__DOT__ap_NS_fsm = Vfir__ConstPool__TABLE_h7a411543_0
        [__Vtableidx1];
}

void Vfir___024root___eval_triggers__ico(Vfir___024root* vlSelf);

bool Vfir___024root___eval_phase__ico(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_phase__ico\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VicoExecute;
    // Body
    Vfir___024root___eval_triggers__ico(vlSelf);
    __VicoExecute = vlSelfRef.__VicoTriggered.any();
    if (__VicoExecute) {
        Vfir___024root___eval_ico(vlSelf);
    }
    return (__VicoExecute);
}

void Vfir___024root___act_sequent__TOP__0(Vfir___024root* vlSelf);

void Vfir___024root___eval_act(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_act\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((2ULL & vlSelfRef.__VactTriggered.word(0U))) {
        Vfir___024root___act_sequent__TOP__0(vlSelf);
        vlSelfRef.__Vm_traceActivity[5U] = 1U;
    }
}

VL_INLINE_OPT void Vfir___024root___act_sequent__TOP__0(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___act_sequent__TOP__0\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    SData/*10:0*/ __Vtableidx1;
    __Vtableidx1 = 0;
    // Body
    VL_ASSIGN_SII(1,vlSelfRef.y_ap_vld, (1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                               >> 4U)));
    VL_ASSIGN_SUI(8,vlSelfRef.y, ((0x2af8U > (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36))
                                   ? 0xabU : (0xffU 
                                              & (((IData)(0x1508U) 
                                                  + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)) 
                                                 >> 6U))));
    VL_ASSIGN_SII(1,vlSelfRef.ap_ready, (1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                               >> 4U)));
    VL_ASSIGN_SII(1,vlSelfRef.ap_done, (1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                              >> 4U)));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_NS_fsm 
        = vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_NS_fsm 
        = vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm;
    VL_ASSIGN_SII(1,vlSelfRef.ap_idle, (1U & ((~ (IData)(vlSelfRef.__Vcellinp__fir__ap_start)) 
                                              & (IData)(vlSelfRef.fir__DOT__ap_CS_fsm))));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p 
        = (0xffffffffffffULL & (VL_EXTENDS_QQ(48,43, vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__m_reg) 
                                + (QData)((IData)((0xffffU 
                                                   & ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4)
                                                       ? (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg)
                                                       : (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)))))));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce0 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_ce0 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_int 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_reg) 
           | (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter3_reg));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_init 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_loop_init 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i 
        = (((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm) 
            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_init))
            ? 0U : (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40));
    if ((8U & (IData)(vlSelfRef.fir__DOT__ap_CS_fsm))) {
        vlSelfRef.fir__DOT__shift_reg_ce0 = vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_ce0;
        vlSelfRef.fir__DOT__shift_reg_address0 = (7U 
                                                  & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i));
    } else {
        vlSelfRef.fir__DOT__shift_reg_ce0 = (((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                              >> 1U) 
                                             & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce0));
        vlSelfRef.fir__DOT__shift_reg_address0 = (7U 
                                                  & ((2U 
                                                      & (IData)(vlSelfRef.fir__DOT__ap_CS_fsm))
                                                      ? (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_1_reg_137)
                                                      : 0U));
    }
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1 
        = (((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_loop_init) 
            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm))
            ? 7U : (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_ready 
        = ((8U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i)) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_ce0));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_address1 
        = (((~ ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1) 
                >> 3U)) & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int))
            ? ((0U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1))
                ? 0U : ((0U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1))
                         ? 0U : (7U & ((IData)(7U) 
                                       + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)))))
            : 0U);
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT____VdfgRegularize_h8c07728a_0_7 
        = (IData)((0U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_ready 
        = (((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1) 
            >> 3U) & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int));
    vlSelfRef.fir__DOT__shift_reg_ce1 = (((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                          >> 1U) & 
                                         ((((0U != (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)) 
                                            & (~ ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1) 
                                                  >> 3U))) 
                                           | (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT____VdfgRegularize_h8c07728a_0_7)) 
                                          & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int)));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_int 
        = (((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_ready) 
            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm)) 
           | (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_reg));
    __Vtableidx1 = ((((IData)(vlSelfRef.__Vcellinp__fir__ap_start) 
                      << 0xaU) | ((0x200U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                             << 9U)) 
                                  | (0x100U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                               << 7U)))) 
                    | ((((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_int) 
                         | ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg)) 
                            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache))) 
                        << 7U) | ((0x40U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                            << 3U)) 
                                  | ((((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_int) 
                                       | ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg)) 
                                          & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache))) 
                                      << 5U) | (IData)(vlSelfRef.fir__DOT__ap_CS_fsm)))));
    vlSelfRef.fir__DOT__ap_NS_fsm = Vfir__ConstPool__TABLE_h7a411543_0
        [__Vtableidx1];
}

void Vfir___024root___nba_sequent__TOP__0(Vfir___024root* vlSelf);
void Vfir___024root___nba_comb__TOP__0(Vfir___024root* vlSelf);

void Vfir___024root___eval_nba(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_nba\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((1ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        Vfir___024root___nba_sequent__TOP__0(vlSelf);
        vlSelfRef.__Vm_traceActivity[6U] = 1U;
    }
    if ((3ULL & vlSelfRef.__VnbaTriggered.word(0U))) {
        Vfir___024root___nba_comb__TOP__0(vlSelf);
        vlSelfRef.__Vm_traceActivity[7U] = 1U;
    }
}

VL_INLINE_OPT void Vfir___024root___nba_sequent__TOP__0(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___nba_sequent__TOP__0\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*4:0*/ __Vdly__fir__DOT__ap_CS_fsm;
    __Vdly__fir__DOT__ap_CS_fsm = 0;
    CData/*0:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg;
    __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg = 0;
    CData/*0:0*/ __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg;
    __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg = 0;
    CData/*0:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg;
    __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg = 0;
    CData/*0:0*/ __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg;
    __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg = 0;
    CData/*0:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm;
    __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm = 0;
    CData/*0:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_reg;
    __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_reg = 0;
    CData/*0:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1;
    __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1 = 0;
    CData/*0:0*/ __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1;
    __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1 = 0;
    CData/*3:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40;
    __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40 = 0;
    CData/*3:0*/ __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40;
    __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40 = 0;
    CData/*0:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int;
    __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 0;
    CData/*0:0*/ __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int;
    __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 0;
    CData/*0:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache;
    __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 0;
    CData/*0:0*/ __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache;
    __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 0;
    CData/*0:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm;
    __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm = 0;
    CData/*0:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_reg;
    __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_reg = 0;
    CData/*0:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1;
    __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1 = 0;
    CData/*0:0*/ __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1;
    __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1 = 0;
    CData/*0:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2;
    __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2 = 0;
    CData/*0:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3;
    __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3 = 0;
    CData/*0:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4;
    __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4 = 0;
    SData/*15:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36;
    __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36 = 0;
    SData/*15:0*/ __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36;
    __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36 = 0;
    CData/*3:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40;
    __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40 = 0;
    CData/*3:0*/ __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40;
    __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40 = 0;
    CData/*0:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int;
    __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 0;
    CData/*0:0*/ __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int;
    __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 0;
    CData/*0:0*/ __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache;
    __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 0;
    CData/*0:0*/ __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache;
    __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 0;
    CData/*7:0*/ __VdlyVal__fir__DOT__shift_reg_U__DOT__ram__v0;
    __VdlyVal__fir__DOT__shift_reg_U__DOT__ram__v0 = 0;
    CData/*2:0*/ __VdlyDim0__fir__DOT__shift_reg_U__DOT__ram__v0;
    __VdlyDim0__fir__DOT__shift_reg_U__DOT__ram__v0 = 0;
    CData/*0:0*/ __VdlySet__fir__DOT__shift_reg_U__DOT__ram__v0;
    __VdlySet__fir__DOT__shift_reg_U__DOT__ram__v0 = 0;
    CData/*7:0*/ __VdlyVal__fir__DOT__shift_reg_U__DOT__ram__v1;
    __VdlyVal__fir__DOT__shift_reg_U__DOT__ram__v1 = 0;
    CData/*2:0*/ __VdlyDim0__fir__DOT__shift_reg_U__DOT__ram__v1;
    __VdlyDim0__fir__DOT__shift_reg_U__DOT__ram__v1 = 0;
    CData/*0:0*/ __VdlySet__fir__DOT__shift_reg_U__DOT__ram__v1;
    __VdlySet__fir__DOT__shift_reg_U__DOT__ram__v1 = 0;
    // Body
    __VdlySet__fir__DOT__shift_reg_U__DOT__ram__v1 = 0U;
    __VdlySet__fir__DOT__shift_reg_U__DOT__ram__v0 = 0U;
    __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_reg = 0U;
    __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_reg = 0U;
    __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2 
        = ((1U & (~ (IData)(vlSelfRef.__Vcellinp__fir__ap_rst))) 
           && (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1));
    __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3 
        = ((1U & (~ (IData)(vlSelfRef.__Vcellinp__fir__ap_rst))) 
           && (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2));
    __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4 
        = ((1U & (~ (IData)(vlSelfRef.__Vcellinp__fir__ap_rst))) 
           && (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3));
    __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm 
        = ((IData)(vlSelfRef.__Vcellinp__fir__ap_rst) 
           || (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_NS_fsm));
    if (vlSelfRef.__Vcellinp__fir__ap_rst) {
        __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 1U;
        __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 1U;
        __Vdly__fir__DOT__ap_CS_fsm = 1U;
        __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 0U;
        __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 1U;
        __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1 = 0U;
        __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1 = 1U;
        __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg = 0U;
        __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg = 1U;
        __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 0U;
        __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 1U;
        __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 1U;
        __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 1U;
        __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1 = 0U;
        __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1 = 1U;
        __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg = 0U;
        __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg = 1U;
    } else {
        if (vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_int) {
            __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 1U;
            __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 1U;
            __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 1U;
            __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 1U;
        } else {
            if (vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_ce0) {
                __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 0U;
                __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 1U;
            }
            if (vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg) {
                __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 0U;
                __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 1U;
            }
        }
        __Vdly__fir__DOT__ap_CS_fsm = vlSelfRef.fir__DOT__ap_NS_fsm;
        if (vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_ready) {
            __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1 = 0U;
            __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1 = 1U;
        } else if (vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm) {
            __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1 
                = vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg;
            __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1 = 1U;
        }
        if ((4U & (IData)(vlSelfRef.fir__DOT__ap_CS_fsm))) {
            __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg = 1U;
            __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg = 1U;
        } else if (vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_ready) {
            __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg = 0U;
            __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg = 1U;
        }
        if (vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_int) {
            __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 1U;
            __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 1U;
            __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 1U;
            __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 1U;
        } else {
            if (vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg) {
                __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 0U;
                __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 1U;
            }
            if (vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int) {
                __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 0U;
                __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 1U;
            }
        }
        if (vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_ready) {
            __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1 = 0U;
            __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1 = 1U;
        } else if (vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm) {
            __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1 
                = vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg;
            __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1 = 1U;
        }
        if (((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
             & (IData)(vlSelfRef.__Vcellinp__fir__ap_start))) {
            __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg = 1U;
            __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg = 1U;
        } else if (vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_ready) {
            __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg = 0U;
            __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg = 1U;
        }
    }
    if (((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm) 
         & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_init))) {
        __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36 = 0U;
        __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36 = 0xffffU;
    } else if (vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4) {
        __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36 
            = (0xffffU & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg));
        __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36 = 0xffffU;
    }
    __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm 
        = ((IData)(vlSelfRef.__Vcellinp__fir__ap_rst) 
           || (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_NS_fsm));
    if (vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm) {
        if (((~ ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1) 
                 >> 3U)) & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg))) {
            __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40 
                = (0xfU & ((IData)(0xfU) + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)));
            __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40 = 0xfU;
        } else if (vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_loop_init) {
            __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40 = 7U;
            __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40 = 0xfU;
        }
        vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_1_reg_137 
            = vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1;
    }
    if (vlSelfRef.fir__DOT__shift_reg_ce0) {
        if ((((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
              >> 1U) & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__icmp_ln62_reg_145)) 
                        & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce0)))) {
            __VdlyVal__fir__DOT__shift_reg_U__DOT__ram__v0 
                = vlSelfRef.fir__DOT__shift_reg_q1;
            __VdlyDim0__fir__DOT__shift_reg_U__DOT__ram__v0 
                = vlSelfRef.fir__DOT__shift_reg_address0;
            __VdlySet__fir__DOT__shift_reg_U__DOT__ram__v0 = 1U;
        }
    }
    if (vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm) {
        vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__icmp_ln62_reg_145 
            = (0U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1));
    }
    if (vlSelfRef.fir__DOT__shift_reg_ce1) {
        if ((((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
              >> 1U) & ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT____VdfgRegularize_h8c07728a_0_7) 
                        & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int)))) {
            __VdlyVal__fir__DOT__shift_reg_U__DOT__ram__v1 
                = vlSelfRef.fir__DOT__x_read_reg_118;
            __VdlyDim0__fir__DOT__shift_reg_U__DOT__ram__v1 
                = vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_address1;
            __VdlySet__fir__DOT__shift_reg_U__DOT__ram__v1 = 1U;
        }
        vlSelfRef.fir__DOT__shift_reg_q1 = vlSelfRef.fir__DOT__shift_reg_U__DOT__ram
            [vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_address1];
    }
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_reg 
        = __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_reg;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_reg 
        = __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_reg;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2 
        = __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3 
        = __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int 
        = (((IData)(__Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int) 
            & (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int)) 
           | ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int) 
              & (~ (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int))));
    __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 0U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache 
        = (((IData)(__Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache) 
            & (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache)) 
           | ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache) 
              & (~ (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache))));
    __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 0U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1 
        = (((IData)(__Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1) 
            & (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1)) 
           | ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1) 
              & (~ (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1))));
    __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1 = 0U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4 
        = __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36 
        = (((IData)(__Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36) 
            & (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)) 
           | ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36) 
              & (~ (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36))));
    __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36 = 0U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__m_reg 
        = (0x7ffffffffffULL & VL_MULS_QQQ(43, (0x7ffffffffffULL 
                                               & VL_EXTENDS_QI(43,25, vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__a_reg)), 
                                          (0x7ffffffffffULL 
                                           & VL_EXTENDS_QI(43,18, vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__b_reg))));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156_pp0_iter2_reg 
        = vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156_pp0_iter1_reg;
    if (vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm) {
        if (((8U != (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i)) 
             & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg))) {
            __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40 
                = (0xfU & ((IData)(1U) + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i)));
            __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40 = 0xfU;
        } else if (vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_init) {
            __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40 = 0U;
            __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40 = 0xfU;
        }
    }
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40 
        = (((IData)(__Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40) 
            & (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40)) 
           | ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40) 
              & (~ (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40))));
    __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40 = 0U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter3_reg 
        = vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter2_reg;
    if (vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm) {
        vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156_pp0_iter1_reg 
            = vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156;
        vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter2_reg 
            = vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter1_reg;
        vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156 
            = (8U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i));
        vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter1_reg 
            = vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_ready;
    }
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg 
        = (((IData)(__Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg) 
            & (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg)) 
           | ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg) 
              & (~ (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg))));
    __VdlyMask__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg = 0U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache 
        = (((IData)(__Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache) 
            & (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache)) 
           | ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache) 
              & (~ (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache))));
    __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache = 0U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int 
        = (((IData)(__Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int) 
            & (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int)) 
           | ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int) 
              & (~ (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int))));
    __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int = 0U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1 
        = (((IData)(__Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1) 
            & (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1)) 
           | ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1) 
              & (~ (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1))));
    __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1 = 0U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40 
        = (((IData)(__Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40) 
            & (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40)) 
           | ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40) 
              & (~ (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40))));
    __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40 = 0U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg 
        = (((IData)(__Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg) 
            & (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg)) 
           | ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg) 
              & (~ (IData)(__VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg))));
    __VdlyMask__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg = 0U;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg 
        = vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p;
    if ((1U & (IData)(vlSelfRef.fir__DOT__ap_CS_fsm))) {
        vlSelfRef.fir__DOT__x_read_reg_118 = vlSelfRef.__Vcellinp__fir__x;
    }
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__a_reg 
        = vlSelfRef.fir__DOT__shift_reg_q0;
    if (vlSelfRef.fir__DOT__shift_reg_ce0) {
        vlSelfRef.fir__DOT__shift_reg_q0 = vlSelfRef.fir__DOT__shift_reg_U__DOT__ram
            [vlSelfRef.fir__DOT__shift_reg_address0];
    }
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__b_reg 
        = vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_q0;
    vlSelfRef.fir__DOT__ap_CS_fsm = __Vdly__fir__DOT__ap_CS_fsm;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm 
        = __Vdly__fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm;
    if (vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_ce0) {
        vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_q0 
            = vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0
            [(7U & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i))];
    }
    if (__VdlySet__fir__DOT__shift_reg_U__DOT__ram__v0) {
        vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[__VdlyDim0__fir__DOT__shift_reg_U__DOT__ram__v0] 
            = __VdlyVal__fir__DOT__shift_reg_U__DOT__ram__v0;
    }
    if (__VdlySet__fir__DOT__shift_reg_U__DOT__ram__v1) {
        vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[__VdlyDim0__fir__DOT__shift_reg_U__DOT__ram__v1] 
            = __VdlyVal__fir__DOT__shift_reg_U__DOT__ram__v1;
    }
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm 
        = __Vdly__fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm;
}

VL_INLINE_OPT void Vfir___024root___nba_comb__TOP__0(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___nba_comb__TOP__0\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    SData/*10:0*/ __Vtableidx1;
    __Vtableidx1 = 0;
    // Body
    VL_ASSIGN_SUI(8,vlSelfRef.y, ((0x2af8U > (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36))
                                   ? 0xabU : (0xffU 
                                              & (((IData)(0x1508U) 
                                                  + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)) 
                                                 >> 6U))));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_init 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_loop_init 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_int 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_reg) 
           | (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter3_reg));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p 
        = (0xffffffffffffULL & (VL_EXTENDS_QQ(48,43, vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__m_reg) 
                                + (QData)((IData)((0xffffU 
                                                   & ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4)
                                                       ? (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg)
                                                       : (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)))))));
    VL_ASSIGN_SII(1,vlSelfRef.y_ap_vld, (1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                               >> 4U)));
    VL_ASSIGN_SII(1,vlSelfRef.ap_ready, (1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                               >> 4U)));
    VL_ASSIGN_SII(1,vlSelfRef.ap_done, (1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                              >> 4U)));
    VL_ASSIGN_SII(1,vlSelfRef.ap_idle, (1U & ((~ (IData)(vlSelfRef.__Vcellinp__fir__ap_start)) 
                                              & (IData)(vlSelfRef.fir__DOT__ap_CS_fsm))));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_NS_fsm 
        = vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce0 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_NS_fsm 
        = vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm;
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_ce0 
        = ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i 
        = (((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm) 
            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_init))
            ? 0U : (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1 
        = (((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_loop_init) 
            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm))
            ? 7U : (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40));
    if ((8U & (IData)(vlSelfRef.fir__DOT__ap_CS_fsm))) {
        vlSelfRef.fir__DOT__shift_reg_ce0 = vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_ce0;
        vlSelfRef.fir__DOT__shift_reg_address0 = (7U 
                                                  & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i));
    } else {
        vlSelfRef.fir__DOT__shift_reg_ce0 = (((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                              >> 1U) 
                                             & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce0));
        vlSelfRef.fir__DOT__shift_reg_address0 = (7U 
                                                  & ((2U 
                                                      & (IData)(vlSelfRef.fir__DOT__ap_CS_fsm))
                                                      ? (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_1_reg_137)
                                                      : 0U));
    }
    vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_ready 
        = ((8U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i)) 
           & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_ce0));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_address1 
        = (((~ ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1) 
                >> 3U)) & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int))
            ? ((0U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1))
                ? 0U : ((0U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1))
                         ? 0U : (7U & ((IData)(7U) 
                                       + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)))))
            : 0U);
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT____VdfgRegularize_h8c07728a_0_7 
        = (IData)((0U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_ready 
        = (((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1) 
            >> 3U) & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int));
    vlSelfRef.fir__DOT__shift_reg_ce1 = (((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                          >> 1U) & 
                                         ((((0U != (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)) 
                                            & (~ ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1) 
                                                  >> 3U))) 
                                           | (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT____VdfgRegularize_h8c07728a_0_7)) 
                                          & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int)));
    vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_int 
        = (((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_ready) 
            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm)) 
           | (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_reg));
    __Vtableidx1 = ((((IData)(vlSelfRef.__Vcellinp__fir__ap_start) 
                      << 0xaU) | ((0x200U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                             << 9U)) 
                                  | (0x100U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                               << 7U)))) 
                    | ((((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_int) 
                         | ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg)) 
                            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache))) 
                        << 7U) | ((0x40U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                            << 3U)) 
                                  | ((((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_int) 
                                       | ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg)) 
                                          & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache))) 
                                      << 5U) | (IData)(vlSelfRef.fir__DOT__ap_CS_fsm)))));
    vlSelfRef.fir__DOT__ap_NS_fsm = Vfir__ConstPool__TABLE_h7a411543_0
        [__Vtableidx1];
}

void Vfir___024root___timing_resume(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___timing_resume\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Body
    if ((2ULL & vlSelfRef.__VactTriggered.word(0U))) {
        vlSelfRef.__VdlySched.resume();
    }
}

void Vfir___024root___eval_triggers__act(Vfir___024root* vlSelf);

bool Vfir___024root___eval_phase__act(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_phase__act\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    VlTriggerVec<2> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    Vfir___024root___eval_triggers__act(vlSelf);
    __VactExecute = vlSelfRef.__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelfRef.__VactTriggered, vlSelfRef.__VnbaTriggered);
        vlSelfRef.__VnbaTriggered.thisOr(vlSelfRef.__VactTriggered);
        Vfir___024root___timing_resume(vlSelf);
        Vfir___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vfir___024root___eval_phase__nba(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_phase__nba\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelfRef.__VnbaTriggered.any();
    if (__VnbaExecute) {
        Vfir___024root___eval_nba(vlSelf);
        vlSelfRef.__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vfir___024root___dump_triggers__ico(Vfir___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vfir___024root___dump_triggers__nba(Vfir___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vfir___024root___dump_triggers__act(Vfir___024root* vlSelf);
#endif  // VL_DEBUG

void Vfir___024root___eval(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    IData/*31:0*/ __VicoIterCount;
    CData/*0:0*/ __VicoContinue;
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VicoIterCount = 0U;
    vlSelfRef.__VicoFirstIteration = 1U;
    __VicoContinue = 1U;
    while (__VicoContinue) {
        if (VL_UNLIKELY(((0x64U < __VicoIterCount)))) {
#ifdef VL_DEBUG
            Vfir___024root___dump_triggers__ico(vlSelf);
#endif
            VL_FATAL_MT("../fir/hls_component/syn/verilog/fir.v", 11, "", "Input combinational region did not converge.");
        }
        __VicoIterCount = ((IData)(1U) + __VicoIterCount);
        __VicoContinue = 0U;
        if (Vfir___024root___eval_phase__ico(vlSelf)) {
            __VicoContinue = 1U;
        }
        vlSelfRef.__VicoFirstIteration = 0U;
    }
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY(((0x64U < __VnbaIterCount)))) {
#ifdef VL_DEBUG
            Vfir___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("../fir/hls_component/syn/verilog/fir.v", 11, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelfRef.__VactIterCount = 0U;
        vlSelfRef.__VactContinue = 1U;
        while (vlSelfRef.__VactContinue) {
            if (VL_UNLIKELY(((0x64U < vlSelfRef.__VactIterCount)))) {
#ifdef VL_DEBUG
                Vfir___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("../fir/hls_component/syn/verilog/fir.v", 11, "", "Active region did not converge.");
            }
            vlSelfRef.__VactIterCount = ((IData)(1U) 
                                         + vlSelfRef.__VactIterCount);
            vlSelfRef.__VactContinue = 0U;
            if (Vfir___024root___eval_phase__act(vlSelf)) {
                vlSelfRef.__VactContinue = 1U;
            }
        }
        if (Vfir___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void Vfir___024root___eval_debug_assertions(Vfir___024root* vlSelf) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root___eval_debug_assertions\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
}
#endif  // VL_DEBUG
