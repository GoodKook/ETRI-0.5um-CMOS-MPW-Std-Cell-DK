// Verilated -*- SystemC -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_vcd_sc.h"
#include "Vfir__Syms.h"


void Vfir___024root__trace_chg_0_sub_0(Vfir___024root* vlSelf, VerilatedVcd::Buffer* bufp);

void Vfir___024root__trace_chg_0(void* voidSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root__trace_chg_0\n"); );
    // Init
    Vfir___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vfir___024root*>(voidSelf);
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    if (VL_UNLIKELY(!vlSymsp->__Vm_activity)) return;
    // Body
    Vfir___024root__trace_chg_0_sub_0((&vlSymsp->TOP), bufp);
}

void Vfir___024root__trace_chg_0_sub_0(Vfir___024root* vlSelf, VerilatedVcd::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root__trace_chg_0_sub_0\n"); );
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    auto& vlSelfRef = std::ref(*vlSelf).get();
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode + 1);
    // Body
    if (VL_UNLIKELY((vlSelfRef.__Vm_traceActivity[1U]))) {
        bufp->chgCData(oldp+0,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[0]),6);
        bufp->chgCData(oldp+1,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[1]),6);
        bufp->chgCData(oldp+2,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[2]),6);
        bufp->chgCData(oldp+3,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[3]),6);
        bufp->chgCData(oldp+4,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[4]),6);
        bufp->chgCData(oldp+5,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[5]),6);
        bufp->chgCData(oldp+6,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[6]),6);
        bufp->chgCData(oldp+7,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_U__DOT__rom0[7]),6);
    }
    if (VL_UNLIKELY((((vlSelfRef.__Vm_traceActivity
                       [1U] | vlSelfRef.__Vm_traceActivity
                       [2U]) | vlSelfRef.__Vm_traceActivity
                      [6U])))) {
        bufp->chgBit(oldp+8,((1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                    >> 4U))));
        bufp->chgCData(oldp+9,(vlSelfRef.fir__DOT__ap_CS_fsm),5);
        bufp->chgBit(oldp+10,((1U & (IData)(vlSelfRef.fir__DOT__ap_CS_fsm))));
        bufp->chgBit(oldp+11,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg));
        bufp->chgBit(oldp+12,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg));
        bufp->chgBit(oldp+13,((1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                     >> 1U))));
        bufp->chgBit(oldp+14,((1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                     >> 2U))));
        bufp->chgBit(oldp+15,((1U & ((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                                     >> 3U))));
    }
    if (VL_UNLIKELY((((vlSelfRef.__Vm_traceActivity
                       [1U] | vlSelfRef.__Vm_traceActivity
                       [3U]) | vlSelfRef.__Vm_traceActivity
                      [6U])))) {
        bufp->chgCData(oldp+16,(((0x2af8U > (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36))
                                  ? 0xabU : (0xffU 
                                             & (((IData)(0x1508U) 
                                                 + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)) 
                                                >> 6U)))),8);
        bufp->chgSData(oldp+17,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36),16);
        bufp->chgSData(oldp+18,((0x3fffU & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36))),14);
        bufp->chgSData(oldp+19,((0x3fffU & ((IData)(0x1508U) 
                                            + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)))),14);
        bufp->chgBit(oldp+20,((0x2af8U > (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36))));
        bufp->chgCData(oldp+21,((0xffU & (((IData)(0x1508U) 
                                           + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)) 
                                          >> 6U))),8);
        bufp->chgBit(oldp+22,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm));
        bufp->chgBit(oldp+23,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1));
        bufp->chgBit(oldp+24,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2));
        bufp->chgBit(oldp+25,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3));
        bufp->chgBit(oldp+26,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4));
        bufp->chgSData(oldp+27,((0xffffU & ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4)
                                             ? (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg)
                                             : (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)))),16);
        bufp->chgCData(oldp+28,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__i_1_fu_40),4);
        bufp->chgBit(oldp+29,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_reg));
        bufp->chgQData(oldp+30,((QData)((IData)((0xffffU 
                                                 & ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4)
                                                     ? (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg)
                                                     : (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)))))),48);
        bufp->chgQData(oldp+32,((0xffffffffffffULL 
                                 & (VL_EXTENDS_QQ(48,43, vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__m_reg) 
                                    + (QData)((IData)(
                                                      (0xffffU 
                                                       & ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4)
                                                           ? (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg)
                                                           : (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__acc_fu_36)))))))),48);
    }
    if (VL_UNLIKELY(((vlSelfRef.__Vm_traceActivity[1U] 
                      | vlSelfRef.__Vm_traceActivity
                      [6U])))) {
        bufp->chgCData(oldp+34,(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[0]),8);
        bufp->chgCData(oldp+35,(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[1]),8);
        bufp->chgCData(oldp+36,(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[2]),8);
        bufp->chgCData(oldp+37,(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[3]),8);
        bufp->chgCData(oldp+38,(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[4]),8);
        bufp->chgCData(oldp+39,(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[5]),8);
        bufp->chgCData(oldp+40,(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[6]),8);
        bufp->chgCData(oldp+41,(vlSelfRef.fir__DOT__shift_reg_U__DOT__ram[7]),8);
    }
    if (VL_UNLIKELY((vlSelfRef.__Vm_traceActivity[4U]))) {
        bufp->chgBit(oldp+42,(vlSelfRef.__Vcellinp__fir__ap_clk));
        bufp->chgBit(oldp+43,(vlSelfRef.__Vcellinp__fir__ap_rst));
        bufp->chgBit(oldp+44,(vlSelfRef.__Vcellinp__fir__ap_start));
        bufp->chgCData(oldp+45,(vlSelfRef.__Vcellinp__fir__x),8);
        bufp->chgBit(oldp+46,((1U & (~ (IData)(vlSelfRef.__Vcellinp__fir__ap_start)))));
    }
    if (VL_UNLIKELY(((vlSelfRef.__Vm_traceActivity[5U] 
                      | vlSelfRef.__Vm_traceActivity
                      [7U])))) {
        bufp->chgCData(oldp+47,(vlSelfRef.fir__DOT__shift_reg_address0),3);
        bufp->chgBit(oldp+48,(vlSelfRef.fir__DOT__shift_reg_ce0));
        bufp->chgBit(oldp+49,(vlSelfRef.fir__DOT__shift_reg_ce1));
        bufp->chgBit(oldp+50,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_ready));
        bufp->chgBit(oldp+51,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce0));
        bufp->chgCData(oldp+52,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_address1),3);
        bufp->chgBit(oldp+53,(((((0U != (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)) 
                                 & (~ ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1) 
                                       >> 3U))) | (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT____VdfgRegularize_h8c07728a_0_7)) 
                               & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int))));
        bufp->chgBit(oldp+54,(((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT____VdfgRegularize_h8c07728a_0_7) 
                               & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int))));
        bufp->chgBit(oldp+55,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_ready));
        bufp->chgCData(oldp+56,((7U & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i))),3);
        bufp->chgBit(oldp+57,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_shift_reg_ce0));
        bufp->chgBit(oldp+58,((8U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i))));
        bufp->chgQData(oldp+59,((QData)((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i))),64);
        bufp->chgBit(oldp+61,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_init));
        bufp->chgCData(oldp+62,((0xfU & ((IData)(1U) 
                                         + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i)))),4);
        bufp->chgCData(oldp+63,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_sig_allocacmp_i),4);
        bufp->chgBit(oldp+64,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_int));
        bufp->chgBit(oldp+65,((1U & ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1) 
                                     >> 3U))));
        bufp->chgBit(oldp+66,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int));
        bufp->chgBit(oldp+67,((0U == (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1))));
        bufp->chgQData(oldp+68,((QData)((IData)((7U 
                                                 & ((IData)(7U) 
                                                    + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)))))),64);
        bufp->chgCData(oldp+70,((0xfU & ((IData)(0xfU) 
                                         + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)))),4);
        bufp->chgBit(oldp+71,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_loop_init));
        bufp->chgCData(oldp+72,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1),4);
        bufp->chgCData(oldp+73,((7U & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1))),3);
        bufp->chgCData(oldp+74,((7U & ((IData)(7U) 
                                       + (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1)))),3);
        bufp->chgBit(oldp+75,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_int));
        bufp->chgBit(oldp+76,(((~ ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_sig_allocacmp_i_1) 
                                   >> 3U)) & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int))));
    }
    if (VL_UNLIKELY((vlSelfRef.__Vm_traceActivity[6U]))) {
        bufp->chgCData(oldp+77,(vlSelfRef.fir__DOT__shift_reg_q0),8);
        bufp->chgCData(oldp+78,(vlSelfRef.fir__DOT__shift_reg_q1),8);
        bufp->chgCData(oldp+79,(vlSelfRef.fir__DOT__x_read_reg_118),8);
        bufp->chgCData(oldp+80,((7U & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_1_reg_137))),3);
        bufp->chgBit(oldp+81,(((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter3_reg) 
                               & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156_pp0_iter2_reg))));
        bufp->chgCData(oldp+82,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_q0),6);
        bufp->chgBit(oldp+83,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156));
        bufp->chgBit(oldp+84,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156_pp0_iter1_reg));
        bufp->chgBit(oldp+85,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__icmp_ln70_reg_156_pp0_iter2_reg));
        bufp->chgSData(oldp+86,((0xffffU & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg))),16);
        bufp->chgBit(oldp+87,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter1_reg));
        bufp->chgBit(oldp+88,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter2_reg));
        bufp->chgBit(oldp+89,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_loop_exit_ready_pp0_iter3_reg));
        bufp->chgSData(oldp+90,(vlSelfRef.fir__DOT__shift_reg_q0),14);
        bufp->chgSData(oldp+91,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_q0),14);
        bufp->chgIData(oldp+92,(vlSelfRef.fir__DOT__shift_reg_q0),25);
        bufp->chgIData(oldp+93,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__filter_taps_q0),18);
        bufp->chgQData(oldp+94,((0x7ffffffffffULL & 
                                 VL_MULS_QQQ(43, (0x7ffffffffffULL 
                                                  & VL_EXTENDS_QI(43,25, vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__a_reg)), 
                                             (0x7ffffffffffULL 
                                              & VL_EXTENDS_QI(43,18, vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__b_reg))))),43);
        bufp->chgQData(oldp+96,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__m_reg),43);
        bufp->chgIData(oldp+98,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__a_reg),25);
        bufp->chgIData(oldp+99,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__b_reg),18);
        bufp->chgQData(oldp+100,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__mac_muladd_8ns_6ns_16ns_16_4_1_U3__DOT__fir_mac_muladd_8ns_6ns_16ns_16_4_1_DSP48_0_U__DOT__p_reg),48);
        bufp->chgCData(oldp+102,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_1_reg_137),4);
        bufp->chgBit(oldp+103,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__icmp_ln62_reg_145));
        bufp->chgQData(oldp+104,((QData)((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_1_reg_137))),64);
    }
    bufp->chgBit(oldp+106,((1U & ((~ (IData)(vlSelfRef.__Vcellinp__fir__ap_start)) 
                                  & (IData)(vlSelfRef.fir__DOT__ap_CS_fsm)))));
    bufp->chgBit(oldp+107,((((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                             >> 1U) & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__icmp_ln62_reg_145)) 
                                       & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce0)))));
    bufp->chgBit(oldp+108,((((IData)(vlSelfRef.fir__DOT__ap_CS_fsm) 
                             >> 1U) & ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT____VdfgRegularize_h8c07728a_0_7) 
                                       & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_ready_int)))));
    bufp->chgBit(oldp+109,(((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_int) 
                            | ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg)) 
                               & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache)))));
    bufp->chgBit(oldp+110,((((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1)) 
                             & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg))) 
                            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm))));
    bufp->chgBit(oldp+111,(((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__icmp_ln62_reg_145)) 
                            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_shift_reg_ce0))));
    bufp->chgBit(oldp+112,(((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_int) 
                            | ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg)) 
                               & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache)))));
    bufp->chgBit(oldp+113,(((((((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4)) 
                                & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3))) 
                               & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2))) 
                              & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1))) 
                             & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg))) 
                            & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_CS_fsm))));
    bufp->chgCData(oldp+114,(vlSelfRef.fir__DOT__ap_NS_fsm),5);
    bufp->chgBit(oldp+115,((1U & (~ ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_int) 
                                     | ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg)) 
                                        & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache)))))));
    bufp->chgBit(oldp+116,((1U & (~ ((IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_done_int) 
                                     | ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg)) 
                                        & (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache)))))));
    bufp->chgBit(oldp+117,((1U & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4)) 
                                  & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3)) 
                                     & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2)) 
                                        & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1)) 
                                           & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg)))))))));
    bufp->chgBit(oldp+118,((1U & (~ ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter4)) 
                                     & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter3)) 
                                        & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter2)) 
                                           & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__ap_enable_reg_pp0_iter1)) 
                                              & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71_ap_start_reg))))))))));
    bufp->chgBit(oldp+119,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int));
    bufp->chgBit(oldp+120,(vlSelfRef.fir__DOT__grp_fir_Pipeline_MACC_LOOP_fu_71__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache));
    bufp->chgBit(oldp+121,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_CS_fsm));
    bufp->chgBit(oldp+122,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1));
    bufp->chgBit(oldp+123,((1U & ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1)) 
                                  & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg))))));
    bufp->chgCData(oldp+124,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__i_fu_40),4);
    bufp->chgBit(oldp+125,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_done_reg));
    bufp->chgBit(oldp+126,((1U & (~ ((~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__ap_enable_reg_pp0_iter1)) 
                                     & (~ (IData)(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63_ap_start_reg)))))));
    bufp->chgBit(oldp+127,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_loop_init_int));
    bufp->chgBit(oldp+128,(vlSelfRef.fir__DOT__grp_fir_Pipeline_SHIFTER_LOOP_fu_63__DOT__flow_control_loop_pipe_sequential_init_U__DOT__ap_done_cache));
}

void Vfir___024root__trace_cleanup(void* voidSelf, VerilatedVcd* /*unused*/) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vfir___024root__trace_cleanup\n"); );
    // Init
    Vfir___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vfir___024root*>(voidSelf);
    Vfir__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    vlSymsp->__Vm_activity = false;
    vlSymsp->TOP.__Vm_traceActivity[0U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[1U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[2U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[3U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[4U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[5U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[6U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[7U] = 0U;
}
