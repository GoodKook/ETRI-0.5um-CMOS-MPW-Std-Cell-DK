/* timing routines */
extern float CPUTime(void);
extern float ElapsedCPUTime(float since);
