#ifndef _TECH_H
#define _TECH_H

extern int ActelLibPresent(void);
extern void ActelLib(void);
extern void VerilogTop(char *name, int fnum, char *filename);

#endif /* _TECH_H */
