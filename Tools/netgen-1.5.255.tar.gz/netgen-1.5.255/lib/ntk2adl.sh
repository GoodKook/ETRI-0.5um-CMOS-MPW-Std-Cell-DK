#!/bin/csh
echo ntk2adl $1 $2
netgen A K $1 a $2
