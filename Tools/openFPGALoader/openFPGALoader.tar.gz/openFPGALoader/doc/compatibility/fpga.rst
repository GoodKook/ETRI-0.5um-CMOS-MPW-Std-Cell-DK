.. _compatibility:fpgas:

FPGAs
#####

.. include:: fpga.inc

* IF: Internal Flash
* AS: Active Serial flash mode
* NA: Not Available
* NT: Not Tested
