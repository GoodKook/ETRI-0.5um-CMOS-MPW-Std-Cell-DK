# DueFreeRTOS

FreeRTOS port for the Arduino Due (AT91SAM3X8E) to be used in combination with Arduino IDE.

Based on FreeRTOS 10.1.1 and the [FreeRTOS-Arduino](https://github.com/greiman/FreeRTOS-Arduino) port.