#!/bin/bash

#Create 2023.3.15                                            #
#Author fzq                                                  #
#Describe:                                                   #
#This script is used to change the permissions of the cable  #
#device in the system of linux                               #
#                                                            #
#                                                            #
# History:                                                   #                                                          
# 2023.3.27                                                  #
# Add function tips:                                         #
# 1.Exit with non root privileges                            #
# 2.If a file with the same name exists, change the name to+1#
#                                                            #
# 2023.3.29                                                  #
# Add function tips:                                         #
# 1.Delete ftdi_sio when ftdi cable accesses                 #
#                                                            #
# 2023.4.13                                                  #
# Add function tips:                                         #
# 1.Reload udev                                              #
# 2.Adding shutdown script                                   #
# 3.Modify the overall script layout                         #
# 4.Remove Shutdown Service                                  #
# 5.Remove Gowin_USB_Cable_Udevreload.sh                     #
# 6.Adding Reboot in Centos6 System                          #
#                                                            #
# 2023.4.17                                                  #
# Add function tips:                                         #
# 1.Delete gwscript                                          #
#                                                            #
# 2023.5.8                                                   #
# Add function tips:                                         #
# 1.Adding device  privileges ,which pid is 6010             #
# 2.Deleting system judgment                                 #
#                                                            #
# 2023.5.11                                                  #
# Add function tips:                                         #
# 1.Prompt for modifying system permissions                  #


#Get target address                                          #
DST=/etc/udev/rules.d

#Add restart udev rule file                                  #
function add_rules {
   if [ ! -d "$DST" ];then
     echo "this system is not applicable to udev"
     return 2
   fi
# Determine whether it is exist 50-programmer_usb.rules
   DST_DOC=/etc/udev/rules.d/50-programmer_usb.rules

   if [ -f "$DST_DOC" ];then
      index=51
      DST_DOC_AFTER=$"/etc/udev/rules.d/"$index$"-programmer_usb.rules"
      while  [ -f "$DST_DOC_AFTER" ]; do
	      index=$[$index+1] 
         DST_DOC_AFTER=$"/etc/udev/rules.d/"$index$"-programmer_usb.rules"
      done
   mv $DST_DOC $DST_DOC_AFTER
   fi 

#Get source address                                          #
   SRC=$( cd "$(dirname "${BASH_SOURCE[0]}")" && pwd);

#Copy the rule file to the specified locationet              #
   cp $SRC/50-programmer_usb.rules $DST

   return 0
}

#Complete different operations based on different systems    #
function system_operation {

   if [ -f "/etc/redhat-release" ]; then
      
#Determine system model
      length=$(cat /etc/redhat-release | awk '{print NF}')
      length=$((length - 1))
  
      system=$(cat /etc/redhat-release | awk '{print $'"$length"'}')

      first_char=${system:0:1}
#Perform operations based on the system
      case "$first_char" in
         "7")
            
         ;;
         "6")
            if zenity --question --title="warning" --text="Do you want to restart the system?"; then
               reboot
            else
               echo "Please restart the system later to complete the setup"
            fi
         ;;
      esac
   fi
}

# Determine whether it is root
if [ "$UID" != "0" ];then
	echo "This script must be executed with root-level privileges. Please run as root user or run with sudo"
	exit 1
fi 

# Copy the rule file to udev
add_rules
code=$?
if [ ! code=0 ];then
   exit code
fi
#

echo "If the rule does not take effect,please restart the system later to complete the setup"
echo "completed !"

exit 0

