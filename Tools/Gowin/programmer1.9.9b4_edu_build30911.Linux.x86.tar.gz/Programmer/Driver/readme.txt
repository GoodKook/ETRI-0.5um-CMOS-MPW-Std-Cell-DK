

Note:
* 50-programmer_usb.rules is a USB access rule file
* Gowin_USB_Cable_Installer.sh is a Linux script file is used to installation
* Makefile is a Linux compiled file


Installation:
* Run Gowin_USB_Cable_Installer.sh with root privileges, as follows:   
     $sudo bash Gowin_USB_Cable_Installer.sh 
* Run make with root privileges in the current directory, as follows.
     $sudo make
 
warning:
*After the system restarts, there will be a brief lag phenomenon when inserting the FTDI device 