#!/bin/tcsh -f
#-------------------------------------------
# qflow variables for project ~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO
#-------------------------------------------

set qflowversion=1.4.100
set projectpath=~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO
set techdir=/usr/local/share/qflow/tech/etri050
set sourcedir=~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO/source
set synthdir=~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO
set layoutdir=~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO/layout
set techname=etri050
set scriptdir=/usr/local/share/qflow/scripts
set bindir=/usr/local/share/qflow/bin
set logdir=~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO/log
#-------------------------------------------

