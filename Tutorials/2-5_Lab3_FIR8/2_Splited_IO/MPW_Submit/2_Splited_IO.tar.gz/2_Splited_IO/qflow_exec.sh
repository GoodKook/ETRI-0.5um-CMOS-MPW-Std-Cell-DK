#!/bin/tcsh -f
#-------------------------------------------
# qflow exec script for project ~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO
#-------------------------------------------

# /usr/local/share/qflow/scripts/yosys.sh ~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO fir_pe ~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO/source/fir_pe.v || exit 1
# /usr/local/share/qflow/scripts/graywolf.sh -d ~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO fir_pe || exit 1
# /usr/local/share/qflow/scripts/vesta.sh  ~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO fir_pe || exit 1
# /usr/local/share/qflow/scripts/qrouter.sh ~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO fir_pe || exit 1
# /usr/local/share/qflow/scripts/vesta.sh  -d ~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO fir_pe || exit 1
# /usr/local/share/qflow/scripts/magic_db.sh ~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO fir_pe || exit 1
# /usr/local/share/qflow/scripts/magic_drc.sh ~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO fir_pe || exit 1
/usr/local/share/qflow/scripts/netgen_lvs.sh ~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO fir_pe || exit 1
# /usr/local/share/qflow/scripts/magic_gds.sh ~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO fir_pe || exit 1
# /usr/local/share/qflow/scripts/cleanup.sh ~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO fir_pe || exit 1
# /usr/local/share/qflow/scripts/cleanup.sh -p ~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO fir_pe || exit 1
# /usr/local/share/qflow/scripts/magic_view.sh ~/workspace/MPW/ETRI-0.5um-CMOS-MPW-Std-Cell-DK/design/example/ETRI-0.5u-CMOS-MPW-DK-Example--FIR8/2_Splited_IO fir_pe || exit 1
